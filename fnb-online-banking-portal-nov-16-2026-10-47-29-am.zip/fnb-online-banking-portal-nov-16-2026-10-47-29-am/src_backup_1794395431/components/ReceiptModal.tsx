import React, { useState, useEffect } from 'react';
import { Transaction } from '../types.ts';
import { 
  X, 
  Printer, 
  Download, 
  CheckCircle2, 
  RotateCcw, 
  Clock, 
  ShieldAlert, 
  ArrowUpRight,
  Sparkles,
  Building2,
  Share2
} from 'lucide-react';
import { TransactionTagBadge } from './TransactionTagBadge.tsx';
import { tagTransaction } from '../utils/transactionTagger.ts';
import { api } from '../services/api.ts';

interface ReceiptModalProps {
  transaction: Transaction | null;
  onClose: () => void;
  onReversalSuccess?: () => void;
}

export const ReceiptModal: React.FC<ReceiptModalProps> = ({ 
  transaction, 
  onClose,
  onReversalSuccess 
}) => {
  const [isReversing, setIsReversing] = useState(false);
  const [reversalMessage, setReversalMessage] = useState<string | null>(null);
  const [timeLeft, setTimeLeft] = useState<string>('');

  useEffect(() => {
    if (!transaction?.scheduledReversalAt || transaction.isReversed) {
      return;
    }

    const updateTimer = () => {
      const remainingMs = Math.max(0, (transaction.scheduledReversalAt || 0) - Date.now());
      if (remainingMs <= 0) {
        setTimeLeft('Reversing now...');
        return;
      }
      const minutes = Math.floor(remainingMs / 60000);
      const seconds = Math.floor((remainingMs % 60000) / 1000);
      setTimeLeft(`${minutes}m ${seconds.toString().padStart(2, '0')}s`);
    };

    updateTimer();
    const interval = setInterval(updateTimer, 1000);
    return () => clearInterval(interval);
  }, [transaction]);

  if (!transaction) return null;

  const handleFastForwardReversal = async () => {
    try {
      setIsReversing(true);
      const res = await api.fastForwardReversal(transaction.id);
      setReversalMessage(res.message);
      if (onReversalSuccess) {
        onReversalSuccess();
      }
    } catch (err: any) {
      alert(err.message || 'Reversal failed');
    } finally {
      setIsReversing(false);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-sm animate-fade-in print:p-0 print:bg-white">
      <div className="relative w-full max-w-lg bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col max-h-[92vh]">
        
        {/* Top Watermark / Sandbox Disclaimer */}
        <div className="bg-amber-500 text-slate-950 font-bold text-[11px] uppercase tracking-wider py-1.5 px-4 text-center flex items-center justify-center gap-2">
          <ShieldAlert className="w-4 h-4" />
          <span>SIMULATED TRANSACTION RECEIPT • SANDBOX DEMONSTRATION</span>
        </div>

        {/* Header */}
        <div className="p-6 pb-4 border-b border-slate-100 dark:border-slate-800 flex items-start justify-between">
          <div className="flex items-center gap-3">
            <img 
              src="/assets/aistudio/file_00000000763081f4a6c9438dcd4940cf_665e4923.png" 
              alt="FNB Logo" 
              className="w-12 h-12 object-contain rounded-xl shadow-sm"
            />
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold text-xl tracking-tight text-[#002752] dark:text-white">
                  FIRST NATIONAL BANK
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Official Transaction Electronic Voucher
              </p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors print:hidden"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Receipt Body */}
        <div className="p-6 space-y-5 overflow-y-auto flex-1">
          
          {/* Status & Amount Highlight */}
          <div className="text-center py-4 bg-slate-50 dark:bg-slate-950 rounded-2xl border border-slate-200/80 dark:border-slate-800">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400 rounded-full text-xs font-semibold mb-2">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>Payment Successful (Simulated)</span>
            </div>
            
            <div className="text-3xl sm:text-4xl font-extrabold tracking-tight text-[#002752] dark:text-white">
              {transaction.currency}{Number(transaction.amount).toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              {transaction.description || 'Electronic Funds Transfer'}
            </p>
          </div>

          {/* Key Details Table */}
          <div className="space-y-3 text-xs sm:text-sm">
            <div className="flex justify-between py-2 border-b border-slate-100 dark:border-slate-800">
              <span className="text-slate-500 dark:text-slate-400">Transaction Reference</span>
              <span className="font-mono font-bold text-slate-900 dark:text-white">
                {transaction.reference}
              </span>
            </div>

            <div className="flex justify-between py-2 border-b border-slate-100 dark:border-slate-800">
              <span className="text-slate-500 dark:text-slate-400">Transaction Date & Time</span>
              <span className="font-medium text-slate-800 dark:text-slate-200">
                {new Date(transaction.createdAt).toLocaleString()}
              </span>
            </div>

            <div className="flex justify-between py-2 border-b border-slate-100 dark:border-slate-800 items-center">
              <span className="text-slate-500 dark:text-slate-400">Category Tag</span>
              <TransactionTagBadge 
                tag={transaction.tag || tagTransaction(transaction.description, transaction.type, transaction.billerCategory).tag} 
                showIcon 
                size="md"
              />
            </div>

            {transaction.beneficiaryName && (
              <div className="flex justify-between py-2 border-b border-slate-100 dark:border-slate-800">
                <span className="text-slate-500 dark:text-slate-400">Beneficiary Name</span>
                <span className="font-semibold text-slate-900 dark:text-white">
                  {transaction.beneficiaryName}
                </span>
              </div>
            )}

            {transaction.beneficiaryBank && (
              <div className="flex justify-between py-2 border-b border-slate-100 dark:border-slate-800">
                <span className="text-slate-500 dark:text-slate-400">Beneficiary Bank</span>
                <span className="font-medium text-slate-800 dark:text-slate-200">
                  {transaction.beneficiaryBank}
                </span>
              </div>
            )}

            {transaction.beneficiaryAccount && (
              <div className="flex justify-between py-2 border-b border-slate-100 dark:border-slate-800">
                <span className="text-slate-500 dark:text-slate-400">Destination Account / IBAN</span>
                <span className="font-mono font-medium text-slate-800 dark:text-slate-200">
                  {transaction.beneficiaryAccount}
                </span>
              </div>
            )}

            {transaction.withdrawalMethod && (
              <div className="flex justify-between py-2 border-b border-slate-100 dark:border-slate-800">
                <span className="text-slate-500 dark:text-slate-400">Withdrawal Method</span>
                <span className="font-semibold text-slate-900 dark:text-white">
                  {transaction.withdrawalMethod}
                </span>
              </div>
            )}

            <div className="flex justify-between py-2 border-b border-slate-100 dark:border-slate-800">
              <span className="text-slate-500 dark:text-slate-400">Sender Account</span>
              <span className="font-mono text-slate-800 dark:text-slate-200">
                {transaction.accountNumber || 'Primary Checking'}
              </span>
            </div>

            <div className="flex justify-between py-2">
              <span className="text-slate-500 dark:text-slate-400">Sort Code</span>
              <span className="font-mono font-semibold text-slate-800 dark:text-slate-200">
                20-04-15
              </span>
            </div>
          </div>

          {/* Automated Reversal Workflow Panel */}
          {transaction.type === 'transfer' && (
            <div className="p-4 rounded-2xl bg-blue-50/70 dark:bg-blue-950/40 border border-blue-200/80 dark:border-blue-900 text-xs">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-1.5 font-bold text-blue-900 dark:text-blue-300">
                  <RotateCcw className="w-4 h-4 text-blue-600 dark:text-blue-400 animate-spin-slow" />
                  <span>Automated 30-Min Reversal Protocol</span>
                </div>
                {transaction.isReversed ? (
                  <span className="px-2 py-0.5 bg-emerald-600 text-white font-bold rounded text-[10px]">
                    REVERSED & REFUNDED
                  </span>
                ) : (
                  <span className="flex items-center gap-1 font-mono font-bold text-blue-700 dark:text-blue-300">
                    <Clock className="w-3.5 h-3.5" />
                    {timeLeft || '30:00'}
                  </span>
                )}
              </div>

              <p className="text-slate-600 dark:text-slate-400 leading-relaxed mb-3">
                In this sandbox demonstration, transfers are scheduled to automatically refund to your account balance after 30 minutes, producing an official credit reversal entry and email notification.
              </p>

              {!transaction.isReversed && !reversalMessage && (
                <button
                  onClick={handleFastForwardReversal}
                  disabled={isReversing}
                  className="w-full py-2 px-3 bg-[#002752] hover:bg-[#001f42] text-white font-semibold rounded-xl flex items-center justify-center gap-2 shadow-sm transition-all"
                >
                  <RotateCcw className={`w-3.5 h-3.5 ${isReversing ? 'animate-spin' : ''}`} />
                  <span>{isReversing ? 'Processing Reversal...' : 'Process Instant Reversal (Simulation)'}</span>
                </button>
              )}

              {reversalMessage && (
                <div className="p-2.5 bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 rounded-lg font-medium text-center">
                  ✓ {reversalMessage}
                </div>
              )}
            </div>
          )}

          {/* Official Bank Signoff */}
          <div className="text-[11px] text-slate-400 text-center space-y-1 pt-2">
            <p>FIRST NATIONAL BANK (FNB) • AUTHORISED FINANCIAL INSTITUTION</p>
            <p>Tel: +447723165577 | WhatsApp: +447723165577 | info@fnnbbankss.online</p>
          </div>
        </div>

        {/* Modal Actions */}
        <div className="p-4 bg-slate-50 dark:bg-slate-950 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3 print:hidden">
          <button
            onClick={handlePrint}
            className="px-4 py-2 bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 rounded-xl text-xs font-semibold flex items-center gap-2 transition-colors"
          >
            <Printer className="w-4 h-4" />
            <span>Print Receipt</span>
          </button>

          <button
            onClick={onClose}
            className="px-6 py-2 bg-[#c8102e] hover:bg-[#b00d27] text-white rounded-xl text-xs font-bold transition-all shadow-md"
          >
            Done
          </button>
        </div>

      </div>
    </div>
  );
};
