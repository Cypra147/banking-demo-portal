import React from 'react';
import { Phone, Mail, MessageCircle, ShieldCheck, Lock, ExternalLink, Shield } from 'lucide-react';

interface FooterProps {
  onNavigate: (page: string) => void;
  onOpenCustomerAuth: () => void;
  onNavigateAdmin: () => void;
}

export const Footer: React.FC<FooterProps> = ({ 
  onNavigate, 
  onOpenCustomerAuth, 
  onNavigateAdmin 
}) => {
  return (
    <footer className="bg-[#001f42] text-slate-300 pt-16 pb-12 border-t border-blue-900/40">
      <div className="max-w-7xl mx-auto px-4 sm:px-8">
        
        {/* Main Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 pb-12 border-b border-blue-900/50">
          
          {/* Column 1: Brand & Contact Info */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-3">
              <img
                src="/assets/aistudio/file_00000000763081f4a6c9438dcd4940cf_665e4923.png"
                alt="FNB"
                className="w-12 h-12 object-contain rounded-xl bg-white p-1"
              />
              <div>
                <span className="text-2xl font-black text-white tracking-tight">FIRST NATIONAL BANK</span>
                <p className="text-xs text-red-400 font-semibold uppercase tracking-wider">
                  Safe • Simple • For You
                </p>
              </div>
            </div>

            <p className="text-sm text-slate-400 leading-relaxed pr-6">
              First National Bank (FNB) delivers resilient personal banking, corporate financing, secure electronic transfers, high-yield investment portfolios, and digital account management.
            </p>

            <div className="pt-2 space-y-2.5 text-xs text-slate-300">
              <div className="flex items-center gap-2.5">
                <Phone className="w-4 h-4 text-red-400" />
                <span>Telephone Helpline: </span>
                <a href="tel:+447723165577" className="font-semibold text-white hover:underline">+447723165577</a>
              </div>

              <div className="flex items-center gap-2.5">
                <MessageCircle className="w-4 h-4 text-emerald-400" />
                <span>WhatsApp Instant Support: </span>
                <a href="https://wa.me/447723165577" target="_blank" rel="noopener noreferrer" className="font-semibold text-white hover:underline">+447723165577</a>
              </div>

              <div className="flex items-center gap-2.5">
                <Mail className="w-4 h-4 text-blue-300" />
                <span>Official Inquiries: </span>
                <a href="mailto:info@fnnbbankss.online" className="font-semibold text-white hover:underline">info@fnnbbankss.online</a>
              </div>
            </div>
          </div>

          {/* Column 2: Navigation & Services */}
          <div>
            <h4 className="text-white font-bold text-sm mb-4 tracking-wider uppercase">
              Banking Services
            </h4>
            <ul className="space-y-2.5 text-xs text-slate-400">
              <li><button onClick={() => onNavigate('about')} className="hover:text-white transition-colors">About First National Bank</button></li>
              <li><button onClick={() => onNavigate('services')} className="hover:text-white transition-colors">Services & Accounts</button></li>
              <li><button onClick={() => onNavigate('investments')} className="hover:text-white transition-colors">Investment Portfolios</button></li>
              <li><button onClick={() => onNavigate('verification')} className="hover:text-white transition-colors">Tier-1 Verification (KYC)</button></li>
              <li><button onClick={() => onNavigate('transactions')} className="hover:text-white transition-colors">Transactions & Reversals</button></li>
            </ul>
          </div>

          {/* Column 3: Legal & Regulatory */}
          <div>
            <h4 className="text-white font-bold text-sm mb-4 tracking-wider uppercase">
              Legal & Support
            </h4>
            <ul className="space-y-2.5 text-xs text-slate-400">
              <li><button onClick={() => onNavigate('privacy')} className="hover:text-white transition-colors">Privacy Policy</button></li>
              <li><button onClick={() => onNavigate('terms')} className="hover:text-white transition-colors">Terms & Conditions</button></li>
              <li><button onClick={() => onNavigate('security')} className="hover:text-white transition-colors">Security Centre</button></li>
              <li><button onClick={() => onNavigate('faq')} className="hover:text-white transition-colors">Frequently Asked Questions</button></li>
              <li><button onClick={() => onNavigate('support')} className="hover:text-white transition-colors">Contact Client Relations</button></li>
            </ul>
          </div>

          {/* Column 4: Portal Access & Admin */}
          <div className="space-y-4">
            <h4 className="text-white font-bold text-sm mb-4 tracking-wider uppercase">
              Portal Access
            </h4>
            <div className="space-y-3 text-xs">
              <button
                onClick={onOpenCustomerAuth}
                className="w-full text-left py-2.5 px-3.5 rounded-xl bg-white/10 hover:bg-white/15 text-white font-semibold transition-colors border border-white/10 flex items-center justify-between"
              >
                <span>Customer Banking Portal</span>
                <span className="text-xs text-slate-400">Sign In →</span>
              </button>
            </div>

            <div className="p-3 bg-blue-950/40 rounded-xl border border-blue-900/60 text-[11px] text-slate-400 leading-relaxed">
              Branch: Canary Wharf, London, E14 5AB • Sort Code: 20-04-15
            </div>
          </div>

        </div>

        {/* Regulatory Disclosure & Copyright */}
        <div className="pt-8 flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-slate-400">
          <p>© {new Date().getFullYear()} First National Bank (FNB). All rights reserved.</p>

          <div className="flex items-center gap-2 text-center md:text-right">
            <ShieldCheck className="w-4 h-4 text-amber-400 shrink-0" />
            <span className="text-[11px] text-slate-400">
              Simulated Digital Banking & Educational Demonstration Platform
            </span>
          </div>
        </div>

      </div>
    </footer>
  );
};
