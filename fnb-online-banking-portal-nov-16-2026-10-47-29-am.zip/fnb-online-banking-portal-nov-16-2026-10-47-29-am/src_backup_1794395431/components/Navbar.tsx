import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext.tsx';
import { useLanguage } from '../context/LanguageContext.tsx';
import { LanguageToggle } from './LanguageToggle.tsx';
import { 
  Phone, 
  Mail, 
  MessageCircle, 
  Shield, 
  LogOut, 
  LayoutDashboard, 
  Sun, 
  Moon, 
  Bell, 
  Menu, 
  X,
  ArrowRight,
  TrendingUp,
  FileCheck2,
  History,
  HelpCircle,
  Building2,
  Layers
} from 'lucide-react';

interface NavbarProps {
  currentPage: string;
  onNavigate: (page: string) => void;
  onOpenAuth: (mode: 'login' | 'register') => void;
}

export const Navbar: React.FC<NavbarProps> = ({ 
  currentPage, 
  onNavigate, 
  onOpenAuth 
}) => {
  const { 
    user, 
    logout, 
    theme, 
    toggleTheme, 
    unreadEmailCount, 
    setIsMailModalOpen 
  } = useAuth();
  
  const { t } = useLanguage();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { id: 'home', label: t('nav.home', 'Home') },
    { id: 'about', label: t('nav.about', 'About Us') },
    { id: 'services', label: t('nav.services', 'Services') },
    { id: 'investments', label: t('nav.investments', 'Investments') },
    { id: 'verification', label: t('nav.verification', 'Verification') },
    { id: 'transactions', label: t('nav.transactions', 'Transactions') },
    { id: 'support', label: t('nav.support', 'Support') },
  ];

  const handleLinkClick = (pageId: string) => {
    onNavigate(pageId);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 w-full bg-white dark:bg-slate-900 shadow-sm border-b border-slate-200 dark:border-slate-800 transition-colors">
      
      {/* Top Corporate Strip */}
      <div className="bg-[#002752] text-slate-200 text-xs py-2 px-4 sm:px-8 border-b border-blue-900/40">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
          
          {/* Contact coordinates */}
          <div className="flex flex-wrap items-center gap-4 sm:gap-6">
            <a 
              href="tel:+447723165577" 
              className="flex items-center gap-1.5 hover:text-white transition-colors"
            >
              <Phone className="w-3.5 h-3.5 text-red-400" />
              <span>+447723165577</span>
            </a>

            <a 
              href="https://wa.me/447723165577" 
              target="_blank" 
              rel="noopener noreferrer" 
              className="flex items-center gap-1.5 hover:text-white transition-colors"
            >
              <MessageCircle className="w-3.5 h-3.5 text-emerald-400" />
              <span>WhatsApp Support</span>
            </a>

            <a 
              href="mailto:info@fnnbbankss.online" 
              className="hidden sm:flex items-center gap-1.5 hover:text-white transition-colors"
            >
              <Mail className="w-3.5 h-3.5 text-blue-300" />
              <span>info@fnnbbankss.online</span>
            </a>
          </div>

          <div className="hidden sm:flex items-center gap-3 text-[11px] text-slate-300">
            <span>24/7 Telephone Helpline & Electronic Banking</span>
          </div>

        </div>
      </div>

      {/* Main Navbar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-8 py-3.5 flex items-center justify-between gap-4">
        
        {/* Brand Logo */}
        <button
          onClick={() => handleLinkClick('home')}
          className="flex items-center gap-3 text-left focus:outline-none group shrink-0"
        >
          <img
            src="/assets/aistudio/file_00000000763081f4a6c9438dcd4940cf_665e4923.png"
            alt="FNB Logo"
            className="w-10 h-10 sm:w-11 sm:h-11 object-contain rounded-xl shadow-sm group-hover:scale-105 transition-transform"
          />
          <div>
            <div className="flex items-center">
              <span className="text-2xl font-black tracking-tight text-[#002752] dark:text-white">
                FNB
              </span>
              <span className="ml-1 text-xs font-bold text-[#c8102e] tracking-widest uppercase">
                ONLINE
              </span>
            </div>
            <p className="text-[10px] text-slate-500 dark:text-slate-400 tracking-wider font-semibold uppercase -mt-1">
              FIRST NATIONAL BANK
            </p>
          </div>
        </button>

        {/* Desktop Navigation Links */}
        <nav className="hidden xl:flex items-center gap-6 text-xs sm:text-sm font-semibold text-slate-700 dark:text-slate-200">
          {navLinks.map(link => {
            const isActive = currentPage === link.id;
            return (
              <button 
                key={link.id}
                onClick={() => handleLinkClick(link.id)}
                className={`hover:text-[#c8102e] transition-colors py-1 ${
                  isActive ? 'text-[#c8102e] font-bold border-b-2 border-[#c8102e]' : ''
                }`}
              >
                {link.label}
              </button>
            );
          })}
        </nav>

        {/* Actions & Session Controls */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          
          {/* Live Notification / Mail Center Icon */}
          <button
            onClick={() => setIsMailModalOpen(true)}
            className="relative p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            title="Notification & Communications Center"
          >
            <Bell className="w-5 h-5 text-slate-700 dark:text-slate-300" />
            {unreadEmailCount > 0 && (
              <span className="absolute top-1 right-1 w-5 h-5 bg-[#c8102e] text-white text-[10px] font-extrabold rounded-full flex items-center justify-center">
                {unreadEmailCount}
              </span>
            )}
          </button>

          {/* Language Toggle Component */}
          <LanguageToggle variant="navbar" />

          {/* Theme Toggle Button */}
          <button
            onClick={toggleTheme}
            className="hidden sm:flex p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            title={theme === 'dark' ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
          >
            {theme === 'dark' ? <Sun className="w-5 h-5 text-amber-400" /> : <Moon className="w-5 h-5 text-slate-700" />}
          </button>

          {/* User Logged In state */}
          {user ? (
            <div className="flex items-center gap-2">
              <button
                onClick={() => handleLinkClick('dashboard')}
                className={`py-2 px-3.5 rounded-xl font-bold text-xs flex items-center gap-2 shadow-sm transition-all ${
                  currentPage === 'dashboard'
                    ? 'bg-[#002752] text-white'
                    : 'bg-blue-50 dark:bg-blue-950 text-[#002752] dark:text-blue-300 hover:bg-blue-100'
                }`}
              >
                <LayoutDashboard className="w-4 h-4" />
                <span className="hidden sm:inline">{t('nav.myDashboard', 'My Dashboard')}</span>
              </button>

              <button
                onClick={logout}
                className="p-2 rounded-xl text-slate-500 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-950/40 transition-colors"
                title="Log Out of Customer Portal"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <button
                onClick={() => onOpenAuth('login')}
                className="px-3.5 py-2 text-xs font-bold text-[#002752] dark:text-white hover:text-[#c8102e] transition-colors"
              >
                {t('nav.signIn', 'Sign In')}
              </button>

              <button
                onClick={() => onOpenAuth('register')}
                className="px-4 py-2 bg-[#c8102e] hover:bg-[#a50d26] text-white font-bold rounded-xl text-xs shadow-md transition-all flex items-center gap-1.5"
              >
                <span>{t('nav.register', 'Register')}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          {/* Mobile Menu Button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="xl:hidden p-2 rounded-xl text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            aria-label="Toggle Navigation Menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>

        </div>
      </div>

      {/* Mobile Slide-down Navigation Menu */}
      {mobileMenuOpen && (
        <div className="xl:hidden bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 px-4 py-4 space-y-3 shadow-xl">
          <div className="flex flex-col space-y-2 text-sm font-semibold">
            {navLinks.map(link => (
              <button
                key={link.id}
                onClick={() => handleLinkClick(link.id)}
                className={`text-left py-2 px-3 rounded-xl transition-colors ${
                  currentPage === link.id
                    ? 'bg-blue-50 dark:bg-blue-950/50 text-[#002752] dark:text-blue-400 font-bold'
                    : 'text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                {link.label}
              </button>
            ))}

            {user && (
              <button
                onClick={() => handleLinkClick('dashboard')}
                className="text-left py-2 px-3 rounded-xl bg-[#002752] text-white font-bold flex items-center justify-between"
              >
                <span>{t('nav.myDashboard', 'My Customer Dashboard')}</span>
                <LayoutDashboard className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Mobile Language Selector */}
          <LanguageToggle variant="mobile" />

          <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs text-slate-500">
            <span>Telephone: +447723165577</span>
            <button
              onClick={toggleTheme}
              className="px-2 py-1 bg-slate-100 dark:bg-slate-800 rounded-lg text-slate-700 dark:text-slate-300 font-semibold"
            >
              {theme === 'dark' ? 'Light Theme' : 'Dark Theme'}
            </button>
          </div>
        </div>
      )}

    </header>
  );
};
