import React, { useState } from 'react';
import { INVESTMENT_PLANS } from '../constants/investments.ts';
import { InvestmentPlan } from '../types.ts';
import { 
  TrendingUp, 
  ShieldCheck, 
  Leaf, 
  Cpu, 
  Calculator, 
  ArrowRight, 
  Check, 
  AlertCircle, 
  Sparkles,
  Info
} from 'lucide-react';

interface InvestmentsPageProps {
  onOpenAuth: (mode?: 'login' | 'register') => void;
  onNavigate: (page: string) => void;
  isAuthenticated: boolean;
}

export const InvestmentsPage: React.FC<InvestmentsPageProps> = ({ 
  onOpenAuth, 
  onNavigate,
  isAuthenticated 
}) => {
  const [selectedPlanId, setSelectedPlanId] = useState<string>('plan-bluechip-dividends');
  const [calcAmount, setCalcAmount] = useState<number>(5000);
  const [calcDuration, setCalcDuration] = useState<number>(12);

  const selectedPlan = INVESTMENT_PLANS.find(p => p.id === selectedPlanId) || INVESTMENT_PLANS[0];

  // Calculation of simulated projected returns
  const returnRate = selectedPlan.annualReturnRate;
  const projectedReturn = Number(((calcAmount * (returnRate / 100) * (calcDuration / 12))).toFixed(2));
  const totalMaturity = Number((calcAmount + projectedReturn).toFixed(2));

  const getPlanIcon = (planId: string) => {
    switch (planId) {
      case 'plan-fixed-income': return ShieldCheck;
      case 'plan-bluechip-dividends': return TrendingUp;
      case 'plan-green-energy': return Leaf;
      case 'plan-tech-growth': return Cpu;
      default: return TrendingUp;
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 pb-20">
      
      {/* Hero Header */}
      <section className="bg-gradient-to-r from-[#001833] via-[#002752] to-[#003875] text-white py-16 px-4 sm:px-6 lg:px-8 border-b border-blue-900/50">
        <div className="max-w-6xl mx-auto">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-red-600/20 border border-red-500/30 text-red-300 text-xs font-semibold mb-4">
            <Sparkles className="w-4 h-4 text-red-400" />
            <span>Simulated Wealth & Portfolio Management</span>
          </div>
          <h1 className="text-3xl sm:text-5xl font-black tracking-tight leading-tight max-w-3xl">
            Institutional Wealth Strategies, Engineered for Precision.
          </h1>
          <p className="mt-4 text-base sm:text-lg text-slate-300 max-w-2xl leading-relaxed">
            Explore FNB's curated range of simulated investment portfolios with transparent return models, low-volatility sovereign bonds, and high-growth technology equities.
          </p>
        </div>
      </section>

      {/* Simulator Disclosure Banner */}
      <div className="max-w-6xl mx-auto px-4 -mt-6">
        <div className="bg-amber-50 dark:bg-amber-950/40 border border-amber-300/80 dark:border-amber-700/60 rounded-2xl p-4 sm:p-5 text-xs sm:text-sm text-amber-900 dark:text-amber-200 flex items-start gap-3 shadow-sm">
          <AlertCircle className="w-5 h-5 text-amber-700 dark:text-amber-400 shrink-0 mt-0.5" />
          <div className="leading-relaxed">
            <strong className="font-bold block text-sm mb-0.5">Simulated Financial Projection Notice</strong>
            All investment yields, projected returns, compounding ledgers, and portfolio percentages displayed on this website are illustrative simulations designed strictly for platform demonstration purposes.
          </div>
        </div>
      </div>

      {/* Interactive Returns Calculator */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 mt-14">
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 sm:p-10 shadow-lg">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 rounded-xl bg-[#002752] text-white flex items-center justify-center">
              <Calculator className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white">
                Simulated Projected Return Calculator
              </h2>
              <p className="text-xs text-slate-500">
                Adjust the plan, allocation capital, and tenure to estimate your simulated yield.
              </p>
            </div>
          </div>

          <div className="grid lg:grid-cols-12 gap-8 items-center">
            
            {/* Inputs Column */}
            <div className="lg:col-span-7 space-y-6">
              
              {/* Plan Picker */}
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-2">
                  Select Investment Strategy
                </label>
                <div className="grid sm:grid-cols-2 gap-3">
                  {INVESTMENT_PLANS.map((plan) => {
                    const isSelected = plan.id === selectedPlanId;
                    const Icon = getPlanIcon(plan.id);
                    return (
                      <button
                        key={plan.id}
                        type="button"
                        onClick={() => {
                          setSelectedPlanId(plan.id);
                          if (calcAmount < plan.minimumAmount) setCalcAmount(plan.minimumAmount);
                        }}
                        className={`p-3.5 rounded-2xl border text-left transition-all ${
                          isSelected
                            ? 'border-[#002752] dark:border-blue-500 bg-blue-50/50 dark:bg-blue-950/40 ring-2 ring-[#002752]/20'
                            : 'border-slate-200 dark:border-slate-800 hover:border-slate-300'
                        }`}
                      >
                        <div className="flex items-center justify-between mb-1.5">
                          <Icon className={`w-4 h-4 ${isSelected ? 'text-[#002752] dark:text-blue-400' : 'text-slate-400'}`} />
                          <span className="text-xs font-black text-emerald-600 dark:text-emerald-400">
                            +{plan.annualReturnRate}% p.a.
                          </span>
                        </div>
                        <h4 className="font-bold text-xs text-slate-900 dark:text-white leading-tight">
                          {plan.name.replace(' (Simulated)', '')}
                        </h4>
                        <span className="text-[10px] text-slate-500 mt-1 block">
                          Min: £{plan.minimumAmount.toLocaleString()}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Capital Amount Slider & Input */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider">
                    Allocation Amount (£)
                  </label>
                  <span className="text-sm font-black text-[#002752] dark:text-blue-400">
                    £{calcAmount.toLocaleString()}
                  </span>
                </div>
                <input
                  type="range"
                  min={selectedPlan.minimumAmount}
                  max={Math.min(selectedPlan.maximumAmount, 100000)}
                  step={500}
                  value={calcAmount}
                  onChange={(e) => setCalcAmount(Number(e.target.value))}
                  className="w-full accent-[#002752] cursor-pointer"
                />
                <div className="flex justify-between text-[11px] text-slate-400 mt-1">
                  <span>Min £{selectedPlan.minimumAmount.toLocaleString()}</span>
                  <span>Max £100,000+</span>
                </div>
              </div>

              {/* Duration Buttons */}
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-2">
                  Simulation Duration
                </label>
                <div className="flex flex-wrap gap-2">
                  {selectedPlan.allowedDurationsMonths.map((months) => (
                    <button
                      key={months}
                      type="button"
                      onClick={() => setCalcDuration(months)}
                      className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                        calcDuration === months
                          ? 'bg-[#002752] text-white shadow-sm'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
                      }`}
                    >
                      {months} Months
                    </button>
                  ))}
                </div>
              </div>

            </div>

            {/* Results Column */}
            <div className="lg:col-span-5 bg-gradient-to-br from-[#002752] to-[#001833] text-white rounded-3xl p-6 sm:p-8 flex flex-col justify-between shadow-xl">
              <div>
                <span className="text-xs font-bold text-red-400 uppercase tracking-widest block mb-1">
                  {selectedPlan.riskLevel} • {selectedPlan.category}
                </span>
                <h3 className="text-xl font-black mb-6">
                  {selectedPlan.name}
                </h3>

                <div className="space-y-4 py-4 border-y border-white/10">
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-slate-300">Initial Capital</span>
                    <span className="font-bold text-white text-sm">£{calcAmount.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-slate-300">Annualized Yield Rate</span>
                    <span className="font-bold text-emerald-400 text-sm">+{returnRate}% p.a.</span>
                  </div>
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-slate-300">Estimated Simulated Gain</span>
                    <span className="font-bold text-emerald-400 text-base">+£{projectedReturn.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between items-center pt-3 border-t border-white/10">
                    <span className="text-slate-200 font-semibold text-sm">Total Projected Maturity</span>
                    <span className="font-black text-amber-400 text-2xl">£{totalMaturity.toLocaleString()}</span>
                  </div>
                </div>

                <p className="text-[11px] text-slate-400 mt-4 leading-relaxed">
                  * All calculations are simulated estimates. Final portfolio yields compound based on real-time simulated market cycles.
                </p>
              </div>

              <div className="mt-8">
                {isAuthenticated ? (
                  <button
                    onClick={() => onNavigate('dashboard')}
                    className="w-full py-3.5 bg-[#c8102e] hover:bg-[#a50d26] text-white font-bold rounded-xl text-sm shadow-lg transition-all flex items-center justify-center gap-2"
                  >
                    <span>Allocate in Customer Dashboard</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                ) : (
                  <button
                    onClick={() => onOpenAuth('register')}
                    className="w-full py-3.5 bg-[#c8102e] hover:bg-[#a50d26] text-white font-bold rounded-xl text-sm shadow-lg transition-all flex items-center justify-center gap-2"
                  >
                    <span>Open Account to Allocate</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* Plans Detailed Grid */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 mt-16">
        <div className="text-center max-w-2xl mx-auto mb-10">
          <h2 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white">
            Available Investment Portfolios
          </h2>
          <p className="mt-2 text-xs sm:text-sm text-slate-500">
            Select a verified plan tailored to your simulated capital requirements and risk tolerance.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {INVESTMENT_PLANS.map((plan) => {
            const Icon = getPlanIcon(plan.id);
            return (
              <div 
                key={plan.id}
                className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-8 shadow-sm hover:shadow-lg transition-all flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <div className="w-12 h-12 bg-blue-50 dark:bg-blue-950 text-[#002752] dark:text-blue-400 rounded-2xl flex items-center justify-center">
                      <Icon className="w-6 h-6" />
                    </div>
                    <span className="text-xs font-bold px-3 py-1 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 rounded-full border border-emerald-200 dark:border-emerald-800">
                      +{plan.annualReturnRate}% p.a.
                    </span>
                  </div>

                  <span className="text-[11px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider block mb-1">
                    {plan.category}
                  </span>
                  <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2">
                    {plan.name}
                  </h3>
                  <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed mb-6">
                    {plan.description}
                  </p>

                  <div className="grid grid-cols-2 gap-3 p-3.5 bg-slate-50 dark:bg-slate-950 rounded-2xl mb-6 text-xs">
                    <div>
                      <span className="text-slate-400 block text-[10px] uppercase">Min Capital</span>
                      <strong className="text-slate-800 dark:text-slate-200">£{plan.minimumAmount.toLocaleString()}</strong>
                    </div>
                    <div>
                      <span className="text-slate-400 block text-[10px] uppercase">Lock-in Tenure</span>
                      <strong className="text-slate-800 dark:text-slate-200">{plan.lockInPeriod}</strong>
                    </div>
                  </div>

                  <div className="space-y-2 mb-6">
                    {plan.features.map((feat, i) => (
                      <div key={i} className="flex items-start gap-2 text-xs text-slate-600 dark:text-slate-300">
                        <Check className="w-3.5 h-3.5 text-emerald-500 shrink-0 mt-0.5" />
                        <span>{feat}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <button
                  onClick={() => {
                    if (isAuthenticated) {
                      onNavigate('dashboard');
                    } else {
                      onOpenAuth('register');
                    }
                  }}
                  className="w-full py-3 bg-[#002752] hover:bg-[#001d3d] text-white font-bold rounded-xl text-xs transition-colors shadow-sm flex items-center justify-center gap-2"
                >
                  <span>Select Plan</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            );
          })}
        </div>
      </section>

    </div>
  );
};
