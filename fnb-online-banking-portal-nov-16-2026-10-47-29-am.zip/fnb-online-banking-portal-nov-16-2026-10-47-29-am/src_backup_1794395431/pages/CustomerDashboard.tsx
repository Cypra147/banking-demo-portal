import React, { useState, useEffect, useCallback } from 'react';
import { useAuth } from '../context/AuthContext.tsx';
import { api } from '../services/api.ts';
import { 
  Transaction, 
  VirtualCard, 
  LoginActivity, 
  InvestmentRequest, 
  VerificationRequest, 
  SupportEnquiry, 
  NotificationItem 
} from '../types.ts';
import { INVESTMENT_PLANS } from '../constants/investments.ts';
import { ReceiptModal } from '../components/ReceiptModal.tsx';
import { StatementModal } from '../components/StatementModal.tsx';
import { TransactionTagBadge } from '../components/TransactionTagBadge.tsx';
import { tagTransaction, AVAILABLE_TRANSACTION_TAGS, TRANSACTION_TAG_RULES } from '../utils/transactionTagger.ts';
import { 
  Tag,
  ArrowUpRight, 
  ArrowDownLeft, 
  CreditCard, 
  Send, 
  Zap, 
  Download, 
  Settings, 
  Eye, 
  EyeOff, 
  Copy, 
  Check, 
  RotateCcw, 
  Lock, 
  ShieldAlert, 
  ShieldCheck, 
  Search, 
  Filter, 
  Sparkles,
  Smartphone,
  History,
  Building2,
  Calendar,
  Layers,
  FileSpreadsheet,
  TrendingUp,
  UserCheck,
  Bell,
  MessageSquare,
  HelpCircle,
  FileCheck2,
  UploadCloud,
  CheckCircle2,
  Clock,
  AlertCircle,
  Phone,
  Mail,
  Globe,
  MapPin,
  ChevronRight,
  Printer
} from 'lucide-react';

export type DashboardTab = 
  | 'overview' 
  | 'account' 
  | 'investments' 
  | 'transfers' 
  | 'transactions' 
  | 'cards' 
  | 'statements' 
  | 'verification' 
  | 'notifications' 
  | 'support' 
  | 'settings';

export const CustomerDashboard: React.FC = () => {
  const { user, refreshUser, theme, toggleTheme, setIsMailModalOpen } = useAuth();
  
  // Tab Navigation (11 required tabs)
  const [activeTab, setActiveTab] = useState<DashboardTab>('overview');

  // Balances & Data
  const [balanceVisible, setBalanceVisible] = useState(true);
  const [copiedAcc, setCopiedAcc] = useState(false);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [virtualCards, setVirtualCards] = useState<VirtualCard[]>([]);
  const [loginActivities, setLoginActivities] = useState<LoginActivity[]>([]);
  const [investments, setInvestments] = useState<InvestmentRequest[]>([]);
  const [verifications, setVerifications] = useState<VerificationRequest[]>([]);
  const [supportEnquiries, setSupportEnquiries] = useState<SupportEnquiry[]>([]);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [loading, setLoading] = useState(true);

  // Modals
  const [activeReceiptTx, setActiveReceiptTx] = useState<Transaction | null>(null);
  const [isStatementOpen, setIsStatementOpen] = useState(false);

  // ================= FORMS & STATE =================
  
  // 1. Transfers Form
  const [transferForm, setTransferForm] = useState({
    beneficiaryName: '',
    beneficiaryBank: 'First National Bank (Domestic)',
    beneficiaryAccount: '',
    amount: '',
    description: '',
    reference: '',
  });
  const [transferLoading, setTransferLoading] = useState(false);
  const [transferError, setTransferError] = useState<string | null>(null);

  // 2. Investments Form
  const [selectedPlanId, setSelectedPlanId] = useState<string>('plan-fixed-income');
  const [invAmount, setInvAmount] = useState<string>('2500');
  const [invDuration, setInvDuration] = useState<number>(12);
  const [invNotes, setInvNotes] = useState<string>('');
  const [invTermsAccepted, setInvTermsAccepted] = useState<boolean>(true);
  const [invLoading, setInvLoading] = useState(false);
  const [invSuccessMsg, setInvSuccessMsg] = useState<string | null>(null);
  const [invErrorMsg, setInvErrorMsg] = useState<string | null>(null);

  // 3. KYC Verification Form
  const [kycForm, setKycForm] = useState({
    fullName: user?.fullName || `${user?.firstName || ''} ${user?.lastName || ''}`.trim(),
    dateOfBirth: '1992-06-14',
    countryOfResidence: user?.country || 'United Kingdom',
    residentialAddress: user?.residentialAddress || '44 Canary Wharf, London, E14 5AB',
    phone: user?.phone || '+447700900123',
    idDocumentType: 'passport' as 'passport' | 'national_id' | 'drivers_licence' | 'other',
    idDocumentNumber: 'GB982149021',
    sampleDocFrontName: 'Passport_Bio_Data_Page.pdf',
    sampleDocBackName: '',
    sampleProofOfAddressName: 'Utility_Bill_Proof_Of_Address.pdf',
    additionalComments: '',
    declarationAccepted: true,
    consentAccepted: true,
  });
  const [kycLoading, setKycLoading] = useState(false);
  const [kycSuccessMsg, setKycSuccessMsg] = useState<string | null>(null);
  const [kycErrorMsg, setKycErrorMsg] = useState<string | null>(null);

  // 4. Support Enquiry Form
  const [supportForm, setSupportForm] = useState({
    category: 'general',
    subject: '',
    message: '',
  });
  const [supportLoading, setSupportLoading] = useState(false);
  const [supportSuccess, setSupportSuccess] = useState<string | null>(null);
  const [supportError, setSupportError] = useState<string | null>(null);

  // 5. Virtual Card Controls
  const [revealedCvvCardId, setRevealedCvvCardId] = useState<string | null>(null);
  const [cardActionLoading, setCardActionLoading] = useState(false);
  const [editingCardLimit, setEditingCardLimit] = useState<{ id: string; limit: number } | null>(null);

  // 6. Settings Form
  const [settingsProfile, setSettingsProfile] = useState({
    firstName: user?.firstName || '',
    lastName: user?.lastName || '',
    fullName: user?.fullName || '',
    phone: user?.phone || '',
    country: user?.country || 'United Kingdom',
    residentialAddress: user?.residentialAddress || '',
    isTwoFactorEnabled: !!user?.isTwoFactorEnabled,
  });
  const [passwords, setPasswords] = useState({ current: '', new: '', confirm: '' });
  const [settingsMessage, setSettingsMessage] = useState<string | null>(null);
  const [settingsError, setSettingsError] = useState<string | null>(null);

  // Search & Filters for Transactions
  const [txSearch, setTxSearch] = useState('');
  const [txFilterType, setTxFilterType] = useState<string>('all');
  const [txFilterTag, setTxFilterTag] = useState<string>('All');
  const [notifCategoryFilter, setNotifCategoryFilter] = useState<string>('all');

  const fetchDashboardData = useCallback(async () => {
    try {
      setLoading(true);
      const [summary, actRes, invRes, verRes, supRes, notifRes] = await Promise.all([
        api.getBankingSummary(),
        api.getLoginActivity().catch(() => ({ activities: [] })),
        api.getInvestments().catch(() => ({ investments: [] })),
        api.getVerifications().catch(() => ({ verifications: [] })),
        api.getSupportEnquiries().catch(() => ({ enquiries: [] })),
        api.getNotifications().catch(() => ({ notifications: [] }))
      ]);

      setTransactions(summary.recentTransactions || []);
      setVirtualCards(summary.virtualCards || []);
      setLoginActivities(actRes.activities || []);
      setInvestments(invRes.investments || []);
      setVerifications(verRes.verifications || []);
      setSupportEnquiries(supRes.enquiries || []);
      setNotifications(notifRes.notifications || []);
    } catch (err) {
      console.error('Error fetching dashboard data:', err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchDashboardData();
  }, [fetchDashboardData]);

  if (!user) return null;

  const isFrozen = user.status === 'frozen';

  const handleCopyAcc = () => {
    if (user.accountNumber) {
      navigator.clipboard.writeText(user.accountNumber);
      setCopiedAcc(true);
      setTimeout(() => setCopiedAcc(false), 2000);
    }
  };

  // Submit Transfer
  const handleTransferSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setTransferError(null);

    const amt = parseFloat(transferForm.amount);
    if (isNaN(amt) || amt <= 0) {
      setTransferError('Please enter a valid amount.');
      return;
    }
    if (amt > user.balance) {
      setTransferError(`Insufficient funds. Your available balance is ${user.currency}${user.balance.toFixed(2)}.`);
      return;
    }

    setTransferLoading(true);
    try {
      const res = await api.transfer({
        beneficiaryName: transferForm.beneficiaryName,
        beneficiaryBank: transferForm.beneficiaryBank,
        beneficiaryAccount: transferForm.beneficiaryAccount,
        amount: amt,
        description: transferForm.description || `Transfer to ${transferForm.beneficiaryName}`,
        reference: transferForm.reference || undefined,
      });

      await refreshUser();
      await fetchDashboardData();

      setActiveReceiptTx(res.transaction);
      setTransferForm({
        beneficiaryName: '',
        beneficiaryBank: 'First National Bank (Domestic)',
        beneficiaryAccount: '',
        amount: '',
        description: '',
        reference: '',
      });
      setActiveTab('overview');
    } catch (err: any) {
      setTransferError(err.message || 'Transfer failed');
    } finally {
      setTransferLoading(false);
    }
  };

  // Submit Investment Allocation
  const handleInvestmentSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setInvErrorMsg(null);
    setInvSuccessMsg(null);

    const amt = parseFloat(invAmount);
    if (isNaN(amt) || amt <= 0) {
      setInvErrorMsg('Please specify a valid allocation amount.');
      return;
    }

    setInvLoading(true);
    try {
      const res = await api.createInvestment({
        planId: selectedPlanId,
        amount: amt,
        durationMonths: invDuration,
        userNotes: invNotes || undefined,
      });

      await refreshUser();
      await fetchDashboardData();
      setInvSuccessMsg(`Investment request ${res.investment.reference} submitted successfully for administrative compliance review!`);
      setInvNotes('');
    } catch (err: any) {
      setInvErrorMsg(err.message || 'Failed to submit investment request.');
    } finally {
      setInvLoading(false);
    }
  };

  // Submit KYC Verification
  const handleKycSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setKycErrorMsg(null);
    setKycSuccessMsg(null);

    setKycLoading(true);
    try {
      const res = await api.createVerification({
        ...kycForm,
        email: user.email,
        accountReference: user.accountNumber || '1084920194',
      });

      await refreshUser();
      await fetchDashboardData();
      setKycSuccessMsg(`Identity verification submitted under reference ${res.verification.reference}! Your documents are now under compliance review.`);
    } catch (err: any) {
      setKycErrorMsg(err.message || 'Failed to submit verification request.');
    } finally {
      setKycLoading(false);
    }
  };

  // Submit Support Enquiry
  const handleSupportSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSupportError(null);
    setSupportSuccess(null);
    setSupportLoading(true);

    try {
      const res = await api.createSupportEnquiry({
        name: user.fullName || `${user.firstName} ${user.lastName}`,
        email: user.email,
        phone: user.phone,
        category: supportForm.category,
        subject: supportForm.subject,
        message: supportForm.message,
      });

      await fetchDashboardData();
      setSupportSuccess(`Support ticket created! Reference: ${res.enquiry.reference}`);
      setSupportForm({ category: 'general', subject: '', message: '' });
    } catch (err: any) {
      setSupportError(err.message || 'Failed to submit ticket.');
    } finally {
      setSupportLoading(false);
    }
  };

  // Toggle Card Freeze
  const handleToggleCardFreeze = async (cardId: string) => {
    try {
      setCardActionLoading(true);
      await api.toggleCardFreeze(cardId);
      await fetchDashboardData();
    } catch (err: any) {
      alert(err.message || 'Action failed');
    } finally {
      setCardActionLoading(false);
    }
  };

  // Save Settings
  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setSettingsMessage(null);
    setSettingsError(null);
    try {
      await api.updateProfile(settingsProfile);
      await refreshUser();
      setSettingsMessage('Profile updated successfully.');
    } catch (err: any) {
      setSettingsError(err.message || 'Failed to update profile.');
    }
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setSettingsMessage(null);
    setSettingsError(null);
    if (passwords.new !== passwords.confirm) {
      setSettingsError('New passwords do not match.');
      return;
    }
    try {
      await api.changePassword(passwords.current, passwords.new);
      setPasswords({ current: '', new: '', confirm: '' });
      setSettingsMessage('Password updated successfully.');
    } catch (err: any) {
      setSettingsError(err.message || 'Failed to change password.');
    }
  };

  const handleMarkNotifRead = async (id: string) => {
    try {
      await api.markNotificationRead(id);
      setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
    } catch (e) {
      console.error(e);
    }
  };

  // Filtered transactions
  const filteredTransactions = transactions.filter(tx => {
    const q = txSearch.toLowerCase();
    const tag = tx.tag || tagTransaction(tx.description, tx.type, tx.billerCategory).tag;
    const matchesSearch = 
      tx.reference.toLowerCase().includes(q) ||
      tx.description.toLowerCase().includes(q) ||
      (tx.beneficiaryName && tx.beneficiaryName.toLowerCase().includes(q)) ||
      (tag && tag.toLowerCase().includes(q));
    
    const matchesType = txFilterType === 'all' || tx.type === txFilterType;
    const matchesTag = txFilterTag === 'All' || tag.toLowerCase() === txFilterTag.toLowerCase();

    return matchesSearch && matchesType && matchesTag;
  });

  const filteredNotifications = notifications.filter(n => {
    if (notifCategoryFilter === 'all') return true;
    return n.category === notifCategoryFilter;
  });

  const unreadNotifsCount = notifications.filter(n => !n.read).length;

  return (
    <div className="min-h-screen bg-slate-100 dark:bg-slate-950 text-slate-800 dark:text-slate-100 py-6 px-4 sm:px-8 transition-colors">
      <div className="max-w-7xl mx-auto space-y-6">

        {/* Frozen Alert Banner */}
        {isFrozen && (
          <div className="p-4 bg-red-100 dark:bg-red-950/60 border border-red-300 dark:border-red-900 rounded-2xl flex items-center gap-3 text-red-800 dark:text-red-200 text-xs sm:text-sm shadow-sm">
            <ShieldAlert className="w-5 h-5 text-red-600 shrink-0" />
            <div className="flex-1">
              <strong>Account Frozen for Security:</strong> Outbound transactions and card charges are temporarily paused. Contact client relations at +447723165577 to reactivate.
            </div>
          </div>
        )}

        {/* Top Header Card */}
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 shadow-sm border border-slate-200 dark:border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 bg-gradient-to-br from-[#002752] to-[#c8102e] text-white font-black text-xl rounded-2xl flex items-center justify-center shadow-md shrink-0">
              {user.firstName[0]}{user.lastName[0]}
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h1 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white">
                  Welcome back, {user.firstName}
                </h1>
                <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider ${
                  user.status === 'active' 
                    ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                    : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                }`}>
                  {user.status}
                </span>
                <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                  user.kycStatus === 'verified'
                    ? 'bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300'
                    : 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300'
                }`}>
                  KYC: {user.kycStatus || 'Unverified'}
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                Sort Code: <span className="font-mono font-bold text-slate-700 dark:text-slate-300">20-04-15</span> • Account: <span className="font-mono font-bold text-slate-700 dark:text-slate-300">{user.accountNumber || 'PENDING'}</span>
              </p>
            </div>
          </div>

          {/* Quick Shortcuts */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveTab('notifications')}
              className="p-2.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-200 rounded-xl text-xs relative transition-colors"
              title="Notifications"
            >
              <Bell className="w-4 h-4" />
              {unreadNotifsCount > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 bg-[#c8102e] text-white text-[9px] font-black rounded-full flex items-center justify-center">
                  {unreadNotifsCount}
                </span>
              )}
            </button>
            <button
              onClick={() => setIsStatementOpen(true)}
              className="px-3.5 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-200 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors"
            >
              <FileSpreadsheet className="w-3.5 h-3.5" />
              <span>Statement</span>
            </button>
          </div>
        </div>

        {/* 11 Main Functional Navigation Tabs */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-2 border border-slate-200 dark:border-slate-800 shadow-sm overflow-x-auto">
          <div className="flex items-center gap-1.5 min-w-max text-xs font-bold">
            {[
              { id: 'overview', label: 'Overview', icon: Layers },
              { id: 'account', label: 'My Account', icon: Building2 },
              { id: 'investments', label: 'Investments', icon: TrendingUp },
              { id: 'transfers', label: 'Transfers', icon: Send },
              { id: 'transactions', label: 'Transactions', icon: History },
              { id: 'cards', label: 'Virtual Cards', icon: CreditCard },
              { id: 'statements', label: 'Statements', icon: FileSpreadsheet },
              { id: 'verification', label: 'Verification', icon: FileCheck2 },
              { id: 'notifications', label: 'Notifications', icon: Bell, count: unreadNotifsCount },
              { id: 'support', label: 'Customer Support', icon: MessageSquare },
              { id: 'settings', label: 'Settings', icon: Settings },
            ].map(tab => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as DashboardTab)}
                  className={`px-3.5 py-2 rounded-xl transition-all flex items-center gap-1.5 whitespace-nowrap ${
                    isActive 
                      ? 'bg-[#002752] text-white shadow-sm' 
                      : 'hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{tab.label}</span>
                  {tab.count !== undefined && tab.count > 0 && (
                    <span className="w-4 h-4 rounded-full bg-red-600 text-white text-[9px] flex items-center justify-center font-bold">
                      {tab.count}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* ================= TAB 1: OVERVIEW ================= */}
        {activeTab === 'overview' && (
          <div className="space-y-6">
            
            {/* Balance & Account Cards */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              
              {/* Main Balance Card */}
              <div className="lg:col-span-2 relative overflow-hidden rounded-3xl p-7 bg-gradient-to-br from-[#002752] via-[#053770] to-[#001736] text-white shadow-xl">
                <div className="flex items-center justify-between text-xs text-slate-300 mb-3">
                  <div className="flex items-center gap-2">
                    <span className="font-semibold uppercase tracking-wider">Available Checking Balance</span>
                    <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-bold text-[10px]">
                      TIER 1 CHECKING
                    </span>
                  </div>
                  <button
                    onClick={() => setBalanceVisible(!balanceVisible)}
                    className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 transition-colors"
                  >
                    {balanceVisible ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>

                <div className="my-2">
                  <div className="text-4xl sm:text-5xl font-black tracking-tight">
                    {balanceVisible ? `${user.currency}${user.balance.toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}` : '••••••••'}
                  </div>
                  <p className="text-xs text-slate-300 mt-1 font-medium">
                    Ledger Currency: British Pounds Sterling (GBP)
                  </p>
                </div>

                <div className="pt-6 mt-6 border-t border-white/10 flex flex-wrap items-center justify-between gap-4">
                  <div className="flex items-center gap-6 text-xs text-slate-200">
                    <div>
                      <span className="text-slate-400 block text-[10px] uppercase">Account Number</span>
                      <div className="flex items-center gap-1.5 font-mono font-bold text-sm">
                        <span>{user.accountNumber || 'PENDING'}</span>
                        <button onClick={handleCopyAcc} className="text-slate-300 hover:text-white">
                          {copiedAcc ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                        </button>
                      </div>
                    </div>
                    <div>
                      <span className="text-slate-400 block text-[10px] uppercase">Sort Code</span>
                      <span className="font-mono font-bold text-sm">20-04-15</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setActiveTab('transfers')}
                      className="px-4 py-2 bg-[#c8102e] hover:bg-[#a50d26] text-white font-bold rounded-xl text-xs shadow-md transition-all flex items-center gap-1.5"
                    >
                      <Send className="w-3.5 h-3.5" />
                      <span>Send Transfer</span>
                    </button>
                    <button
                      onClick={() => setActiveTab('investments')}
                      className="px-4 py-2 bg-white/10 hover:bg-white/20 text-white font-bold rounded-xl text-xs border border-white/20 transition-all flex items-center gap-1.5"
                    >
                      <TrendingUp className="w-3.5 h-3.5" />
                      <span>Invest</span>
                    </button>
                  </div>
                </div>
              </div>

              {/* Virtual Card Widget */}
              <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Active Virtual Card</span>
                    <button 
                      onClick={() => setActiveTab('cards')} 
                      className="text-xs font-bold text-[#002752] dark:text-blue-400 hover:underline"
                    >
                      Manage
                    </button>
                  </div>
                  
                  {virtualCards.length > 0 ? (
                    <div className="relative rounded-2xl p-5 bg-gradient-to-tr from-[#001736] to-[#002752] text-white shadow-lg overflow-hidden">
                      <div className="flex justify-between items-center mb-6">
                        <span className="text-[10px] font-black uppercase tracking-widest text-red-400">FNB PLATINUM</span>
                        <CreditCard className="w-5 h-5 text-slate-300" />
                      </div>
                      <div className="font-mono text-sm tracking-widest font-bold mb-4">
                        {virtualCards[0].cardNumber}
                      </div>
                      <div className="flex justify-between items-end text-[10px] text-slate-300">
                        <div>
                          <span className="text-[8px] uppercase block text-slate-400">Cardholder</span>
                          <span className="font-bold text-white uppercase">{virtualCards[0].cardHolder}</span>
                        </div>
                        <div>
                          <span className="text-[8px] uppercase block text-slate-400">Expires</span>
                          <span className="font-bold text-white">{virtualCards[0].expiryDate}</span>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-8 text-xs text-slate-400">
                      No active virtual card provisioned.
                    </div>
                  )}
                </div>

                <div className="mt-4 pt-4 border-t border-slate-100 dark:border-slate-800 flex justify-between items-center text-xs">
                  <span className="text-slate-500">Status</span>
                  <span className="font-bold text-emerald-600">Active & Ready</span>
                </div>
              </div>

            </div>

            {/* Quick Actions Bar */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              {[
                { label: 'Electronic Transfer', icon: Send, tab: 'transfers', color: 'text-red-600 bg-red-50 dark:bg-red-950/40' },
                { label: 'Invest Capital', icon: TrendingUp, tab: 'investments', color: 'text-[#002752] dark:text-blue-400 bg-blue-50 dark:bg-blue-950/40' },
                { label: 'Verify Identity', icon: FileCheck2, tab: 'verification', color: 'text-emerald-600 bg-emerald-50 dark:bg-emerald-950/40' },
                { label: 'Print Statement', icon: FileSpreadsheet, action: () => setIsStatementOpen(true), color: 'text-amber-600 bg-amber-50 dark:bg-amber-950/40' },
              ].map((act, i) => {
                const Icon = act.icon;
                return (
                  <button
                    key={i}
                    onClick={() => act.action ? act.action() : setActiveTab(act.tab as DashboardTab)}
                    className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-md transition-all text-left flex items-center gap-3 group"
                  >
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${act.color}`}>
                      <Icon className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="font-bold text-xs text-slate-900 dark:text-white group-hover:text-[#002752] dark:group-hover:text-blue-400">
                        {act.label}
                      </h4>
                      <span className="text-[10px] text-slate-400">Instant Access</span>
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Recent Transactions List */}
            <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-sm">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h3 className="text-lg font-bold text-slate-900 dark:text-white">Recent Transactions</h3>
                  <p className="text-xs text-slate-500">Real-time ledger entries and automated 30-min reversal statuses</p>
                </div>
                <button
                  onClick={() => setActiveTab('transactions')}
                  className="text-xs font-bold text-[#002752] dark:text-blue-400 hover:underline"
                >
                  View All ({transactions.length})
                </button>
              </div>

              {transactions.length === 0 ? (
                <div className="text-center py-12 text-slate-400 text-xs">
                  No transaction records found.
                </div>
              ) : (
                <div className="divide-y divide-slate-100 dark:divide-slate-800">
                  {transactions.slice(0, 5).map(tx => (
                    <div key={tx.id} className="py-3.5 flex items-center justify-between gap-4">
                      <div className="flex items-center gap-3">
                        <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                          tx.type === 'credit' || tx.type === 'reversal'
                            ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600'
                            : 'bg-red-50 dark:bg-red-950/40 text-red-600'
                        }`}>
                          {tx.type === 'credit' || tx.type === 'reversal' ? (
                            <ArrowDownLeft className="w-5 h-5" />
                          ) : (
                            <ArrowUpRight className="w-5 h-5" />
                          )}
                        </div>
                        <div>
                          <div className="flex flex-wrap items-center gap-2">
                            <p className="font-bold text-xs sm:text-sm text-slate-900 dark:text-white">
                              {tx.description}
                            </p>
                            <TransactionTagBadge 
                              tag={tx.tag || tagTransaction(tx.description, tx.type, tx.billerCategory).tag} 
                              showIcon 
                            />
                          </div>
                          <div className="flex items-center gap-2 text-[11px] text-slate-400 mt-0.5">
                            <span className="font-mono">{tx.reference}</span>
                            <span>•</span>
                            <span>{new Date(tx.createdAt).toLocaleDateString()}</span>
                          </div>
                        </div>
                      </div>

                      <div className="text-right shrink-0">
                        <p className={`font-black text-xs sm:text-sm ${
                          tx.type === 'credit' || tx.type === 'reversal'
                            ? 'text-emerald-600 dark:text-emerald-400'
                            : 'text-slate-900 dark:text-white'
                        }`}>
                          {tx.type === 'credit' || tx.type === 'reversal' ? '+' : '-'}
                          {tx.currency}{tx.amount.toFixed(2)}
                        </p>
                        <button
                          onClick={() => setActiveReceiptTx(tx)}
                          className="text-[10px] text-slate-400 hover:text-[#002752] dark:hover:text-blue-400 font-semibold"
                        >
                          Receipt
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

          </div>
        )}

        {/* ================= TAB 2: MY ACCOUNT ================= */}
        {activeTab === 'account' && (
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-sm space-y-6">
            <div>
              <h2 className="text-xl font-bold text-slate-900 dark:text-white">My Account Details</h2>
              <p className="text-xs text-slate-500">Official account credentials and branch settlement references.</p>
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              
              <div className="p-6 bg-slate-50 dark:bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-4">
                <h3 className="font-bold text-sm text-[#002752] dark:text-blue-400 border-b border-slate-200 dark:border-slate-800 pb-2">
                  Banking Identification
                </h3>
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-500">Account Holder:</span>
                  <strong className="text-slate-900 dark:text-white">{user.fullName || `${user.firstName} ${user.lastName}`}</strong>
                </div>
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-500">10-Digit Account Number:</span>
                  <div className="flex items-center gap-1.5 font-mono font-bold text-slate-900 dark:text-white">
                    <span>{user.accountNumber || 'PENDING'}</span>
                    <button onClick={handleCopyAcc} className="text-slate-400 hover:text-slate-600">
                      {copiedAcc ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                </div>
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-500">Sort Code:</span>
                  <strong className="font-mono text-slate-900 dark:text-white">20-04-15</strong>
                </div>
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-500">Account Type:</span>
                  <span className="font-semibold text-slate-800 dark:text-slate-200">Personal Checking (Sandbox)</span>
                </div>
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-500">Currency:</span>
                  <span className="font-semibold text-slate-800 dark:text-slate-200">British Pounds Sterling (£)</span>
                </div>
              </div>

              <div className="p-6 bg-slate-50 dark:bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-4">
                <h3 className="font-bold text-sm text-[#002752] dark:text-blue-400 border-b border-slate-200 dark:border-slate-800 pb-2">
                  Branch & Regulatory Info
                </h3>
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-500">Institution:</span>
                  <strong className="text-slate-900 dark:text-white">First National Bank (FNB)</strong>
                </div>
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-500">Branch Location:</span>
                  <span className="text-slate-800 dark:text-slate-200">Canary Wharf, London, E14 5AB</span>
                </div>
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-500">Account Tier:</span>
                  <span className="font-bold text-emerald-600">Tier-1 Full Sandbox</span>
                </div>
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-500">Telephone Helpline:</span>
                  <span className="text-slate-800 dark:text-slate-200">+447723165577</span>
                </div>
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-500">Official Email:</span>
                  <span className="text-slate-800 dark:text-slate-200">info@fnnbbankss.online</span>
                </div>
              </div>

            </div>
          </div>
        )}

        {/* ================= TAB 3: INVESTMENTS ================= */}
        {activeTab === 'investments' && (
          <div className="space-y-6">
            
            {/* Allocation Form Card */}
            <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-sm">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 bg-[#002752] text-white rounded-xl flex items-center justify-center">
                  <TrendingUp className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-xl font-bold text-slate-900 dark:text-white">
                    Simulated Portfolio Allocation
                  </h2>
                  <p className="text-xs text-slate-500">
                    Allocate available checking funds into an institutional simulated investment plan.
                  </p>
                </div>
              </div>

              {invSuccessMsg && (
                <div className="mb-6 p-4 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 rounded-2xl text-xs text-emerald-800 dark:text-emerald-200 flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />
                  <span>{invSuccessMsg}</span>
                </div>
              )}

              {invErrorMsg && (
                <div className="mb-6 p-4 bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 rounded-2xl text-xs text-red-700 dark:text-red-300 flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  <span>{invErrorMsg}</span>
                </div>
              )}

              <form onSubmit={handleInvestmentSubmit} className="space-y-6">
                {/* Plan Selection */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-2">
                    Choose Investment Strategy
                  </label>
                  <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
                    {INVESTMENT_PLANS.map(plan => {
                      const isSel = plan.id === selectedPlanId;
                      return (
                        <button
                          key={plan.id}
                          type="button"
                          onClick={() => {
                            setSelectedPlanId(plan.id);
                            if (parseFloat(invAmount) < plan.minimumAmount) {
                              setInvAmount(plan.minimumAmount.toString());
                            }
                          }}
                          className={`p-4 rounded-2xl border text-left transition-all ${
                            isSel
                              ? 'border-[#002752] dark:border-blue-500 bg-blue-50/50 dark:bg-blue-950/40 ring-2 ring-[#002752]/20'
                              : 'border-slate-200 dark:border-slate-800 hover:border-slate-300'
                          }`}
                        >
                          <span className="text-[10px] font-bold text-slate-400 block mb-1 uppercase">{plan.riskLevel}</span>
                          <h4 className="font-bold text-xs text-slate-900 dark:text-white mb-2 leading-tight">
                            {plan.name.replace(' (Simulated)', '')}
                          </h4>
                          <span className="text-sm font-black text-emerald-600 block">
                            +{plan.annualReturnRate}% p.a.
                          </span>
                          <span className="text-[10px] text-slate-500 mt-1 block">
                            Min: £{plan.minimumAmount.toLocaleString()}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Capital to Allocate (£)
                    </label>
                    <input
                      type="number"
                      required
                      value={invAmount}
                      onChange={e => setInvAmount(e.target.value)}
                      className="w-full px-3.5 py-2.5 text-xs sm:text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#002752]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Duration (Months)
                    </label>
                    <select
                      value={invDuration}
                      onChange={e => setInvDuration(parseInt(e.target.value, 10))}
                      className="w-full px-3.5 py-2.5 text-xs sm:text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#002752]"
                    >
                      <option value={3}>3 Months</option>
                      <option value={6}>6 Months</option>
                      <option value={12}>12 Months (Recommended)</option>
                      <option value={24}>24 Months</option>
                      <option value={36}>36 Months</option>
                    </select>
                  </div>
                </div>

                <div className="p-4 bg-slate-50 dark:bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-800 text-xs flex justify-between items-center">
                  <div>
                    <span className="text-slate-500 block">Projected Simulated Return</span>
                    <strong className="text-emerald-600 text-sm">
                      +£{((parseFloat(invAmount || '0') * ((INVESTMENT_PLANS.find(p => p.id === selectedPlanId)?.annualReturnRate || 7.2) / 100) * (invDuration / 12))).toFixed(2)}
                    </strong>
                  </div>
                  <div className="text-right">
                    <span className="text-slate-500 block">Available Balance</span>
                    <strong className="text-slate-800 dark:text-slate-200">£{user.balance.toFixed(2)}</strong>
                  </div>
                </div>

                <div className="flex items-start gap-2">
                  <input
                    type="checkbox"
                    id="invConsent"
                    checked={invTermsAccepted}
                    onChange={e => setInvTermsAccepted(e.target.checked)}
                    className="mt-1"
                  />
                  <label htmlFor="invConsent" className="text-xs text-slate-600 dark:text-slate-400">
                    I acknowledge that all yields and allocations are simulated demonstrations. Upon submission, an investment reference (<code>INV-...</code>) will be created and reviewed by administration.
                  </label>
                </div>

                <button
                  type="submit"
                  disabled={invLoading || !invTermsAccepted}
                  className="w-full py-3 bg-[#002752] hover:bg-[#001d3d] text-white font-bold rounded-xl text-sm shadow-md transition-all flex items-center justify-center gap-2"
                >
                  <TrendingUp className="w-4 h-4" />
                  <span>{invLoading ? 'Submitting Allocation...' : 'Submit Investment Request'}</span>
                </button>
              </form>
            </div>

            {/* My Investment Requests History */}
            <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-sm">
              <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-4">
                My Investment Requests
              </h3>
              {investments.length === 0 ? (
                <p className="text-xs text-slate-400 py-6 text-center">No investment requests submitted yet.</p>
              ) : (
                <div className="divide-y divide-slate-100 dark:divide-slate-800">
                  {investments.map(inv => (
                    <div key={inv.id} className="py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
                      <div>
                        <div className="flex items-center gap-2">
                          <strong className="font-bold text-slate-900 dark:text-white">{inv.planName}</strong>
                          <span className={`px-2 py-0.5 rounded-full font-bold uppercase text-[9px] ${
                            inv.status === 'active' || inv.status === 'approved'
                              ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                              : inv.status === 'rejected'
                              ? 'bg-red-100 text-red-800 dark:bg-red-950 dark:text-red-300'
                              : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                          }`}>
                            {inv.status.replace('_', ' ')}
                          </span>
                        </div>
                        <p className="text-slate-500 mt-0.5">
                          Ref: <span className="font-mono">{inv.reference}</span> • Duration: {inv.durationMonths} Months • Projected: +£{inv.projectedReturnAmount.toFixed(2)}
                        </p>
                      </div>
                      <div className="sm:text-right">
                        <span className="font-black text-sm text-slate-900 dark:text-white">
                          £{inv.amount.toLocaleString()}
                        </span>
                        <span className="block text-[10px] text-slate-400">{new Date(inv.createdAt).toLocaleDateString()}</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

          </div>
        )}

        {/* ================= TAB 4: TRANSFERS ================= */}
        {activeTab === 'transfers' && (
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-sm max-w-2xl mx-auto">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 bg-red-50 dark:bg-red-950/40 text-red-600 rounded-xl flex items-center justify-center">
                <Send className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-slate-900 dark:text-white">Electronic Transfer</h2>
                <p className="text-xs text-slate-500">Send simulated funds with instant receipt and 30-min auto-reversal</p>
              </div>
            </div>

            {transferError && (
              <div className="mb-6 p-4 bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 rounded-2xl text-xs text-red-700 dark:text-red-300 flex items-start gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                <span>{transferError}</span>
              </div>
            )}

            <form onSubmit={handleTransferSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Beneficiary Name
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. David Miller"
                  value={transferForm.beneficiaryName}
                  onChange={e => setTransferForm({ ...transferForm, beneficiaryName: e.target.value })}
                  className="w-full px-3.5 py-2.5 text-xs sm:text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#002752]"
                />
              </div>

              <div className="grid sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Beneficiary Bank
                  </label>
                  <select
                    value={transferForm.beneficiaryBank}
                    onChange={e => setTransferForm({ ...transferForm, beneficiaryBank: e.target.value })}
                    className="w-full px-3.5 py-2.5 text-xs sm:text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#002752]"
                  >
                    <option value="First National Bank (Domestic)">First National Bank (Domestic)</option>
                    <option value="Barclays Bank UK">Barclays Bank UK</option>
                    <option value="HSBC UK">HSBC UK</option>
                    <option value="Lloyds Bank">Lloyds Bank</option>
                    <option value="International Wire (SWIFT)">International Wire (SWIFT)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Account Number / IBAN
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. 1084920481"
                    value={transferForm.beneficiaryAccount}
                    onChange={e => setTransferForm({ ...transferForm, beneficiaryAccount: e.target.value })}
                    className="w-full px-3.5 py-2.5 text-xs sm:text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#002752]"
                  />
                </div>
              </div>

              <div className="grid sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Amount ({user.currency})
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    required
                    placeholder="0.00"
                    value={transferForm.amount}
                    onChange={e => setTransferForm({ ...transferForm, amount: e.target.value })}
                    className="w-full px-3.5 py-2.5 text-xs sm:text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#002752]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Custom Reference (Optional)
                  </label>
                  <input
                    type="text"
                    placeholder="Auto-generated if blank"
                    value={transferForm.reference}
                    onChange={e => setTransferForm({ ...transferForm, reference: e.target.value })}
                    className="w-full px-3.5 py-2.5 text-xs sm:text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#002752]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Payment Description
                </label>
                <input
                  type="text"
                  placeholder="e.g. Invoice payment, rent, gift"
                  value={transferForm.description}
                  onChange={e => setTransferForm({ ...transferForm, description: e.target.value })}
                  className="w-full px-3.5 py-2.5 text-xs sm:text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#002752]"
                />
              </div>

              <div className="p-3.5 bg-amber-50 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-700/60 rounded-xl text-xs text-amber-900 dark:text-amber-200">
                Notice: All outbound transfers trigger an automated 30-minute sandbox demonstration cycle. Transferred funds automatically return to your balance after 30 minutes.
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  disabled={transferLoading}
                  className="w-full py-3 bg-[#c8102e] hover:bg-[#a50d26] text-white font-bold rounded-xl text-sm shadow-md transition-all flex items-center justify-center gap-2"
                >
                  <Send className="w-4 h-4" />
                  <span>{transferLoading ? 'Authorizing Transfer...' : 'Confirm & Execute Transfer'}</span>
                </button>
              </div>
            </form>
          </div>
        )}

        {/* ================= TAB 5: TRANSACTIONS ================= */}
        {activeTab === 'transactions' && (
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-sm space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h2 className="text-xl font-bold text-slate-900 dark:text-white">Transaction History & Ledger</h2>
                <p className="text-xs text-slate-500">Filter, search, and download official receipts with automatic category tags</p>
              </div>
              <button
                onClick={() => setIsStatementOpen(true)}
                className="px-4 py-2 bg-[#002752] text-white font-bold text-xs rounded-xl flex items-center gap-2 shadow"
              >
                <FileSpreadsheet className="w-4 h-4" />
                <span>Export Statement</span>
              </button>
            </div>

            {/* Spending Breakdown by Auto-Tag */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {['Groceries', 'Utilities', 'Entertainment', 'Dining & Food'].map(cat => {
                const catTxs = transactions.filter(t => 
                  (t.tag === cat || tagTransaction(t.description, t.type, t.billerCategory).tag === cat) && 
                  (t.type === 'debit' || t.type === 'bill_payment')
                );
                const catTotal = catTxs.reduce((sum, t) => sum + t.amount, 0);
                const isSelected = txFilterTag === cat;
                return (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => setTxFilterTag(prev => prev === cat ? 'All' : cat)}
                    className={`p-3 rounded-2xl border text-left transition-all ${
                      isSelected 
                        ? 'bg-blue-50/80 dark:bg-blue-950/60 border-[#002752] dark:border-blue-500 ring-2 ring-blue-500/20'
                        : 'bg-slate-50 dark:bg-slate-950/60 border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1.5">
                      <TransactionTagBadge tag={cat} size="sm" />
                      <span className="text-[10px] text-slate-400 font-semibold">{catTxs.length} txs</span>
                    </div>
                    <p className="text-sm sm:text-base font-extrabold text-slate-900 dark:text-white">
                      {user?.currency || '£'}{catTotal.toFixed(2)}
                    </p>
                  </button>
                );
              })}
            </div>

            {/* Filter Bar */}
            <div className="flex flex-col sm:flex-row gap-3">
              <div className="relative flex-1">
                <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search by reference, description, beneficiary, or tag..."
                  value={txSearch}
                  onChange={e => setTxSearch(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl"
                />
              </div>
              <select
                value={txFilterType}
                onChange={e => setTxFilterType(e.target.value)}
                className="px-3 py-2 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl"
              >
                <option value="all">All Types</option>
                <option value="credit">Credits</option>
                <option value="debit">Debits</option>
                <option value="transfer">Transfers</option>
                <option value="reversal">Reversals</option>
                <option value="bill_payment">Bill Payments</option>
              </select>
            </div>

            {/* Automatic Category Tag Filter Pills */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none text-xs">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider shrink-0 mr-1 flex items-center gap-1">
                <Tag className="w-3 h-3 text-[#c8102e]" />
                Tag:
              </span>
              {AVAILABLE_TRANSACTION_TAGS.map(tag => {
                const isSelected = txFilterTag === tag;
                return (
                  <button
                    key={tag}
                    type="button"
                    onClick={() => setTxFilterTag(tag)}
                    className={`px-3 py-1 rounded-full text-xs font-semibold whitespace-nowrap transition-all ${
                      isSelected
                        ? 'bg-[#002752] text-white shadow-sm ring-2 ring-[#002752]/20'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                    }`}
                  >
                    {tag}
                  </button>
                );
              })}
            </div>

            {filteredTransactions.length === 0 ? (
              <p className="text-center py-12 text-slate-400 text-xs">No matching transactions found.</p>
            ) : (
              <div className="divide-y divide-slate-100 dark:divide-slate-800">
                {filteredTransactions.map(tx => (
                  <div key={tx.id} className="py-4 flex items-center justify-between gap-4 text-xs">
                    <div className="flex items-center gap-3">
                      <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                        tx.type === 'credit' || tx.type === 'reversal'
                          ? 'bg-emerald-50 text-emerald-600'
                          : 'bg-red-50 text-red-600'
                      }`}>
                        {tx.type === 'credit' || tx.type === 'reversal' ? <ArrowDownLeft className="w-5 h-5" /> : <ArrowUpRight className="w-5 h-5" />}
                      </div>
                      <div>
                        <div className="flex flex-wrap items-center gap-2">
                          <p className="font-bold text-slate-900 dark:text-white text-sm">{tx.description}</p>
                          <TransactionTagBadge 
                            tag={tx.tag || tagTransaction(tx.description, tx.type, tx.billerCategory).tag} 
                            showIcon 
                          />
                        </div>
                        <div className="flex items-center gap-2 text-slate-400 mt-1 font-mono text-[11px]">
                          <span>{tx.reference}</span>
                          <span>•</span>
                          <span>{new Date(tx.createdAt).toLocaleString()}</span>
                          {tx.isReversed && (
                            <span className="px-1.5 py-0.2 bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 rounded font-sans text-[9px]">
                              REVERSED
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                    <div className="text-right shrink-0">
                      <p className={`font-black text-sm ${
                        tx.type === 'credit' || tx.type === 'reversal' ? 'text-emerald-600' : 'text-slate-900 dark:text-white'
                      }`}>
                        {tx.type === 'credit' || tx.type === 'reversal' ? '+' : '-'}
                        {tx.currency}{tx.amount.toFixed(2)}
                      </p>
                      <button
                        onClick={() => setActiveReceiptTx(tx)}
                        className="text-[10px] text-[#002752] dark:text-blue-400 font-bold hover:underline"
                      >
                        View Official Receipt
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ================= TAB 6: VIRTUAL CARDS ================= */}
        {activeTab === 'cards' && (
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-sm space-y-6">
            <div>
              <h2 className="text-xl font-bold text-slate-900 dark:text-white">Virtual Debit Cards</h2>
              <p className="text-xs text-slate-500">Manage instant digital Visa cards with live security freeze controls</p>
            </div>

            <div className="grid md:grid-cols-2 gap-8 items-start">
              {virtualCards.map(card => {
                const isFrozen = card.status === 'frozen';
                const showCvv = revealedCvvCardId === card.id;
                return (
                  <div key={card.id} className="space-y-4">
                    {/* Visual Card */}
                    <div className={`relative rounded-3xl p-7 text-white shadow-2xl transition-all ${
                      isFrozen 
                        ? 'bg-gradient-to-tr from-slate-700 to-slate-900 opacity-75' 
                        : 'bg-gradient-to-tr from-[#001736] via-[#002752] to-[#0a3d75]'
                    }`}>
                      <div className="flex justify-between items-center mb-8">
                        <div>
                          <span className="text-[10px] font-black tracking-widest text-red-400 uppercase">FNB DEBIT</span>
                          <p className="text-xs font-bold text-slate-300">Platinum Virtual</p>
                        </div>
                        <CreditCard className="w-7 h-7 text-white" />
                      </div>

                      <div className="font-mono text-xl sm:text-2xl tracking-widest font-black mb-6">
                        {card.cardNumber}
                      </div>

                      <div className="flex justify-between items-end text-xs">
                        <div>
                          <span className="text-[9px] uppercase tracking-wider block text-slate-400">Cardholder</span>
                          <span className="font-bold text-white uppercase">{card.cardHolder}</span>
                        </div>
                        <div>
                          <span className="text-[9px] uppercase tracking-wider block text-slate-400">Expires</span>
                          <span className="font-bold text-white">{card.expiryDate}</span>
                        </div>
                        <div>
                          <span className="text-[9px] uppercase tracking-wider block text-slate-400">CVV</span>
                          <span className="font-mono font-bold text-amber-400">
                            {showCvv ? card.cvv : '•••'}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Card Actions */}
                    <div className="flex flex-wrap gap-2 text-xs">
                      <button
                        onClick={() => handleToggleCardFreeze(card.id)}
                        disabled={cardActionLoading}
                        className={`flex-1 py-2.5 rounded-xl font-bold transition-colors ${
                          isFrozen 
                            ? 'bg-emerald-600 hover:bg-emerald-700 text-white' 
                            : 'bg-red-600 hover:bg-red-700 text-white'
                        }`}
                      >
                        {isFrozen ? 'Unfreeze Card' : 'Freeze Card'}
                      </button>
                      <button
                        onClick={() => {
                          setRevealedCvvCardId(showCvv ? null : card.id);
                          if (!showCvv) {
                            setTimeout(() => setRevealedCvvCardId(null), 5000);
                          }
                        }}
                        className="px-4 py-2.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300 rounded-xl font-bold"
                      >
                        {showCvv ? 'Hide CVV' : 'Reveal CVV'}
                      </button>
                    </div>

                    <div className="p-4 bg-slate-50 dark:bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-800 text-xs space-y-2">
                      <div className="flex justify-between">
                        <span className="text-slate-500">Daily Spending Limit:</span>
                        <strong className="text-slate-800 dark:text-slate-200">£{card.dailyLimit.toLocaleString()}</strong>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-500">Online Transactions:</span>
                        <strong className="text-emerald-600">Enabled</strong>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ================= TAB 7: STATEMENTS ================= */}
        {activeTab === 'statements' && (
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-sm space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h2 className="text-xl font-bold text-slate-900 dark:text-white">Account Statements & Reports</h2>
                <p className="text-xs text-slate-500">Generate, print, and export official statement certificates</p>
              </div>
              <button
                onClick={() => setIsStatementOpen(true)}
                className="px-5 py-2.5 bg-[#002752] hover:bg-[#001d3d] text-white font-bold text-xs rounded-xl flex items-center gap-2 shadow"
              >
                <Printer className="w-4 h-4" />
                <span>Open Printable Statement</span>
              </button>
            </div>

            <div className="p-6 bg-slate-50 dark:bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-4 text-xs">
              <h3 className="font-bold text-sm text-[#002752] dark:text-blue-400">Statement Period Summary</h3>
              <div className="grid sm:grid-cols-3 gap-4">
                <div className="p-4 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800">
                  <span className="text-slate-400 block text-[10px] uppercase">Opening Balance</span>
                  <span className="text-base font-black text-slate-900 dark:text-white">£15,000.00</span>
                </div>
                <div className="p-4 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800">
                  <span className="text-slate-400 block text-[10px] uppercase">Current Net Balance</span>
                  <span className="text-base font-black text-emerald-600">£{user.balance.toFixed(2)}</span>
                </div>
                <div className="p-4 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800">
                  <span className="text-slate-400 block text-[10px] uppercase">Total Recorded Transactions</span>
                  <span className="text-base font-black text-slate-900 dark:text-white">{transactions.length}</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ================= TAB 8: VERIFICATION (KYC) ================= */}
        {activeTab === 'verification' && (
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-sm max-w-2xl mx-auto space-y-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 rounded-xl flex items-center justify-center">
                <FileCheck2 className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-slate-900 dark:text-white">Identity Verification (KYC)</h2>
                <p className="text-xs text-slate-500">Tier-1 customer due diligence and compliance documentation</p>
              </div>
            </div>

            {kycSuccessMsg && (
              <div className="p-4 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 rounded-2xl text-xs text-emerald-800 dark:text-emerald-200 flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />
                <span>{kycSuccessMsg}</span>
              </div>
            )}

            {kycErrorMsg && (
              <div className="p-4 bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 rounded-2xl text-xs text-red-700 dark:text-red-300 flex items-start gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                <span>{kycErrorMsg}</span>
              </div>
            )}

            <form onSubmit={handleKycSubmit} className="space-y-4">
              <div className="grid sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Legal Full Name
                  </label>
                  <input
                    type="text"
                    required
                    value={kycForm.fullName}
                    onChange={e => setKycForm({ ...kycForm, fullName: e.target.value })}
                    className="w-full px-3.5 py-2.5 text-xs sm:text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Date of Birth
                  </label>
                  <input
                    type="date"
                    required
                    value={kycForm.dateOfBirth}
                    onChange={e => setKycForm({ ...kycForm, dateOfBirth: e.target.value })}
                    className="w-full px-3.5 py-2.5 text-xs sm:text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl"
                  />
                </div>
              </div>

              <div className="grid sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Country of Residence
                  </label>
                  <input
                    type="text"
                    required
                    value={kycForm.countryOfResidence}
                    onChange={e => setKycForm({ ...kycForm, countryOfResidence: e.target.value })}
                    className="w-full px-3.5 py-2.5 text-xs sm:text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    ID Document Type
                  </label>
                  <select
                    value={kycForm.idDocumentType}
                    onChange={e => setKycForm({ ...kycForm, idDocumentType: e.target.value as any })}
                    className="w-full px-3.5 py-2.5 text-xs sm:text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl"
                  >
                    <option value="passport">International Passport</option>
                    <option value="national_id">National ID Card</option>
                    <option value="drivers_licence">Driving Licence</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Residential Street Address
                </label>
                <input
                  type="text"
                  required
                  value={kycForm.residentialAddress}
                  onChange={e => setKycForm({ ...kycForm, residentialAddress: e.target.value })}
                  className="w-full px-3.5 py-2.5 text-xs sm:text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl"
                />
              </div>

              <div className="grid sm:grid-cols-2 gap-4">
                <div className="p-4 bg-slate-50 dark:bg-slate-950 rounded-2xl border border-dashed border-slate-300 dark:border-slate-700 text-xs text-center space-y-1">
                  <UploadCloud className="w-6 h-6 mx-auto text-slate-400" />
                  <span className="font-bold block text-slate-700 dark:text-slate-300">Front ID Scan</span>
                  <span className="text-[10px] text-slate-500 font-mono">{kycForm.sampleDocFrontName}</span>
                </div>

                <div className="p-4 bg-slate-50 dark:bg-slate-950 rounded-2xl border border-dashed border-slate-300 dark:border-slate-700 text-xs text-center space-y-1">
                  <UploadCloud className="w-6 h-6 mx-auto text-slate-400" />
                  <span className="font-bold block text-slate-700 dark:text-slate-300">Proof of Address</span>
                  <span className="text-[10px] text-slate-500 font-mono">{kycForm.sampleProofOfAddressName}</span>
                </div>
              </div>

              <div className="space-y-2 pt-2">
                <label className="flex items-start gap-2 text-xs text-slate-600 dark:text-slate-400">
                  <input
                    type="checkbox"
                    checked={kycForm.declarationAccepted}
                    onChange={e => setKycForm({ ...kycForm, declarationAccepted: e.target.checked })}
                    className="mt-1"
                  />
                  <span>I declare that all personal identification details provided herein are accurate and true.</span>
                </label>
                <label className="flex items-start gap-2 text-xs text-slate-600 dark:text-slate-400">
                  <input
                    type="checkbox"
                    checked={kycForm.consentAccepted}
                    onChange={e => setKycForm({ ...kycForm, consentAccepted: e.target.checked })}
                    className="mt-1"
                  />
                  <span>I consent to institutional electronic verification by FNB compliance officers.</span>
                </label>
              </div>

              <button
                type="submit"
                disabled={kycLoading || !kycForm.declarationAccepted || !kycForm.consentAccepted}
                className="w-full py-3 bg-[#002752] hover:bg-[#001d3d] text-white font-bold rounded-xl text-sm shadow-md transition-all flex items-center justify-center gap-2"
              >
                <FileCheck2 className="w-4 h-4" />
                <span>{kycLoading ? 'Submitting Documents...' : 'Submit Verification Application'}</span>
              </button>
            </form>
          </div>
        )}

        {/* ================= TAB 9: NOTIFICATIONS ================= */}
        {activeTab === 'notifications' && (
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-sm space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h2 className="text-xl font-bold text-slate-900 dark:text-white">Account Alerts & Notifications</h2>
                <p className="text-xs text-slate-500">Security warnings, compliance notices, and transactional alerts</p>
              </div>
              <div className="flex gap-2">
                {['all', 'verification', 'investment', 'account'].map(cat => (
                  <button
                    key={cat}
                    onClick={() => setNotifCategoryFilter(cat)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold capitalize ${
                      notifCategoryFilter === cat
                        ? 'bg-[#002752] text-white'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            {filteredNotifications.length === 0 ? (
              <p className="text-center py-12 text-slate-400 text-xs">No notifications to display.</p>
            ) : (
              <div className="divide-y divide-slate-100 dark:divide-slate-800">
                {filteredNotifications.map(n => (
                  <div 
                    key={n.id}
                    onClick={() => !n.read && handleMarkNotifRead(n.id)}
                    className={`py-4 flex items-start justify-between gap-4 text-xs cursor-pointer ${
                      !n.read ? 'bg-blue-50/40 dark:bg-blue-950/20 px-3 rounded-2xl' : ''
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${
                        n.type === 'success' 
                          ? 'bg-emerald-100 text-emerald-600'
                          : 'bg-blue-100 text-[#002752]'
                      }`}>
                        <Bell className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <strong className="font-bold text-slate-900 dark:text-white text-sm">{n.title}</strong>
                          {!n.read && (
                            <span className="w-2 h-2 rounded-full bg-red-600"></span>
                          )}
                        </div>
                        <p className="text-slate-600 dark:text-slate-400 mt-1 leading-relaxed">{n.message}</p>
                        <span className="text-[10px] text-slate-400 mt-1 block font-mono">
                          {new Date(n.createdAt).toLocaleString()}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ================= TAB 10: CUSTOMER SUPPORT ================= */}
        {activeTab === 'support' && (
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-sm max-w-2xl mx-auto space-y-6">
            <div>
              <h2 className="text-xl font-bold text-slate-900 dark:text-white">Customer Support & Direct Tickets</h2>
              <p className="text-xs text-slate-500">Contact our 24/7 client relations desk directly from your portal</p>
            </div>

            {supportSuccess && (
              <div className="p-4 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 rounded-2xl text-xs text-emerald-800 dark:text-emerald-200 flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />
                <span>{supportSuccess}</span>
              </div>
            )}

            {supportError && (
              <div className="p-4 bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 rounded-2xl text-xs text-red-700 dark:text-red-300 flex items-start gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                <span>{supportError}</span>
              </div>
            )}

            <form onSubmit={handleSupportSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Enquiry Category
                </label>
                <select
                  value={supportForm.category}
                  onChange={e => setSupportForm({ ...supportForm, category: e.target.value })}
                  className="w-full px-3.5 py-2.5 text-xs sm:text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl"
                >
                  <option value="general">General Banking Assistance</option>
                  <option value="technical">Technical / Security Issue</option>
                  <option value="account">Account & Wire Query</option>
                  <option value="complaint">Formal Complaint</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Subject Line
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Question about my investment yield"
                  value={supportForm.subject}
                  onChange={e => setSupportForm({ ...supportForm, subject: e.target.value })}
                  className="w-full px-3.5 py-2.5 text-xs sm:text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Message Details
                </label>
                <textarea
                  rows={4}
                  required
                  placeholder="Describe your issue or query..."
                  value={supportForm.message}
                  onChange={e => setSupportForm({ ...supportForm, message: e.target.value })}
                  className="w-full px-3.5 py-2.5 text-xs sm:text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl"
                />
              </div>

              <button
                type="submit"
                disabled={supportLoading}
                className="w-full py-3 bg-[#c8102e] hover:bg-[#a50d26] text-white font-bold rounded-xl text-sm shadow-md transition-all flex items-center justify-center gap-2"
              >
                <MessageSquare className="w-4 h-4" />
                <span>{supportLoading ? 'Submitting Ticket...' : 'Submit Support Ticket'}</span>
              </button>
            </form>

            {/* List of user's support enquiries */}
            {supportEnquiries.length > 0 && (
              <div className="pt-6 border-t border-slate-200 dark:border-slate-800 space-y-3">
                <h3 className="font-bold text-sm text-slate-900 dark:text-white">My Support Tickets</h3>
                <div className="space-y-3">
                  {supportEnquiries.map(ticket => (
                    <div key={ticket.id} className="p-4 bg-slate-50 dark:bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-800 text-xs space-y-1">
                      <div className="flex justify-between items-center">
                        <strong className="text-slate-900 dark:text-white">{ticket.subject}</strong>
                        <span className="px-2 py-0.5 rounded-full font-bold uppercase text-[9px] bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300">
                          {ticket.status}
                        </span>
                      </div>
                      <p className="text-slate-500">Ref: {ticket.reference} • {new Date(ticket.createdAt).toLocaleDateString()}</p>
                      {ticket.adminReply && (
                        <div className="mt-2 p-2.5 bg-white dark:bg-slate-900 rounded-xl border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300">
                          <strong>Admin Reply:</strong> {ticket.adminReply}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* ================= TAB 11: SETTINGS ================= */}
        {activeTab === 'settings' && (
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-sm max-w-2xl mx-auto space-y-8">
            <div>
              <h2 className="text-xl font-bold text-slate-900 dark:text-white">Security & Profile Settings</h2>
              <p className="text-xs text-slate-500">Update your customer profile details and manage login security</p>
            </div>

            {settingsMessage && (
              <div className="p-4 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 rounded-2xl text-xs text-emerald-800 dark:text-emerald-200">
                {settingsMessage}
              </div>
            )}

            {settingsError && (
              <div className="p-4 bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 rounded-2xl text-xs text-red-700 dark:text-red-300">
                {settingsError}
              </div>
            )}

            {/* Profile Update */}
            <form onSubmit={handleSaveProfile} className="space-y-4">
              <h3 className="font-bold text-sm text-[#002752] dark:text-blue-400">Personal Information</h3>
              <div className="grid sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    First Name
                  </label>
                  <input
                    type="text"
                    value={settingsProfile.firstName}
                    onChange={e => setSettingsProfile({ ...settingsProfile, firstName: e.target.value })}
                    className="w-full px-3.5 py-2.5 text-xs sm:text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Last Name
                  </label>
                  <input
                    type="text"
                    value={settingsProfile.lastName}
                    onChange={e => setSettingsProfile({ ...settingsProfile, lastName: e.target.value })}
                    className="w-full px-3.5 py-2.5 text-xs sm:text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Contact Phone
                </label>
                <input
                  type="tel"
                  value={settingsProfile.phone}
                  onChange={e => setSettingsProfile({ ...settingsProfile, phone: e.target.value })}
                  className="w-full px-3.5 py-2.5 text-xs sm:text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl"
                />
              </div>

              <button
                type="submit"
                className="px-6 py-2.5 bg-[#002752] hover:bg-[#001d3d] text-white font-bold rounded-xl text-xs shadow"
              >
                Save Profile Changes
              </button>
            </form>

            {/* Change Password */}
            <form onSubmit={handleChangePassword} className="space-y-4 pt-6 border-t border-slate-200 dark:border-slate-800">
              <h3 className="font-bold text-sm text-[#002752] dark:text-blue-400">Change Confidential Password</h3>
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Current Password
                </label>
                <input
                  type="password"
                  required
                  value={passwords.current}
                  onChange={e => setPasswords({ ...passwords, current: e.target.value })}
                  className="w-full px-3.5 py-2.5 text-xs sm:text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl"
                />
              </div>
              <div className="grid sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    New Password
                  </label>
                  <input
                    type="password"
                    required
                    value={passwords.new}
                    onChange={e => setPasswords({ ...passwords, new: e.target.value })}
                    className="w-full px-3.5 py-2.5 text-xs sm:text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Confirm New Password
                  </label>
                  <input
                    type="password"
                    required
                    value={passwords.confirm}
                    onChange={e => setPasswords({ ...passwords, confirm: e.target.value })}
                    className="w-full px-3.5 py-2.5 text-xs sm:text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="px-6 py-2.5 bg-[#c8102e] hover:bg-[#a50d26] text-white font-bold rounded-xl text-xs shadow"
              >
                Update Password
              </button>
            </form>

            {/* Active Login Sessions */}
            <div className="pt-6 border-t border-slate-200 dark:border-slate-800 space-y-3">
              <h3 className="font-bold text-sm text-[#002752] dark:text-blue-400">Recent Login Sessions</h3>
              <div className="space-y-2">
                {loginActivities.slice(0, 3).map(act => (
                  <div key={act.id} className="p-3 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-200 dark:border-slate-800 text-xs flex justify-between items-center">
                    <div>
                      <strong className="text-slate-900 dark:text-white">{act.device || 'Authorized Browser'}</strong>
                      <span className="text-slate-500 block text-[10px] font-mono">{act.ipAddress}</span>
                    </div>
                    <span className="text-[10px] text-slate-400">{new Date(act.timestamp).toLocaleTimeString()}</span>
                  </div>
                ))}
              </div>
            </div>

          </div>
        )}

      </div>

      {/* Receipts & Statements Modals */}
      {activeReceiptTx && (
        <ReceiptModal
          transaction={activeReceiptTx}
          onClose={() => setActiveReceiptTx(null)}
          onReversalSuccess={async () => {
            await refreshUser();
            await fetchDashboardData();
          }}
        />
      )}

      {isStatementOpen && (
        <StatementModal
          user={user}
          transactions={transactions}
          onClose={() => setIsStatementOpen(false)}
        />
      )}

    </div>
  );
};
