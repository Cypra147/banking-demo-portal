import React, { useState, useEffect, useCallback } from 'react';
import { useAuth } from '../context/AuthContext.tsx';
import { api } from '../services/api.ts';
import { 
  User, 
  Transaction, 
  AuditLog, 
  InvestmentRequest, 
  VerificationRequest, 
  SupportEnquiry 
} from '../types.ts';
import { StatementModal } from '../components/StatementModal.tsx';
import { ReceiptModal } from '../components/ReceiptModal.tsx';
import { TransactionTagBadge } from '../components/TransactionTagBadge.tsx';
import { tagTransaction } from '../utils/transactionTagger.ts';
import { 
  ShieldCheck, 
  Users, 
  Clock, 
  CheckCircle2, 
  XCircle, 
  Snowflake, 
  Ban, 
  Edit, 
  PlusCircle, 
  MinusCircle, 
  FileText, 
  RotateCcw, 
  Search, 
  Filter, 
  AlertTriangle,
  CreditCard,
  Building2,
  DollarSign,
  TrendingUp,
  Activity,
  UserCheck,
  Download,
  Mail,
  Shield,
  Eye,
  FileCheck2,
  MessageSquare,
  MessageCircle,
  HelpCircle,
  Send,
  Layers,
  ArrowRight,
  History
} from 'lucide-react';

export const AdminDashboard: React.FC = () => {
  const { adminUser, setIsMailModalOpen, logout } = useAuth();

  // Navigation sub-tabs
  const [activeTab, setActiveTab] = useState<'overview' | 'customers' | 'verifications' | 'investments' | 'transactions' | 'support' | 'audit'>('overview');

  // Data states
  const [stats, setStats] = useState<any>(null);
  const [customers, setCustomers] = useState<User[]>([]);
  const [ledger, setLedger] = useState<Transaction[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [investments, setInvestments] = useState<InvestmentRequest[]>([]);
  const [verifications, setVerifications] = useState<VerificationRequest[]>([]);
  const [supportEnquiries, setSupportEnquiries] = useState<SupportEnquiry[]>([]);
  const [loading, setLoading] = useState(true);

  // Search & Filter
  const [customerSearch, setCustomerSearch] = useState('');
  const [customerStatusFilter, setCustomerStatusFilter] = useState<'all' | 'pending_approval' | 'active' | 'frozen' | 'suspended'>('all');
  const [txSearch, setTxSearch] = useState('');
  const [verifFilter, setVerifFilter] = useState<string>('all');
  const [invFilter, setInvFilter] = useState<string>('all');

  // Modals state
  // 1. Credit / Debit Modal
  const [creditDebitModal, setCreditDebitModal] = useState<{
    isOpen: boolean;
    customer: User | null;
    type: 'credit' | 'debit';
    amount: string;
    description: string;
    reference: string;
  }>({
    isOpen: false,
    customer: null,
    type: 'credit',
    amount: '',
    description: '',
    reference: '',
  });

  // 2. Edit Profile Modal
  const [editProfileModal, setEditProfileModal] = useState<{
    isOpen: boolean;
    customer: User | null;
    firstName: string;
    lastName: string;
    phone: string;
    username: string;
  }>({
    isOpen: false,
    customer: null,
    firstName: '',
    lastName: '',
    phone: '',
    username: '',
  });

  // 3. Support Reply Modal
  const [replyTicketModal, setReplyTicketModal] = useState<{
    isOpen: boolean;
    ticket: SupportEnquiry | null;
    replyText: string;
    status: 'open' | 'in_progress' | 'resolved';
  }>({
    isOpen: false,
    ticket: null,
    replyText: '',
    status: 'resolved',
  });

  // 4. Statement Modal for a selected customer
  const [statementCustomer, setStatementCustomer] = useState<User | null>(null);

  // 5. Receipt Modal
  const [activeReceiptTx, setActiveReceiptTx] = useState<Transaction | null>(null);

  // Action status notification
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  const fetchAdminData = useCallback(async () => {
    try {
      setLoading(true);
      const [statsRes, custRes, ledgerRes, auditRes, invRes, verRes, supRes] = await Promise.all([
        api.getAdminStats(),
        api.getAdminCustomers(),
        api.getAdminLedger(),
        api.getAdminAuditLogs(),
        api.getInvestments(true).catch(() => ({ investments: [] })),
        api.getVerifications(true).catch(() => ({ verifications: [] })),
        api.getSupportEnquiries(undefined, true).catch(() => ({ enquiries: [] })),
      ]);

      setStats(statsRes);
      setCustomers(custRes.customers || []);
      setLedger(ledgerRes.ledger || []);
      setAuditLogs(auditRes.auditLogs || []);
      setInvestments(invRes.investments || []);
      setVerifications(verRes.verifications || []);
      setSupportEnquiries(supRes.enquiries || []);
    } catch (err: any) {
      console.error(err);
      setFeedback({ type: 'error', message: err.message || 'Failed to load administrator data.' });
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchAdminData();
  }, [fetchAdminData]);

  const showNotification = (type: 'success' | 'error', message: string) => {
    setFeedback({ type, message });
    setTimeout(() => setFeedback(null), 5000);
  };

  // --- Customer Actions ---
  const handleApprove = async (customerId: string) => {
    try {
      const res = await api.approveCustomer(customerId, 10000); // assigns £10,000 initial sandbox credit
      showNotification('success', res.message);
      await fetchAdminData();
    } catch (err: any) {
      showNotification('error', err.message || 'Approval failed');
    }
  };

  const handleReject = async (customerId: string) => {
    const reason = prompt('Please enter rejection reason to be sent to applicant:', 'Application details could not be verified.');
    if (!reason) return;
    try {
      const res = await api.rejectCustomer(customerId, reason);
      showNotification('success', res.message);
      await fetchAdminData();
    } catch (err: any) {
      showNotification('error', err.message || 'Rejection failed');
    }
  };

  const handleToggleFreeze = async (customer: User) => {
    const nextStatus = customer.status === 'frozen' ? 'active' : 'frozen';
    try {
      const res = await api.setCustomerStatus(customer.id, nextStatus);
      showNotification('success', res.message);
      await fetchAdminData();
    } catch (err: any) {
      showNotification('error', err.message || 'Status update failed');
    }
  };

  const handleToggleSuspend = async (customer: User) => {
    const nextStatus = customer.status === 'suspended' ? 'active' : 'suspended';
    try {
      const res = await api.setCustomerStatus(customer.id, nextStatus);
      showNotification('success', res.message);
      await fetchAdminData();
    } catch (err: any) {
      showNotification('error', err.message || 'Status update failed');
    }
  };

  // Submit Credit / Debit
  const handleCreditDebitSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!creditDebitModal.customer) return;

    const amt = parseFloat(creditDebitModal.amount);
    if (isNaN(amt) || amt <= 0) {
      alert('Please enter a valid amount.');
      return;
    }

    try {
      const res = await api.adminCreditDebit({
        customerId: creditDebitModal.customer.id,
        type: creditDebitModal.type,
        amount: amt,
        description: creditDebitModal.description || `Administrative ${creditDebitModal.type}`,
        reference: creditDebitModal.reference || undefined,
      });

      showNotification('success', res.message);
      setCreditDebitModal({ isOpen: false, customer: null, type: 'credit', amount: '', description: '', reference: '' });
      await fetchAdminData();
    } catch (err: any) {
      alert(err.message || 'Action failed');
    }
  };

  // Submit Profile Edit
  const handleEditProfileSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editProfileModal.customer) return;
    try {
      const res = await api.updateCustomerProfile(editProfileModal.customer.id, {
        firstName: editProfileModal.firstName,
        lastName: editProfileModal.lastName,
        phone: editProfileModal.phone,
        username: editProfileModal.username,
      });
      showNotification('success', 'Customer profile updated.');
      setEditProfileModal({ isOpen: false, customer: null, firstName: '', lastName: '', phone: '', username: '' });
      await fetchAdminData();
    } catch (err: any) {
      alert(err.message || 'Profile update failed');
    }
  };

  // Manual Reversal
  const handleAdminReversal = async (txId: string) => {
    if (!confirm('Are you sure you want to execute an immediate administrative reversal and refund for this transaction?')) {
      return;
    }
    try {
      const res = await api.adminReversal(txId);
      showNotification('success', res.message);
      await fetchAdminData();
    } catch (err: any) {
      showNotification('error', err.message || 'Reversal failed');
    }
  };

  // Verification Status Update
  const handleUpdateVerification = async (id: string, status: 'approved' | 'rejected') => {
    const comments = prompt(`Enter optional comments for setting verification to ${status.toUpperCase()}:`, status === 'approved' ? 'Verified by compliance officer.' : 'Document details illegible.');
    try {
      await api.updateVerificationStatus(id, status, comments || undefined);
      showNotification('success', `Verification marked as ${status}.`);
      await fetchAdminData();
    } catch (err: any) {
      showNotification('error', err.message || 'Failed to update verification status.');
    }
  };

  // Investment Status Update
  const handleUpdateInvestment = async (id: string, status: 'approved' | 'active' | 'rejected') => {
    const comments = prompt(`Enter administrative note for setting investment to ${status.toUpperCase()}:`, 'Authorized by FNB Asset Management.');
    try {
      await api.updateInvestmentStatus(id, status, comments || undefined);
      showNotification('success', `Investment marked as ${status}.`);
      await fetchAdminData();
    } catch (err: any) {
      showNotification('error', err.message || 'Failed to update investment status.');
    }
  };

  // Support Reply Submit
  const handleSupportReplySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!replyTicketModal.ticket) return;
    try {
      await api.replySupportEnquiry(
        replyTicketModal.ticket.id, 
        replyTicketModal.replyText, 
        replyTicketModal.status
      );
      showNotification('success', 'Reply dispatched to customer email and dashboard.');
      setReplyTicketModal({ isOpen: false, ticket: null, replyText: '', status: 'resolved' });
      await fetchAdminData();
    } catch (err: any) {
      alert(err.message || 'Failed to send reply');
    }
  };

  // Filter customers
  const filteredCustomers = customers.filter(c => {
    const matchesSearch = 
      c.firstName.toLowerCase().includes(customerSearch.toLowerCase()) ||
      c.lastName.toLowerCase().includes(customerSearch.toLowerCase()) ||
      c.email.toLowerCase().includes(customerSearch.toLowerCase()) ||
      c.username.toLowerCase().includes(customerSearch.toLowerCase()) ||
      (c.accountNumber && c.accountNumber.includes(customerSearch));

    if (customerStatusFilter === 'all') return matchesSearch;
    return matchesSearch && c.status === customerStatusFilter;
  });

  const pendingCustomers = customers.filter(c => c.status === 'pending_approval');
  const pendingVerifications = verifications.filter(v => v.status === 'pending_review');
  const pendingInvestments = investments.filter(i => i.status === 'pending_review');
  const openTickets = supportEnquiries.filter(s => s.status === 'open' || s.status === 'in_progress');

  return (
    <div className="min-h-screen bg-slate-100 dark:bg-slate-950 text-slate-800 dark:text-slate-100 py-6 px-4 sm:px-8 transition-colors">
      <div className="max-w-7xl mx-auto space-y-6">

        {/* Status Notification Toast */}
        {feedback && (
          <div className={`p-4 rounded-2xl flex items-center justify-between text-xs sm:text-sm font-semibold shadow-md ${
            feedback.type === 'success' 
              ? 'bg-emerald-600 text-white' 
              : 'bg-red-600 text-white'
          }`}>
            <span>{feedback.message}</span>
            <button onClick={() => setFeedback(null)} className="ml-4 font-bold">×</button>
          </div>
        )}

        {/* Master Admin Header Card */}
        <div className="bg-[#002752] text-white rounded-3xl p-6 sm:p-8 shadow-xl border border-blue-900/50 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 bg-gradient-to-br from-red-600 to-amber-500 rounded-2xl flex items-center justify-center text-white shadow-lg shrink-0">
              <ShieldCheck className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 rounded-full bg-red-600/30 border border-red-500/40 text-red-300 font-bold text-[10px] tracking-wider uppercase">
                  MASTER ADMINISTRATOR
                </span>
                <span className="text-xs text-slate-400">fnbadmin</span>
              </div>
              <h1 className="text-xl sm:text-2xl font-black mt-1">
                FNB Central Banking Administrator Console
              </h1>
              <p className="text-xs text-slate-300 mt-0.5">
                Session: <strong className="text-white">admin@fnnbbankss.online</strong> • Sovereign Control Desk
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsMailModalOpen(true)}
              className="px-4 py-2 bg-white/10 hover:bg-white/20 text-white font-bold rounded-xl text-xs border border-white/20 transition-all flex items-center gap-1.5"
            >
              <Mail className="w-3.5 h-3.5" />
              <span>Simulated In-App Mailbox</span>
            </button>
            <button
              onClick={logout}
              className="px-4 py-2 bg-[#c8102e] hover:bg-[#a50d26] text-white font-bold rounded-xl text-xs shadow-md transition-all flex items-center gap-1.5"
            >
              <span>Logout</span>
            </button>
          </div>
        </div>

        {/* Sub-Navigation Tabs */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-2 border border-slate-200 dark:border-slate-800 shadow-sm overflow-x-auto">
          <div className="flex items-center gap-2 min-w-max text-xs font-bold">
            {[
              { id: 'overview', label: 'Overview Stats', icon: Layers },
              { id: 'customers', label: `Customers (${customers.length})`, icon: Users, badge: pendingCustomers.length },
              { id: 'verifications', label: `KYC Verifications (${verifications.length})`, icon: FileCheck2, badge: pendingVerifications.length },
              { id: 'investments', label: `Investments (${investments.length})`, icon: TrendingUp, badge: pendingInvestments.length },
              { id: 'transactions', label: `Ledger (${ledger.length})`, icon: History },
              { id: 'support', label: `Support Tickets (${supportEnquiries.length})`, icon: MessageSquare, badge: openTickets.length },
              { id: 'audit', label: `Audit Trail (${auditLogs.length})`, icon: Shield },
            ].map(tab => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`px-3.5 py-2 rounded-xl transition-all flex items-center gap-1.5 whitespace-nowrap ${
                    isActive
                      ? 'bg-[#002752] text-white shadow-sm'
                      : 'hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{tab.label}</span>
                  {tab.badge !== undefined && tab.badge > 0 && (
                    <span className="w-4 h-4 rounded-full bg-red-600 text-white text-[9px] flex items-center justify-center font-bold">
                      {tab.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* ================= TAB: OVERVIEW STATS ================= */}
        {activeTab === 'overview' && (
          <div className="space-y-6">
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Total Customer Accounts</span>
                <p className="text-3xl font-black text-slate-900 dark:text-white mt-1">{customers.length}</p>
                <span className="text-[11px] text-emerald-600 font-semibold mt-1 block">
                  {customers.filter(c => c.status === 'active').length} Active Accounts
                </span>
              </div>

              <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Pending Registrations</span>
                <p className="text-3xl font-black text-amber-600 mt-1">{pendingCustomers.length}</p>
                <button onClick={() => setActiveTab('customers')} className="text-[11px] text-[#002752] dark:text-blue-400 font-bold hover:underline mt-1 block">
                  Review Applications →
                </button>
              </div>

              <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Pending KYC Reviews</span>
                <p className="text-3xl font-black text-red-600 mt-1">{pendingVerifications.length}</p>
                <button onClick={() => setActiveTab('verifications')} className="text-[11px] text-[#002752] dark:text-blue-400 font-bold hover:underline mt-1 block">
                  Review KYC Docs →
                </button>
              </div>

              <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Pending Investments</span>
                <p className="text-3xl font-black text-[#002752] dark:text-blue-400 mt-1">{pendingInvestments.length}</p>
                <button onClick={() => setActiveTab('investments')} className="text-[11px] text-[#002752] dark:text-blue-400 font-bold hover:underline mt-1 block">
                  Review Allocations →
                </button>
              </div>
            </div>

            {/* Quick Pending Applicants List */}
            {pendingCustomers.length > 0 && (
              <div className="bg-amber-50 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-700/60 rounded-3xl p-6 shadow-sm">
                <h3 className="font-bold text-base text-amber-900 dark:text-amber-200 mb-2 flex items-center gap-2">
                  <Clock className="w-5 h-5 text-amber-700 dark:text-amber-400" />
                  <span>Applicant Registrations Awaiting Approval ({pendingCustomers.length})</span>
                </h3>
                <div className="divide-y divide-amber-200 dark:divide-amber-800 mt-4">
                  {pendingCustomers.map(applicant => (
                    <div key={applicant.id} className="py-3 flex items-center justify-between gap-4 text-xs">
                      <div>
                        <strong className="text-slate-900 dark:text-white text-sm">{applicant.firstName} {applicant.lastName}</strong>
                        <p className="text-slate-600 dark:text-slate-400">{applicant.email} • {applicant.phone}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => handleApprove(applicant.id)}
                          className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow-sm text-xs"
                        >
                          Approve & Issue Account
                        </button>
                        <button
                          onClick={() => handleReject(applicant.id)}
                          className="px-3.5 py-1.5 bg-red-600 hover:bg-red-700 text-white font-bold rounded-xl shadow-sm text-xs"
                        >
                          Reject
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* ================= TAB: CUSTOMER MANAGEMENT ================= */}
        {activeTab === 'customers' && (
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-sm space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h2 className="text-xl font-bold text-slate-900 dark:text-white">Customer Account Directory</h2>
                <p className="text-xs text-slate-500">Approve registrations, generate account numbers, freeze/suspend, or authorize adjustments</p>
              </div>
            </div>

            {/* Search and Status Filters */}
            <div className="flex flex-col sm:flex-row gap-3">
              <div className="relative flex-1">
                <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search by customer name, email, account number, or username..."
                  value={customerSearch}
                  onChange={e => setCustomerSearch(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl"
                />
              </div>
              <select
                value={customerStatusFilter}
                onChange={e => setCustomerStatusFilter(e.target.value as any)}
                className="px-3 py-2 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl"
              >
                <option value="all">All Statuses</option>
                <option value="pending_approval">Pending Approval</option>
                <option value="active">Active</option>
                <option value="frozen">Frozen</option>
                <option value="suspended">Suspended</option>
              </select>
            </div>

            {/* Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 dark:bg-slate-950 text-slate-400 uppercase text-[10px] font-bold border-b border-slate-200 dark:border-slate-800">
                  <tr>
                    <th className="py-3 px-4">Customer Name</th>
                    <th className="py-3 px-4">Account Number</th>
                    <th className="py-3 px-4">Balance</th>
                    <th className="py-3 px-4">KYC Tier</th>
                    <th className="py-3 px-4">Status</th>
                    <th className="py-3 px-4 text-right">Administrative Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {filteredCustomers.map(cust => (
                    <tr key={cust.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-950/40">
                      <td className="py-3.5 px-4">
                        <strong className="font-bold text-slate-900 dark:text-white text-sm block">
                          {cust.firstName} {cust.lastName}
                        </strong>
                        <span className="text-slate-400 text-[11px] block">{cust.email} • {cust.phone}</span>
                      </td>
                      <td className="py-3.5 px-4 font-mono font-bold text-slate-800 dark:text-slate-200">
                        {cust.accountNumber || (
                          <span className="text-amber-600 font-sans text-[11px] italic">Not Assigned</span>
                        )}
                      </td>
                      <td className="py-3.5 px-4 font-black text-slate-900 dark:text-white">
                        {cust.currency}{(cust.balance || 0).toFixed(2)}
                      </td>
                      <td className="py-3.5 px-4">
                        <span className={`px-2 py-0.5 rounded-full font-bold uppercase text-[9px] ${
                          cust.kycStatus === 'verified' ? 'bg-blue-100 text-blue-800' : 'bg-slate-100 text-slate-600'
                        }`}>
                          {cust.kycStatus || 'Unverified'}
                        </span>
                      </td>
                      <td className="py-3.5 px-4">
                        <span className={`px-2.5 py-0.5 rounded-full font-bold uppercase text-[10px] ${
                          cust.status === 'active'
                            ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                            : cust.status === 'frozen'
                            ? 'bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300'
                            : cust.status === 'suspended'
                            ? 'bg-red-100 text-red-800 dark:bg-red-950 dark:text-red-300'
                            : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                        }`}>
                          {cust.status.replace('_', ' ')}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5 flex-wrap">
                          {cust.status === 'pending_approval' ? (
                            <>
                              <button
                                onClick={() => handleApprove(cust.id)}
                                className="px-3 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-bold text-[11px]"
                              >
                                Approve
                              </button>
                              <button
                                onClick={() => handleReject(cust.id)}
                                className="px-3 py-1 bg-red-600 hover:bg-red-700 text-white rounded-lg font-bold text-[11px]"
                              >
                                Reject
                              </button>
                            </>
                          ) : (
                            <>
                              <button
                                onClick={() => setCreditDebitModal({
                                  isOpen: true,
                                  customer: cust,
                                  type: 'credit',
                                  amount: '',
                                  description: '',
                                  reference: '',
                                })}
                                className="px-2.5 py-1 bg-emerald-50 text-emerald-700 hover:bg-emerald-100 dark:bg-emerald-950 dark:text-emerald-300 rounded-lg font-bold text-[11px]"
                              >
                                + Credit
                              </button>
                              <button
                                onClick={() => setCreditDebitModal({
                                  isOpen: true,
                                  customer: cust,
                                  type: 'debit',
                                  amount: '',
                                  description: '',
                                  reference: '',
                                })}
                                className="px-2.5 py-1 bg-red-50 text-red-700 hover:bg-red-100 dark:bg-red-950 dark:text-red-300 rounded-lg font-bold text-[11px]"
                              >
                                - Debit
                              </button>
                              <button
                                onClick={() => handleToggleFreeze(cust)}
                                className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-lg font-semibold text-[11px]"
                              >
                                {cust.status === 'frozen' ? 'Unfreeze' : 'Freeze'}
                              </button>
                              <button
                                onClick={() => setStatementCustomer(cust)}
                                className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-lg font-semibold text-[11px]"
                              >
                                Statement
                              </button>
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* ================= TAB: KYC VERIFICATIONS ================= */}
        {activeTab === 'verifications' && (
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-sm space-y-6">
            <div>
              <h2 className="text-xl font-bold text-slate-900 dark:text-white">KYC Identity Verifications</h2>
              <p className="text-xs text-slate-500">Review identification scans, proofs of address, and compliance declarations</p>
            </div>

            {verifications.length === 0 ? (
              <p className="text-center py-12 text-slate-400 text-xs">No verification requests submitted.</p>
            ) : (
              <div className="divide-y divide-slate-100 dark:divide-slate-800">
                {verifications.map(ver => (
                  <div key={ver.id} className="py-5 flex flex-col md:flex-row md:items-center justify-between gap-4 text-xs">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <strong className="text-sm font-bold text-slate-900 dark:text-white">{ver.fullName}</strong>
                        <span className="font-mono text-slate-400">({ver.reference})</span>
                        <span className={`px-2 py-0.5 rounded-full font-bold uppercase text-[9px] ${
                          ver.status === 'approved' ? 'bg-emerald-100 text-emerald-800' : ver.status === 'rejected' ? 'bg-red-100 text-red-800' : 'bg-amber-100 text-amber-800'
                        }`}>
                          {ver.status.replace('_', ' ')}
                        </span>
                      </div>
                      <p className="text-slate-500">
                        DOB: {ver.dateOfBirth} • Country: {ver.countryOfResidence} • Address: {ver.residentialAddress}
                      </p>
                      <p className="text-slate-500">
                        Document: <strong className="capitalize">{ver.idDocumentType}</strong> ({ver.sampleDocFrontName}) • Proof of Address: ({ver.sampleProofOfAddressName})
                      </p>
                    </div>

                    <div className="flex items-center gap-2">
                      {ver.status === 'pending_review' && (
                        <>
                          <button
                            onClick={() => handleUpdateVerification(ver.id, 'approved')}
                            className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs shadow-sm"
                          >
                            Approve KYC
                          </button>
                          <button
                            onClick={() => handleUpdateVerification(ver.id, 'rejected')}
                            className="px-3.5 py-2 bg-red-600 hover:bg-red-700 text-white font-bold rounded-xl text-xs shadow-sm"
                          >
                            Reject
                          </button>
                        </>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ================= TAB: INVESTMENTS ================= */}
        {activeTab === 'investments' && (
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-sm space-y-6">
            <div>
              <h2 className="text-xl font-bold text-slate-900 dark:text-white">Customer Investment Portfolios</h2>
              <p className="text-xs text-slate-500">Approve or reject customer simulated investment allocations</p>
            </div>

            {investments.length === 0 ? (
              <p className="text-center py-12 text-slate-400 text-xs">No investment applications logged.</p>
            ) : (
              <div className="divide-y divide-slate-100 dark:divide-slate-800">
                {investments.map(inv => (
                  <div key={inv.id} className="py-4 flex flex-col md:flex-row md:items-center justify-between gap-4 text-xs">
                    <div>
                      <div className="flex items-center gap-2">
                        <strong className="text-sm font-bold text-slate-900 dark:text-white">{inv.planName}</strong>
                        <span className="font-mono text-slate-400">({inv.reference})</span>
                        <span className={`px-2 py-0.5 rounded-full font-bold uppercase text-[9px] ${
                          inv.status === 'approved' || inv.status === 'active'
                            ? 'bg-emerald-100 text-emerald-800'
                            : inv.status === 'rejected'
                            ? 'bg-red-100 text-red-800'
                            : 'bg-amber-100 text-amber-800'
                        }`}>
                          {inv.status.replace('_', ' ')}
                        </span>
                      </div>
                      <p className="text-slate-500 mt-1">
                        Customer: <strong className="text-slate-800 dark:text-slate-200">{inv.userName}</strong> ({inv.userEmail}) • Amount: <strong className="text-slate-900 dark:text-white">£{inv.amount.toLocaleString()}</strong> • Projected: +£{inv.projectedReturnAmount.toFixed(2)}
                      </p>
                    </div>

                    <div className="flex items-center gap-2">
                      {inv.status === 'pending_review' && (
                        <>
                          <button
                            onClick={() => handleUpdateInvestment(inv.id, 'approved')}
                            className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs shadow-sm"
                          >
                            Approve Portfolio
                          </button>
                          <button
                            onClick={() => handleUpdateInvestment(inv.id, 'rejected')}
                            className="px-3.5 py-2 bg-red-600 hover:bg-red-700 text-white font-bold rounded-xl text-xs shadow-sm"
                          >
                            Reject & Refund
                          </button>
                        </>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ================= TAB: TRANSACTIONS & REVERSALS ================= */}
        {activeTab === 'transactions' && (
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-sm space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h2 className="text-xl font-bold text-slate-900 dark:text-white">Bank-wide Transaction Ledger</h2>
                <p className="text-xs text-slate-500">Inspect all customer debits, credits, transfers, and trigger administrative reversals</p>
              </div>
            </div>

            <div className="divide-y divide-slate-100 dark:divide-slate-800">
              {ledger.map(tx => (
                <div key={tx.id} className="py-4 flex items-center justify-between gap-4 text-xs">
                  <div>
                    <div className="flex flex-wrap items-center gap-2">
                      <strong className="text-slate-900 dark:text-white text-sm block">{tx.description}</strong>
                      <TransactionTagBadge 
                        tag={tx.tag || tagTransaction(tx.description, tx.type, tx.billerCategory).tag} 
                        showIcon 
                      />
                    </div>
                    <div className="flex items-center gap-2 text-slate-400 font-mono text-[11px] mt-0.5">
                      <span>{tx.reference}</span>
                      <span>•</span>
                      <span>{tx.customerName}</span>
                      <span>•</span>
                      <span>{new Date(tx.createdAt).toLocaleString()}</span>
                      {tx.isReversed && (
                        <span className="px-1.5 py-0.2 bg-amber-100 text-amber-800 rounded font-sans text-[9px]">
                          REVERSED
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <span className="font-black text-sm text-slate-900 dark:text-white">
                      {tx.currency}{tx.amount.toFixed(2)}
                    </span>
                    {tx.type === 'transfer' && !tx.isReversed && (
                      <button
                        onClick={() => handleAdminReversal(tx.id)}
                        className="px-3 py-1 bg-red-600 hover:bg-red-700 text-white font-bold rounded-lg text-[11px]"
                      >
                        Force Reversal
                      </button>
                    )}
                    <button
                      onClick={() => setActiveReceiptTx(tx)}
                      className="text-[#002752] dark:text-blue-400 font-bold hover:underline"
                    >
                      Receipt
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ================= TAB: SUPPORT TICKETS ================= */}
        {activeTab === 'support' && (
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-sm space-y-6">
            <div>
              <h2 className="text-xl font-bold text-slate-900 dark:text-white">Support & Complaints Queue</h2>
              <p className="text-xs text-slate-500">Manage client tickets, dispatch email replies, and resolve customer complaints</p>
            </div>

            {supportEnquiries.length === 0 ? (
              <p className="text-center py-12 text-slate-400 text-xs">No customer support tickets received.</p>
            ) : (
              <div className="divide-y divide-slate-100 dark:divide-slate-800">
                {supportEnquiries.map(ticket => (
                  <div key={ticket.id} className="py-4 flex flex-col md:flex-row md:items-center justify-between gap-4 text-xs">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <strong className="text-sm font-bold text-slate-900 dark:text-white">{ticket.subject}</strong>
                        <span className="font-mono text-slate-400">({ticket.reference})</span>
                        <span className="px-2 py-0.5 rounded-full font-bold uppercase text-[9px] bg-blue-100 text-blue-800">
                          {ticket.category}
                        </span>
                        <span className="px-2 py-0.5 rounded-full font-bold uppercase text-[9px] bg-slate-100 text-slate-800">
                          {ticket.status}
                        </span>
                      </div>
                      <p className="text-slate-600 dark:text-slate-300">"{ticket.message}"</p>
                      <p className="text-slate-400 text-[11px]">From: {ticket.name} ({ticket.email}) • {new Date(ticket.createdAt).toLocaleString()}</p>
                      {ticket.adminReply && (
                        <p className="text-emerald-700 dark:text-emerald-300 italic pt-1">Reply: "{ticket.adminReply}"</p>
                      )}
                    </div>

                    <button
                      onClick={() => setReplyTicketModal({
                        isOpen: true,
                        ticket,
                        replyText: ticket.adminReply || '',
                        status: 'resolved',
                      })}
                      className="px-4 py-2 bg-[#002752] hover:bg-[#001d3d] text-white font-bold rounded-xl text-xs shadow-sm whitespace-nowrap"
                    >
                      Reply to Ticket
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ================= TAB: AUDIT TRAIL ================= */}
        {activeTab === 'audit' && (
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
            <div>
              <h2 className="text-xl font-bold text-slate-900 dark:text-white">Administrative Audit Trail</h2>
              <p className="text-xs text-slate-500">Immutable ledger of every administrative action executed</p>
            </div>

            <div className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
              {auditLogs.map(log => (
                <div key={log.id} className="py-3 flex items-start justify-between gap-4">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 rounded-md font-mono font-bold text-[10px] bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200">
                        {log.action}
                      </span>
                      <strong className="text-slate-800 dark:text-slate-200">{log.adminEmail}</strong>
                    </div>
                    <p className="text-slate-600 dark:text-slate-400 mt-1">{log.details}</p>
                  </div>
                  <span className="text-[10px] text-slate-400 whitespace-nowrap font-mono">
                    {new Date(log.timestamp).toLocaleString()}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

      </div>

      {/* Credit / Debit Modal */}
      {creditDebitModal.isOpen && creditDebitModal.customer && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200 dark:border-slate-800 space-y-4">
            <h3 className="text-lg font-bold text-slate-900 dark:text-white">
              Authorize {creditDebitModal.type === 'credit' ? 'Credit' : 'Debit'}
            </h3>
            <p className="text-xs text-slate-500">
              Customer: <strong>{creditDebitModal.customer.firstName} {creditDebitModal.customer.lastName}</strong> ({creditDebitModal.customer.accountNumber})
            </p>

            <form onSubmit={handleCreditDebitSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold mb-1">Amount (£)</label>
                <input
                  type="number"
                  step="0.01"
                  required
                  placeholder="0.00"
                  value={creditDebitModal.amount}
                  onChange={e => setCreditDebitModal({ ...creditDebitModal, amount: e.target.value })}
                  className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold mb-1">Description</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Authorized wire credit"
                  value={creditDebitModal.description}
                  onChange={e => setCreditDebitModal({ ...creditDebitModal, description: e.target.value })}
                  className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setCreditDebitModal({ ...creditDebitModal, isOpen: false })}
                  className="flex-1 py-2.5 bg-slate-100 dark:bg-slate-800 font-bold text-xs rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-[#002752] hover:bg-[#001d3d] text-white font-bold text-xs rounded-xl"
                >
                  Confirm {creditDebitModal.type === 'credit' ? 'Credit' : 'Debit'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Support Reply Modal */}
      {replyTicketModal.isOpen && replyTicketModal.ticket && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 dark:border-slate-800 space-y-4">
            <h3 className="text-lg font-bold text-slate-900 dark:text-white">
              Reply to Support Ticket ({replyTicketModal.ticket.reference})
            </h3>
            <p className="text-xs text-slate-500">
              To: <strong>{replyTicketModal.ticket.name}</strong> ({replyTicketModal.ticket.email})
            </p>
            <div className="p-3 bg-slate-50 dark:bg-slate-950 rounded-xl text-xs text-slate-600 dark:text-slate-400">
              <strong>Customer Enquiry:</strong> "{replyTicketModal.ticket.message}"
            </div>

            <form onSubmit={handleSupportReplySubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold mb-1">Your Response Message</label>
                <textarea
                  rows={4}
                  required
                  placeholder="Write clear official response to customer..."
                  value={replyTicketModal.replyText}
                  onChange={e => setReplyTicketModal({ ...replyTicketModal, replyText: e.target.value })}
                  className="w-full px-3 py-2 text-xs sm:text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold mb-1">Ticket Resolution Status</label>
                <select
                  value={replyTicketModal.status}
                  onChange={e => setReplyTicketModal({ ...replyTicketModal, status: e.target.value as any })}
                  className="w-full px-3 py-2 text-xs sm:text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl"
                >
                  <option value="resolved">Resolved (Closed)</option>
                  <option value="in_progress">In Progress (Under Review)</option>
                  <option value="open">Keep Open</option>
                </select>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setReplyTicketModal({ ...replyTicketModal, isOpen: false })}
                  className="flex-1 py-2.5 bg-slate-100 dark:bg-slate-800 font-bold text-xs rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-[#002752] hover:bg-[#001d3d] text-white font-bold text-xs rounded-xl"
                >
                  Dispatch Reply
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Customer Statement Modal */}
      {statementCustomer && (
        <StatementModal
          user={statementCustomer}
          transactions={ledger.filter(t => t.userId === statementCustomer.id)}
          onClose={() => setStatementCustomer(null)}
        />
      )}

      {/* Active Receipt Modal */}
      {activeReceiptTx && (
        <ReceiptModal
          transaction={activeReceiptTx}
          onClose={() => setActiveReceiptTx(null)}
          onReversalSuccess={fetchAdminData}
        />
      )}

    </div>
  );
};
