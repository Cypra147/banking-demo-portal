import React from 'react';
import { ShieldCheck, Lock, FileText, CheckCircle2, AlertCircle, Phone, Mail, HelpCircle } from 'lucide-react';

interface LegalPageProps {
  onNavigate: (page: string) => void;
  onOpenAuth: (mode?: 'login' | 'register') => void;
}

// 1. PRIVACY POLICY
export const PrivacyPolicyPage: React.FC<LegalPageProps> = ({ onNavigate, onOpenAuth }) => {
  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 pb-20">
      <div className="bg-[#002752] text-white py-14 px-4 sm:px-6 lg:px-8 border-b border-blue-900/50">
        <div className="max-w-4xl mx-auto">
          <span className="text-xs font-bold text-red-400 uppercase tracking-widest block mb-1">Legal & Data Protection</span>
          <h1 className="text-3xl sm:text-4xl font-black">Customer Privacy Policy</h1>
          <p className="mt-2 text-sm text-slate-300">Effective Date: October 2026 • First National Bank (FNB)</p>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 mt-10">
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-8 sm:p-12 shadow-sm space-y-8 text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
          
          <div className="p-4 bg-amber-50 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-700/60 rounded-2xl text-amber-900 dark:text-amber-200 flex items-start gap-3">
            <AlertCircle className="w-5 h-5 shrink-0 mt-0.5 text-amber-700 dark:text-amber-400" />
            <div>
              <strong className="font-bold block text-sm">Platform Simulation Notice</strong>
              This policy governs data processed by the FNB Online Banking simulator. Real-world financial credentials must never be inputted. Simulated accounts, test transactions, and sandbox balances are retained for demonstration workflows.
            </div>
          </div>

          <section>
            <h2 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white mb-2">1. Information We Collect</h2>
            <p>We process information submitted during account registration, verification, and banking operations:</p>
            <ul className="list-disc pl-5 mt-2 space-y-1">
              <li><strong>Profile Information:</strong> Full name, email address, username, phone number, country of residence, and residential address.</li>
              <li><strong>Authentication Data:</strong> Scrypt-salted password hashes, dynamic one-time password (OTP) records, and active session tokens.</li>
              <li><strong>Transaction Data:</strong> Simulated transfer amounts, recipient beneficiary names, sort codes, account numbers, and references.</li>
              <li><strong>Verification Submissions:</strong> Sample identification document metadata and compliance declarations.</li>
            </ul>
          </section>

          <section>
            <h2 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white mb-2">2. How We Protect Your Data</h2>
            <p>FNB employs 256-bit AES encryption for stored data, secure session headers, strict role-based access control (RBAC), and multi-factor email verification. Passwords are never stored in plain text.</p>
          </section>

          <section>
            <h2 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white mb-2">3. Data Sharing & Third Parties</h2>
            <p>We do not sell, rent, or trade customer data to any commercial advertisers. Customer session logs and verification records are restricted exclusively to authorized administrators for audit compliance.</p>
          </section>

          <section>
            <h2 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white mb-2">4. Your Rights</h2>
            <p>You maintain the right to view your transaction ledger, update your contact details in dashboard settings, and request full account closure by contacting our support desk at <a href="mailto:info@fnnbbankss.online" className="text-[#002752] dark:text-blue-400 font-bold underline">info@fnnbbankss.online</a>.</p>
          </section>
        </div>
      </div>
    </div>
  );
};

// 2. TERMS & CONDITIONS
export const TermsConditionsPage: React.FC<LegalPageProps> = ({ onNavigate, onOpenAuth }) => {
  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 pb-20">
      <div className="bg-[#002752] text-white py-14 px-4 sm:px-6 lg:px-8 border-b border-blue-900/50">
        <div className="max-w-4xl mx-auto">
          <span className="text-xs font-bold text-amber-400 uppercase tracking-widest block mb-1">Customer Agreement</span>
          <h1 className="text-3xl sm:text-4xl font-black">Terms and Conditions of Banking</h1>
          <p className="mt-2 text-sm text-slate-300">Governing Online Banking, Transfers, and Simulated Portfolios</p>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 mt-10">
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-8 sm:p-12 shadow-sm space-y-8 text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
          
          <section>
            <h2 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white mb-2">1. Acceptance of Terms</h2>
            <p>By creating an account, accessing the customer dashboard, or utilizing FNB digital services, you confirm that you have read, understood, and agreed to these Terms and Conditions.</p>
          </section>

          <section>
            <h2 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white mb-2">2. Nature of the Platform</h2>
            <p>FNB Online Banking operates as an advanced institutional digital banking demonstration environment. All balances, deposits, interest earnings, and virtual cards are simulated entities provided for interactive product evaluation.</p>
          </section>

          <section>
            <h2 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white mb-2">3. Customer Registration & Approval</h2>
            <p>Accounts require successful email OTP verification. In accordance with banking regulations, newly registered accounts remain in pending status until reviewed and approved by an authorized administrator.</p>
          </section>

          <section>
            <h2 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white mb-2">4. 30-Minute Transaction Reversal Protocol</h2>
            <p>Outbound demonstration transfers trigger an automated 30-minute demonstration safety protocol. Upon expiration of the 30-minute interval, transferred funds are systematically credited back to the customer's available balance.</p>
          </section>

          <section>
            <h2 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white mb-2">5. User Conduct & Security</h2>
            <p>Users are responsible for safeguarding their login credentials and OTP codes. Never disclose verification codes to third parties. Any unauthorized access attempts should be reported immediately to our support team.</p>
          </section>
        </div>
      </div>
    </div>
  );
};

// 3. SECURITY CENTRE
export const SecurityCentrePage: React.FC<LegalPageProps> = ({ onNavigate, onOpenAuth }) => {
  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 pb-20">
      <div className="bg-[#002752] text-white py-14 px-4 sm:px-6 lg:px-8 border-b border-blue-900/50">
        <div className="max-w-4xl mx-auto">
          <span className="text-xs font-bold text-emerald-400 uppercase tracking-widest block mb-1">Defense & Architecture</span>
          <h1 className="text-3xl sm:text-4xl font-black">FNB Security & Defense Centre</h1>
          <p className="mt-2 text-sm text-slate-300">How we protect your capital, assets, and identities around the clock</p>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 mt-10">
        <div className="grid sm:grid-cols-2 gap-6 mb-10">
          <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm">
            <Lock className="w-8 h-8 text-[#002752] dark:text-blue-400 mb-3" />
            <h3 className="text-base font-bold text-slate-900 dark:text-white mb-2">256-Bit Cryptography</h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
              All communications between your device and our banking servers are encrypted with TLS 1.3 cryptographic tunnels.
            </p>
          </div>
          <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm">
            <ShieldCheck className="w-8 h-8 text-emerald-600 mb-3" />
            <h3 className="text-base font-bold text-slate-900 dark:text-white mb-2">Dynamic OTP Verification</h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
              Account registrations and password resets require single-use 6-digit cryptographic verification codes.
            </p>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-8 sm:p-12 shadow-sm space-y-6 text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
          <h2 className="text-xl font-bold text-slate-900 dark:text-white">Fraud Prevention Tips for Customers</h2>
          <ul className="space-y-3">
            <li className="flex items-start gap-3">
              <CheckCircle2 className="w-5 h-5 text-emerald-500 shrink-0 mt-0.5" />
              <span><strong>FNB will never ask for your password via telephone or email.</strong> Our officers only verify identity via official portal workflows.</span>
            </li>
            <li className="flex items-start gap-3">
              <CheckCircle2 className="w-5 h-5 text-emerald-500 shrink-0 mt-0.5" />
              <span><strong>Review your transaction ledger regularly.</strong> In your customer dashboard, examine credit and debit notices for any unfamiliar references.</span>
            </li>
            <li className="flex items-start gap-3">
              <CheckCircle2 className="w-5 h-5 text-emerald-500 shrink-0 mt-0.5" />
              <span><strong>Utilize virtual card freeze controls.</strong> If you misplace or suspect compromise of your virtual debit card, freeze it in one tap.</span>
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
};

// 4. FAQ PAGE
export const FAQPage: React.FC<LegalPageProps> = ({ onNavigate, onOpenAuth }) => {
  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 pb-20">
      <div className="bg-[#002752] text-white py-14 px-4 sm:px-6 lg:px-8 border-b border-blue-900/50">
        <div className="max-w-4xl mx-auto">
          <span className="text-xs font-bold text-amber-400 uppercase tracking-widest block mb-1">Knowledge Base</span>
          <h1 className="text-3xl sm:text-4xl font-black">Frequently Asked Questions</h1>
          <p className="mt-2 text-sm text-slate-300">Detailed answers to common questions about FNB Online Banking</p>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 mt-10">
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-8 sm:p-12 shadow-sm space-y-6">
          {[
            {
              q: 'How do I access my FNB customer dashboard?',
              a: 'Click "Sign In" in the navigation bar or homepage, enter your registered username/email and confidential password. Once authenticated, you will be redirected to your personal dashboard.'
            },
            {
              q: 'Where do I find my account number and sort code?',
              a: 'Once your registration application is approved by administration, your unique 10-digit account number and sort code (20-04-15) are prominently displayed on your Customer Dashboard under "Overview" and "My Account".'
            },
            {
              q: 'What is the purpose of the 30-minute reversal timer?',
              a: 'In accordance with FNB Sandbox guidelines, demonstration transfers auto-refund after 30 minutes to preserve customer test funds. Users can also trigger immediate instant reversals with the "Simulate Immediate Reversal" button.'
            },
            {
              q: 'Can I generate multiple virtual debit cards?',
              a: 'Yes, customers can generate and manage multiple virtual debit cards with customizable daily limits and instant freeze controls under the Virtual Cards section.'
            },
            {
              q: 'How do I submit KYC identity verification?',
              a: 'Navigate to "Verification" from the top menu or inside the Customer Dashboard. Complete the form, select your ID document type, attach your sample scans, accept the declaration, and submit for compliance review.'
            },
            {
              q: 'How can I reach administrator or customer support?',
              a: 'Telephone and WhatsApp: +447723165577, Email: info@fnnbbankss.online, or start a live discussion with the Tawk.to widget located in the bottom-right corner.'
            }
          ].map((item, i) => (
            <div key={i} className="pb-6 border-b border-slate-100 dark:border-slate-800 last:border-0 last:pb-0">
              <h3 className="font-bold text-sm sm:text-base text-slate-900 dark:text-white mb-2 flex items-start gap-2">
                <HelpCircle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
                <span>{item.q}</span>
              </h3>
              <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 pl-7 leading-relaxed">
                {item.a}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
