import React, { useState } from 'react';
import { 
  ShieldCheck, 
  FileCheck2, 
  Search, 
  ArrowRight, 
  Lock, 
  CheckCircle2, 
  Clock, 
  AlertTriangle,
  Building,
  UploadCloud,
  HelpCircle
} from 'lucide-react';
import { api } from '../services/api.ts';

interface VerificationPageProps {
  onOpenAuth: (mode?: 'login' | 'register') => void;
  onNavigate: (page: string) => void;
  isAuthenticated: boolean;
}

export const VerificationPage: React.FC<VerificationPageProps> = ({
  onOpenAuth,
  onNavigate,
  isAuthenticated
}) => {
  const [searchRef, setSearchRef] = useState('');
  const [lookupResult, setLookupResult] = useState<any>(null);
  const [lookupError, setLookupError] = useState<string | null>(null);
  const [lookupLoading, setLookupLoading] = useState(false);

  const handleTrackSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchRef.trim()) return;
    setLookupLoading(true);
    setLookupError(null);
    setLookupResult(null);

    try {
      // Fetch verifications
      const res = await api.getVerifications();
      const match = res.verifications.find(
        v => v.reference.toLowerCase() === searchRef.trim().toLowerCase()
      );
      if (match) {
        setLookupResult(match);
      } else {
        setLookupError(`No verification record found matching reference "${searchRef.trim()}". Please verify your reference number.`);
      }
    } catch (err: any) {
      setLookupError('Unable to check reference at this time. Please log in to your dashboard to inspect your status.');
    } finally {
      setLookupLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 pb-20">
      
      {/* Hero Header */}
      <section className="bg-gradient-to-r from-[#001833] via-[#002752] to-[#003875] text-white py-16 px-4 sm:px-6 lg:px-8 border-b border-blue-900/50">
        <div className="max-w-6xl mx-auto">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-red-600/20 border border-red-500/30 text-red-300 text-xs font-semibold mb-4">
            <ShieldCheck className="w-4 h-4 text-red-400" />
            <span>Customer Due Diligence & Identity Protection</span>
          </div>
          <h1 className="text-3xl sm:text-5xl font-black tracking-tight leading-tight max-w-3xl">
            Account Identity Verification (KYC)
          </h1>
          <p className="mt-4 text-base sm:text-lg text-slate-300 max-w-2xl leading-relaxed">
            FNB adheres to international anti-money laundering (AML) standards. Complete your identity verification to unlock higher transaction limits, unlimited virtual cards, and institutional portfolio access.
          </p>
        </div>
      </section>

      {/* Main Container */}
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 mt-12">
        
        <div className="grid lg:grid-cols-12 gap-8">
          
          {/* Left: Requirements & Instructions */}
          <div className="lg:col-span-7 space-y-6">
            
            <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 shadow-sm">
              <h2 className="text-xl font-bold text-slate-900 dark:text-white mb-4 flex items-center gap-2">
                <FileCheck2 className="w-5 h-5 text-[#002752] dark:text-blue-400" />
                <span>Verification Requirements & Guidelines</span>
              </h2>
              <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 leading-relaxed mb-6">
                To maintain Tier-1 verification, customers submit valid government-issued photographic identification alongside verified proof of residential address.
              </p>

              <div className="space-y-4">
                <div className="p-4 bg-slate-50 dark:bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-800">
                  <h4 className="font-bold text-sm text-[#002752] dark:text-blue-400 mb-1">
                    1. Primary Government Photo ID
                  </h4>
                  <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed mb-2">
                    Must be unexpired, clearly legible, and showing full legal name, date of birth, and facial photograph.
                  </p>
                  <ul className="text-xs text-slate-500 space-y-1 list-disc pl-5">
                    <li>International Passport (Bio-data page)</li>
                    <li>National Identity Card (Front & Back)</li>
                    <li>Full Driving Licence (Photocard)</li>
                  </ul>
                </div>

                <div className="p-4 bg-slate-50 dark:bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-800">
                  <h4 className="font-bold text-sm text-[#002752] dark:text-blue-400 mb-1">
                    2. Proof of Residential Address
                  </h4>
                  <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed mb-2">
                    Must display your residential address matching your account profile, issued within the last 3 months.
                  </p>
                  <ul className="text-xs text-slate-500 space-y-1 list-disc pl-5">
                    <li>Utility Bill (Gas, Electricity, Water, or Broadband)</li>
                    <li>Council Tax Statement or Assessment</li>
                    <li>Official Bank Statement or Building Society Notice</li>
                  </ul>
                </div>
              </div>

              {/* Action Button */}
              <div className="mt-8 pt-6 border-t border-slate-100 dark:border-slate-800">
                {isAuthenticated ? (
                  <button
                    onClick={() => onNavigate('dashboard')}
                    className="w-full py-3.5 bg-[#002752] hover:bg-[#001d3d] text-white font-bold rounded-xl text-sm shadow-md transition-all flex items-center justify-center gap-2"
                  >
                    <span>Complete Verification in Your Dashboard</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                ) : (
                  <button
                    onClick={() => onOpenAuth('login')}
                    className="w-full py-3.5 bg-[#002752] hover:bg-[#001d3d] text-white font-bold rounded-xl text-sm shadow-md transition-all flex items-center justify-center gap-2"
                  >
                    <span>Sign In to Submit Verification</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>

          </div>

          {/* Right: Verification Status Tracker & Support */}
          <div className="lg:col-span-5 space-y-6">
            
            {/* Status Tracker Card */}
            <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 shadow-sm">
              <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-2 flex items-center gap-2">
                <Search className="w-5 h-5 text-red-600" />
                <span>Track Verification Status</span>
              </h3>
              <p className="text-xs text-slate-500 mb-4">
                Have you already submitted documents? Enter your unique reference code (e.g. <code>VER-261028-98C3</code>).
              </p>

              <form onSubmit={handleTrackSubmit} className="space-y-3">
                <div className="relative">
                  <input
                    type="text"
                    required
                    placeholder="VER-XXXXXX-XXXX"
                    value={searchRef}
                    onChange={(e) => setSearchRef(e.target.value)}
                    className="w-full px-4 py-2.5 text-xs sm:text-sm font-mono uppercase bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#002752]"
                  />
                </div>
                <button
                  type="submit"
                  disabled={lookupLoading}
                  className="w-full py-2.5 bg-[#c8102e] hover:bg-[#a50d26] text-white font-bold rounded-xl text-xs shadow transition-all flex items-center justify-center gap-1.5"
                >
                  <Search className="w-3.5 h-3.5" />
                  <span>{lookupLoading ? 'Checking...' : 'Check Status'}</span>
                </button>
              </form>

              {lookupError && (
                <div className="mt-4 p-3 bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 rounded-xl text-xs text-red-700 dark:text-red-300">
                  {lookupError}
                </div>
              )}

              {lookupResult && (
                <div className="mt-4 p-4 bg-slate-50 dark:bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-800 text-xs space-y-2">
                  <div className="flex justify-between items-center pb-2 border-b border-slate-200 dark:border-slate-800">
                    <span className="text-slate-500">Reference:</span>
                    <strong className="font-mono text-slate-800 dark:text-slate-200">{lookupResult.reference}</strong>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-slate-500">Applicant:</span>
                    <span className="font-semibold text-slate-800 dark:text-slate-200">{lookupResult.fullName}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-slate-500">Document Type:</span>
                    <span className="capitalize">{lookupResult.idDocumentType.replace('_', ' ')}</span>
                  </div>
                  <div className="flex justify-between items-center pt-2 border-t border-slate-200 dark:border-slate-800">
                    <span className="text-slate-500">Verification Status:</span>
                    <span className={`px-2 py-0.5 rounded-full font-bold uppercase text-[10px] ${
                      lookupResult.status === 'approved' 
                        ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300'
                        : lookupResult.status === 'rejected'
                        ? 'bg-red-100 text-red-800 dark:bg-red-950/60 dark:text-red-300'
                        : 'bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300'
                    }`}>
                      {lookupResult.status.replace('_', ' ')}
                    </span>
                  </div>
                  {lookupResult.adminComments && (
                    <p className="text-[11px] text-slate-600 dark:text-slate-400 italic pt-1">
                      Note: "{lookupResult.adminComments}"
                    </p>
                  )}
                </div>
              )}
            </div>

            {/* Security Guarantee Box */}
            <div className="bg-[#002752] text-white rounded-3xl p-6 sm:p-7 shadow-md">
              <div className="flex items-center gap-2 mb-2 text-red-400">
                <Lock className="w-4 h-4" />
                <span className="text-xs font-bold uppercase tracking-wider">Bank-Grade Encryption</span>
              </div>
              <h4 className="text-base font-bold mb-2">How your documents are protected</h4>
              <p className="text-xs text-slate-300 leading-relaxed">
                All submitted identification files are encrypted with AES-256 ciphering at rest and accessed strictly by certified compliance officers during verification workflows.
              </p>
            </div>

          </div>

        </div>

      </div>

    </div>
  );
};
