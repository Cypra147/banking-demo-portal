import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext.tsx';
import { api } from '../services/api.ts';
import { 
  Lock, 
  Mail, 
  User as UserIcon, 
  Phone, 
  ArrowRight, 
  AlertCircle, 
  Clock, 
  KeyRound,
  Eye,
  EyeOff,
  Info,
  Globe,
  MapPin,
  CheckCircle2
} from 'lucide-react';

interface AuthPagesProps {
  initialMode?: 'login' | 'register' | 'forgot';
  onClose?: () => void;
  onSuccess?: () => void;
}

export const AuthPages: React.FC<AuthPagesProps> = ({ 
  initialMode = 'login', 
  onClose,
  onSuccess 
}) => {
  const { loginCustomer, fetchEmails, setIsMailModalOpen } = useAuth();
  const [mode, setMode] = useState<'login' | 'register' | 'forgot'>(initialMode);
  const [showPassword, setShowPassword] = useState(false);

  // Customer Login Form State
  const [loginIdentifier, setLoginIdentifier] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [loginError, setLoginError] = useState<string | null>(null);
  const [loginLoading, setLoginLoading] = useState(false);

  // Customer Registration State
  const [regStep, setRegStep] = useState<'form' | 'otp' | 'pending_success'>('form');
  const [regForm, setRegForm] = useState({
    firstName: '',
    lastName: '',
    email: '',
    username: '',
    phone: '',
    country: 'United Kingdom',
    residentialAddress: '',
    password: '',
    confirmPassword: '',
  });
  const [regOtp, setRegOtp] = useState('');
  const [regError, setRegError] = useState<string | null>(null);
  const [regLoading, setRegLoading] = useState(false);
  const [dispatchedRegOtp, setDispatchedRegOtp] = useState<string | null>(null);
  const [resending, setResending] = useState(false);
  const [resendStatus, setResendStatus] = useState<string | null>(null);

  // Forgot Password State
  const [forgotStep, setForgotStep] = useState<'request' | 'verify' | 'done'>('request');
  const [forgotEmail, setForgotEmail] = useState('');
  const [forgotCode, setForgotCode] = useState('');
  const [forgotNewPassword, setForgotNewPassword] = useState('');
  const [forgotConfirmPassword, setForgotConfirmPassword] = useState('');
  const [forgotError, setForgotError] = useState<string | null>(null);
  const [forgotLoading, setForgotLoading] = useState(false);
  const [dispatchedForgotCode, setDispatchedForgotCode] = useState<string | null>(null);

  // Customer Login Submit
  const handleCustomerLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);
    setLoginLoading(true);

    try {
      await loginCustomer(loginIdentifier, loginPassword);
      if (onSuccess) onSuccess();
      if (onClose) onClose();
    } catch (err: any) {
      setLoginError(err.message || 'Login failed. Please verify your credentials.');
    } finally {
      setLoginLoading(false);
    }
  };

  // Step 1: Submit Registration Form (triggers OTP creation & email)
  const handleRegisterFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setRegError(null);

    if (regForm.password !== regForm.confirmPassword) {
      setRegError('Passwords do not match.');
      return;
    }
    if (regForm.password.length < 8) {
      setRegError('Password must be at least 8 characters long.');
      return;
    }

    setRegLoading(true);
    try {
      const res = await api.registerRequest({
        ...regForm,
        fullName: `${regForm.firstName} ${regForm.lastName}`.trim(),
      });
      if (res.otpCode) {
        setDispatchedRegOtp(res.otpCode);
        setRegOtp(res.otpCode);
      }
      setRegStep('otp');
      await fetchEmails();
    } catch (err: any) {
      setRegError(err.message || 'Registration request failed.');
    } finally {
      setRegLoading(false);
    }
  };

  // Resend Registration OTP immediately
  const handleResendRegOtp = async () => {
    setResending(true);
    setRegError(null);
    try {
      const res = await api.resendOtp(regForm.email);
      if (res.otpCode) {
        setDispatchedRegOtp(res.otpCode);
        setRegOtp(res.otpCode);
        setResendStatus('A fresh verification code was generated and delivered instantly.');
        setTimeout(() => setResendStatus(null), 4000);
      }
      await fetchEmails();
    } catch (err: any) {
      setRegError(err.message || 'Failed to resend code.');
    } finally {
      setResending(false);
    }
  };

  // Step 2: Verify OTP and create customer with status "pending_approval"
  const handleVerifyOtpSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setRegError(null);
    setRegLoading(true);

    try {
      await api.verifyOtpAndSubmit(regForm.email, regOtp);
      await fetchEmails();
      setRegStep('pending_success');
    } catch (err: any) {
      setRegError(err.message || 'Invalid or expired verification code.');
    } finally {
      setRegLoading(false);
    }
  };

  // Password Recovery Handlers
  const handleForgotRequestSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setForgotError(null);
    setForgotLoading(true);
    try {
      const res = await api.forgotPassword(forgotEmail);
      if (res.resetCode) {
        setDispatchedForgotCode(res.resetCode);
        setForgotCode(res.resetCode);
      }
      await fetchEmails();
      setForgotStep('verify');
    } catch (err: any) {
      setForgotError(err.message || 'Failed to request password reset code.');
    } finally {
      setForgotLoading(false);
    }
  };

  // Resend password recovery code
  const handleResendForgotCode = async () => {
    setResending(true);
    setForgotError(null);
    try {
      const res = await api.forgotPassword(forgotEmail);
      if (res.resetCode) {
        setDispatchedForgotCode(res.resetCode);
        setForgotCode(res.resetCode);
        setResendStatus('New recovery code generated and delivered instantly.');
        setTimeout(() => setResendStatus(null), 4000);
      }
      await fetchEmails();
    } catch (err: any) {
      setForgotError(err.message || 'Failed to resend recovery code.');
    } finally {
      setResending(false);
    }
  };

  const handleForgotVerifySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setForgotError(null);
    if (forgotNewPassword !== forgotConfirmPassword) {
      setForgotError('New passwords do not match.');
      return;
    }
    if (forgotNewPassword.length < 8) {
      setForgotError('New password must be at least 8 characters long.');
      return;
    }
    setForgotLoading(true);
    try {
      await api.resetPassword({
        email: forgotEmail,
        code: forgotCode,
        newPassword: forgotNewPassword,
        confirmPassword: forgotConfirmPassword,
      });
      setForgotStep('done');
    } catch (err: any) {
      setForgotError(err.message || 'Failed to reset password.');
    } finally {
      setForgotLoading(false);
    }
  };

  return (
    <div className="w-full max-w-xl mx-auto bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden transition-all">
      
      {/* Brand Header */}
      <div className="bg-[#002752] p-6 text-white text-center relative">
        <div className="flex justify-center mb-3">
          <img
            src="/fnb-logo.png"
            alt="First National Bank"
            className="w-14 h-14 object-contain rounded-2xl bg-white p-1.5 shadow-md"
            onError={(e) => {
              e.currentTarget.onerror = null;
              e.currentTarget.src = "/assets/aistudio/file_00000000763081f4a6c9438dcd4940cf_665e4923.png";
            }}
          />
        </div>
        <h2 className="text-2xl font-black tracking-tight">FIRST NATIONAL BANK</h2>
        <p className="text-xs text-red-400 font-semibold uppercase tracking-wider mt-0.5">
          Secure Online Banking Portal
        </p>

        {/* Tab Switcher */}
        <div className="flex bg-white/10 p-1 rounded-2xl mt-5 text-xs font-bold">
          <button
            type="button"
            onClick={() => { setMode('login'); setLoginError(null); }}
            className={`flex-1 py-2 rounded-xl transition-all ${
              mode === 'login' ? 'bg-white text-[#002752] shadow-sm' : 'text-slate-200 hover:text-white'
            }`}
          >
            Customer Sign In
          </button>
          <button
            type="button"
            onClick={() => { setMode('register'); setRegError(null); }}
            className={`flex-1 py-2 rounded-xl transition-all ${
              mode === 'register' ? 'bg-[#c8102e] text-white shadow-sm' : 'text-slate-200 hover:text-white'
            }`}
          >
            Open An Account
          </button>
        </div>
      </div>

      {/* Main Body */}
      <div className="p-6 sm:p-8">
        
        {/* ================= MODE 1: CUSTOMER LOGIN ================= */}
        {mode === 'login' && (
          <form onSubmit={handleCustomerLoginSubmit} className="space-y-4">

            {loginError && (
              <div className="p-3.5 bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 rounded-2xl text-xs text-red-700 dark:text-red-300 flex items-start gap-2 leading-relaxed">
                <AlertCircle className="w-4 h-4 mt-0.5 shrink-0 text-red-600" />
                <span>{loginError}</span>
              </div>
            )}

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-1.5">
                Username or Email Address
              </label>
              <div className="relative">
                <UserIcon className="w-4 h-4 absolute left-3.5 top-3.5 text-slate-400" />
                <input
                  type="text"
                  required
                  placeholder="Enter registered username or email"
                  value={loginIdentifier}
                  onChange={e => setLoginIdentifier(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#002752]"
                />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider">
                  Password
                </label>
                <button
                  type="button"
                  onClick={() => { setMode('forgot'); setForgotStep('request'); setForgotError(null); }}
                  className="text-xs font-semibold text-[#c8102e] hover:underline"
                >
                  Forgot Password?
                </button>
              </div>
              <div className="relative">
                <Lock className="w-4 h-4 absolute left-3.5 top-3.5 text-slate-400" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  placeholder="Enter your confidential password"
                  value={loginPassword}
                  onChange={e => setLoginPassword(e.target.value)}
                  className="w-full pl-10 pr-10 py-2.5 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#002752]"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(p => !p)}
                  className="absolute right-3.5 top-3 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <div className="pt-2">
              <button
                type="submit"
                disabled={loginLoading}
                className="w-full py-3 bg-[#002752] hover:bg-[#001d3d] text-white font-bold rounded-xl text-sm shadow-md transition-all flex items-center justify-center gap-2"
              >
                <span>{loginLoading ? 'Authenticating...' : 'Sign In to Banking'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>

            <div className="text-center pt-2 text-xs text-slate-500">
              Don't have an account yet?{' '}
              <button
                type="button"
                onClick={() => setMode('register')}
                className="font-bold text-[#c8102e] hover:underline"
              >
                Apply for an Account
              </button>
            </div>
          </form>
        )}

        {/* ================= MODE 2: CUSTOMER REGISTRATION ================= */}
        {mode === 'register' && (
          <div>
            {/* Step 1: User Information Form */}
            {regStep === 'form' && (
              <form onSubmit={handleRegisterFormSubmit} className="space-y-3.5">
                
                <div className="p-3 bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-900 rounded-2xl text-xs text-blue-900 dark:text-blue-200 flex items-start gap-2">
                  <Info className="w-4 h-4 mt-0.5 shrink-0 text-blue-600" />
                  <span>
                    New account applications require email OTP verification. Once approved by administration, your unique account number is generated and your portal is activated.
                  </span>
                </div>

                {regError && (
                  <div className="p-3 bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 rounded-2xl text-xs text-red-700 dark:text-red-300">
                    {regError}
                  </div>
                )}

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      First Name
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. John"
                      value={regForm.firstName}
                      onChange={e => setRegForm({ ...regForm, firstName: e.target.value })}
                      className="w-full px-3 py-2 text-xs sm:text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#c8102e]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Last Name
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Smith"
                      value={regForm.lastName}
                      onChange={e => setRegForm({ ...regForm, lastName: e.target.value })}
                      className="w-full px-3 py-2 text-xs sm:text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#c8102e]"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Email Address (OTP sent here)
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
                    <input
                      type="email"
                      required
                      placeholder="name@example.com"
                      value={regForm.email}
                      onChange={e => setRegForm({ ...regForm, email: e.target.value })}
                      className="w-full pl-9 pr-3 py-2 text-xs sm:text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#c8102e]"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Username
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. johnsmith"
                      value={regForm.username}
                      onChange={e => setRegForm({ ...regForm, username: e.target.value })}
                      className="w-full px-3 py-2 text-xs sm:text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#c8102e]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Phone Number
                    </label>
                    <div className="relative">
                      <Phone className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-400" />
                      <input
                        type="tel"
                        required
                        placeholder="+44 7700 000000"
                        value={regForm.phone}
                        onChange={e => setRegForm({ ...regForm, phone: e.target.value })}
                        className="w-full pl-8 pr-3 py-2 text-xs sm:text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#c8102e]"
                      />
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Country of Residence
                    </label>
                    <div className="relative">
                      <Globe className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-400" />
                      <input
                        type="text"
                        required
                        placeholder="e.g. United Kingdom"
                        value={regForm.country}
                        onChange={e => setRegForm({ ...regForm, country: e.target.value })}
                        className="w-full pl-8 pr-3 py-2 text-xs sm:text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#c8102e]"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Residential Address
                    </label>
                    <div className="relative">
                      <MapPin className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-400" />
                      <input
                        type="text"
                        required
                        placeholder="Street, City, Postal Code"
                        value={regForm.residentialAddress}
                        onChange={e => setRegForm({ ...regForm, residentialAddress: e.target.value })}
                        className="w-full pl-8 pr-3 py-2 text-xs sm:text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#c8102e]"
                      />
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Password (min 8 chars)
                    </label>
                    <input
                      type="password"
                      required
                      placeholder="••••••••"
                      value={regForm.password}
                      onChange={e => setRegForm({ ...regForm, password: e.target.value })}
                      className="w-full px-3 py-2 text-xs sm:text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#c8102e]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Confirm Password
                    </label>
                    <input
                      type="password"
                      required
                      placeholder="••••••••"
                      value={regForm.confirmPassword}
                      onChange={e => setRegForm({ ...regForm, confirmPassword: e.target.value })}
                      className="w-full px-3 py-2 text-xs sm:text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#c8102e]"
                    />
                  </div>
                </div>

                <div className="pt-2">
                  <button
                    type="submit"
                    disabled={regLoading}
                    className="w-full py-3 bg-[#c8102e] hover:bg-[#b00d27] text-white font-bold rounded-xl text-sm shadow-md transition-all flex items-center justify-center gap-2"
                  >
                    <span>{regLoading ? 'Sending Verification Code...' : 'Send Verification OTP'}</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </form>
            )}

            {/* Step 2: Email OTP Verification */}
            {regStep === 'otp' && (
              <form onSubmit={handleVerifyOtpSubmit} className="space-y-4">
                <div className="text-center space-y-2">
                  <div className="w-12 h-12 bg-red-100 dark:bg-red-950/60 text-[#c8102e] rounded-2xl flex items-center justify-center mx-auto">
                    <KeyRound className="w-6 h-6" />
                  </div>
                  <h3 className="text-lg font-bold text-slate-900 dark:text-white">
                    Enter Verification Code
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    A 6-digit verification code has been dispatched to <strong className="text-slate-900 dark:text-white">{regForm.email}</strong>.
                  </p>
                </div>

                {/* Instant OTP Delivery Banner */}
                {dispatchedRegOtp && (
                  <div className="p-3.5 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-300 dark:border-emerald-700/60 rounded-2xl text-left space-y-2.5">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
                        <span className="text-xs font-bold text-emerald-900 dark:text-emerald-200 uppercase tracking-wide">
                          Instant Security Dispatch
                        </span>
                      </div>
                      <span className="text-[10px] font-bold text-emerald-800 dark:text-emerald-300 bg-emerald-100 dark:bg-emerald-900/60 px-2.5 py-0.5 rounded-full">
                        Delivered in 0.0s
                      </span>
                    </div>

                    <div className="flex items-center justify-between bg-white dark:bg-slate-900 p-2.5 rounded-xl border border-emerald-200 dark:border-emerald-800 shadow-sm">
                      <div>
                        <p className="text-[10px] font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                          One-Time Verification Code
                        </p>
                        <p className="font-mono text-2xl font-black text-emerald-600 dark:text-emerald-400 tracking-widest">
                          {dispatchedRegOtp}
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={() => setRegOtp(dispatchedRegOtp)}
                        className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-lg shadow-sm transition-all flex items-center gap-1.5"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Auto-Fill Code</span>
                      </button>
                    </div>

                    <p className="text-[11px] text-emerald-800 dark:text-emerald-300 leading-snug">
                      Your verification OTP was created and sent to your email and in-portal Mailbox center.
                    </p>
                  </div>
                )}

                {resendStatus && (
                  <div className="p-3 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-300 dark:border-emerald-800 rounded-xl text-xs text-emerald-800 dark:text-emerald-300 flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>{resendStatus}</span>
                  </div>
                )}

                {regError && (
                  <div className="p-3 bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 rounded-2xl text-xs text-red-700 dark:text-red-300">
                    {regError}
                  </div>
                )}

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-1.5 text-center">
                    6-Digit Verification Code
                  </label>
                  <input
                    type="text"
                    maxLength={6}
                    required
                    placeholder="• • • • • •"
                    value={regOtp}
                    onChange={e => setRegOtp(e.target.value.replace(/\D/g, ''))}
                    className="w-full py-3 text-center font-mono font-bold text-2xl tracking-[0.5em] bg-slate-50 dark:bg-slate-950 border-2 border-slate-300 dark:border-slate-700 rounded-2xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#002752]"
                  />
                </div>

                <div className="flex items-center justify-between text-xs px-1">
                  <button
                    type="button"
                    onClick={handleResendRegOtp}
                    disabled={resending}
                    className="font-bold text-[#c8102e] hover:underline disabled:opacity-50"
                  >
                    {resending ? 'Generating new code...' : 'Resend Code (Instant 0s)'}
                  </button>

                  <button
                    type="button"
                    onClick={() => setIsMailModalOpen(true)}
                    className="font-bold text-[#002752] dark:text-blue-400 hover:underline"
                  >
                    Open Mailbox Viewer
                  </button>
                </div>

                <div className="flex gap-3 pt-1">
                  <button
                    type="button"
                    onClick={() => setRegStep('form')}
                    className="flex-1 py-2.5 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-semibold rounded-xl text-xs hover:bg-slate-200 transition-colors"
                  >
                    Back to Edit
                  </button>
                  <button
                    type="submit"
                    disabled={regLoading || regOtp.length !== 6}
                    className="flex-1 py-2.5 bg-[#002752] hover:bg-[#001d3d] disabled:opacity-50 text-white font-bold rounded-xl text-xs shadow-md transition-all"
                  >
                    {regLoading ? 'Verifying...' : 'Submit Application'}
                  </button>
                </div>
              </form>
            )}

            {/* Step 3: Pending Administrator Approval Success State */}
            {regStep === 'pending_success' && (
              <div className="text-center py-4 space-y-4">
                <div className="w-16 h-16 bg-blue-100 dark:bg-blue-950/60 text-[#002752] dark:text-blue-400 rounded-full flex items-center justify-center mx-auto">
                  <Clock className="w-8 h-8" />
                </div>
                <h3 className="text-xl font-black text-slate-900 dark:text-white">
                  Application Under Administrative Review
                </h3>
                <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed max-w-md mx-auto">
                  Thank you, <strong>{regForm.firstName} {regForm.lastName}</strong>! Your email has been verified and your registration application has been submitted. In accordance with banking security guidelines, an administrator will review your application before your unique account number is generated.
                </p>

                <div className="p-4 bg-slate-50 dark:bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-800 text-xs text-left space-y-1.5">
                  <p className="text-slate-500">Applicant: <strong className="text-slate-800 dark:text-slate-200">{regForm.firstName} {regForm.lastName}</strong></p>
                  <p className="text-slate-500">Registered Email: <strong className="text-slate-800 dark:text-slate-200">{regForm.email}</strong></p>
                  <p className="text-slate-500">Status: <span className="font-bold text-amber-600 uppercase">PENDING_APPROVAL</span></p>
                </div>

                <div className="pt-2">
                  <button
                    type="button"
                    onClick={() => { setMode('login'); setRegStep('form'); }}
                    className="w-full py-2.5 bg-[#002752] hover:bg-[#001d3d] text-white font-semibold rounded-xl text-xs transition-colors"
                  >
                    Return to Customer Sign In
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* ================= MODE 3: FORGOT PASSWORD ================= */}
        {mode === 'forgot' && (
          <div className="space-y-4">
            {forgotStep === 'request' && (
              <form onSubmit={handleForgotRequestSubmit} className="space-y-4">
                <div className="text-center space-y-1">
                  <h3 className="text-lg font-bold text-slate-900 dark:text-white">
                    Reset Your Password
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Enter your registered email address to receive an authorization code.
                  </p>
                </div>

                {forgotError && (
                  <div className="p-3 bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 rounded-2xl text-xs text-red-700 dark:text-red-300">
                    {forgotError}
                  </div>
                )}

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Email Address
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                    <input
                      type="email"
                      required
                      placeholder="e.g. sarah.jenkins@fnnbbankss.online"
                      value={forgotEmail}
                      onChange={e => setForgotEmail(e.target.value)}
                      className="w-full pl-9 pr-3 py-2.5 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#002752]"
                    />
                  </div>
                </div>

                <div className="flex gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setMode('login')}
                    className="flex-1 py-2.5 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-semibold rounded-xl text-xs hover:bg-slate-200"
                  >
                    Back to Sign In
                  </button>
                  <button
                    type="submit"
                    disabled={forgotLoading}
                    className="flex-1 py-2.5 bg-[#002752] hover:bg-[#001d3d] text-white font-bold rounded-xl text-xs shadow-md"
                  >
                    {forgotLoading ? 'Sending...' : 'Send Recovery Code'}
                  </button>
                </div>
              </form>
            )}

            {forgotStep === 'verify' && (
              <form onSubmit={handleForgotVerifySubmit} className="space-y-3.5">
                <div className="text-center space-y-1">
                  <h3 className="text-lg font-bold text-slate-900 dark:text-white">
                    Set New Password
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Enter the code sent to <strong>{forgotEmail}</strong> and your new password.
                  </p>
                </div>

                {/* Instant Recovery Code Delivery Banner */}
                {dispatchedForgotCode && (
                  <div className="p-3.5 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-300 dark:border-emerald-700/60 rounded-2xl text-left space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
                        <span className="text-xs font-bold text-emerald-900 dark:text-emerald-200 uppercase tracking-wide">
                          Instant Recovery Dispatch
                        </span>
                      </div>
                      <span className="text-[10px] font-bold text-emerald-800 dark:text-emerald-300 bg-emerald-100 dark:bg-emerald-900/60 px-2.5 py-0.5 rounded-full">
                        Delivered in 0.0s
                      </span>
                    </div>

                    <div className="flex items-center justify-between bg-white dark:bg-slate-900 p-2.5 rounded-xl border border-emerald-200 dark:border-emerald-800 shadow-sm">
                      <div>
                        <p className="text-[10px] font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                          Authorization Recovery Code
                        </p>
                        <p className="font-mono text-2xl font-black text-emerald-600 dark:text-emerald-400 tracking-widest">
                          {dispatchedForgotCode}
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={() => setForgotCode(dispatchedForgotCode)}
                        className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-lg shadow-sm transition-all flex items-center gap-1.5"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Auto-Fill Code</span>
                      </button>
                    </div>

                    <p className="text-[11px] text-emerald-800 dark:text-emerald-300">
                      Dispatched instantly to your email and communications center.
                    </p>
                  </div>
                )}

                {resendStatus && (
                  <div className="p-3 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-300 dark:border-emerald-800 rounded-xl text-xs text-emerald-800 dark:text-emerald-300 flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>{resendStatus}</span>
                  </div>
                )}

                {forgotError && (
                  <div className="p-3 bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 rounded-2xl text-xs text-red-700 dark:text-red-300">
                    {forgotError}
                  </div>
                )}

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    6-Digit Recovery Code
                  </label>
                  <input
                    type="text"
                    maxLength={6}
                    required
                    placeholder="123456"
                    value={forgotCode}
                    onChange={e => setForgotCode(e.target.value.replace(/\D/g, ''))}
                    className="w-full py-2.5 text-center font-mono font-bold text-xl tracking-widest bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#002752]"
                  />
                </div>

                <div className="flex items-center justify-between text-xs px-1">
                  <button
                    type="button"
                    onClick={handleResendForgotCode}
                    disabled={resending}
                    className="font-bold text-[#c8102e] hover:underline disabled:opacity-50"
                  >
                    {resending ? 'Re-issuing code...' : 'Resend Code (Instant 0s)'}
                  </button>

                  <button
                    type="button"
                    onClick={() => setIsMailModalOpen(true)}
                    className="font-bold text-[#002752] dark:text-blue-400 hover:underline"
                  >
                    Open Mailbox Viewer
                  </button>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    New Password (min 8 chars)
                  </label>
                  <input
                    type="password"
                    required
                    placeholder="••••••••"
                    value={forgotNewPassword}
                    onChange={e => setForgotNewPassword(e.target.value)}
                    className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#002752]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Confirm New Password
                  </label>
                  <input
                    type="password"
                    required
                    placeholder="••••••••"
                    value={forgotConfirmPassword}
                    onChange={e => setForgotConfirmPassword(e.target.value)}
                    className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#002752]"
                  />
                </div>

                <div className="flex gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setForgotStep('request')}
                    className="flex-1 py-2.5 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-semibold rounded-xl text-xs hover:bg-slate-200"
                  >
                    Back
                  </button>
                  <button
                    type="submit"
                    disabled={forgotLoading}
                    className="flex-1 py-2.5 bg-[#002752] hover:bg-[#001d3d] disabled:opacity-50 text-white font-bold rounded-xl text-xs shadow-md"
                  >
                    {forgotLoading ? 'Updating...' : 'Update Password'}
                  </button>
                </div>
              </form>
            )}

            {forgotStep === 'done' && (
              <div className="text-center py-6 space-y-3">
                <CheckCircle2 className="w-14 h-14 text-emerald-500 mx-auto" />
                <h3 className="text-xl font-bold text-slate-900 dark:text-white">Password Updated</h3>
                <p className="text-xs text-slate-500">
                  Your account password has been successfully reset. You may now sign in using your new credentials.
                </p>
                <div className="pt-2">
                  <button
                    type="button"
                    onClick={() => { setMode('login'); setForgotStep('request'); }}
                    className="w-full py-2.5 bg-[#002752] hover:bg-[#001d3d] text-white font-bold rounded-xl text-xs shadow-md"
                  >
                    Sign In Now
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

      </div>

    </div>
  );
};

