import React from 'react';
import { useLanguage } from '../context/LanguageContext.tsx';
import { 
  ShieldCheck, 
  ArrowRight, 
  CreditCard, 
  Send, 
  Smartphone, 
  Lock, 
  PiggyBank,
  CheckCircle2,
  Phone,
  MessageCircle,
  Zap,
  FileCheck
} from 'lucide-react';

interface HomePageProps {
  onOpenAuth: (mode: 'login' | 'register') => void;
  onNavigate?: (page: string) => void;
}

export const HomePage: React.FC<HomePageProps> = ({ onOpenAuth, onNavigate }) => {
  const { t } = useLanguage();

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-800 dark:text-slate-100 transition-colors">
      
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-b from-blue-50/70 via-white to-slate-50 dark:from-slate-900 dark:via-slate-950 dark:to-slate-950 pt-12 pb-16 lg:pt-20 lg:pb-28">
        
        {/* Subtle decorative background glow */}
        <div className="absolute top-0 right-1/4 w-96 h-96 bg-red-500/10 dark:bg-red-500/5 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-10 left-10 w-96 h-96 bg-[#002752]/10 dark:bg-blue-600/5 rounded-full blur-3xl pointer-events-none" />

        <div className="max-w-7xl mx-auto px-4 sm:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            {/* Left Content Column */}
            <div className="lg:col-span-7 space-y-6">
              
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-red-100 dark:bg-red-950/60 border border-red-200 dark:border-red-900 text-red-700 dark:text-red-300 text-xs font-bold tracking-wide uppercase">
                <span className="w-2 h-2 rounded-full bg-red-600" />
                {t('hero.badge', 'SECURE • RELIABLE • GLOBAL')}
              </div>

              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black tracking-tight text-[#002752] dark:text-white leading-[1.1]">
                {t('hero.titleLine1', 'Banking for a')} <br className="hidden sm:inline" />
                <span className="text-[#c8102e]">{t('hero.titleLine2', 'Brighter Tomorrow.')}</span>
              </h1>

              <p className="text-lg text-slate-600 dark:text-slate-300 leading-relaxed max-w-2xl">
                {t('hero.description', 'At FNB, we’re more than just a bank. We’re your partner in progress — helping you achieve your personal and business financial aspirations, today and always.')}
              </p>

              {/* Action Buttons */}
              <div className="flex flex-wrap items-center gap-4 pt-2">
                <button
                  onClick={() => onOpenAuth('register')}
                  className="px-6 py-3.5 bg-[#c8102e] hover:bg-[#b00d27] text-white font-extrabold rounded-2xl shadow-lg shadow-red-600/20 hover:shadow-red-600/30 transition-all flex items-center gap-2 text-base group"
                >
                  <span>{t('hero.openAccount', 'Open An Account')}</span>
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </button>

                <button
                  onClick={() => onOpenAuth('login')}
                  className="px-6 py-3.5 bg-white dark:bg-slate-900 border-2 border-[#002752] dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-[#002752] dark:text-white font-bold rounded-2xl transition-all text-base"
                >
                  {t('hero.signIn', 'Sign In to Online Banking')}
                </button>
              </div>

              {/* Security & Reliability Metrics */}
              <div className="pt-6 border-t border-slate-200 dark:border-slate-800 grid grid-cols-3 gap-4 text-xs">
                <div>
                  <p className="font-extrabold text-xl text-[#002752] dark:text-white">{t('hero.encryptedMetric', '256-Bit')}</p>
                  <p className="text-slate-500 dark:text-slate-400">{t('hero.encryptedDesc', 'Encrypted Banking')}</p>
                </div>
                <div>
                  <p className="font-extrabold text-xl text-[#002752] dark:text-white">{t('hero.instantMetric', 'Instant')}</p>
                  <p className="text-slate-500 dark:text-slate-400">{t('hero.instantDesc', 'Electronic Transfers')}</p>
                </div>
                <div>
                  <p className="font-extrabold text-xl text-[#002752] dark:text-white">{t('hero.helplineMetric', '24 / 7')}</p>
                  <p className="text-slate-500 dark:text-slate-400">{t('hero.helplineDesc', 'Customer Helpline')}</p>
                </div>
              </div>

            </div>

            {/* Right Hero Image Card (User Attachment 2) */}
            <div className="lg:col-span-5 relative">
              <div className="relative rounded-3xl overflow-hidden shadow-2xl border-4 border-white dark:border-slate-800 bg-white dark:bg-slate-900 group">
                <img
                  src="/assets/aistudio/file_00000000ca8082108bfff4c109c0080a_a58f0a5a.png"
                  alt="FNB Banking for a Brighter Tomorrow"
                  className="w-full h-auto object-cover transform group-hover:scale-102 transition-transform duration-500"
                />

                {/* Floating Institutional Badge */}
                <div className="absolute bottom-4 left-4 right-4 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md p-4 rounded-2xl shadow-xl border border-slate-200/80 dark:border-slate-800 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-[#002752] text-white flex items-center justify-center font-black">
                      FNB
                    </div>
                    <div>
                      <p className="text-xs font-bold text-slate-900 dark:text-white">Your goals. Our priority.</p>
                      <p className="text-[11px] text-slate-500">First National Bank Premier Network</p>
                    </div>
                  </div>
                  <span className="px-2.5 py-1 bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 text-[10px] font-bold rounded-lg">
                    ONLINE
                  </span>
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* Core Banking Pillars */}
      <section id="features" className="py-20 bg-white dark:bg-slate-900 border-y border-slate-200 dark:border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-8">
          
          <div className="text-center max-w-2xl mx-auto mb-16">
            <span className="text-xs font-extrabold uppercase tracking-widest text-[#c8102e]">
              {t('features.tag', 'BANKING CAPABILITIES')}
            </span>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-[#002752] dark:text-white mt-2">
              {t('features.heading', 'Modern Banking Services for Everyday Life')}
            </h2>
            <p className="text-slate-600 dark:text-slate-400 text-sm mt-3">
              {t('features.subheading', 'Engineered with advanced financial technology, robust security safeguards, and seamless cross-device compatibility.')}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            
            {/* Feature 1 */}
            <div 
              onClick={() => onNavigate ? onNavigate('services') : onOpenAuth('login')}
              role="button"
              tabIndex={0}
              className="p-7 rounded-3xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 hover:border-red-400 dark:hover:border-red-700 hover:shadow-xl hover:-translate-y-1.5 transition-all cursor-pointer group text-left flex flex-col justify-between"
            >
              <div>
                <div className="w-12 h-12 rounded-2xl bg-red-100 dark:bg-red-950/60 text-red-600 flex items-center justify-center mb-5 group-hover:scale-110 transition-transform shadow-sm">
                  <Send className="w-6 h-6" />
                </div>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-2 group-hover:text-[#c8102e] transition-colors">
                  {t('features.transfersTitle', 'Domestic & International Transfers')}
                </h3>
                <p className="text-slate-600 dark:text-slate-400 text-xs leading-relaxed">
                  {t('features.transfersDesc', 'Send funds to any beneficiary with validated sort codes and account numbers. Complete with rapid processing, cryptographic reference tags, and instant downloadable receipts.')}
                </p>
              </div>
              <div className="mt-4 pt-3 border-t border-slate-200/60 dark:border-slate-800/60 flex items-center gap-1.5 text-xs font-bold text-[#002752] dark:text-blue-400 group-hover:translate-x-1 transition-transform">
                <span>{t('features.exploreTransfers', 'Explore Transfers')}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </div>
            </div>

            {/* Feature 2 */}
            <div 
              onClick={() => onNavigate ? onNavigate('services') : onOpenAuth('login')}
              role="button"
              tabIndex={0}
              className="p-7 rounded-3xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 hover:border-red-400 dark:hover:border-red-700 hover:shadow-xl hover:-translate-y-1.5 transition-all cursor-pointer group text-left flex flex-col justify-between"
            >
              <div>
                <div className="w-12 h-12 rounded-2xl bg-blue-100 dark:bg-blue-950/60 text-[#002752] dark:text-blue-400 flex items-center justify-center mb-5 group-hover:scale-110 transition-transform shadow-sm">
                  <CreditCard className="w-6 h-6" />
                </div>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-2 group-hover:text-[#c8102e] transition-colors">
                  {t('features.cardsTitle', 'Virtual Visa & Mastercard Cards')}
                </h3>
                <p className="text-slate-600 dark:text-slate-400 text-xs leading-relaxed">
                  {t('features.cardsDesc', 'Instantly provision debit cards with customizable daily limits, one-tap freeze/unfreeze controls, and dynamic CVV security.')}
                </p>
              </div>
              <div className="mt-4 pt-3 border-t border-slate-200/60 dark:border-slate-800/60 flex items-center gap-1.5 text-xs font-bold text-[#002752] dark:text-blue-400 group-hover:translate-x-1 transition-transform">
                <span>{t('features.viewCards', 'View Card Solutions')}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </div>
            </div>

            {/* Feature 3 */}
            <div 
              onClick={() => onNavigate ? onNavigate('services') : onOpenAuth('login')}
              role="button"
              tabIndex={0}
              className="p-7 rounded-3xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 hover:border-red-400 dark:hover:border-red-700 hover:shadow-xl hover:-translate-y-1.5 transition-all cursor-pointer group text-left flex flex-col justify-between"
            >
              <div>
                <div className="w-12 h-12 rounded-2xl bg-amber-100 dark:bg-amber-950/60 text-amber-600 flex items-center justify-center mb-5 group-hover:scale-110 transition-transform shadow-sm">
                  <Zap className="w-6 h-6" />
                </div>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-2 group-hover:text-[#c8102e] transition-colors">
                  {t('features.billsTitle', 'Utility Bill Payments & Top-Ups')}
                </h3>
                <p className="text-slate-600 dark:text-slate-400 text-xs leading-relaxed">
                  {t('features.billsDesc', 'Pay electricity, internet broadband, airtime, and mobile data packages directly from your account balance with official receipts.')}
                </p>
              </div>
              <div className="mt-4 pt-3 border-t border-slate-200/60 dark:border-slate-800/60 flex items-center gap-1.5 text-xs font-bold text-[#002752] dark:text-blue-400 group-hover:translate-x-1 transition-transform">
                <span>{t('features.learnMore', 'Learn More')}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </div>
            </div>

            {/* Feature 4 */}
            <div 
              onClick={() => onNavigate ? onNavigate('security') : onOpenAuth('login')}
              role="button"
              tabIndex={0}
              className="p-7 rounded-3xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 hover:border-red-400 dark:hover:border-red-700 hover:shadow-xl hover:-translate-y-1.5 transition-all cursor-pointer group text-left flex flex-col justify-between"
            >
              <div>
                <div className="w-12 h-12 rounded-2xl bg-emerald-100 dark:bg-emerald-950/60 text-emerald-600 flex items-center justify-center mb-5 group-hover:scale-110 transition-transform shadow-sm">
                  <ShieldCheck className="w-6 h-6" />
                </div>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-2 group-hover:text-[#c8102e] transition-colors">
                  {t('features.otpTitle', 'Multi-Factor OTP Authentication')}
                </h3>
                <p className="text-slate-600 dark:text-slate-400 text-xs leading-relaxed">
                  {t('features.otpDesc', 'Secure registration and banking access protected by 6-digit email OTP verification, server-side password hashing, and administrative review.')}
                </p>
              </div>
              <div className="mt-4 pt-3 border-t border-slate-200/60 dark:border-slate-800/60 flex items-center gap-1.5 text-xs font-bold text-[#002752] dark:text-blue-400 group-hover:translate-x-1 transition-transform">
                <span>{t('features.securityStandards', 'Security Standards')}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </div>
            </div>

            {/* Feature 5 */}
            <div 
              onClick={() => onNavigate ? onNavigate('about') : onOpenAuth('login')}
              role="button"
              tabIndex={0}
              className="p-7 rounded-3xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 hover:border-red-400 dark:hover:border-red-700 hover:shadow-xl hover:-translate-y-1.5 transition-all cursor-pointer group text-left flex flex-col justify-between"
            >
              <div>
                <div className="w-12 h-12 rounded-2xl bg-purple-100 dark:bg-purple-950/60 text-purple-600 flex items-center justify-center mb-5 group-hover:scale-110 transition-transform shadow-sm">
                  <Smartphone className="w-6 h-6" />
                </div>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-2 group-hover:text-[#c8102e] transition-colors">
                  {t('features.crossDeviceTitle', 'Cross-Device Experience')}
                </h3>
                <p className="text-slate-600 dark:text-slate-400 text-xs leading-relaxed">
                  {t('features.crossDeviceDesc', 'Fully responsive layout engineered to perform smoothly across iOS, Android, tablets, and desktop computers.')}
                </p>
              </div>
              <div className="mt-4 pt-3 border-t border-slate-200/60 dark:border-slate-800/60 flex items-center gap-1.5 text-xs font-bold text-[#002752] dark:text-blue-400 group-hover:translate-x-1 transition-transform">
                <span>{t('features.aboutPlatform', 'About Our Platform')}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </div>
            </div>

            {/* Feature 6 */}
            <div 
              onClick={() => onNavigate ? onNavigate('services') : onOpenAuth('login')}
              role="button"
              tabIndex={0}
              className="p-7 rounded-3xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 hover:border-red-400 dark:hover:border-red-700 hover:shadow-xl hover:-translate-y-1.5 transition-all cursor-pointer group text-left flex flex-col justify-between"
            >
              <div>
                <div className="w-12 h-12 rounded-2xl bg-rose-100 dark:bg-rose-950/60 text-rose-600 flex items-center justify-center mb-5 group-hover:scale-110 transition-transform shadow-sm">
                  <FileCheck className="w-6 h-6" />
                </div>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-2 group-hover:text-[#c8102e] transition-colors">
                  {t('features.statementsTitle', 'Certified Account Statements')}
                </h3>
                <p className="text-slate-600 dark:text-slate-400 text-xs leading-relaxed">
                  {t('features.statementsDesc', 'Generate official printable account statements and CSV records complete with Sort Code 20-04-15 and transaction references.')}
                </p>
              </div>
              <div className="mt-4 pt-3 border-t border-slate-200/60 dark:border-slate-800/60 flex items-center gap-1.5 text-xs font-bold text-[#002752] dark:text-blue-400 group-hover:translate-x-1 transition-transform">
                <span>{t('features.generateStatements', 'Generate Statements')}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </div>
            </div>

          </div>

        </div>
      </section>

      {/* Children & Youth Savings Section (User Attachment 3) */}
      <section id="savings" className="py-20 bg-gradient-to-br from-slate-100 via-white to-blue-50/50 dark:from-slate-950 dark:via-slate-900 dark:to-slate-950">
        <div className="max-w-7xl mx-auto px-4 sm:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            {/* Visual Attachment 3 */}
            <div className="lg:col-span-5 order-2 lg:order-1">
              <div className="relative rounded-3xl overflow-hidden shadow-2xl border-4 border-white dark:border-slate-800 bg-white dark:bg-slate-900 group">
                <img
                  src="/assets/aistudio/file_0000000001888210a364b9b0694cab78_6a6bbbe5.png"
                  alt="FNB Little Steps, Big Dreams Savings"
                  className="w-full h-auto object-cover group-hover:scale-102 transition-transform duration-500"
                />
              </div>
            </div>

            {/* Content Details */}
            <div className="lg:col-span-7 order-1 lg:order-2 space-y-6">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300 text-xs font-bold uppercase tracking-wider">
                <PiggyBank className="w-4 h-4 text-amber-600" />
                CHILD & FUTURE SAVINGS
              </div>

              <h2 className="text-3xl sm:text-5xl font-black text-[#002752] dark:text-white tracking-tight leading-tight">
                Little Steps, <br />
                <span className="text-[#c8102e]">Big Dreams!</span>
              </h2>

              <p className="text-base text-slate-600 dark:text-slate-300 leading-relaxed">
                Open a savings account for your child today. Because their future deserves a great start. Teach smart money management, build solid savings habits, and prepare for long-term growth.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                  <h4 className="font-bold text-sm text-[#002752] dark:text-white flex items-center gap-2 mb-1">
                    <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                    Build Good Habits
                  </h4>
                  <p className="text-xs text-slate-500">
                    Teach your child the value of saving and smart financial habits from an early age.
                  </p>
                </div>

                <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                  <h4 className="font-bold text-sm text-[#002752] dark:text-white flex items-center gap-2 mb-1">
                    <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                    Secure Their Future
                  </h4>
                  <p className="text-xs text-slate-500">
                    Consistent savings today unlock future education and life opportunities tomorrow.
                  </p>
                </div>
              </div>

              <div className="pt-2">
                <button
                  onClick={() => onOpenAuth('register')}
                  className="px-6 py-3.5 bg-[#c8102e] hover:bg-[#b00d27] text-white font-bold rounded-2xl shadow-lg transition-all flex items-center gap-2"
                >
                  <span>Open a Child Savings Account</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>

            </div>

          </div>
        </div>
      </section>

      {/* Security & Regulatory Compliance */}
      <section id="security" className="py-20 bg-[#002752] text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            
            <div className="space-y-4">
              <span className="text-xs font-bold text-red-400 uppercase tracking-widest">
                FINANCIAL INSTITUTION PROTECTION
              </span>
              <h2 className="text-3xl font-extrabold tracking-tight">
                Institutional Security Built into Every Layer
              </h2>
              <p className="text-slate-300 text-sm leading-relaxed">
                From server-side cryptographic scrypt password hashing and email OTP authentication to rate limiting and comprehensive administrative audit trails, customer records and funds are protected by industry-standard encryption protocols.
              </p>
              
              <div className="pt-4 flex flex-wrap gap-6 text-xs text-slate-200">
                <div className="flex items-center gap-2">
                  <Phone className="w-4 h-4 text-red-400" />
                  <span>Telephone Helpline: <strong>+447723165577</strong></span>
                </div>
                <div className="flex items-center gap-2">
                  <MessageCircle className="w-4 h-4 text-emerald-400" />
                  <span>WhatsApp: <strong>+447723165577</strong></span>
                </div>
              </div>
            </div>

            <div className="bg-white/10 p-7 rounded-3xl border border-white/15 backdrop-blur-md space-y-4">
              <h3 className="font-bold text-lg text-white">Banking Coordinates & Support</h3>
              <p className="text-xs text-slate-200 leading-relaxed">
                Official contact and registration records for First National Bank.
              </p>
              <div className="space-y-2.5 text-xs">
                <div className="flex justify-between py-2 border-b border-white/10">
                  <span className="text-slate-300">Bank Name</span>
                  <span className="font-bold text-white">FNB (First National Bank)</span>
                </div>
                <div className="flex justify-between py-2 border-b border-white/10">
                  <span className="text-slate-300">Official Inquiries</span>
                  <span className="font-mono text-white">info@fnnbbankss.online</span>
                </div>
                <div className="flex justify-between py-2 border-b border-white/10">
                  <span className="text-slate-300">Branch Sort Code</span>
                  <span className="font-mono font-bold text-white">20-04-15</span>
                </div>
                <div className="flex justify-between py-2">
                  <span className="text-slate-300">Customer Helpline</span>
                  <span className="font-bold text-emerald-300">+447723165577</span>
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>

    </div>
  );
};
