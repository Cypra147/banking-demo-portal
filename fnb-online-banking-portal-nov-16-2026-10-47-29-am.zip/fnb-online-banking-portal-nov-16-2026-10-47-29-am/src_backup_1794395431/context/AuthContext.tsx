import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { User, EmailMessage } from '../types.ts';
import { api, clearSessionToken, setSessionToken, getSessionToken } from '../services/api.ts';

interface AuthContextType {
  user: User | null;
  adminUser: User | null;
  activePortal: 'customer' | 'admin' | 'public';
  setActivePortal: (portal: 'customer' | 'admin' | 'public') => void;
  isLoading: boolean;
  theme: 'light' | 'dark';
  toggleTheme: () => void;
  // Auth actions
  loginCustomer: (identifier: string, pass: string) => Promise<void>;
  loginAdmin: (pass: string, email: string) => Promise<void>;
  logout: () => void;
  refreshUser: () => Promise<void>;
  // Mail notification center
  emails: EmailMessage[];
  unreadEmailCount: number;
  isMailModalOpen: boolean;
  setIsMailModalOpen: (open: boolean) => void;
  fetchEmails: () => Promise<void>;
  markEmailRead: (id: string) => Promise<void>;
  activeEmailForPreview: EmailMessage | null;
  setActiveEmailForPreview: (email: EmailMessage | null) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [adminUser, setAdminUser] = useState<User | null>(null);
  const [activePortal, setActivePortal] = useState<'customer' | 'admin' | 'public'>('public');
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [theme, setTheme] = useState<'light' | 'dark'>('light');

  // Emails & notification modal
  const [emails, setEmails] = useState<EmailMessage[]>([]);
  const [isMailModalOpen, setIsMailModalOpen] = useState(false);
  const [activeEmailForPreview, setActiveEmailForPreview] = useState<EmailMessage | null>(null);

  // Load saved theme
  useEffect(() => {
    const savedTheme = localStorage.getItem('fnb_theme') as 'light' | 'dark';
    if (savedTheme) {
      setTheme(savedTheme);
      if (savedTheme === 'dark') {
        document.documentElement.classList.add('dark');
      } else {
        document.documentElement.classList.remove('dark');
      }
    }
  }, []);

  const toggleTheme = () => {
    setTheme(prev => {
      const next = prev === 'light' ? 'dark' : 'light';
      localStorage.setItem('fnb_theme', next);
      if (next === 'dark') {
        document.documentElement.classList.add('dark');
      } else {
        document.documentElement.classList.remove('dark');
      }
      return next;
    });
  };

  const fetchEmails = useCallback(async () => {
    try {
      const isAdmin = activePortal === 'admin' || (!!adminUser && !user);
      const res = await api.getEmails(isAdmin);
      setEmails(res.emails || []);
    } catch {
      // Silently fail if not authenticated
    }
  }, [activePortal, adminUser, user]);

  const markEmailRead = async (id: string) => {
    try {
      await api.markEmailRead(id, activePortal === 'admin');
      setEmails(prev => prev.map(e => e.id === id ? { ...e, read: true } : e));
    } catch (e) {
      console.error(e);
    }
  };

  // Initial session restoration
  useEffect(() => {
    const initAuth = async () => {
      setIsLoading(true);
      const token = getSessionToken(false);
      const adminToken = getSessionToken(true);

      if (token) {
        try {
          const res = await api.getMe(false);
          if (res.user.role === 'customer') {
            setUser(res.user);
            setActivePortal('customer');
          }
        } catch {
          // Token expired or invalid
        }
      }

      if (adminToken) {
        try {
          const res = await api.getMe(true);
          if (res.user.role === 'admin') {
            setAdminUser(res.user);
            if (!token) {
              setActivePortal('admin');
            }
          }
        } catch {
          // Admin token expired
        }
      }

      setIsLoading(false);
    };

    initAuth();
  }, []);

  // Poll for live emails periodically so OTPs and transaction notices appear instantly
  useEffect(() => {
    fetchEmails();
    const interval = setInterval(fetchEmails, 2000);
    return () => clearInterval(interval);
  }, [fetchEmails]);

  const loginCustomer = async (identifier: string, pass: string) => {
    const res = await api.login(identifier, pass);
    setSessionToken(res.token, false);
    setUser(res.user);
    setActivePortal('customer');
    await fetchEmails();
  };

  const loginAdmin = async (pass: string, email: string) => {
    const res = await api.adminLogin(pass, email);
    setSessionToken(res.token, true);
    setAdminUser(res.user);
    setActivePortal('admin');
    await fetchEmails();
  };

  const logout = () => {
    if (activePortal === 'admin') {
      localStorage.removeItem('fnb_admin_token');
      setAdminUser(null);
    } else {
      localStorage.removeItem('fnb_session_token');
      setUser(null);
    }
    setActivePortal('public');
  };

  const refreshUser = async () => {
    if (activePortal === 'admin' && adminUser) {
      try {
        const res = await api.getMe(true);
        setAdminUser(res.user);
      } catch (e) {
        console.error(e);
      }
    } else if (user) {
      try {
        const res = await api.getMe(false);
        setUser(res.user);
      } catch (e) {
        console.error(e);
      }
    }
  };

  const unreadEmailCount = emails.filter(e => !e.read).length;

  return (
    <AuthContext.Provider
      value={{
        user,
        adminUser,
        activePortal,
        setActivePortal,
        isLoading,
        theme,
        toggleTheme,
        loginCustomer,
        loginAdmin,
        logout,
        refreshUser,
        emails,
        unreadEmailCount,
        isMailModalOpen,
        setIsMailModalOpen,
        fetchEmails,
        markEmailRead,
        activeEmailForPreview,
        setActiveEmailForPreview,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
