import { 
  User, 
  Transaction, 
  VirtualCard, 
  AuditLog, 
  EmailMessage, 
  LoginActivity, 
  InvestmentPlan, 
  InvestmentRequest, 
  VerificationRequest, 
  SupportEnquiry, 
  NotificationItem 
} from '../types.ts';

const TOKEN_KEY = 'fnb_session_token';
const ADMIN_TOKEN_KEY = 'fnb_admin_token';

export function getSessionToken(isAdmin = false): string | null {
  return localStorage.getItem(isAdmin ? ADMIN_TOKEN_KEY : TOKEN_KEY) || localStorage.getItem(TOKEN_KEY);
}

export function setSessionToken(token: string, isAdmin = false) {
  if (isAdmin) {
    localStorage.setItem(ADMIN_TOKEN_KEY, token);
  } else {
    localStorage.setItem(TOKEN_KEY, token);
  }
}

export function clearSessionToken() {
  localStorage.removeItem(TOKEN_KEY);
  localStorage.removeItem(ADMIN_TOKEN_KEY);
}

async function request<T>(endpoint: string, options: RequestInit = {}, isAdmin = false): Promise<T> {
  const token = getSessionToken(isAdmin);
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(options.headers as Record<string, string> || {}),
  };

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  let response: Response;
  try {
    response = await fetch(endpoint, {
      ...options,
      headers,
    });
  } catch (netErr: any) {
    console.error('Network request failed:', netErr);
    throw new Error('Unable to connect to the banking server. Please verify your connection or try again shortly.');
  }

  const data = await response.json().catch(() => ({}));

  if (!response.ok) {
    throw new Error(data.error || `Request failed with status ${response.status}`);
  }

  return data as T;
}

export const api = {
  registerRequest: (payload: {
    firstName?: string;
    lastName?: string;
    fullName?: string;
    email: string;
    username: string;
    phone: string;
    country?: string;
    residentialAddress?: string;
    password: string;
    confirmPassword: string;
  }) => request<{ success: boolean; message: string; email: string; otpCode?: string }>('/api/auth/register-request', {
    method: 'POST',
    body: JSON.stringify(payload),
  }),

  resendOtp: (email: string) =>
    request<{ success: boolean; message: string; email?: string; otpCode?: string }>('/api/auth/resend-otp', {
      method: 'POST',
      body: JSON.stringify({ email }),
    }),

  verifyOtpAndSubmit: (email: string, code: string) =>
    request<{ success: boolean; message: string; user: any }>('/api/auth/verify-otp-and-submit', {
      method: 'POST',
      body: JSON.stringify({ email, code }),
    }),

  forgotPassword: (email: string) =>
    request<{ success: boolean; message: string; email?: string; resetCode?: string }>('/api/auth/forgot-password', {
      method: 'POST',
      body: JSON.stringify({ email }),
    }),

  resetPassword: (payload: { email: string; code: string; newPassword: string; confirmPassword: string }) =>
    request<{ success: boolean; message: string }>('/api/auth/reset-password', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  login: (identifier: string, password: string) =>
    request<{ success: boolean; token: string; user: User }>('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ identifier, password }),
    }),

  adminLogin: (password: string, email: string) =>
    request<{ success: boolean; token: string; user: User }>('/api/auth/admin-login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    }),

  getMe: (isAdmin = false) => request<{ user: User }>('/api/auth/me', { method: 'GET' }, isAdmin),

  updateProfile: (profile: { firstName?: string; lastName?: string; fullName?: string; phone?: string; country?: string; residentialAddress?: string; isTwoFactorEnabled?: boolean }) =>
    request<{ success: boolean; user: User }>('/api/auth/profile', {
      method: 'PUT',
      body: JSON.stringify(profile),
    }),

  changePassword: (currentPassword: string, newPassword: string) =>
    request<{ success: boolean; message: string }>('/api/auth/change-password', {
      method: 'POST',
      body: JSON.stringify({ currentPassword, newPassword }),
    }),

  getLoginActivity: () => request<{ activities: LoginActivity[] }>('/api/auth/login-activity', { method: 'GET' }),

  // --- Customer Banking ---
  getBankingSummary: () => request<{
    account: {
      id: string;
      holderName: string;
      email: string;
      phone: string;
      accountNumber: string;
      sortCode: string;
      balance: number;
      currency: string;
      status: string;
      isSandbox: boolean;
      unreadEmails: number;
      kycStatus?: 'unverified' | 'pending' | 'verified' | 'rejected';
    };
    recentTransactions: Transaction[];
    virtualCards: VirtualCard[];
  }>('/api/banking/summary', { method: 'GET' }),

  transfer: (payload: {
    beneficiaryName: string;
    beneficiaryBank: string;
    beneficiaryAccount: string;
    amount: number;
    description: string;
    reference?: string;
  }) => request<{
    success: boolean;
    message: string;
    transaction: Transaction;
    newBalance: number;
    sandboxNotice: string;
  }>('/api/banking/transfer', {
    method: 'POST',
    body: JSON.stringify(payload),
  }),

  fastForwardReversal: (transactionId: string) =>
    request<{ success: boolean; message: string; reversalTransaction: Transaction }>('/api/banking/fast-forward-reversal', {
      method: 'POST',
      body: JSON.stringify({ transactionId }),
    }),

  withdraw: (payload: { amount: number; method: string; destinationAccount: string }) =>
    request<{ success: boolean; message: string; transaction: Transaction }>('/api/banking/withdraw', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  payBill: (payload: {
    billerCategory: string;
    billerName: string;
    accountOrMeterNumber: string;
    amount: number;
  }) => request<{ success: boolean; message: string; transaction: Transaction }>('/api/banking/pay-bill', {
    method: 'POST',
    body: JSON.stringify(payload),
  }),

  getVirtualCards: () => request<{ cards: VirtualCard[] }>('/api/banking/virtual-cards', { method: 'GET' }),

  toggleCardFreeze: (cardId: string) =>
    request<{ success: boolean; card: VirtualCard }>(`/api/banking/virtual-cards/${cardId}/toggle-freeze`, {
      method: 'POST',
    }),

  updateCardLimits: (cardId: string, dailyLimit: number, onlineTransactionsEnabled: boolean) =>
    request<{ success: boolean; card: VirtualCard }>(`/api/banking/virtual-cards/${cardId}/limits`, {
      method: 'POST',
      body: JSON.stringify({ dailyLimit, onlineTransactionsEnabled }),
    }),

  getTransactions: (filters?: { type?: string; status?: string; tag?: string }) => {
    const params = new URLSearchParams(filters as any).toString();
    return request<{ transactions: Transaction[] }>(`/api/banking/transactions?${params}`, { method: 'GET' });
  },

  // --- Investments ---
  getInvestmentPlans: () => request<{ plans: InvestmentPlan[] }>('/api/banking/investment-plans', { method: 'GET' }),

  getInvestments: (isAdmin = false) =>
    request<{ investments: InvestmentRequest[] }>('/api/banking/investments', { method: 'GET' }, isAdmin),

  createInvestment: (payload: { planId: string; amount: number; durationMonths: number; userNotes?: string }) =>
    request<{ success: boolean; message: string; investment: InvestmentRequest }>('/api/banking/investments', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  updateInvestmentStatus: (investmentId: string, status: string, adminComments?: string) =>
    request<{ success: boolean; message: string; investment: InvestmentRequest }>(`/api/admin/investments/${investmentId}/status`, {
      method: 'POST',
      body: JSON.stringify({ status, adminComments }),
    }, true),

  // --- Identity Verification (KYC) ---
  getVerifications: (isAdmin = false) =>
    request<{ verifications: VerificationRequest[] }>('/api/banking/verifications', { method: 'GET' }, isAdmin),

  createVerification: (payload: Omit<VerificationRequest, 'id' | 'userId' | 'reference' | 'status' | 'createdAt'>) =>
    request<{ success: boolean; message: string; verification: VerificationRequest }>('/api/banking/verifications', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  updateVerificationStatus: (verificationId: string, status: string, adminComments?: string) =>
    request<{ success: boolean; message: string; verification: VerificationRequest }>(`/api/admin/verifications/${verificationId}/status`, {
      method: 'POST',
      body: JSON.stringify({ status, adminComments }),
    }, true),

  // --- Support & Tickets ---
  getSupportEnquiries: (email?: string, isAdmin = false) => {
    const query = email ? `?email=${encodeURIComponent(email)}` : '';
    return request<{ enquiries: SupportEnquiry[] }>(`/api/support/enquiries${query}`, { method: 'GET' }, isAdmin);
  },

  createSupportEnquiry: (payload: { name: string; email: string; phone?: string; category: string; subject: string; message: string }) =>
    request<{ success: boolean; message: string; enquiry: SupportEnquiry }>('/api/support/enquiries', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  replySupportEnquiry: (enquiryId: string, reply: string, status?: string) =>
    request<{ success: boolean; message: string; enquiry: SupportEnquiry }>(`/api/admin/support/${enquiryId}/reply`, {
      method: 'POST',
      body: JSON.stringify({ reply, status }),
    }, true),

  // --- Notifications ---
  getNotifications: () => request<{ notifications: NotificationItem[] }>('/api/banking/notifications', { method: 'GET' }),

  markNotificationRead: (notificationId: string) =>
    request<{ success: boolean }>(`/api/banking/notifications/${notificationId}/read`, { method: 'POST' }),

  // --- Emails / Notification Center ---
  getEmails: (isAdmin = false) => request<{ emails: EmailMessage[] }>('/api/emails', { method: 'GET' }, isAdmin),

  markEmailRead: (emailId: string, isAdmin = false) =>
    request<{ success: boolean }>(`/api/emails/${emailId}/read`, { method: 'POST' }, isAdmin),

  // --- Administrator Controls ---
  getAdminStats: () => request<any>('/api/admin/stats', { method: 'GET' }, true),

  getAdminCustomers: () => request<{ customers: User[] }>('/api/admin/customers', { method: 'GET' }, true),

  approveCustomer: (customerId: string, initialBalance = 10000) =>
    request<{ success: boolean; message: string; user: User }>(`/api/admin/customers/${customerId}/approve`, {
      method: 'POST',
      body: JSON.stringify({ initialBalance }),
    }, true),

  rejectCustomer: (customerId: string, reason?: string) =>
    request<{ success: boolean; message: string; user: User }>(`/api/admin/customers/${customerId}/reject`, {
      method: 'POST',
      body: JSON.stringify({ reason }),
    }, true),

  setCustomerStatus: (customerId: string, status: 'active' | 'frozen' | 'suspended') =>
    request<{ success: boolean; message: string; user: User }>(`/api/admin/customers/${customerId}/status`, {
      method: 'POST',
      body: JSON.stringify({ status }),
    }, true),

  updateCustomerProfile: (customerId: string, profile: { firstName: string; lastName: string; phone: string; username: string }) =>
    request<{ success: boolean; user: User }>(`/api/admin/customers/${customerId}/profile`, {
      method: 'PUT',
      body: JSON.stringify(profile),
    }, true),

  adminCreditDebit: (payload: { customerId: string; type: 'credit' | 'debit'; amount: number; description: string; reference?: string }) =>
    request<{ success: boolean; message: string; transaction: Transaction }>('/api/admin/accounts/credit-debit', {
      method: 'POST',
      body: JSON.stringify(payload),
    }, true),

  getAdminLedger: (filters?: { userId?: string; type?: string; status?: string }) => {
    const params = new URLSearchParams(filters as any).toString();
    return request<{ ledger: Transaction[] }>(`/api/admin/ledger?${params}`, { method: 'GET' }, true);
  },

  adminReversal: (transactionId: string) =>
    request<{ success: boolean; message: string; transaction: Transaction }>(`/api/admin/transactions/${transactionId}/reversal`, {
      method: 'POST',
    }, true),

  getAdminAuditLogs: () => request<{ auditLogs: AuditLog[] }>('/api/admin/audit-logs', { method: 'GET' }, true),
};

