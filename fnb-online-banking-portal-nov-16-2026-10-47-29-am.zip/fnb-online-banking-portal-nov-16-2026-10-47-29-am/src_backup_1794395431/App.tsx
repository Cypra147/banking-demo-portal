/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext.tsx';
import { LanguageProvider } from './context/LanguageContext.tsx';
import { Navbar } from './components/Navbar.tsx';
import { Footer } from './components/Footer.tsx';
import { HomePage } from './pages/HomePage.tsx';
import { AuthPages } from './pages/AuthPages.tsx';
import { CustomerDashboard } from './pages/CustomerDashboard.tsx';
import { AdminDashboard } from './pages/AdminDashboard.tsx';
import { AdminLoginPage } from './pages/AdminLoginPage.tsx';
import { AboutPage } from './pages/AboutPage.tsx';
import { ServicesPage } from './pages/ServicesPage.tsx';
import { InvestmentsPage } from './pages/InvestmentsPage.tsx';
import { VerificationPage } from './pages/VerificationPage.tsx';
import { TransactionsPage } from './pages/TransactionsPage.tsx';
import { SupportPage } from './pages/SupportPage.tsx';
import { 
  PrivacyPolicyPage, 
  TermsConditionsPage, 
  SecurityCentrePage, 
  FAQPage 
} from './pages/LegalPages.tsx';
import { EmailViewerModal } from './components/EmailViewerModal.tsx';
import { X } from 'lucide-react';

const AppContent: React.FC = () => {
  const { user, adminUser, activePortal, setActivePortal, isLoading } = useAuth();
  
  // URL Route State
  const [currentPath, setCurrentPath] = useState<string>(() => {
    if (typeof window !== 'undefined') {
      return window.location.pathname || '/';
    }
    return '/';
  });

  // Listen for browser navigation (popstate)
  useEffect(() => {
    const handlePopState = () => {
      setCurrentPath(window.location.pathname || '/');
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  const navigate = (path: string) => {
    window.history.pushState({}, '', path);
    setCurrentPath(path);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const getPageIdFromPath = (path: string): string => {
    const clean = path.replace(/\/$/, '') || '/';
    if (clean === '/admin') return 'admin';
    if (clean === '/about') return 'about';
    if (clean === '/services') return 'services';
    if (clean === '/investments') return 'investments';
    if (clean === '/verification') return 'verification';
    if (clean === '/transactions') return 'transactions';
    if (clean === '/support') return 'support';
    if (clean === '/privacy') return 'privacy';
    if (clean === '/terms') return 'terms';
    if (clean === '/security') return 'security';
    if (clean === '/faq') return 'faq';
    if (clean === '/dashboard') return 'dashboard';
    return 'home';
  };

  const currentPage = getPageIdFromPath(currentPath);

  const handleNavigateByPageId = (pageId: string) => {
    if (pageId === 'home') {
      setActivePortal('public');
      navigate('/');
    } else if (pageId === 'dashboard') {
      if (!user) {
        openAuth('login');
      } else {
        setActivePortal('customer');
        navigate('/dashboard');
      }
    } else {
      setActivePortal('public');
      navigate(`/${pageId}`);
    }
  };

  // Auth Modal state for customer portal
  const [authModal, setAuthModal] = useState<{
    isOpen: boolean;
    mode: 'login' | 'register' | 'forgot';
  }>({
    isOpen: false,
    mode: 'login',
  });

  const openAuth = (mode: 'login' | 'register' | 'forgot' = 'login') => {
    setAuthModal({ isOpen: true, mode });
  };

  const closeAuth = () => {
    setAuthModal(prev => ({ ...prev, isOpen: false }));
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#002752] flex flex-col items-center justify-center text-white">
        <div className="w-16 h-16 rounded-2xl bg-white p-2 shadow-xl flex items-center justify-center animate-bounce">
          <img 
            src="/assets/aistudio/file_00000000763081f4a6c9438dcd4940cf_665e4923.png" 
            alt="FNB" 
            className="w-12 h-12 object-contain"
          />
        </div>
        <p className="mt-4 font-black tracking-widest text-lg">FIRST NATIONAL BANK</p>
        <p className="text-xs text-red-400 font-semibold tracking-wider mt-1">INITIALIZING SECURE BANKING SERVICES...</p>
      </div>
    );
  }

  // Check if current route is the protected /admin path
  const isAdminRoute = currentPath === '/admin' || currentPath.startsWith('/admin/');

  // ================= ADMIN ROUTE (/admin) =================
  if (isAdminRoute) {
    if (!adminUser) {
      // Redirect unauthenticated visitors to the administrator login page
      return (
        <>
          <AdminLoginPage 
            onSuccess={() => {
              navigate('/admin');
            }}
            onNavigateHome={() => {
              navigate('/');
            }}
          />
          <EmailViewerModal />
        </>
      );
    }

    // Authenticated Administrator Dashboard
    return (
      <div className="min-h-screen flex flex-col bg-slate-100 dark:bg-slate-950 text-slate-900 dark:text-slate-100 font-['Plus_Jakarta_Sans',sans-serif]">
        {/* Administrator Header Strip */}
        <div className="bg-[#001736] text-slate-300 text-xs py-2 px-6 flex items-center justify-between border-b border-blue-900/50">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400" />
            <span className="font-semibold text-white">FNB Internal Admin Management Environment</span>
          </div>
          <button
            onClick={() => {
              navigate('/');
            }}
            className="text-xs text-slate-300 hover:text-white underline-offset-4 hover:underline"
          >
            ← View Public Banking Website
          </button>
        </div>

        <main className="flex-1">
          <AdminDashboard />
        </main>

        <EmailViewerModal />
      </div>
    );
  }

  // ================= MAIN APPLICATION ROUTER =================
  return (
    <div className="min-h-screen flex flex-col bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 font-['Plus_Jakarta_Sans',sans-serif]">
      
      {/* Universal Top Navigation */}
      <Navbar 
        currentPage={currentPage}
        onNavigate={handleNavigateByPageId}
        onOpenAuth={openAuth}
      />

      {/* Main Content Router */}
      <main className="flex-1">
        {currentPage === 'dashboard' && user ? (
          <CustomerDashboard />
        ) : currentPage === 'about' ? (
          <AboutPage onOpenAuth={openAuth} onNavigate={handleNavigateByPageId} />
        ) : currentPage === 'services' ? (
          <ServicesPage onOpenAuth={openAuth} onNavigate={handleNavigateByPageId} />
        ) : currentPage === 'investments' ? (
          <InvestmentsPage 
            onOpenAuth={openAuth} 
            onNavigate={handleNavigateByPageId}
            isAuthenticated={!!user}
          />
        ) : currentPage === 'verification' ? (
          <VerificationPage 
            onOpenAuth={openAuth} 
            onNavigate={handleNavigateByPageId}
            isAuthenticated={!!user}
          />
        ) : currentPage === 'transactions' ? (
          <TransactionsPage 
            onOpenAuth={openAuth} 
            onNavigate={handleNavigateByPageId}
            isAuthenticated={!!user}
          />
        ) : currentPage === 'support' ? (
          <SupportPage 
            onOpenAuth={openAuth} 
            userEmail={user?.email}
            userName={user?.fullName || `${user?.firstName || ''} ${user?.lastName || ''}`.trim()}
          />
        ) : currentPage === 'privacy' ? (
          <PrivacyPolicyPage onNavigate={handleNavigateByPageId} onOpenAuth={openAuth} />
        ) : currentPage === 'terms' ? (
          <TermsConditionsPage onNavigate={handleNavigateByPageId} onOpenAuth={openAuth} />
        ) : currentPage === 'security' ? (
          <SecurityCentrePage onNavigate={handleNavigateByPageId} onOpenAuth={openAuth} />
        ) : currentPage === 'faq' ? (
          <FAQPage onNavigate={handleNavigateByPageId} onOpenAuth={openAuth} />
        ) : (
          // Default Home Route
          <HomePage onOpenAuth={openAuth} onNavigate={handleNavigateByPageId} />
        )}
      </main>

      {/* Universal Banking Footer */}
      <Footer 
        onNavigate={handleNavigateByPageId}
        onOpenCustomerAuth={() => openAuth('login')} 
        onNavigateAdmin={() => navigate('/admin')}
      />

      {/* Auth Modal (Customer Login, Registration & Password Recovery) */}
      {authModal.isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-sm animate-fade-in">
          <div className="relative w-full max-w-xl">
            <button
              onClick={closeAuth}
              className="absolute -top-3 -right-3 z-20 w-9 h-9 rounded-full bg-slate-800 text-white flex items-center justify-center hover:bg-red-600 transition-colors shadow-lg"
            >
              <X className="w-5 h-5" />
            </button>
            <AuthPages 
              initialMode={authModal.mode} 
              onClose={closeAuth} 
              onSuccess={() => {
                navigate('/dashboard');
              }}
            />
          </div>
        </div>
      )}

      {/* Live Communications & Notification Center */}
      <EmailViewerModal />

    </div>
  );
};

export default function App() {
  return (
    <LanguageProvider>
      <AuthProvider>
        <AppContent />
      </AuthProvider>
    </LanguageProvider>
  );
}
