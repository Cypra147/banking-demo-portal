import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { 
  User, 
  Transaction, 
  VirtualCard, 
  AuditLog, 
  LoginActivity, 
  EmailMessage, 
  NotificationItem,
  InvestmentPlan,
  InvestmentRequest,
  VerificationRequest,
  SupportEnquiry
} from '../types.ts';
import { INVESTMENT_PLANS } from '../constants/investments.ts';
import { tagTransaction } from '../utils/transactionTagger.ts';
export { INVESTMENT_PLANS };

const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'fnb_database.json');

export interface StoredUser extends User {
  passwordHash: string;
  salt: string;
}

export interface OTPRecord {
  email: string;
  code: string;
  expiresAt: number;
  payload: {
    firstName: string;
    lastName: string;
    fullName?: string;
    email: string;
    username: string;
    phone: string;
    country?: string;
    residentialAddress?: string;
    passwordHash: string;
    salt: string;
  };
}

export interface PasswordResetRecord {
  email: string;
  token: string;
  code: string;
  expiresAt: number;
}

export interface DatabaseSchema {
  users: StoredUser[];
  transactions: Transaction[];
  virtualCards: VirtualCard[];
  auditLogs: AuditLog[];
  loginActivities: LoginActivity[];
  emails: EmailMessage[];
  notifications: NotificationItem[];
  otps: OTPRecord[];
  investments: InvestmentRequest[];
  verifications: VerificationRequest[];
  supportEnquiries: SupportEnquiry[];
  passwordResets: PasswordResetRecord[];
}

function hashPassword(password: string, salt?: string): { hash: string; salt: string } {
  const generatedSalt = salt || crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(password, generatedSalt, 64).toString('hex');
  return { hash, salt: generatedSalt };
}

function verifyPassword(password: string, hash: string, salt: string): boolean {
  const computed = crypto.scryptSync(password, salt, 64).toString('hex');
  return computed === hash;
}

export function generateAccountNumber(): string {
  // 10 digit unique account number
  const prefix = '10';
  const randomDigits = Math.floor(10000000 + Math.random() * 90000000).toString();
  return `${prefix}${randomDigits.slice(0, 8)}`;
}

export function generateCardNumber(): string {
  // 16 digit card number starting with 4200 (Visa) or 5399 (Mastercard)
  const p1 = '4242';
  const p2 = Math.floor(1000 + Math.random() * 9000).toString();
  const p3 = Math.floor(1000 + Math.random() * 9000).toString();
  const p4 = Math.floor(1000 + Math.random() * 9000).toString();
  return `${p1} ${p2} ${p3} ${p4}`;
}

export function generateSortCode(): string {
  return '20-04-15';
}

export function generateReference(prefix = 'TXN'): string {
  const rand = crypto.randomBytes(4).toString('hex').toUpperCase();
  const dateStr = new Date().toISOString().slice(2, 10).replace(/-/g, '');
  return `${prefix}-${dateStr}-${rand}`;
}

// Generate professional HTML email templates matching FNB's branding
export function createEmailTemplate(
  type: EmailMessage['templateType'], 
  recipientName: string, 
  data: Record<string, any>
): { subject: string; html: string; text: string } {
  const currentYear = new Date().getFullYear();
  const baseHeader = `
    <div style="background-color: #002752; padding: 24px 30px; text-align: center; border-radius: 8px 8px 0 0;">
      <div style="display: inline-flex; align-items: center; justify-content: center; gap: 10px;">
        <span style="color: #ffffff; font-size: 28px; font-weight: 800; letter-spacing: 1px; font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif;">
          <span style="color: #c8102e;">FNB</span> ONLINE
        </span>
      </div>
      <p style="margin: 6px 0 0; color: #94a3b8; font-size: 13px; letter-spacing: 0.5px;">FIRST NATIONAL BANK • SECURE PORTAL</p>
    </div>
  `;

  const baseFooter = `
    <div style="background-color: #f8fafc; padding: 20px 30px; border-top: 1px solid #e2e8f0; font-size: 12px; color: #64748b; line-height: 1.6; border-radius: 0 0 8px 8px;">
      <p style="margin: 0 0 8px;"><strong>Need assistance?</strong> Contact FNB 24/7 Support:</p>
      <p style="margin: 0 0 4px;">📞 Telephone: <strong>+447723165577</strong> | 💬 WhatsApp: <strong>+447723165577</strong></p>
      <p style="margin: 0 0 8px;">✉️ Official Email: <a href="mailto:info@fnnbbankss.online" style="color: #002752;">info@fnnbbankss.online</a></p>
      <div style="margin-top: 12px; padding: 8px; background-color: #fef2f2; border: 1px solid #fee2e2; border-radius: 6px; color: #991b1b; font-size: 11px;">
        🛡️ <strong>Sandbox Safety Notice:</strong> This is a secure demonstration platform. FNB will never ask for your password via email.
      </div>
      <p style="margin: 12px 0 0; font-size: 11px; text-align: center; color: #94a3b8;">
        © ${currentYear} First National Bank (FNB). All rights reserved.
      </p>
    </div>
  `;

  let subject = '';
  let content = '';
  let text = '';

  switch (type) {
    case 'registration_otp':
      subject = `FNB Security: Your Registration OTP is ${data.otpCode}`;
      text = `Hello ${recipientName}, Your FNB verification code is ${data.otpCode}. It expires in 10 minutes.`;
      content = `
        <h2 style="color: #002752; margin: 0 0 16px; font-size: 20px;">Email Verification Code</h2>
        <p style="color: #334155; line-height: 1.6; margin: 0 0 16px;">
          Dear <strong>${recipientName}</strong>,<br/>
          Thank you for applying to open an account with First National Bank (FNB). To complete your application, please use the 6-digit verification code below:
        </p>
        <div style="background: linear-gradient(135deg, #002752, #0a3d7a); padding: 20px; border-radius: 8px; text-align: center; margin: 24px 0;">
          <span style="font-size: 36px; font-weight: 800; letter-spacing: 8px; color: #ffffff; font-family: monospace;">
            ${data.otpCode}
          </span>
          <p style="margin: 8px 0 0; color: #cbd5e1; font-size: 12px;">Valid for 10 minutes. Do not share this code.</p>
        </div>
        <p style="color: #64748b; font-size: 13px; margin: 0;">
          If you did not initiate this registration, please contact our security team immediately at <strong>info@fnnbbankss.online</strong>.
        </p>
      `;
      break;

    case 'account_approved':
      subject = `Congratulations! Your FNB Account has been Approved (${data.accountNumber})`;
      text = `Dear ${recipientName}, your FNB account is now active. Account Number: ${data.accountNumber}, Sort Code: ${data.sortCode}.`;
      content = `
        <div style="text-align: center; margin-bottom: 20px;">
          <div style="display: inline-block; background-color: #dcfce7; color: #166534; font-weight: 700; padding: 6px 14px; border-radius: 20px; font-size: 13px;">
            ✓ ACCOUNT APPROVED & ACTIVATED
          </div>
        </div>
        <h2 style="color: #002752; margin: 0 0 12px; font-size: 22px; text-align: center;">Welcome to First National Bank</h2>
        <p style="color: #334155; line-height: 1.6; margin: 0 0 20px;">
          Dear <strong>${recipientName}</strong>,<br/>
          Your account application has been officially reviewed and approved by our banking administration team. Your full online banking privileges are now activated.
        </p>
        <div style="background-color: #f1f5f9; border-left: 4px solid #c8102e; padding: 18px 20px; border-radius: 6px; margin: 20px 0;">
          <table style="width: 100%; border-collapse: collapse; font-size: 14px; color: #1e293b;">
            <tr>
              <td style="padding: 6px 0; color: #64748b;">Account Holder:</td>
              <td style="padding: 6px 0; font-weight: 600; text-align: right;">${recipientName}</td>
            </tr>
            <tr>
              <td style="padding: 6px 0; color: #64748b;">Account Number:</td>
              <td style="padding: 6px 0; font-weight: 700; color: #002752; font-family: monospace; font-size: 16px; text-align: right;">${data.accountNumber}</td>
            </tr>
            <tr>
              <td style="padding: 6px 0; color: #64748b;">Sort Code:</td>
              <td style="padding: 6px 0; font-weight: 600; text-align: right;">${data.sortCode}</td>
            </tr>
            <tr>
              <td style="padding: 6px 0; color: #64748b;">Initial Demo Balance:</td>
              <td style="padding: 6px 0; font-weight: 700; color: #16a34a; text-align: right;">${data.currency || '£'}${Number(data.balance || 0).toLocaleString('en-GB', { minimumFractionDigits: 2 })}</td>
            </tr>
            <tr>
              <td style="padding: 6px 0; color: #64748b;">Account Status:</td>
              <td style="padding: 6px 0; font-weight: 700; color: #15803d; text-align: right;">Active / Verified</td>
            </tr>
          </table>
        </div>
        <p style="color: #334155; line-height: 1.6;">
          You can now log in to the FNB Online Banking portal to manage your funds, generate virtual cards, make transfers, and pay bills.
        </p>
      `;
      break;

    case 'account_rejected':
      subject = `Important Notice: FNB Account Application Status`;
      text = `Dear ${recipientName}, your application could not be approved at this time.`;
      content = `
        <h2 style="color: #991b1b; margin: 0 0 12px; font-size: 20px;">Account Application Notice</h2>
        <p style="color: #334155; line-height: 1.6; margin: 0 0 16px;">
          Dear <strong>${recipientName}</strong>,<br/>
          We regret to inform you that your registration could not be verified and approved at this time.
        </p>
        <div style="background-color: #fef2f2; border: 1px solid #fecaca; padding: 14px; border-radius: 6px; margin: 16px 0; color: #7f1d1d; font-size: 13px;">
          <strong>Reason:</strong> ${data.reason || 'Information provided did not satisfy verification criteria. Please resubmit or reach customer care.'}
        </div>
      `;
      break;

    case 'debit_alert':
      subject = `FNB Debit Alert: ${data.currency}${Number(data.amount).toFixed(2)} debited from ${data.accountNumber}`;
      text = `Debit Alert: ${data.currency}${Number(data.amount).toFixed(2)} on account ${data.accountNumber}. Ref: ${data.reference}.`;
      content = `
        <h2 style="color: #002752; margin: 0 0 16px; font-size: 20px;">Transaction Debit Alert</h2>
        <p style="color: #334155; line-height: 1.6; margin: 0 0 16px;">
          Dear <strong>${recipientName}</strong>, your account has been debited as follows:
        </p>
        <div style="background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px; padding: 16px; margin: 16px 0;">
          <table style="width: 100%; border-collapse: collapse; font-size: 14px;">
            <tr>
              <td style="padding: 6px 0; color: #64748b;">Amount:</td>
              <td style="padding: 6px 0; font-weight: 700; color: #dc2626; text-align: right; font-size: 16px;">-${data.currency}${Number(data.amount).toFixed(2)}</td>
            </tr>
            <tr>
              <td style="padding: 6px 0; color: #64748b;">Beneficiary:</td>
              <td style="padding: 6px 0; font-weight: 600; text-align: right;">${data.beneficiaryName || 'N/A'}</td>
            </tr>
            <tr>
              <td style="padding: 6px 0; color: #64748b;">Reference:</td>
              <td style="padding: 6px 0; font-family: monospace; text-align: right;">${data.reference}</td>
            </tr>
            <tr>
              <td style="padding: 6px 0; color: #64748b;">Remaining Balance:</td>
              <td style="padding: 6px 0; font-weight: 700; text-align: right; color: #002752;">${data.currency}${Number(data.newBalance).toFixed(2)}</td>
            </tr>
          </table>
        </div>
        ${data.isSandbox ? `
          <div style="background-color: #eff6ff; border-left: 3px solid #3b82f6; padding: 12px; border-radius: 4px; font-size: 12px; color: #1e40af; margin-top: 16px;">
            🔄 <strong>Sandbox Automatic Reversal Policy:</strong> This transfer is scheduled for an automated reversal demonstration in 30 minutes. The amount will be refunded to your sandbox balance.
          </div>
        ` : ''}
      `;
      break;

    case 'credit_alert':
      subject = `FNB Credit Alert: ${data.currency}${Number(data.amount).toFixed(2)} credited to ${data.accountNumber}`;
      text = `Credit Alert: ${data.currency}${Number(data.amount).toFixed(2)} received on account ${data.accountNumber}.`;
      content = `
        <h2 style="color: #002752; margin: 0 0 16px; font-size: 20px;">Transaction Credit Alert</h2>
        <p style="color: #334155; line-height: 1.6; margin: 0 0 16px;">
          Dear <strong>${recipientName}</strong>, your account has been credited:
        </p>
        <div style="background-color: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 6px; padding: 16px; margin: 16px 0;">
          <table style="width: 100%; border-collapse: collapse; font-size: 14px;">
            <tr>
              <td style="padding: 6px 0; color: #166534;">Amount Credited:</td>
              <td style="padding: 6px 0; font-weight: 700; color: #16a34a; text-align: right; font-size: 18px;">+${data.currency}${Number(data.amount).toFixed(2)}</td>
            </tr>
            <tr>
              <td style="padding: 6px 0; color: #64748b;">Description:</td>
              <td style="padding: 6px 0; font-weight: 600; text-align: right;">${data.description}</td>
            </tr>
            <tr>
              <td style="padding: 6px 0; color: #64748b;">Reference:</td>
              <td style="padding: 6px 0; font-family: monospace; text-align: right;">${data.reference}</td>
            </tr>
            <tr>
              <td style="padding: 6px 0; color: #64748b;">New Balance:</td>
              <td style="padding: 6px 0; font-weight: 700; text-align: right; color: #002752;">${data.currency}${Number(data.newBalance).toFixed(2)}</td>
            </tr>
          </table>
        </div>
      `;
      break;

    case 'transaction_reversal':
      subject = `FNB Reversal Notice: ${data.currency}${Number(data.amount).toFixed(2)} Refunded (${data.reference})`;
      text = `Reversal Complete: ${data.currency}${Number(data.amount).toFixed(2)} has been returned to your balance.`;
      content = `
        <div style="background-color: #fefce8; border-left: 4px solid #ca8a04; padding: 16px; border-radius: 6px; margin-bottom: 20px;">
          <h2 style="color: #854d0e; margin: 0 0 8px; font-size: 18px;">Automated Sandbox Reversal Executed</h2>
          <p style="margin: 0; color: #713f12; font-size: 13px;">
            In accordance with FNB Sandbox Protocol, the simulated transfer initiated previously has completed its 30-minute demonstration cycle and has been automatically refunded.
          </p>
        </div>
        <table style="width: 100%; border-collapse: collapse; font-size: 14px; background: #ffffff; border: 1px solid #e2e8f0; border-radius: 6px; padding: 14px;">
          <tr>
            <td style="padding: 8px 12px; color: #64748b;">Refunded Amount:</td>
            <td style="padding: 8px 12px; font-weight: 700; color: #16a34a; text-align: right;">+${data.currency}${Number(data.amount).toFixed(2)}</td>
          </tr>
          <tr>
            <td style="padding: 8px 12px; color: #64748b;">Original Reference:</td>
            <td style="padding: 8px 12px; font-family: monospace; text-align: right;">${data.originalReference || data.reference}</td>
          </tr>
          <tr>
            <td style="padding: 8px 12px; color: #64748b;">Reversal Reference:</td>
            <td style="padding: 8px 12px; font-family: monospace; text-align: right; color: #002752; font-weight: 600;">${data.reference}</td>
          </tr>
          <tr>
            <td style="padding: 8px 12px; color: #64748b;">Updated Available Balance:</td>
            <td style="padding: 8px 12px; font-weight: 700; text-align: right; color: #002752;">${data.currency}${Number(data.newBalance).toFixed(2)}</td>
          </tr>
        </table>
      `;
      break;

    case 'investment_received':
      subject = `FNB Investment Request Acknowledged: ${data.planName} (${data.reference})`;
      text = `Your investment simulation request of ${data.currency}${Number(data.amount).toFixed(2)} in ${data.planName} has been received and is under compliance review. Reference: ${data.reference}`;
      content = `
        <h2 style="color: #002752; margin: 0 0 16px; font-size: 20px;">Investment Request Received</h2>
        <p style="color: #334155; line-height: 1.6; margin: 0 0 16px;">
          Dear <strong>${recipientName}</strong>, thank you for submitting your investment simulation application. Your portfolio request has been logged under reference <strong>${data.reference}</strong>.
        </p>
        <div style="background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px; padding: 16px; margin: 16px 0;">
          <table style="width: 100%; border-collapse: collapse; font-size: 14px;">
            <tr><td style="padding: 6px 0; color: #64748b;">Plan:</td><td style="padding: 6px 0; font-weight: 700; color: #002752; text-align: right;">${data.planName}</td></tr>
            <tr><td style="padding: 6px 0; color: #64748b;">Principal Amount:</td><td style="padding: 6px 0; font-weight: 700; color: #002752; text-align: right;">${data.currency}${Number(data.amount).toFixed(2)}</td></tr>
            <tr><td style="padding: 6px 0; color: #64748b;">Duration:</td><td style="padding: 6px 0; font-weight: 600; text-align: right;">${data.durationMonths} Months</td></tr>
            <tr><td style="padding: 6px 0; color: #64748b;">Simulated Projected Return:</td><td style="padding: 6px 0; font-weight: 700; color: #16a34a; text-align: right;">+${data.currency}${Number(data.projectedReturnAmount).toFixed(2)} (${data.projectedReturnRate}% p.a.)</td></tr>
            <tr><td style="padding: 6px 0; color: #64748b;">Status:</td><td style="padding: 6px 0; font-weight: 600; color: #ca8a04; text-align: right;">Pending Administrative Review</td></tr>
          </table>
        </div>
        <p style="color: #64748b; font-size: 12px; margin: 12px 0 0;">
          * Note: All investment yields and projections shown are simulated demonstration calculations.
        </p>
      `;
      break;

    case 'investment_approved':
      subject = `FNB Investment Request Approved: ${data.planName} (${data.reference})`;
      text = `Your investment simulation in ${data.planName} has been approved by FNB Asset Management. Reference: ${data.reference}`;
      content = `
        <h2 style="color: #16a34a; margin: 0 0 16px; font-size: 20px;">Investment Application Approved</h2>
        <p style="color: #334155; line-height: 1.6; margin: 0 0 16px;">
          Dear <strong>${recipientName}</strong>, your investment portfolio allocation has been officially authorized and is now active.
        </p>
        <div style="background-color: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 6px; padding: 16px; margin: 16px 0;">
          <table style="width: 100%; border-collapse: collapse; font-size: 14px;">
            <tr><td style="padding: 6px 0; color: #166534;">Plan:</td><td style="padding: 6px 0; font-weight: 700; color: #166534; text-align: right;">${data.planName}</td></tr>
            <tr><td style="padding: 6px 0; color: #64748b;">Amount:</td><td style="padding: 6px 0; font-weight: 700; color: #002752; text-align: right;">${data.currency}${Number(data.amount).toFixed(2)}</td></tr>
            <tr><td style="padding: 6px 0; color: #64748b;">Reference:</td><td style="padding: 6px 0; font-family: monospace; text-align: right;">${data.reference}</td></tr>
            <tr><td style="padding: 6px 0; color: #64748b;">Status:</td><td style="padding: 6px 0; font-weight: 700; color: #16a34a; text-align: right;">Active Allocation</td></tr>
          </table>
        </div>
      `;
      break;

    case 'verification_submitted':
      subject = `FNB Identity Verification Submitted: Ref ${data.reference}`;
      text = `Your customer verification documents have been received under reference ${data.reference}. Our compliance desk is reviewing your submission.`;
      content = `
        <h2 style="color: #002752; margin: 0 0 16px; font-size: 20px;">Identity Verification (KYC) Received</h2>
        <p style="color: #334155; line-height: 1.6; margin: 0 0 16px;">
          Dear <strong>${recipientName}</strong>, thank you for submitting your verification details.
        </p>
        <div style="background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px; padding: 16px; margin: 16px 0;">
          <table style="width: 100%; border-collapse: collapse; font-size: 14px;">
            <tr><td style="padding: 6px 0; color: #64748b;">Reference:</td><td style="padding: 6px 0; font-family: monospace; text-align: right;">${data.reference}</td></tr>
            <tr><td style="padding: 6px 0; color: #64748b;">Document Type:</td><td style="padding: 6px 0; font-weight: 600; text-align: right;">${data.idDocumentType}</td></tr>
            <tr><td style="padding: 6px 0; color: #64748b;">Status:</td><td style="padding: 6px 0; font-weight: 600; color: #ca8a04; text-align: right;">Pending Review</td></tr>
          </table>
        </div>
      `;
      break;

    case 'verification_approved':
      subject = `FNB Identity Verification Approved - Account Verified`;
      text = `Your identity verification (Reference: ${data.reference}) has been approved. Your account tier has been upgraded to Fully Verified.`;
      content = `
        <h2 style="color: #16a34a; margin: 0 0 16px; font-size: 20px;">Account Verification Successful</h2>
        <p style="color: #334155; line-height: 1.6; margin: 0 0 16px;">
          Dear <strong>${recipientName}</strong>, your verification application has been reviewed and approved by the FNB Compliance Team. Your customer account is now fully verified.
        </p>
        <div style="background-color: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 6px; padding: 16px; margin: 16px 0;">
          <p style="margin: 0; color: #166534; font-weight: 600;">Verification Status: Verified Tier 1</p>
          <p style="margin: 4px 0 0; color: #475569; font-size: 13px;">Reference: ${data.reference}</p>
        </div>
      `;
      break;

    case 'password_reset':
      subject = `FNB Password Recovery Code: ${data.resetCode}`;
      text = `Your password reset code is: ${data.resetCode}. This code is valid for 15 minutes.`;
      content = `
        <h2 style="color: #002752; margin: 0 0 16px; font-size: 20px;">Password Reset Request</h2>
        <p style="color: #334155; line-height: 1.6; margin: 0 0 16px;">
          Dear <strong>${recipientName}</strong>, we received a request to reset the password for your FNB Online Banking account. Use the authorization code below:
        </p>
        <div style="background-color: #eff6ff; border: 1px dashed #3b82f6; border-radius: 8px; padding: 20px; text-align: center; margin: 24px 0;">
          <span style="font-size: 32px; font-weight: 800; letter-spacing: 8px; color: #002752; font-family: monospace;">${data.resetCode}</span>
          <p style="margin: 8px 0 0; color: #64748b; font-size: 13px;">Valid for 15 minutes. Never share this code with anyone.</p>
        </div>
      `;
      break;

    case 'password_change':
    case 'security_notification':
    case 'account_activity':
    default:
      subject = data.subject || `FNB Security Notification: Account Activity`;
      text = data.message || `Account activity recorded for ${recipientName}.`;
      content = `
        <h2 style="color: #002752; margin: 0 0 16px; font-size: 20px;">Security & Account Alert</h2>
        <p style="color: #334155; line-height: 1.6; margin: 0 0 16px;">
          Dear <strong>${recipientName}</strong>,<br/>
          ${data.message || 'We noticed a recent security update or login activity on your FNB account.'}
        </p>
        <div style="background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px; padding: 14px; font-size: 13px; color: #475569;">
          <strong>Time:</strong> ${new Date().toUTCString()}<br/>
          <strong>Device/IP:</strong> ${data.device || 'Authorized Browser Session'} (${data.ip || 'Secure Connection'})
        </div>
      `;
      break;
  }

  const fullHtml = `
    <!DOCTYPE html>
    <html>
      <head>
        <meta charset="utf-8" />
        <title>${subject}</title>
      </head>
      <body style="margin: 0; padding: 24px; background-color: #f1f5f9; font-family: 'Helvetica Neue', Arial, sans-serif;">
        <div style="max-width: 580px; margin: 0 auto; background-color: #ffffff; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.06); overflow: hidden; border: 1px solid #e2e8f0;">
          ${baseHeader}
          <div style="padding: 28px 30px;">
            ${content}
          </div>
          ${baseFooter}
        </div>
      </body>
    </html>
  `;

  return { subject, html: fullHtml, text };
}

class StorageManager {
  private data: DatabaseSchema;

  constructor() {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    this.data = this.loadData();
    this.initSeeds();
  }

  private loadData(): DatabaseSchema {
    let parsed: any = {};
    if (fs.existsSync(DB_FILE)) {
      try {
        const content = fs.readFileSync(DB_FILE, 'utf-8');
        parsed = JSON.parse(content);
      } catch (e) {
        console.error('Failed to read database, initializing fresh:', e);
      }
    }
    const rawTransactions = parsed.transactions || [];
    const transactions: Transaction[] = rawTransactions.map((t: Transaction) => {
      if (!t.tag) {
        const { tag, tags, category } = tagTransaction(t.description, t.type, t.billerCategory);
        return { ...t, tag, tags, category };
      }
      return t;
    });

    return {
      users: parsed.users || [],
      transactions,
      virtualCards: parsed.virtualCards || [],
      auditLogs: parsed.auditLogs || [],
      loginActivities: parsed.loginActivities || [],
      emails: parsed.emails || [],
      notifications: parsed.notifications || [],
      otps: parsed.otps || [],
      investments: parsed.investments || [],
      verifications: parsed.verifications || [],
      supportEnquiries: parsed.supportEnquiries || [],
      passwordResets: parsed.passwordResets || [],
    };
  }

  public recordTransaction(txData: Omit<Transaction, 'tag' | 'tags' | 'category'> & Partial<Transaction>): Transaction {
    const { tag, tags, category } = tagTransaction(
      txData.description, 
      txData.type, 
      txData.billerCategory
    );
    const tx: Transaction = {
      ...txData,
      tag: txData.tag || tag,
      tags: txData.tags || tags,
      category: txData.category || category,
    };
    this.data.transactions.push(tx);
    return tx;
  }

  private saveData(): void {
    const tmp = `${DB_FILE}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify(this.data, null, 2), 'utf-8');
    fs.renameSync(tmp, DB_FILE);
  }

  private initSeeds(): void {
    // 1. Ensure Administrator exists
    const adminEmail = 'admin@fnnbbankss.online';
    let admin = this.data.users.find(u => u.email.toLowerCase() === adminEmail.toLowerCase());
    const { hash, salt } = hashPassword('@Newjob2026');
    if (!admin) {
      admin = {
        id: 'admin-001',
        email: adminEmail,
        username: 'fnbadmin',
        firstName: 'FNB',
        lastName: 'Administrator',
        phone: '+447723165577',
        role: 'admin',
        status: 'active',
        balance: 0,
        currency: '£',
        createdAt: new Date().toISOString(),
        passwordHash: hash,
        salt: salt,
      };
      this.data.users.push(admin);
      this.logAudit(admin.email, 'SYSTEM_INIT', 'Seeded initial master administrator account');
    } else {
      admin.passwordHash = hash;
      admin.salt = salt;
    }
    this.saveData();

    // 2. Ensure a sample active customer exists for instant testing
    const sampleEmail = 'sarah.jenkins@fnnbbankss.online';
    let customer = this.data.users.find(u => u.email === sampleEmail);
    if (!customer) {
      const { hash, salt } = hashPassword('SarahPass123!');
      const custId = 'cust-sarah-101';
      const accNo = '1084920194';
      customer = {
        id: custId,
        email: sampleEmail,
        username: 'sarahjenkins',
        firstName: 'Sarah',
        lastName: 'Jenkins',
        fullName: 'Sarah Jenkins',
        country: 'United Kingdom',
        residentialAddress: '44 Canary Wharf, London, E14 5AB',
        phone: '+447700900123',
        role: 'customer',
        status: 'active',
        kycStatus: 'verified',
        accountNumber: accNo,
        sortCode: '20-04-15',
        balance: 14850.00,
        currency: '£',
        createdAt: new Date(Date.now() - 7 * 86400000).toISOString(),
        approvedAt: new Date(Date.now() - 7 * 86400000).toISOString(),
        passwordHash: hash,
        salt: salt,
        isTwoFactorEnabled: true,
      };
      this.data.users.push(customer);

      // Seed virtual card
      this.data.virtualCards.push({
        id: 'vc-sarah-01',
        userId: custId,
        cardNumber: '4242 8819 3302 9184',
        cardHolder: 'SARAH JENKINS',
        expiryDate: '11/29',
        cvv: '824',
        status: 'active',
        dailyLimit: 2500,
        onlineTransactionsEnabled: true,
        colorTheme: 'navy',
      });

      // Seed initial transactions
      this.data.transactions.push(
        {
          id: 'tx-init-01',
          reference: 'TXN-261028-A7F2',
          userId: custId,
          customerName: 'Sarah Jenkins',
          accountNumber: accNo,
          type: 'credit',
          amount: 15000.00,
          currency: '£',
          status: 'completed',
          description: 'Initial Sandbox Opening Credit',
          isSandbox: true,
          createdAt: new Date(Date.now() - 6 * 86400000).toISOString(),
        },
        {
          id: 'tx-init-02',
          reference: 'TXN-261030-99E1',
          userId: custId,
          customerName: 'Sarah Jenkins',
          accountNumber: accNo,
          type: 'bill_payment',
          amount: 150.00,
          currency: '£',
          status: 'completed',
          description: 'Electricity Bill Payment - British Gas',
          billerCategory: 'Electricity',
          billerName: 'British Gas Residential',
          isSandbox: true,
          createdAt: new Date(Date.now() - 3 * 86400000).toISOString(),
        }
      );
    } else {
      // Ensure missing profile fields are backfilled on existing customer record
      if (!customer.fullName) customer.fullName = `${customer.firstName} ${customer.lastName}`;
      if (!customer.country) customer.country = 'United Kingdom';
      if (!customer.residentialAddress) customer.residentialAddress = '44 Canary Wharf, London, E14 5AB';
      if (!customer.kycStatus) customer.kycStatus = 'verified';
    }

    // Ensure sample tagged transactions exist (e.g. Groceries, Utilities, Entertainment, Dining, Shopping)
    if (customer) {
      const hasGroceries = this.data.transactions.some(t => t.userId === customer!.id && (t.tag === 'Groceries' || t.description.toLowerCase().includes('tesco') || t.description.toLowerCase().includes('grocery')));
      if (!hasGroceries) {
        this.recordTransaction({
          id: 'tx-seed-groceries-01',
          reference: 'TXN-261102-3B4C',
          userId: customer.id,
          customerName: customer.fullName || `${customer.firstName} ${customer.lastName}`,
          accountNumber: customer.accountNumber || '1084920194',
          type: 'debit',
          amount: 86.40,
          currency: '£',
          status: 'completed',
          description: 'Tesco Superstore Weekly Groceries & Fresh Produce',
          isSandbox: true,
          createdAt: new Date(Date.now() - 4 * 86400000).toISOString(),
        });
      }

      const hasEntertainment = this.data.transactions.some(t => t.userId === customer!.id && (t.tag === 'Entertainment' || t.description.toLowerCase().includes('netflix')));
      if (!hasEntertainment) {
        this.recordTransaction({
          id: 'tx-seed-ent-01',
          reference: 'TXN-261104-11A8',
          userId: customer.id,
          customerName: customer.fullName || `${customer.firstName} ${customer.lastName}`,
          accountNumber: customer.accountNumber || '1084920194',
          type: 'debit',
          amount: 15.99,
          currency: '£',
          status: 'completed',
          description: 'Netflix Monthly 4K Family Entertainment Subscription',
          isSandbox: true,
          createdAt: new Date(Date.now() - 3 * 86400000).toISOString(),
        });
      }

      const hasDining = this.data.transactions.some(t => t.userId === customer!.id && (t.tag === 'Dining & Food' || t.description.toLowerCase().includes('starbucks')));
      if (!hasDining) {
        this.recordTransaction({
          id: 'tx-seed-dining-01',
          reference: 'TXN-261106-7F90',
          userId: customer.id,
          customerName: customer.fullName || `${customer.firstName} ${customer.lastName}`,
          accountNumber: customer.accountNumber || '1084920194',
          type: 'debit',
          amount: 12.80,
          currency: '£',
          status: 'completed',
          description: 'Starbucks Coffee & Artisan Bakery London',
          isSandbox: true,
          createdAt: new Date(Date.now() - 2 * 86400000).toISOString(),
        });
      }

      const hasShopping = this.data.transactions.some(t => t.userId === customer!.id && (t.tag === 'Shopping & Retail' || t.description.toLowerCase().includes('amazon')));
      if (!hasShopping) {
        this.recordTransaction({
          id: 'tx-seed-shop-01',
          reference: 'TXN-261108-5D2E',
          userId: customer.id,
          customerName: customer.fullName || `${customer.firstName} ${customer.lastName}`,
          accountNumber: customer.accountNumber || '1084920194',
          type: 'debit',
          amount: 44.50,
          currency: '£',
          status: 'completed',
          description: 'Amazon UK Online Retail Electronics Store',
          isSandbox: true,
          createdAt: new Date(Date.now() - 1 * 86400000).toISOString(),
        });
      }
    }

    // Ensure all existing transactions have auto-assigned tags
    this.data.transactions.forEach(t => {
      if (!t.tag) {
        const { tag, tags, category } = tagTransaction(t.description, t.type, t.billerCategory);
        t.tag = tag;
        t.tags = tags;
        t.category = category;
      }
    });

    // Seed sample investment if none exist
    if (this.data.investments.length === 0 && customer) {
      this.data.investments.push({
        id: 'inv-seed-01',
        userId: customer.id,
        userName: `${customer.firstName} ${customer.lastName}`,
        userEmail: customer.email,
        accountNumber: customer.accountNumber || '1084920194',
        reference: 'INV-261029-7B1A',
        planId: 'plan-fixed-income',
        planName: 'Fixed Income Treasury Note (Simulated)',
        amount: 2500,
        currency: '£',
        durationMonths: 12,
        projectedReturnRate: 7.2,
        projectedReturnAmount: 180,
        status: 'active',
        termsAccepted: true,
        createdAt: new Date(Date.now() - 5 * 86400000).toISOString(),
        approvedAt: new Date(Date.now() - 4 * 86400000).toISOString(),
        adminComments: 'Approved by FNB Asset Management Compliance desk.'
      });
    }

    // Seed sample verification if none exist
    if (this.data.verifications.length === 0 && customer) {
      this.data.verifications.push({
        id: 'ver-seed-01',
        userId: customer.id,
        reference: 'VER-261028-98C3',
        fullName: 'Sarah Jenkins',
        dateOfBirth: '1992-06-14',
        residentialAddress: '44 Canary Wharf, London, E14 5AB',
        countryOfResidence: 'United Kingdom',
        phone: customer.phone,
        email: customer.email,
        accountReference: customer.accountNumber || '1084920194',
        idDocumentType: 'passport',
        idDocumentNumber: 'GB982149021',
        sampleDocFrontName: 'UK_Passport_Scan_Jenkins.pdf',
        sampleProofOfAddressName: 'Council_Tax_Bill_2026.pdf',
        declarationAccepted: true,
        consentAccepted: true,
        status: 'approved',
        createdAt: new Date(Date.now() - 6 * 86400000).toISOString(),
        reviewedAt: new Date(Date.now() - 5 * 86400000).toISOString(),
        adminComments: 'All identification documents verified and archived according to UK simulated compliance tier.'
      });
    }

    // Seed sample notifications if none exist
    if (this.data.notifications.length === 0 && customer) {
      this.data.notifications.push(
        {
          id: 'notif-01',
          userId: customer.id,
          title: 'Account Verification Approved',
          message: 'Your identity documents have been approved. Your account tier is Fully Verified.',
          type: 'success',
          category: 'verification',
          read: false,
          createdAt: new Date(Date.now() - 5 * 86400000).toISOString(),
        },
        {
          id: 'notif-02',
          userId: customer.id,
          title: 'Investment Allocation Active',
          message: 'Your Fixed Income Treasury Note allocation (£2,500.00) is now actively generating simulated returns.',
          type: 'info',
          category: 'investment',
          read: false,
          createdAt: new Date(Date.now() - 4 * 86400000).toISOString(),
        }
      );
    }

    // 3. Ensure a sample PENDING applicant exists so Admin can test approval immediately
    const pendingEmail = 'david.miller@fnnbbankss.online';
    let pendingApplicant = this.data.users.find(u => u.email === pendingEmail);
    if (!pendingApplicant) {
      const { hash, salt } = hashPassword('DavidPass123!');
      pendingApplicant = {
        id: 'cust-david-pending-102',
        email: pendingEmail,
        username: 'davidmiller',
        firstName: 'David',
        lastName: 'Miller',
        phone: '+447700900456',
        role: 'customer',
        status: 'pending_approval',
        balance: 0,
        currency: '£',
        createdAt: new Date(Date.now() - 2 * 3600000).toISOString(),
        passwordHash: hash,
        salt: salt,
      };
      this.data.users.push(pendingApplicant);
    }

    this.saveData();
  }

  // --- Auth & Users ---
  public getUsers(): StoredUser[] {
    return this.data.users;
  }

  public findUserById(id: string): StoredUser | undefined {
    return this.data.users.find(u => u.id === id);
  }

  public findUserByEmailOrUsername(identifier: string): StoredUser | undefined {
    const clean = identifier.trim().toLowerCase();
    return this.data.users.find(u => u.email.toLowerCase() === clean || u.username.toLowerCase() === clean);
  }

  public createOTP(payload: OTPRecord['payload']): string {
    const code = Math.floor(100000 + Math.random() * 900000).toString();
    const expiresAt = Date.now() + 10 * 60 * 1000; // 10 minutes
    
    // Remove old otps for this email
    this.data.otps = this.data.otps.filter(o => o.email !== payload.email);
    this.data.otps.push({
      email: payload.email,
      code,
      expiresAt,
      payload,
    });

    // Send email with OTP
    const fullName = `${payload.firstName} ${payload.lastName}`;
    this.sendEmail('registration_otp', payload.email, fullName, { otpCode: code });
    this.saveData();
    return code;
  }

  public getLatestOTP(email: string): string | undefined {
    const clean = email.trim().toLowerCase();
    const record = this.data.otps.find(o => o.email.toLowerCase() === clean);
    return record?.code;
  }

  public resendOTP(email: string): string {
    const clean = email.trim().toLowerCase();
    const existing = this.data.otps.find(o => o.email.toLowerCase() === clean);
    if (!existing) {
      throw new Error('No pending registration found for this email address. Please submit your registration details again.');
    }
    const newCode = Math.floor(100000 + Math.random() * 900000).toString();
    existing.code = newCode;
    existing.expiresAt = Date.now() + 10 * 60 * 1000;
    const fullName = `${existing.payload.firstName} ${existing.payload.lastName}`;
    this.sendEmail('registration_otp', existing.payload.email, fullName, { otpCode: newCode });
    this.saveData();
    return newCode;
  }

  public verifyOTPAndCreateUser(email: string, code: string): StoredUser {
    const record = this.data.otps.find(o => o.email.toLowerCase() === email.toLowerCase());
    if (!record) {
      throw new Error('No OTP request found for this email address. Please register again.');
    }
    if (Date.now() > record.expiresAt) {
      throw new Error('Verification code has expired. Please request a new one.');
    }
    if (record.code !== code.trim()) {
      throw new Error('Invalid 6-digit verification code. Please check and try again.');
    }

    // Check if user already exists
    if (this.findUserByEmailOrUsername(email) || this.findUserByEmailOrUsername(record.payload.username)) {
      throw new Error('An account with this email or username already exists.');
    }

    const fullName = record.payload.fullName || `${record.payload.firstName} ${record.payload.lastName}`.trim();
    const newUser: StoredUser = {
      id: `cust-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      email: record.payload.email,
      username: record.payload.username,
      firstName: record.payload.firstName,
      lastName: record.payload.lastName,
      fullName: fullName,
      country: record.payload.country || 'United Kingdom',
      residentialAddress: record.payload.residentialAddress || '',
      phone: record.payload.phone,
      role: 'customer',
      status: 'pending_approval', // per requirement: new accounts must remain pending until admin approval
      kycStatus: 'unverified',
      balance: 0,
      currency: '£',
      createdAt: new Date().toISOString(),
      passwordHash: record.payload.passwordHash,
      salt: record.payload.salt,
      isTwoFactorEnabled: false,
    };

    this.data.users.push(newUser);
    // Cleanup OTP
    this.data.otps = this.data.otps.filter(o => o.email.toLowerCase() !== email.toLowerCase());

    // Send pending confirmation email
    this.sendEmail(
      'security_notification', 
      newUser.email, 
      `${newUser.firstName} ${newUser.lastName}`,
      {
        subject: 'FNB Application Received - Pending Administrator Approval',
        message: 'Your registration application has been received and verified via OTP. An FNB banking officer will review and activate your account shortly. You will receive an approval email with your new account number.',
      }
    );

    // Notify administrator
    this.sendEmail(
      'security_notification',
      'admin@fnnbbankss.online',
      'FNB Administrator',
      {
        subject: `[Admin Alert] New Customer Application: ${newUser.firstName} ${newUser.lastName}`,
        message: `A new customer account application has been submitted by ${newUser.firstName} ${newUser.lastName} (${newUser.email}, ${newUser.phone}) from ${newUser.country || 'United Kingdom'}. Please review and approve in the administrator console.`,
      }
    );
    this.logAudit('SYSTEM', 'CUSTOMER_REGISTRATION', `New applicant ${newUser.firstName} ${newUser.lastName} (${newUser.email}) awaiting admin approval.`);
    
    this.saveData();
    return newUser;
  }

  public hashUserPassword(password: string) {
    return hashPassword(password);
  }

  public verifyUserPassword(password: string, hash: string, salt: string) {
    return verifyPassword(password, hash, salt);
  }

  public updateUserPassword(userId: string, newPassword: string): void {
    const user = this.findUserById(userId);
    if (!user) throw new Error('User not found');
    const { hash, salt } = hashPassword(newPassword);
    user.passwordHash = hash;
    user.salt = salt;
    this.sendEmail('password_change', user.email, `${user.firstName} ${user.lastName}`, {
      message: 'Your FNB Online Banking password was successfully updated. If you did not make this change, contact security immediately.',
    });
    this.saveData();
  }

  public updateUserProfile(userId: string, updates: Partial<User>): User {
    const user = this.findUserById(userId);
    if (!user) throw new Error('User not found');
    if (updates.firstName) user.firstName = updates.firstName;
    if (updates.lastName) user.lastName = updates.lastName;
    if (updates.phone) user.phone = updates.phone;
    if (updates.username) user.username = updates.username;
    if (updates.isTwoFactorEnabled !== undefined) user.isTwoFactorEnabled = updates.isTwoFactorEnabled;
    this.saveData();
    return user;
  }

  // --- Admin Approval & Management ---
  public approveCustomer(adminEmail: string, customerId: string, initialBalance = 10000): StoredUser {
    const user = this.findUserById(customerId);
    if (!user) throw new Error('Customer not found');
    if (user.role === 'admin') throw new Error('Cannot approve an administrator account');

    const accNo = user.accountNumber || generateAccountNumber();
    const sortCode = user.sortCode || generateSortCode();

    user.status = 'active';
    user.accountNumber = accNo;
    user.sortCode = sortCode;
    user.approvedAt = new Date().toISOString();
    user.balance = (user.balance || 0) + initialBalance;

    // Create a virtual card automatically if none exists
    let vCard = this.data.virtualCards.find(c => c.userId === user.id);
    if (!vCard) {
      vCard = {
        id: `vc-${Date.now()}`,
        userId: user.id,
        cardNumber: generateCardNumber(),
        cardHolder: `${user.firstName} ${user.lastName}`.toUpperCase(),
        expiryDate: '12/29',
        cvv: Math.floor(100 + Math.random() * 900).toString(),
        status: 'active',
        dailyLimit: 2500,
        onlineTransactionsEnabled: true,
        colorTheme: 'navy',
      };
      this.data.virtualCards.push(vCard);
    }

    // Record initial demo credit transaction
    const ref = generateReference('CR');
    this.data.transactions.push({
      id: `tx-appr-${Date.now()}`,
      reference: ref,
      userId: user.id,
      customerName: `${user.firstName} ${user.lastName}`,
      accountNumber: accNo,
      type: 'credit',
      amount: initialBalance,
      currency: user.currency || '£',
      status: 'completed',
      description: 'Account Approval & Initial Demonstration Credit',
      isSandbox: true,
      createdAt: new Date().toISOString(),
      adminNote: `Approved by admin ${adminEmail}`,
    });

    // Send rich HTML approval email
    this.sendEmail(
      'account_approved',
      user.email,
      `${user.firstName} ${user.lastName}`,
      {
        accountNumber: accNo,
        sortCode: sortCode,
        balance: user.balance,
        currency: user.currency,
      }
    );

    this.logAudit(
      adminEmail,
      'APPROVE_CUSTOMER',
      `Approved customer ${user.firstName} ${user.lastName} (${user.email}). Assigned Account: ${accNo}, Initial Balance: ${user.currency}${initialBalance}`,
      user.id,
      `${user.firstName} ${user.lastName}`
    );

    this.saveData();
    return user;
  }

  public rejectCustomer(adminEmail: string, customerId: string, reason = 'Application details could not be verified.'): StoredUser {
    const user = this.findUserById(customerId);
    if (!user) throw new Error('Customer not found');
    user.status = 'rejected';

    this.sendEmail('account_rejected', user.email, `${user.firstName} ${user.lastName}`, { reason });

    this.logAudit(
      adminEmail,
      'REJECT_CUSTOMER',
      `Rejected customer registration for ${user.firstName} ${user.lastName} (${user.email}). Reason: ${reason}`,
      user.id,
      `${user.firstName} ${user.lastName}`
    );

    this.saveData();
    return user;
  }

  public setCustomerStatus(adminEmail: string, customerId: string, status: 'active' | 'frozen' | 'suspended'): StoredUser {
    const user = this.findUserById(customerId);
    if (!user) throw new Error('Customer not found');
    if (user.role === 'admin') throw new Error('Cannot change status of admin');

    const prevStatus = user.status;
    user.status = status;

    this.logAudit(
      adminEmail,
      'UPDATE_STATUS',
      `Changed customer status from ${prevStatus} to ${status} for ${user.firstName} ${user.lastName}`,
      user.id,
      `${user.firstName} ${user.lastName}`
    );

    this.sendEmail(
      'security_notification',
      user.email,
      `${user.firstName} ${user.lastName}`,
      {
        subject: `FNB Security: Account Status Updated to ${status.toUpperCase()}`,
        message: `Your account status has been updated to ${status}. If you have questions, contact FNB support at +447723165577.`,
      }
    );

    this.saveData();
    return user;
  }

  // --- Account Credit / Debit by Admin ---
  public adjustCustomerBalance(
    adminEmail: string, 
    customerId: string, 
    type: 'credit' | 'debit', 
    amount: number, 
    description: string, 
    reference?: string
  ): Transaction {
    const user = this.findUserById(customerId);
    if (!user) throw new Error('Customer not found');
    if (amount <= 0) throw new Error('Amount must be greater than zero');
    if (type === 'debit' && user.balance < amount) {
      throw new Error(`Insufficient customer funds. Available: ${user.currency}${user.balance.toFixed(2)}`);
    }

    const newBalance = type === 'credit' ? user.balance + amount : user.balance - amount;
    user.balance = newBalance;

    const txRef = reference || generateReference(type === 'credit' ? 'ADM-CR' : 'ADM-DR');
    const tx = this.recordTransaction({
      id: `tx-adm-${Date.now()}`,
      reference: txRef,
      userId: user.id,
      customerName: `${user.firstName} ${user.lastName}`,
      accountNumber: user.accountNumber || 'PENDING',
      type: type,
      amount: amount,
      currency: user.currency || '£',
      status: 'completed',
      description: description || `Authorized administrative ${type}`,
      isSandbox: true,
      createdAt: new Date().toISOString(),
      adminNote: `Authorized by ${adminEmail}`,
    });

    this.logAudit(
      adminEmail,
      type === 'credit' ? 'ADMIN_CREDIT' : 'ADMIN_DEBIT',
      `${type.toUpperCase()} of ${user.currency}${amount.toFixed(2)} for ${user.firstName} ${user.lastName}. Ref: ${txRef}. Description: ${description}`,
      user.id,
      `${user.firstName} ${user.lastName}`
    );

    // Alert customer
    this.sendEmail(
      type === 'credit' ? 'credit_alert' : 'debit_alert',
      user.email,
      `${user.firstName} ${user.lastName}`,
      {
        amount,
        currency: user.currency,
        accountNumber: user.accountNumber,
        reference: txRef,
        description: tx.description,
        newBalance: user.balance,
      }
    );

    this.saveData();
    return tx;
  }

  // --- Customer Banking Operations ---
  public executeTransfer(
    userId: string,
    beneficiaryName: string,
    beneficiaryBank: string,
    beneficiaryAccount: string,
    amount: number,
    description: string,
    userRef?: string
  ): Transaction {
    const user = this.findUserById(userId);
    if (!user) throw new Error('User not found');
    if (user.status !== 'active') {
      throw new Error(`Cannot execute transfer. Your account is currently ${user.status}.`);
    }
    if (amount <= 0) throw new Error('Amount must be greater than zero');
    if (user.balance < amount) {
      throw new Error(`Insufficient available funds. Current balance: ${user.currency}${user.balance.toFixed(2)}`);
    }

    // Deduct balance
    user.balance -= amount;

    const ref = userRef || generateReference('TRF');
    // 30 minute reversal requirement
    const reversalDelayMs = 30 * 60 * 1000; // 30 minutes
    const scheduledReversalAt = Date.now() + reversalDelayMs;

    const tx = this.recordTransaction({
      id: `tx-trf-${Date.now()}`,
      reference: ref,
      userId: user.id,
      customerName: `${user.firstName} ${user.lastName}`,
      accountNumber: user.accountNumber || '1084920194',
      type: 'transfer',
      amount: amount,
      currency: user.currency || '£',
      status: 'completed',
      description: description || `Transfer to ${beneficiaryName}`,
      beneficiaryName,
      beneficiaryBank,
      beneficiaryAccount,
      isSandbox: true,
      isReversed: false,
      scheduledReversalAt,
      createdAt: new Date().toISOString(),
    });

    // Send debit alert
    this.sendEmail('debit_alert', user.email, `${user.firstName} ${user.lastName}`, {
      amount,
      currency: user.currency,
      accountNumber: user.accountNumber,
      beneficiaryName,
      reference: ref,
      newBalance: user.balance,
      isSandbox: true,
    });

    this.saveData();
    return tx;
  }

  // Automated Reversal Processor
  public processAutomaticReversals(): number {
    const now = Date.now();
    let reversedCount = 0;

    for (const tx of this.data.transactions) {
      if (
        tx.type === 'transfer' &&
        tx.isSandbox &&
        !tx.isReversed &&
        tx.scheduledReversalAt &&
        now >= tx.scheduledReversalAt
      ) {
        this.executeReversal(tx.id, 'AUTOMATED_SANDBOX_WORKFLOW');
        reversedCount++;
      }
    }

    return reversedCount;
  }

  // Fast-Forward / Manual reversal method
  public executeReversal(transactionId: string, initiator = 'ADMIN'): Transaction {
    const originalTx = this.data.transactions.find(t => t.id === transactionId);
    if (!originalTx) throw new Error('Transaction not found');
    if (originalTx.isReversed) throw new Error('Transaction has already been reversed');

    const user = this.findUserById(originalTx.userId);
    if (!user) throw new Error('Customer account associated with transaction was not found');

    // Refund exact amount to customer's sandbox balance
    user.balance += originalTx.amount;
    originalTx.isReversed = true;
    originalTx.reversedAt = new Date().toISOString();

    const reversalRef = generateReference('REV');
    const reversalTx = this.recordTransaction({
      id: `tx-rev-${Date.now()}`,
      reference: reversalRef,
      userId: user.id,
      customerName: `${user.firstName} ${user.lastName}`,
      accountNumber: user.accountNumber || originalTx.accountNumber,
      type: 'reversal',
      amount: originalTx.amount,
      currency: originalTx.currency,
      status: 'completed',
      description: `Reversal of sandbox transfer [${originalTx.reference}]`,
      isSandbox: true,
      createdAt: new Date().toISOString(),
      adminNote: `Reversed via ${initiator}`,
    });

    // Send email notification
    this.sendEmail('transaction_reversal', user.email, `${user.firstName} ${user.lastName}`, {
      amount: originalTx.amount,
      currency: originalTx.currency,
      reference: reversalRef,
      originalReference: originalTx.reference,
      newBalance: user.balance,
    });

    this.logAudit(
      initiator,
      'TRANSACTION_REVERSAL',
      `Reversed transfer ${originalTx.reference} of ${originalTx.currency}${originalTx.amount}. Refunded to ${user.firstName} ${user.lastName}. Reversal Ref: ${reversalRef}`,
      user.id,
      `${user.firstName} ${user.lastName}`
    );

    this.saveData();
    return reversalTx;
  }

  public executeWithdrawal(
    userId: string, 
    amount: number, 
    method: string, 
    destinationAccount: string
  ): Transaction {
    const user = this.findUserById(userId);
    if (!user) throw new Error('User not found');
    if (user.status !== 'active') throw new Error('Account is not active for withdrawals');
    if (amount <= 0) throw new Error('Amount must be positive');
    if (user.balance < amount) throw new Error('Insufficient funds for withdrawal');

    user.balance -= amount;
    const ref = generateReference('WDL');

    const tx = this.recordTransaction({
      id: `tx-wdl-${Date.now()}`,
      reference: ref,
      userId: user.id,
      customerName: `${user.firstName} ${user.lastName}`,
      accountNumber: user.accountNumber || '1084920194',
      type: 'withdrawal',
      amount: amount,
      currency: user.currency || '£',
      status: 'completed',
      description: `Withdrawal via ${method} to ${destinationAccount}`,
      withdrawalMethod: method,
      destinationAccount,
      isSandbox: true,
      createdAt: new Date().toISOString(),
    });

    this.sendEmail('debit_alert', user.email, `${user.firstName} ${user.lastName}`, {
      amount,
      currency: user.currency,
      accountNumber: user.accountNumber,
      reference: ref,
      beneficiaryName: `${method} (${destinationAccount})`,
      newBalance: user.balance,
      isSandbox: true,
    });

    this.saveData();
    return tx;
  }

  public payBill(
    userId: string,
    billerCategory: string,
    billerName: string,
    accountOrMeterNumber: string,
    amount: number
  ): Transaction {
    const user = this.findUserById(userId);
    if (!user) throw new Error('User not found');
    if (user.status !== 'active') throw new Error('Account is not active');
    if (amount <= 0) throw new Error('Amount must be positive');
    if (user.balance < amount) throw new Error('Insufficient funds to pay bill');

    user.balance -= amount;
    const ref = generateReference('BILL');

    const tx = this.recordTransaction({
      id: `tx-bill-${Date.now()}`,
      reference: ref,
      userId: user.id,
      customerName: `${user.firstName} ${user.lastName}`,
      accountNumber: user.accountNumber || '1084920194',
      type: 'bill_payment',
      amount: amount,
      currency: user.currency || '£',
      status: 'completed',
      description: `${billerCategory}: ${billerName} (${accountOrMeterNumber})`,
      billerCategory,
      billerName,
      isSandbox: true,
      createdAt: new Date().toISOString(),
    });

    this.sendEmail('debit_alert', user.email, `${user.firstName} ${user.lastName}`, {
      amount,
      currency: user.currency,
      accountNumber: user.accountNumber,
      reference: ref,
      beneficiaryName: `${billerCategory} - ${billerName}`,
      newBalance: user.balance,
      isSandbox: true,
    });

    this.saveData();
    return tx;
  }

  // --- Virtual Cards ---
  public getVirtualCardsForUser(userId: string): VirtualCard[] {
    let cards = this.data.virtualCards.filter(c => c.userId === userId);
    if (cards.length === 0) {
      const user = this.findUserById(userId);
      if (user && user.status === 'active') {
        const newCard: VirtualCard = {
          id: `vc-${Date.now()}`,
          userId: user.id,
          cardNumber: generateCardNumber(),
          cardHolder: `${user.firstName} ${user.lastName}`.toUpperCase(),
          expiryDate: '11/29',
          cvv: Math.floor(100 + Math.random() * 900).toString(),
          status: 'active',
          dailyLimit: 2500,
          onlineTransactionsEnabled: true,
          colorTheme: 'navy',
        };
        this.data.virtualCards.push(newCard);
        this.saveData();
        return [newCard];
      }
    }
    return cards;
  }

  public toggleCardFreeze(cardId: string, userId: string): VirtualCard {
    const card = this.data.virtualCards.find(c => c.id === cardId && c.userId === userId);
    if (!card) throw new Error('Virtual card not found');
    card.status = card.status === 'active' ? 'frozen' : 'active';
    this.saveData();
    return card;
  }

  public updateCardLimits(cardId: string, userId: string, dailyLimit: number, onlineEnabled: boolean): VirtualCard {
    const card = this.data.virtualCards.find(c => c.id === cardId && c.userId === userId);
    if (!card) throw new Error('Virtual card not found');
    card.dailyLimit = dailyLimit;
    card.onlineTransactionsEnabled = onlineEnabled;
    this.saveData();
    return card;
  }

  // --- Transactions & Ledger ---
  public getTransactions(filter?: { userId?: string; type?: string; status?: string; tag?: string }): Transaction[] {
    let list = [...this.data.transactions];
    list.forEach(t => {
      if (!t.tag) {
        const { tag, tags, category } = tagTransaction(t.description, t.type, t.billerCategory);
        t.tag = tag;
        t.tags = tags;
        t.category = category;
      }
    });
    if (filter?.userId) {
      list = list.filter(t => t.userId === filter.userId);
    }
    if (filter?.type && filter.type !== 'all') {
      list = list.filter(t => t.type === filter.type);
    }
    if (filter?.status && filter.status !== 'all') {
      list = list.filter(t => t.status === filter.status);
    }
    if (filter?.tag && filter.tag !== 'All' && filter.tag !== 'all') {
      const cleanTag = filter.tag.toLowerCase();
      list = list.filter(t => 
        (t.tag && t.tag.toLowerCase() === cleanTag) || 
        (t.tags && t.tags.some(tagItem => tagItem.toLowerCase() === cleanTag)) ||
        (t.category && t.category.toLowerCase() === cleanTag)
      );
    }
    return list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  // --- Emails & In-App Mailbox ---
  public sendEmail(
    templateType: EmailMessage['templateType'],
    toEmail: string,
    toName: string,
    data: Record<string, any>
  ): EmailMessage {
    const { subject, html, text } = createEmailTemplate(templateType, toName, data);
    const email: EmailMessage = {
      id: `mail-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      toEmail,
      toName,
      subject,
      templateType,
      htmlContent: html,
      textContent: text,
      otpCode: data.otpCode || data.resetCode,
      createdAt: new Date().toISOString(),
      read: false,
    };

    this.data.emails.unshift(email);
    // Keep max 200 emails in sandbox store
    if (this.data.emails.length > 200) {
      this.data.emails = this.data.emails.slice(0, 200);
    }
    this.saveData();
    return email;
  }

  public getEmails(forEmail?: string): EmailMessage[] {
    if (!forEmail) return this.data.emails;
    const clean = forEmail.toLowerCase();
    return this.data.emails.filter(e => e.toEmail.toLowerCase() === clean);
  }

  public markEmailRead(id: string): void {
    const email = this.data.emails.find(e => e.id === id);
    if (email) {
      email.read = true;
      this.saveData();
    }
  }

  // --- Audit Logs ---
  public logAudit(
    adminEmail: string, 
    action: string, 
    details: string, 
    targetUserId?: string, 
    targetUserName?: string
  ): void {
    this.data.auditLogs.unshift({
      id: `audit-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      timestamp: new Date().toISOString(),
      adminEmail,
      action,
      targetUserId,
      targetUserName,
      details,
    });
    if (this.data.auditLogs.length > 300) {
      this.data.auditLogs = this.data.auditLogs.slice(0, 300);
    }
    this.saveData();
  }

  public getAuditLogs(): AuditLog[] {
    return this.data.auditLogs;
  }

  // --- Login Activity ---
  public recordLoginActivity(userId: string, ipAddress: string, device: string, status: 'success' | 'failed'): void {
    this.data.loginActivities.unshift({
      id: `login-${Date.now()}`,
      userId,
      timestamp: new Date().toISOString(),
      ipAddress,
      device,
      status,
    });
    if (this.data.loginActivities.length > 100) {
      this.data.loginActivities = this.data.loginActivities.slice(0, 100);
    }
    this.saveData();
  }

  public getLoginActivities(userId: string): LoginActivity[] {
    return this.data.loginActivities.filter(l => l.userId === userId);
  }

  // --- Investment Plans & Requests ---
  public getInvestmentPlans(): InvestmentPlan[] {
    return INVESTMENT_PLANS;
  }

  public createInvestmentRequest(
    userId: string,
    planId: string,
    amount: number,
    durationMonths: number,
    userNotes?: string
  ): InvestmentRequest {
    const user = this.findUserById(userId);
    if (!user) throw new Error('User account not found');
    if (user.status !== 'active') throw new Error(`Account status is ${user.status}. Only active accounts can allocate investment requests.`);
    
    const plan = INVESTMENT_PLANS.find(p => p.id === planId);
    if (!plan) throw new Error('Selected investment plan not found');
    if (amount < plan.minimumAmount) throw new Error(`Minimum allocation for ${plan.name} is £${plan.minimumAmount.toLocaleString()}`);
    if (amount > plan.maximumAmount) throw new Error(`Maximum allocation for ${plan.name} is £${plan.maximumAmount.toLocaleString()}`);
    if (!plan.allowedDurationsMonths.includes(durationMonths)) {
      throw new Error(`Invalid duration. Allowed durations: ${plan.allowedDurationsMonths.join(', ')} months.`);
    }

    // Check balance
    if (user.balance < amount) {
      throw new Error(`Insufficient funds. Your available balance is ${user.currency}${user.balance.toFixed(2)}.`);
    }

    // Deduct allocated funds
    user.balance -= amount;

    const ref = generateReference('INV');
    const returnAmount = Number(((amount * (plan.annualReturnRate / 100) * (durationMonths / 12))).toFixed(2));

    const invRequest: InvestmentRequest = {
      id: `inv-${Date.now()}`,
      userId: user.id,
      userName: user.fullName || `${user.firstName} ${user.lastName}`,
      userEmail: user.email,
      accountNumber: user.accountNumber || '1084920194',
      reference: ref,
      planId: plan.id,
      planName: plan.name,
      amount,
      currency: user.currency || '£',
      durationMonths,
      projectedReturnRate: plan.annualReturnRate,
      projectedReturnAmount: returnAmount,
      status: 'pending_review',
      termsAccepted: true,
      createdAt: new Date().toISOString(),
      adminComments: userNotes ? `User note: ${userNotes}` : undefined,
    };

    this.data.investments.unshift(invRequest);

    // Record debit transaction for ledger
    this.data.transactions.push({
      id: `tx-inv-${Date.now()}`,
      reference: generateReference('TXN'),
      userId: user.id,
      customerName: user.fullName || `${user.firstName} ${user.lastName}`,
      accountNumber: user.accountNumber || '1084920194',
      type: 'debit',
      amount,
      currency: user.currency || '£',
      status: 'completed',
      description: `Investment Allocation - ${plan.name} (${ref})`,
      isSandbox: true,
      createdAt: new Date().toISOString(),
    });

    // Notify customer
    this.sendEmail('investment_received', user.email, user.fullName || `${user.firstName} ${user.lastName}`, {
      planName: plan.name,
      amount,
      currency: user.currency || '£',
      reference: ref,
      durationMonths,
      projectedReturnRate: plan.annualReturnRate,
      projectedReturnAmount: returnAmount,
    });

    this.createNotification(
      user.id,
      'Investment Request Submitted',
      `Your request for ${plan.name} (${ref}) for £${amount.toLocaleString()} is currently pending compliance review.`,
      'info',
      'investment'
    );

    this.logAudit('CUSTOMER', 'INVESTMENT_REQUEST', `Customer ${user.email} submitted investment request ${ref} for £${amount} in ${plan.name}`, user.id, user.fullName);

    this.saveData();
    return invRequest;
  }

  public getInvestments(userId?: string): InvestmentRequest[] {
    if (userId) {
      return this.data.investments.filter(i => i.userId === userId);
    }
    return this.data.investments;
  }

  public updateInvestmentStatus(
    adminEmail: string,
    investmentId: string,
    status: 'pending_review' | 'approved' | 'active' | 'completed' | 'rejected',
    adminComments?: string
  ): InvestmentRequest {
    const inv = this.data.investments.find(i => i.id === investmentId);
    if (!inv) throw new Error('Investment record not found');

    const previousStatus = inv.status;
    inv.status = status;
    inv.adminComments = adminComments || inv.adminComments;
    if (status === 'approved' || status === 'active') {
      inv.approvedAt = new Date().toISOString();
    }

    const user = this.findUserById(inv.userId);
    if (user) {
      // If rejected, refund balance
      if (status === 'rejected' && previousStatus !== 'rejected') {
        user.balance += inv.amount;
        this.data.transactions.push({
          id: `tx-inv-ref-${Date.now()}`,
          reference: generateReference('TXN'),
          userId: user.id,
          customerName: user.fullName || `${user.firstName} ${user.lastName}`,
          accountNumber: user.accountNumber || '1084920194',
          type: 'credit',
          amount: inv.amount,
          currency: inv.currency,
          status: 'completed',
          description: `Investment Request Rejected - Refund (${inv.reference})`,
          isSandbox: true,
          createdAt: new Date().toISOString(),
        });
      }

      if (status === 'approved' || status === 'active') {
        this.sendEmail('investment_approved', user.email, user.fullName || `${user.firstName} ${user.lastName}`, {
          planName: inv.planName,
          amount: inv.amount,
          currency: inv.currency,
          reference: inv.reference,
        });

        this.createNotification(
          user.id,
          'Investment Request Approved',
          `Your investment in ${inv.planName} (${inv.reference}) has been approved and is actively generating simulated returns.`,
          'success',
          'investment'
        );
      }
    }

    this.logAudit(
      adminEmail,
      'UPDATE_INVESTMENT_STATUS',
      `Updated investment ${inv.reference} from ${previousStatus} to ${status}. Notes: ${adminComments || 'None'}`,
      inv.userId,
      inv.userName
    );

    this.saveData();
    return inv;
  }

  // --- KYC Identity Verifications ---
  public createVerificationRequest(
    userId: string,
    data: Omit<VerificationRequest, 'id' | 'userId' | 'reference' | 'status' | 'createdAt'>
  ): VerificationRequest {
    const user = this.findUserById(userId);
    if (!user) throw new Error('User not found');

    const ref = generateReference('VER');
    const req: VerificationRequest = {
      ...data,
      id: `ver-${Date.now()}`,
      userId: user.id,
      reference: ref,
      status: 'pending_review',
      createdAt: new Date().toISOString(),
    };

    // Remove any existing pending request for this user
    this.data.verifications = this.data.verifications.filter(v => v.userId !== userId || v.status !== 'pending_review');
    this.data.verifications.unshift(req);

    // Update user kycStatus to pending
    user.kycStatus = 'pending';

    this.sendEmail('verification_submitted', user.email, data.fullName || `${user.firstName} ${user.lastName}`, {
      reference: ref,
      idDocumentType: data.idDocumentType,
    });

    this.createNotification(
      user.id,
      'Verification Under Review',
      `Your identity verification documents (Ref: ${ref}) have been received and are pending compliance desk evaluation.`,
      'info',
      'verification'
    );

    this.logAudit('CUSTOMER', 'SUBMIT_VERIFICATION', `Customer ${user.email} submitted verification request ${ref} (${data.idDocumentType})`, user.id, data.fullName);

    // Forward to Administrator
    this.sendEmail(
      'security_notification',
      'admin@fnnbbankss.online',
      'FNB Administrator',
      {
        subject: `[Admin Alert] New KYC Verification Request: ${ref} - ${data.fullName}`,
        message: `Customer ${data.fullName} (${user.email}, ${user.phone}) has submitted ${data.idDocumentType} verification documents under reference ${ref}. Please review in the Administrator Dashboard.`,
      }
    );

    this.saveData();
    return req;
  }

  public getVerifications(userId?: string): VerificationRequest[] {
    if (userId) {
      return this.data.verifications.filter(v => v.userId === userId);
    }
    return this.data.verifications;
  }

  public updateVerificationStatus(
    adminEmail: string,
    verificationId: string,
    status: 'pending_review' | 'approved' | 'rejected',
    adminComments?: string
  ): VerificationRequest {
    const ver = this.data.verifications.find(v => v.id === verificationId);
    if (!ver) throw new Error('Verification request not found');

    const prev = ver.status;
    ver.status = status;
    ver.adminComments = adminComments || ver.adminComments;
    ver.reviewedAt = new Date().toISOString();

    const user = this.findUserById(ver.userId);
    if (user) {
      user.kycStatus = status === 'approved' ? 'verified' : status === 'rejected' ? 'rejected' : 'pending';
      if (status === 'approved') {
        this.sendEmail('verification_approved', user.email, ver.fullName, {
          reference: ver.reference,
        });
        this.createNotification(
          user.id,
          'Account Identity Verified',
          `Your identity documentation (${ver.reference}) was verified. You now enjoy Tier-1 unlimited sandbox banking privileges.`,
          'success',
          'verification'
        );
      }
    }

    this.logAudit(
      adminEmail,
      'UPDATE_VERIFICATION_STATUS',
      `Changed verification status from ${prev} to ${status} for ${ver.fullName} (${ver.reference}). Comments: ${adminComments || 'None'}`,
      ver.userId,
      ver.fullName
    );

    this.saveData();
    return ver;
  }

  // --- Customer Support Enquiries ---
  public createSupportEnquiry(
    data: Omit<SupportEnquiry, 'id' | 'reference' | 'status' | 'createdAt' | 'updatedAt'>
  ): SupportEnquiry {
    const ref = generateReference('SUP');
    const enquiry: SupportEnquiry = {
      ...data,
      id: `sup-${Date.now()}`,
      reference: ref,
      status: 'open',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    this.data.supportEnquiries.unshift(enquiry);

    // Send confirmation to customer
    this.sendEmail('security_notification', data.email, data.name, {
      subject: `FNB Support Ticket Logged: ${ref} - ${data.subject}`,
      message: `Thank you for contacting FNB Customer Support. Your enquiry regarding "${data.subject}" has been assigned ticket reference ${ref}. A support specialist will respond shortly.`,
    });

    if (data.userId) {
      this.createNotification(
        data.userId,
        'Support Ticket Logged',
        `Ticket ${ref} ("${data.subject}") was received by our 24/7 client relations team.`,
        'info',
        'account'
      );
    }

    // Forward to Administrator
    this.sendEmail(
      'security_notification',
      'admin@fnnbbankss.online',
      'FNB Administrator',
      {
        subject: `[Admin Alert] New Support Enquiry: ${ref} - ${data.subject}`,
        message: `A new support enquiry has been received from ${data.name} (${data.email}, ${data.phone || 'No phone'}). Category: ${data.category}. Subject: "${data.subject}". Message: "${data.message}". Reference: ${ref}.`,
      }
    );

    this.saveData();
    return enquiry;
  }

  public getSupportEnquiries(emailOrUserId?: string): SupportEnquiry[] {
    if (!emailOrUserId) return this.data.supportEnquiries;
    const clean = emailOrUserId.toLowerCase();
    return this.data.supportEnquiries.filter(e => 
      e.userId === emailOrUserId || e.email.toLowerCase() === clean
    );
  }

  public replySupportEnquiry(
    adminEmail: string,
    enquiryId: string,
    reply: string,
    status?: 'open' | 'in_progress' | 'resolved'
  ): SupportEnquiry {
    const enquiry = this.data.supportEnquiries.find(e => e.id === enquiryId);
    if (!enquiry) throw new Error('Support enquiry not found');

    enquiry.adminReply = reply;
    if (status) enquiry.status = status;
    enquiry.updatedAt = new Date().toISOString();

    // Send email with response
    this.sendEmail('security_notification', enquiry.email, enquiry.name, {
      subject: `Response to FNB Support Ticket ${enquiry.reference}: ${enquiry.subject}`,
      message: `A response has been posted by FNB Support for ticket ${enquiry.reference}:\n\n"${reply}"\n\nStatus: ${enquiry.status.toUpperCase()}`,
    });

    if (enquiry.userId) {
      this.createNotification(
        enquiry.userId,
        `Update on Ticket ${enquiry.reference}`,
        `Support replied: ${reply.slice(0, 100)}...`,
        'info',
        'account'
      );
    }

    this.logAudit(
      adminEmail,
      'SUPPORT_TICKET_REPLY',
      `Admin replied to ticket ${enquiry.reference} (${enquiry.email}) and set status to ${enquiry.status}`,
      enquiry.userId,
      enquiry.name
    );

    this.saveData();
    return enquiry;
  }

  // --- Password Recovery ---
  public requestPasswordReset(email: string): string {
    const clean = email.trim().toLowerCase();
    const user = this.data.users.find(u => u.email.toLowerCase() === clean);
    if (!user) {
      throw new Error('No account found registered with this email address.');
    }

    const resetCode = Math.floor(100000 + Math.random() * 900000).toString();
    const token = crypto.randomBytes(24).toString('hex');
    const expiresAt = Date.now() + 15 * 60 * 1000; // 15 minutes

    this.data.passwordResets = this.data.passwordResets.filter(r => r.email.toLowerCase() !== clean);
    this.data.passwordResets.push({
      email: user.email,
      token,
      code: resetCode,
      expiresAt,
    });

    this.sendEmail('password_reset', user.email, user.fullName || `${user.firstName} ${user.lastName}`, {
      resetCode,
    });

    this.logAudit('SYSTEM', 'PASSWORD_RESET_REQUESTED', `Password reset code sent to ${user.email}`, user.id, user.fullName);

    this.saveData();
    return resetCode;
  }

  public resetPasswordWithCode(email: string, code: string, newPassword: string): void {
    const clean = email.trim().toLowerCase();
    const record = this.data.passwordResets.find(r => r.email.toLowerCase() === clean);
    if (!record) {
      throw new Error('No password recovery request found for this email address.');
    }
    if (Date.now() > record.expiresAt) {
      throw new Error('Password reset code has expired. Please request a new code.');
    }
    if (record.code !== code.trim()) {
      throw new Error('Invalid recovery code. Please check your email and try again.');
    }

    const user = this.data.users.find(u => u.email.toLowerCase() === clean);
    if (!user) throw new Error('User not found');

    const { hash, salt } = hashPassword(newPassword);
    user.passwordHash = hash;
    user.salt = salt;

    // Remove reset record
    this.data.passwordResets = this.data.passwordResets.filter(r => r.email.toLowerCase() !== clean);

    this.sendEmail('password_change', user.email, user.fullName || `${user.firstName} ${user.lastName}`, {
      message: 'Your FNB Online Banking password was successfully updated via password recovery.',
    });

    this.logAudit('SYSTEM', 'PASSWORD_RESET_COMPLETED', `Password was successfully reset for ${user.email}`, user.id, user.fullName);

    this.saveData();
  }

  // --- In-App Notifications ---
  public getNotifications(userId: string): NotificationItem[] {
    return this.data.notifications
      .filter(n => n.userId === userId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  public markNotificationRead(notificationId: string, userId: string): void {
    const notif = this.data.notifications.find(n => n.id === notificationId && n.userId === userId);
    if (notif) {
      notif.read = true;
      this.saveData();
    }
  }

  public createNotification(
    userId: string,
    title: string,
    message: string,
    type: 'info' | 'success' | 'warning' | 'alert' = 'info',
    category?: NotificationItem['category'],
    actionUrl?: string
  ): NotificationItem {
    const notif: NotificationItem = {
      id: `notif-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      userId,
      title,
      message,
      type,
      category,
      read: false,
      createdAt: new Date().toISOString(),
      actionUrl,
    };
    this.data.notifications.unshift(notif);
    if (this.data.notifications.length > 200) {
      this.data.notifications = this.data.notifications.slice(0, 200);
    }
    this.saveData();
    return notif;
  }
}

export const storage = new StorageManager();

