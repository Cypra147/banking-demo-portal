import fs from 'fs';
import path from 'path';
import { initializeApp, getApps } from 'firebase/app';
import {
  getFirestore,
  collection,
  doc,
  getDocFromServer,
  getDocsFromServer,
  setDoc,
  deleteDoc,
  onSnapshot,
  Firestore,
  Unsubscribe,
} from 'firebase/firestore';
import {
  Transaction,
  VirtualCard,
  AuditLog,
  LoginActivity,
  EmailMessage,
  NotificationItem,
  InvestmentRequest,
  VerificationRequest,
  SupportEnquiry,
} from '../types.ts';
import type {
  StoredUser,
  PasswordResetRecord,
  StoredSession,
  DatabaseSchema,
} from './storage.ts';

export interface BackupSnapshotMeta {
  id: string;
  createdAt: string;
  createdBy: string;
  customerCount: number;
  transactionCount: number;
  reason?: string;
}

const SERVER_VAULT_ID = 'fnb_srv_v1_8c4e91a2d7b540f39e1c6a0b2f7d84e1';

export type FirestoreCollectionName =
  | 'customers'
  | 'transactions'
  | 'virtualCards'
  | 'auditLogs'
  | 'loginActivities'
  | 'emails'
  | 'notifications'
  | 'investments'
  | 'verifications'
  | 'supportEnquiries'
  | 'passwordResets'
  | 'sessions'
  | 'backups';

export function sanitizeDocId(rawId: string): string {
  const cleaned = String(rawId || 'doc')
    .trim()
    .replace(/[^a-zA-Z0-9_-]/g, '_')
    .slice(0, 128);
  return cleaned || `doc_${Date.now()}`;
}

export function stripUndefined<T>(value: T): T {
  if (Array.isArray(value)) {
    return value
      .filter((item) => item !== undefined)
      .map((item) => stripUndefined(item)) as unknown as T;
  }
  if (value !== null && typeof value === 'object') {
    const out: Record<string, any> = {};
    for (const [k, v] of Object.entries(value as Record<string, any>)) {
      if (v !== undefined) {
        out[k] = stripUndefined(v);
      }
    }
    return out as T;
  }
  return value;
}

class FirestoreStore {
  private db: Firestore | null = null;
  private initialized = false;
  private unsubscribers: Unsubscribe[] = [];

  private initClient(): Firestore | null {
    if (this.db) return this.db;
    const configPath = path.resolve(process.cwd(), 'firebase-applet-config.json');
    if (!fs.existsSync(configPath)) {
      console.warn('[FirestoreStore] firebase-applet-config.json not found; running in local JSON fallback mode.');
      return null;
    }
    const config = JSON.parse(fs.readFileSync(configPath, 'utf-8'));
    if (!config.projectId || config.projectId === 'remixed-project-id') {
      console.warn('[FirestoreStore] Placeholder firebase-applet-config.json detected; skipping Firestore.');
      return null;
    }
    const app = getApps().length > 0 ? getApps()[0] : initializeApp(config);
    this.db = config.firestoreDatabaseId
      ? getFirestore(app, config.firestoreDatabaseId)
      : getFirestore(app);
    return this.db;
  }

  public isEnabled(): boolean {
    return !!this.initClient();
  }

  private colRef(name: FirestoreCollectionName) {
    const db = this.initClient();
    if (!db) throw new Error('Firestore database not initialized');
    return collection(db, 'vaults', SERVER_VAULT_ID, name);
  }

  private docRef(name: FirestoreCollectionName, docId: string) {
    const db = this.initClient();
    if (!db) throw new Error('Firestore database not initialized');
    return doc(db, 'vaults', SERVER_VAULT_ID, name, sanitizeDocId(docId));
  }

  public async testConnection(): Promise<boolean> {
    const db = this.initClient();
    if (!db) return false;
    try {
      await getDocFromServer(doc(db, 'vaults', SERVER_VAULT_ID, 'health', 'connection'));
      this.initialized = true;
      return true;
    } catch (error) {
      if (error instanceof Error && error.message.includes('the client is offline')) {
        console.error('[FirestoreStore] Firestore connection failed (client offline). Please check Firebase configuration.');
      } else {
        console.error('[FirestoreStore] Firestore testConnection error:', error);
      }
      return false;
    }
  }

  public async fetchAll(): Promise<Partial<DatabaseSchema> & { backups?: BackupSnapshotMeta[] } | null> {
    const db = this.initClient();
    if (!db) return null;

    try {
      const [
        custSnap,
        txSnap,
        cardSnap,
        auditSnap,
        loginSnap,
        emailSnap,
        notifSnap,
        invSnap,
        verSnap,
        supSnap,
        resetSnap,
        sessSnap,
        backupSnap,
      ] = await Promise.all([
        getDocsFromServer(this.colRef('customers')),
        getDocsFromServer(this.colRef('transactions')),
        getDocsFromServer(this.colRef('virtualCards')),
        getDocsFromServer(this.colRef('auditLogs')),
        getDocsFromServer(this.colRef('loginActivities')),
        getDocsFromServer(this.colRef('emails')),
        getDocsFromServer(this.colRef('notifications')),
        getDocsFromServer(this.colRef('investments')),
        getDocsFromServer(this.colRef('verifications')),
        getDocsFromServer(this.colRef('supportEnquiries')),
        getDocsFromServer(this.colRef('passwordResets')),
        getDocsFromServer(this.colRef('sessions')),
        getDocsFromServer(this.colRef('backups')),
      ]);

      const sessions: Record<string, StoredSession> = {};
      sessSnap.forEach((d) => {
        const val = d.data() as StoredSession & { token?: string };
        const tok = val.token || d.id;
        sessions[tok] = {
          userId: val.userId,
          role: val.role,
          email: val.email,
          expiresAt: val.expiresAt,
          ...(typeof val.lastActivityAt === 'number' ? { lastActivityAt: val.lastActivityAt } : {}),
          ...(typeof val.pendingCloseAt === 'number' ? { pendingCloseAt: val.pendingCloseAt } : {}),
        };
      });

      this.initialized = true;
      return {
        users: custSnap.docs.map((d) => d.data() as StoredUser),
        transactions: txSnap.docs.map((d) => d.data() as Transaction),
        virtualCards: cardSnap.docs.map((d) => d.data() as VirtualCard),
        auditLogs: auditSnap.docs.map((d) => d.data() as AuditLog),
        loginActivities: loginSnap.docs.map((d) => d.data() as LoginActivity),
        emails: emailSnap.docs.map((d) => d.data() as EmailMessage),
        notifications: notifSnap.docs.map((d) => d.data() as NotificationItem),
        investments: invSnap.docs.map((d) => d.data() as InvestmentRequest),
        verifications: verSnap.docs.map((d) => d.data() as VerificationRequest),
        supportEnquiries: supSnap.docs.map((d) => d.data() as SupportEnquiry),
        passwordResets: resetSnap.docs.map((d) => d.data() as PasswordResetRecord),
        sessions,
        backups: backupSnap.docs.map((d) => d.data() as BackupSnapshotMeta),
      };
    } catch (error) {
      console.error('[FirestoreStore] Error fetching collections from Firestore:', error);
      return null;
    }
  }

  public async upsert(collectionName: FirestoreCollectionName, docId: string, data: Record<string, any>): Promise<void> {
    if (!this.initClient()) return;
    const clean = stripUndefined(data);
    try {
      await setDoc(this.docRef(collectionName, docId), clean);
    } catch (error) {
      console.error(`[FirestoreStore] Error writing ${collectionName}/${docId}:`, error);
      throw error;
    }
  }

  public async remove(collectionName: FirestoreCollectionName, docId: string): Promise<void> {
    if (!this.initClient()) return;
    try {
      await deleteDoc(this.docRef(collectionName, docId));
    } catch (error) {
      console.error(`[FirestoreStore] Error deleting ${collectionName}/${docId}:`, error);
      throw error;
    }
  }

  public subscribe(handlers: {
    onCustomers?: (users: StoredUser[]) => void;
    onTransactions?: (txs: Transaction[]) => void;
    onVirtualCards?: (cards: VirtualCard[]) => void;
    onSessions?: (sessions: Record<string, StoredSession>) => void;
    onBackups?: (backups: BackupSnapshotMeta[]) => void;
  }): void {
    if (!this.initClient() || this.unsubscribers.length > 0) return;

    if (handlers.onCustomers) {
      this.unsubscribers.push(
        onSnapshot(
          this.colRef('customers'),
          (snap) => {
            if (!snap.empty || this.initialized) {
              handlers.onCustomers!(snap.docs.map((d) => d.data() as StoredUser));
            }
          },
          (err) => console.error('[FirestoreStore] customers listener error:', err)
        )
      );
    }

    if (handlers.onTransactions) {
      this.unsubscribers.push(
        onSnapshot(
          this.colRef('transactions'),
          (snap) => {
            if (!snap.empty || this.initialized) {
              handlers.onTransactions!(snap.docs.map((d) => d.data() as Transaction));
            }
          },
          (err) => console.error('[FirestoreStore] transactions listener error:', err)
        )
      );
    }

    if (handlers.onVirtualCards) {
      this.unsubscribers.push(
        onSnapshot(
          this.colRef('virtualCards'),
          (snap) => {
            if (!snap.empty || this.initialized) {
              handlers.onVirtualCards!(snap.docs.map((d) => d.data() as VirtualCard));
            }
          },
          (err) => console.error('[FirestoreStore] virtualCards listener error:', err)
        )
      );
    }

    if (handlers.onSessions) {
      this.unsubscribers.push(
        onSnapshot(
          this.colRef('sessions'),
          (snap) => {
            const sessions: Record<string, StoredSession> = {};
            snap.forEach((d) => {
              const val = d.data() as StoredSession & { token?: string };
              const tok = val.token || d.id;
              sessions[tok] = {
                userId: val.userId,
                role: val.role,
                email: val.email,
                expiresAt: val.expiresAt,
                ...(typeof val.lastActivityAt === 'number' ? { lastActivityAt: val.lastActivityAt } : {}),
                ...(typeof val.pendingCloseAt === 'number' ? { pendingCloseAt: val.pendingCloseAt } : {}),
              };
            });
            handlers.onSessions!(sessions);
          },
          (err) => console.error('[FirestoreStore] sessions listener error:', err)
        )
      );
    }

    if (handlers.onBackups) {
      this.unsubscribers.push(
        onSnapshot(
          this.colRef('backups'),
          (snap) => {
            handlers.onBackups!(snap.docs.map((d) => d.data() as BackupSnapshotMeta));
          },
          (err) => console.error('[FirestoreStore] backups listener error:', err)
        )
      );
    }
  }
}

export const firestoreStore = new FirestoreStore();
