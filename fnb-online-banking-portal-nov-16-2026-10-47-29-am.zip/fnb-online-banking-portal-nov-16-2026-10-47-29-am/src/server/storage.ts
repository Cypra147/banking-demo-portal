import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { 
  User, 
  Transaction, 
  VirtualCard, 
  AuditLog, 
  LoginActivity, 
  EmailMessage, 
  NotificationItem,
  InvestmentPlan,
  InvestmentRequest,
  VerificationRequest,
  SupportEnquiry
} from '../types.ts';
import { INVESTMENT_PLANS } from '../constants/investments.ts';
import { tagTransaction } from '../utils/transactionTagger.ts';
import { formatUsdNumber, USD_SYMBOL } from '../utils/currency.ts';
export { INVESTMENT_PLANS };

import { emailService } from './emailService.ts';
import {
  firestoreStore,
  BackupSnapshotMeta,
  FirestoreCollectionName,
} from './firestoreStore.ts';

const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'fnb_database.json');
const DB_BACKUP_FILE = path.join(DATA_DIR, 'fnb_database_backup.json');

export interface StoredUser extends User {
  passwordHash: string;
  salt: string;
  transactionPinHash?: string;
  transactionPinSalt?: string;
  transactionPinLength?: 4 | 6;
  transactionPinUpdatedAt?: string;
  pinFailedAttempts?: number;
  pinLockedUntil?: number;
}

export class PinSecurityError extends Error {
  public code: 'PIN_NOT_SET' | 'PIN_REQUIRED' | 'PIN_INVALID' | 'PIN_LOCKED' | 'PIN_FORMAT';
  public statusCode: number;
  public lockedUntil?: number;

  constructor(
    message: string,
    code: 'PIN_NOT_SET' | 'PIN_REQUIRED' | 'PIN_INVALID' | 'PIN_LOCKED' | 'PIN_FORMAT',
    statusCode = 400,
    lockedUntil?: number
  ) {
    super(message);
    this.name = 'PinSecurityError';
    this.code = code;
    this.statusCode = statusCode;
    this.lockedUntil = lockedUntil;
  }
}

export interface OTPRecord {
  email: string;
  code: string;
  expiresAt: number;
  attempts: number;
  lastSentAt: number;
  resendCount: number;
  referenceNumber: string;
  payload: {
    firstName: string;
    middleName?: string;
    lastName: string;
    fullName?: string;
    dateOfBirth?: string;
    email: string;
    username: string;
    phone: string;
    country?: string;
    state?: string;
    residentialAddress?: string;
    postalCode?: string;
    passwordHash: string;
    salt: string;
    notificationPreferences?: {
      emailAlerts: boolean;
      smsAlerts: boolean;
    };
  };
}

export interface PasswordResetRecord {
  email: string;
  token: string;
  code: string;
  expiresAt: number;
  purpose?: 'password_reset' | 'transaction_pin_reset';
  attempts?: number;
  lastSentAt?: number;
  resendCount?: number;
}

export interface StoredSession {
  userId: string;
  role: 'customer' | 'admin';
  email: string;
  expiresAt: number;
  lastActivityAt?: number;
  pendingCloseAt?: number;
}

export interface DatabaseSchema {
  users: StoredUser[];
  transactions: Transaction[];
  virtualCards: VirtualCard[];
  auditLogs: AuditLog[];
  loginActivities: LoginActivity[];
  emails: EmailMessage[];
  notifications: NotificationItem[];
  otps: OTPRecord[];
  investments: InvestmentRequest[];
  verifications: VerificationRequest[];
  supportEnquiries: SupportEnquiry[];
  passwordResets: PasswordResetRecord[];
  sessions?: Record<string, StoredSession>;
}

function hashPassword(password: string, salt?: string): { hash: string; salt: string } {
  const generatedSalt = salt || crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(password, generatedSalt, 64).toString('hex');
  return { hash, salt: generatedSalt };
}

function verifyPassword(password: string, hash: string, salt: string): boolean {
  if (!password || !hash || !salt) return false;
  try {
    const computed = crypto.scryptSync(password, salt, 64);
    const expected = Buffer.from(hash, 'hex');
    if (computed.length !== expected.length) return false;
    return crypto.timingSafeEqual(computed, expected);
  } catch {
    return false;
  }
}

export function generateAccountNumber(existingAccountNumbers: Set<string> = new Set()): string {
  // 10 digit unique account number
  for (let attempt = 0; attempt < 50; attempt++) {
    const prefix = '10';
    const randomDigits = Math.floor(10000000 + Math.random() * 90000000).toString();
    const candidate = `${prefix}${randomDigits.slice(0, 8)}`;
    if (!existingAccountNumbers.has(candidate)) {
      return candidate;
    }
  }
  return `10${Date.now().toString().slice(-8)}`;
}

export function generateCardNumber(): string {
  // 16 digit card number starting with 4200 (Visa) or 5399 (Mastercard)
  const p1 = '4242';
  const p2 = Math.floor(1000 + Math.random() * 9000).toString();
  const p3 = Math.floor(1000 + Math.random() * 9000).toString();
  const p4 = Math.floor(1000 + Math.random() * 9000).toString();
  return `${p1} ${p2} ${p3} ${p4}`;
}

export function generateSortCode(): string {
  return '20-04-15';
}

export function generateReference(prefix = 'TXN'): string {
  const rand = crypto.randomBytes(4).toString('hex').toUpperCase();
  const dateStr = new Date().toISOString().slice(2, 10).replace(/-/g, '');
  return `${prefix}-${dateStr}-${rand}`;
}

// Generate professional HTML email templates matching FNB's branding
export function createEmailTemplate(
  type: EmailMessage['templateType'], 
  recipientName: string, 
  data: Record<string, any>
): { subject: string; html: string; text: string } {
  const currentYear = new Date().getFullYear();
  const baseHeader = `
    <div style="background-color: #002752; padding: 24px 30px; text-align: center; border-radius: 8px 8px 0 0;">
      <div style="display: inline-flex; align-items: center; justify-content: center; gap: 10px;">
        <span style="color: #ffffff; font-size: 28px; font-weight: 800; letter-spacing: 1px; font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif;">
          <span style="color: #c8102e;">FNB</span> ONLINE
        </span>
      </div>
      <p style="margin: 6px 0 0; color: #94a3b8; font-size: 13px; letter-spacing: 0.5px;">FIRST NATIONAL BANK • SECURE PORTAL</p>
    </div>
  `;

  const baseFooter = `
    <div style="background-color: #f8fafc; padding: 20px 30px; border-top: 1px solid #e2e8f0; font-size: 12px; color: #64748b; line-height: 1.6; border-radius: 0 0 8px 8px;">
      <p style="margin: 0 0 8px;"><strong>Need assistance?</strong> Contact FNB 24/7 Support:</p>
      <p style="margin: 0 0 4px;">📞 Telephone: <strong>+12724736857</strong> | 💬 WhatsApp: <strong>+12724736857</strong></p>
      <p style="margin: 0 0 8px;">✉️ Official Email: <a href="mailto:info@fnnbbankss.online" style="color: #002752;">info@fnnbbankss.online</a></p>
      <div style="margin-top: 12px; padding: 8px; background-color: #fef2f2; border: 1px solid #fee2e2; border-radius: 6px; color: #991b1b; font-size: 11px;">
        🛡️ <strong>Security Notice:</strong> FNB will never ask for your password, PIN, or verification codes via email or phone.
      </div>
      <p style="margin: 12px 0 0; font-size: 11px; text-align: center; color: #94a3b8;">
        © ${currentYear} First National Bank (FNB). All rights reserved.
      </p>
    </div>
  `;

  let subject = '';
  let content = '';
  let text = '';

  switch (type) {
    case 'registration_otp':
      subject = `FNB Security: Your Registration OTP is ${data.otpCode}`;
      text = `Hello ${recipientName}, Your FNB verification code is ${data.otpCode}. It expires in 10 minutes.`;
      content = `
        <h2 style="color: #002752; margin: 0 0 16px; font-size: 20px;">Email Verification Code</h2>
        <p style="color: #334155; line-height: 1.6; margin: 0 0 16px;">
          Dear <strong>${recipientName}</strong>,<br/>
          Thank you for applying to open an account with First National Bank (FNB). To complete your application, please use the 6-digit verification code below:
        </p>
        <div style="background: linear-gradient(135deg, #002752, #0a3d7a); padding: 20px; border-radius: 8px; text-align: center; margin: 24px 0;">
          <span style="font-size: 36px; font-weight: 800; letter-spacing: 8px; color: #ffffff; font-family: monospace;">
            ${data.otpCode}
          </span>
          <p style="margin: 8px 0 0; color: #cbd5e1; font-size: 12px;">Valid for 10 minutes. Do not share this code.</p>
        </div>
        <p style="color: #64748b; font-size: 13px; margin: 0;">
          If you did not initiate this registration, please contact our security team immediately at <strong>info@fnnbbankss.online</strong>.
        </p>
      `;
      break;

    case 'account_approved':
      subject = `Congratulations! Your FNB Account has been Approved (${data.accountNumber})`;
      text = `Dear ${recipientName}, your FNB account is now active. Account Number: ${data.accountNumber}, Sort Code: ${data.sortCode}.`;
      content = `
        <div style="text-align: center; margin-bottom: 20px;">
          <div style="display: inline-block; background-color: #dcfce7; color: #166534; font-weight: 700; padding: 6px 14px; border-radius: 20px; font-size: 13px;">
            ✓ ACCOUNT APPROVED & ACTIVATED
          </div>
        </div>
        <h2 style="color: #002752; margin: 0 0 12px; font-size: 22px; text-align: center;">Welcome to First National Bank</h2>
        <p style="color: #334155; line-height: 1.6; margin: 0 0 20px;">
          Dear <strong>${recipientName}</strong>,<br/>
          Your account application has been officially reviewed and approved by our banking administration team. Your full online banking privileges are now activated.
        </p>
        <div style="background-color: #f1f5f9; border-left: 4px solid #c8102e; padding: 18px 20px; border-radius: 6px; margin: 20px 0;">
          <table style="width: 100%; border-collapse: collapse; font-size: 14px; color: #1e293b;">
            <tr>
              <td style="padding: 6px 0; color: #64748b;">Account Holder:</td>
              <td style="padding: 6px 0; font-weight: 600; text-align: right;">${recipientName}</td>
            </tr>
            <tr>
              <td style="padding: 6px 0; color: #64748b;">Account Number:</td>
              <td style="padding: 6px 0; font-weight: 700; color: #002752; font-family: monospace; font-size: 16px; text-align: right;">${data.accountNumber}</td>
            </tr>
            <tr>
              <td style="padding: 6px 0; color: #64748b;">Sort Code:</td>
              <td style="padding: 6px 0; font-weight: 600; text-align: right;">${data.sortCode}</td>
            </tr>
            <tr>
              <td style="padding: 6px 0; color: #64748b;">Opening Balance:</td>
              <td style="padding: 6px 0; font-weight: 700; color: #16a34a; text-align: right;">${USD_SYMBOL}${formatUsdNumber(Number(data.balance || 0))} USD</td>
            </tr>
            <tr>
              <td style="padding: 6px 0; color: #64748b;">Account Status:</td>
              <td style="padding: 6px 0; font-weight: 700; color: #15803d; text-align: right;">Active / Verified</td>
            </tr>
          </table>
        </div>
        <p style="color: #334155; line-height: 1.6;">
          You can now log in to the FNB Online Banking portal to manage your funds, generate virtual cards, make transfers, and pay bills.
        </p>
      `;
      break;

    case 'account_rejected':
      subject = `Important Notice: FNB Account Application Status`;
      text = `Dear ${recipientName}, your application could not be approved at this time.`;
      content = `
        <h2 style="color: #991b1b; margin: 0 0 12px; font-size: 20px;">Account Application Notice</h2>
        <p style="color: #334155; line-height: 1.6; margin: 0 0 16px;">
          Dear <strong>${recipientName}</strong>,<br/>
          We regret to inform you that your registration could not be verified and approved at this time.
        </p>
        <div style="background-color: #fef2f2; border: 1px solid #fecaca; padding: 14px; border-radius: 6px; margin: 16px 0; color: #7f1d1d; font-size: 13px;">
          <strong>Reason:</strong> ${data.reason || 'Information provided did not satisfy verification criteria. Please resubmit or reach customer care.'}
        </div>
      `;
      break;

    case 'debit_alert':
      subject = `FNB Debit Alert: ${USD_SYMBOL}${formatUsdNumber(Number(data.amount))} debited from ${data.accountNumber}`;
      text = `Debit Alert: ${USD_SYMBOL}${formatUsdNumber(Number(data.amount))} USD on account ${data.accountNumber}. Ref: ${data.reference}.`;
      content = `
        <h2 style="color: #002752; margin: 0 0 16px; font-size: 20px;">Transaction Debit Alert</h2>
        <p style="color: #334155; line-height: 1.6; margin: 0 0 16px;">
          Dear <strong>${recipientName}</strong>, your account has been debited as follows:
        </p>
        <div style="background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px; padding: 16px; margin: 16px 0;">
          <table style="width: 100%; border-collapse: collapse; font-size: 14px;">
            <tr>
              <td style="padding: 6px 0; color: #64748b;">Amount:</td>
              <td style="padding: 6px 0; font-weight: 700; color: #dc2626; text-align: right; font-size: 16px;">-${USD_SYMBOL}${formatUsdNumber(Number(data.amount))} USD</td>
            </tr>
            <tr>
              <td style="padding: 6px 0; color: #64748b;">Beneficiary:</td>
              <td style="padding: 6px 0; font-weight: 600; text-align: right;">${data.beneficiaryName || 'N/A'}</td>
            </tr>
            <tr>
              <td style="padding: 6px 0; color: #64748b;">Reference:</td>
              <td style="padding: 6px 0; font-family: monospace; text-align: right;">${data.reference}</td>
            </tr>
            <tr>
              <td style="padding: 6px 0; color: #64748b;">Remaining Balance:</td>
              <td style="padding: 6px 0; font-weight: 700; text-align: right; color: #002752;">${USD_SYMBOL}${formatUsdNumber(Number(data.newBalance))} USD</td>
            </tr>
          </table>
        </div>
      `;
      break;

    case 'credit_alert':
      subject = `FNB Credit Alert: ${USD_SYMBOL}${formatUsdNumber(Number(data.amount))} credited to ${data.accountNumber}`;
      text = `Credit Alert: ${USD_SYMBOL}${formatUsdNumber(Number(data.amount))} USD received on account ${data.accountNumber}.`;
      content = `
        <h2 style="color: #002752; margin: 0 0 16px; font-size: 20px;">Transaction Credit Alert</h2>
        <p style="color: #334155; line-height: 1.6; margin: 0 0 16px;">
          Dear <strong>${recipientName}</strong>, your account has been credited:
        </p>
        <div style="background-color: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 6px; padding: 16px; margin: 16px 0;">
          <table style="width: 100%; border-collapse: collapse; font-size: 14px;">
            <tr>
              <td style="padding: 6px 0; color: #166534;">Amount Credited:</td>
              <td style="padding: 6px 0; font-weight: 700; color: #16a34a; text-align: right; font-size: 18px;">+${USD_SYMBOL}${formatUsdNumber(Number(data.amount))} USD</td>
            </tr>
            <tr>
              <td style="padding: 6px 0; color: #64748b;">Description:</td>
              <td style="padding: 6px 0; font-weight: 600; text-align: right;">${data.description}</td>
            </tr>
            <tr>
              <td style="padding: 6px 0; color: #64748b;">Reference:</td>
              <td style="padding: 6px 0; font-family: monospace; text-align: right;">${data.reference}</td>
            </tr>
            <tr>
              <td style="padding: 6px 0; color: #64748b;">New Balance:</td>
              <td style="padding: 6px 0; font-weight: 700; text-align: right; color: #002752;">${USD_SYMBOL}${formatUsdNumber(Number(data.newBalance))} USD</td>
            </tr>
          </table>
        </div>
      `;
      break;

    case 'transaction_reversal':
      subject = `FNB Reversal Notice: ${USD_SYMBOL}${formatUsdNumber(Number(data.amount))} Refunded (${data.reference})`;
      text = `Reversal Complete: ${USD_SYMBOL}${formatUsdNumber(Number(data.amount))} USD has been returned to your balance.`;
      content = `
        <div style="background-color: #fefce8; border-left: 4px solid #ca8a04; padding: 16px; border-radius: 6px; margin-bottom: 20px;">
          <h2 style="color: #854d0e; margin: 0 0 8px; font-size: 18px;">Transaction Reversal Processed</h2>
          <p style="margin: 0; color: #713f12; font-size: 13px;">
            The referenced transfer has been reversed and the funds have been credited back to your account balance.
          </p>
        </div>
        <table style="width: 100%; border-collapse: collapse; font-size: 14px; background: #ffffff; border: 1px solid #e2e8f0; border-radius: 6px; padding: 14px;">
          <tr>
            <td style="padding: 8px 12px; color: #64748b;">Refunded Amount:</td>
            <td style="padding: 8px 12px; font-weight: 700; color: #16a34a; text-align: right;">+${USD_SYMBOL}${formatUsdNumber(Number(data.amount))} USD</td>
          </tr>
          <tr>
            <td style="padding: 8px 12px; color: #64748b;">Original Reference:</td>
            <td style="padding: 8px 12px; font-family: monospace; text-align: right;">${data.originalReference || data.reference}</td>
          </tr>
          <tr>
            <td style="padding: 8px 12px; color: #64748b;">Reversal Reference:</td>
            <td style="padding: 8px 12px; font-family: monospace; text-align: right; color: #002752; font-weight: 600;">${data.reference}</td>
          </tr>
          <tr>
            <td style="padding: 8px 12px; color: #64748b;">Updated Available Balance:</td>
            <td style="padding: 8px 12px; font-weight: 700; text-align: right; color: #002752;">${USD_SYMBOL}${formatUsdNumber(Number(data.newBalance))} USD</td>
          </tr>
        </table>
      `;
      break;

    case 'investment_received':
      subject = `FNB Investment Request Acknowledged: ${data.planName} (${data.reference})`;
      text = `Your investment request of ${USD_SYMBOL}${formatUsdNumber(Number(data.amount))} USD in ${data.planName} has been received and is under compliance review. Reference: ${data.reference}`;
      content = `
        <h2 style="color: #002752; margin: 0 0 16px; font-size: 20px;">Investment Request Received</h2>
        <p style="color: #334155; line-height: 1.6; margin: 0 0 16px;">
          Dear <strong>${recipientName}</strong>, thank you for submitting your investment application. Your portfolio request has been logged under reference <strong>${data.reference}</strong>.
        </p>
        <div style="background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px; padding: 16px; margin: 16px 0;">
          <table style="width: 100%; border-collapse: collapse; font-size: 14px;">
            <tr><td style="padding: 6px 0; color: #64748b;">Plan:</td><td style="padding: 6px 0; font-weight: 700; color: #002752; text-align: right;">${data.planName}</td></tr>
            <tr><td style="padding: 6px 0; color: #64748b;">Principal Amount:</td><td style="padding: 6px 0; font-weight: 700; color: #002752; text-align: right;">${USD_SYMBOL}${formatUsdNumber(Number(data.amount))} USD</td></tr>
            <tr><td style="padding: 6px 0; color: #64748b;">Duration:</td><td style="padding: 6px 0; font-weight: 600; text-align: right;">${data.durationMonths} Months</td></tr>
            <tr><td style="padding: 6px 0; color: #64748b;">Projected Return:</td><td style="padding: 6px 0; font-weight: 700; color: #16a34a; text-align: right;">+${USD_SYMBOL}${formatUsdNumber(Number(data.projectedReturnAmount))} USD (${data.projectedReturnRate}% p.a.)</td></tr>
            <tr><td style="padding: 6px 0; color: #64748b;">Status:</td><td style="padding: 6px 0; font-weight: 600; color: #ca8a04; text-align: right;">Pending Administrative Review</td></tr>
          </table>
        </div>
      `;
      break;

    case 'investment_approved':
      subject = `FNB Investment Request Approved: ${data.planName} (${data.reference})`;
      text = `Your investment in ${data.planName} has been approved by FNB Asset Management. Reference: ${data.reference}`;
      content = `
        <h2 style="color: #16a34a; margin: 0 0 16px; font-size: 20px;">Investment Application Approved</h2>
        <p style="color: #334155; line-height: 1.6; margin: 0 0 16px;">
          Dear <strong>${recipientName}</strong>, your investment portfolio allocation has been officially authorized and is now active.
        </p>
        <div style="background-color: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 6px; padding: 16px; margin: 16px 0;">
          <table style="width: 100%; border-collapse: collapse; font-size: 14px;">
            <tr><td style="padding: 6px 0; color: #166534;">Plan:</td><td style="padding: 6px 0; font-weight: 700; color: #166534; text-align: right;">${data.planName}</td></tr>
            <tr><td style="padding: 6px 0; color: #64748b;">Amount:</td><td style="padding: 6px 0; font-weight: 700; color: #002752; text-align: right;">${USD_SYMBOL}${formatUsdNumber(Number(data.amount))} USD</td></tr>
            <tr><td style="padding: 6px 0; color: #64748b;">Reference:</td><td style="padding: 6px 0; font-family: monospace; text-align: right;">${data.reference}</td></tr>
            <tr><td style="padding: 6px 0; color: #64748b;">Status:</td><td style="padding: 6px 0; font-weight: 700; color: #16a34a; text-align: right;">Active Allocation</td></tr>
          </table>
        </div>
      `;
      break;

    case 'verification_submitted':
      subject = `FNB Identity Verification Submitted: Ref ${data.reference}`;
      text = `Your customer verification documents have been received under reference ${data.reference}. Our compliance desk is reviewing your submission.`;
      content = `
        <h2 style="color: #002752; margin: 0 0 16px; font-size: 20px;">Identity Verification (KYC) Received</h2>
        <p style="color: #334155; line-height: 1.6; margin: 0 0 16px;">
          Dear <strong>${recipientName}</strong>, thank you for submitting your verification details.
        </p>
        <div style="background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px; padding: 16px; margin: 16px 0;">
          <table style="width: 100%; border-collapse: collapse; font-size: 14px;">
            <tr><td style="padding: 6px 0; color: #64748b;">Reference:</td><td style="padding: 6px 0; font-family: monospace; text-align: right;">${data.reference}</td></tr>
            <tr><td style="padding: 6px 0; color: #64748b;">Document Type:</td><td style="padding: 6px 0; font-weight: 600; text-align: right;">${data.idDocumentType}</td></tr>
            <tr><td style="padding: 6px 0; color: #64748b;">Status:</td><td style="padding: 6px 0; font-weight: 600; color: #ca8a04; text-align: right;">Pending Review</td></tr>
          </table>
        </div>
      `;
      break;

    case 'verification_approved':
      subject = `FNB Identity Verification Approved - Account Verified`;
      text = `Your identity verification (Reference: ${data.reference}) has been approved. Your account tier has been upgraded to Fully Verified.`;
      content = `
        <h2 style="color: #16a34a; margin: 0 0 16px; font-size: 20px;">Account Verification Successful</h2>
        <p style="color: #334155; line-height: 1.6; margin: 0 0 16px;">
          Dear <strong>${recipientName}</strong>, your verification application has been reviewed and approved by the FNB Compliance Team. Your customer account is now fully verified.
        </p>
        <div style="background-color: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 6px; padding: 16px; margin: 16px 0;">
          <p style="margin: 0; color: #166534; font-weight: 600;">Verification Status: Verified Tier 1</p>
          <p style="margin: 4px 0 0; color: #475569; font-size: 13px;">Reference: ${data.reference}</p>
        </div>
      `;
      break;

    case 'password_reset':
      subject = `FNB Password Recovery Code: ${data.resetCode}`;
      text = `Your password reset code is: ${data.resetCode}. This code is valid for 15 minutes.`;
      content = `
        <h2 style="color: #002752; margin: 0 0 16px; font-size: 20px;">Password Reset Request</h2>
        <p style="color: #334155; line-height: 1.6; margin: 0 0 16px;">
          Dear <strong>${recipientName}</strong>, we received a request to reset the password for your FNB Online Banking account. Use the authorization code below:
        </p>
        <div style="background-color: #eff6ff; border: 1px dashed #3b82f6; border-radius: 8px; padding: 20px; text-align: center; margin: 24px 0;">
          <span style="font-size: 32px; font-weight: 800; letter-spacing: 8px; color: #002752; font-family: monospace;">${data.resetCode}</span>
          <p style="margin: 8px 0 0; color: #64748b; font-size: 13px;">Valid for 15 minutes. Never share this code with anyone.</p>
        </div>
      `;
      break;

    case 'pin_reset_code':
      subject = `FNB Security Verification: Transaction PIN Reset Code (${data.resetCode})`;
      text = `Your FNB Transaction PIN reset verification code is ${data.resetCode}. It is valid for 10 minutes. Never share your Transaction PIN or this code with anyone, including FNB staff.`;
      content = `
        <h2 style="color: #002752; margin: 0 0 16px; font-size: 20px;">Transaction PIN Reset Verification</h2>
        <p style="color: #334155; line-height: 1.6; margin: 0 0 16px;">
          Dear <strong>${recipientName}</strong>, we received an authorized request to reset the Transaction PIN on your FNB Online Banking account. Enter the 6-digit verification code below to set a new PIN:
        </p>
        <div style="background: linear-gradient(135deg, #002752, #0a3d7a); padding: 20px; border-radius: 8px; text-align: center; margin: 24px 0;">
          <span style="font-size: 32px; font-weight: 800; letter-spacing: 8px; color: #ffffff; font-family: monospace;">${data.resetCode}</span>
          <p style="margin: 8px 0 0; color: #cbd5e1; font-size: 12px;">Valid for 10 minutes. FNB staff will never ask you for your Transaction PIN or this code.</p>
        </div>
        <p style="color: #64748b; font-size: 13px; margin: 0;">
          If you did not initiate this request, contact FNB Security immediately at <strong>+12724736857</strong> or <strong>info@fnnbbankss.online</strong>.
        </p>
      `;
      break;

    case 'password_change':
    case 'security_notification':
    case 'account_activity':
    default:
      subject = data.subject || `FNB Security Notification: Account Activity`;
      text = data.message || `Account activity recorded for ${recipientName}.`;
      content = `
        <h2 style="color: #002752; margin: 0 0 16px; font-size: 20px;">Security & Account Alert</h2>
        <p style="color: #334155; line-height: 1.6; margin: 0 0 16px;">
          Dear <strong>${recipientName}</strong>,<br/>
          ${data.message || 'We noticed a recent security update or login activity on your FNB account.'}
        </p>
        <div style="background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px; padding: 14px; font-size: 13px; color: #475569;">
          <strong>Time:</strong> ${new Date().toUTCString()}<br/>
          <strong>Device/IP:</strong> ${data.device || 'Authorized Browser Session'} (${data.ip || 'Secure Connection'})
        </div>
      `;
      break;
  }

  const fullHtml = `
    <!DOCTYPE html>
    <html>
      <head>
        <meta charset="utf-8" />
        <title>${subject}</title>
      </head>
      <body style="margin: 0; padding: 24px; background-color: #f1f5f9; font-family: 'Helvetica Neue', Arial, sans-serif;">
        <div style="max-width: 580px; margin: 0 auto; background-color: #ffffff; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.06); overflow: hidden; border: 1px solid #e2e8f0;">
          ${baseHeader}
          <div style="padding: 28px 30px;">
            ${content}
          </div>
          ${baseFooter}
        </div>
      </body>
    </html>
  `;

  return { subject, html: fullHtml, text };
}

class StorageManager {
  private data: DatabaseSchema;
  private backups: BackupSnapshotMeta[] = [];
  private pendingWrites: Promise<void>[] = [];
  private readyPromise: Promise<void>;
  private lastFirestoreSyncAt = 0;
  private activeRefreshPromise: Promise<void> | null = null;

  constructor() {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    this.data = this.loadData();
    this.readyPromise = this.initializePersistence();
  }

  public async ready(): Promise<void> {
    await this.readyPromise;
  }

  public async flush(): Promise<void> {
    if (this.pendingWrites.length === 0) return;
    const batch = [...this.pendingWrites];
    this.pendingWrites = [];
    await Promise.allSettled(batch);
  }

  private queueWrite(op: Promise<void>): void {
    const tracked = op.catch((err) => {
      console.error('[StorageManager] Background Firestore persistence error:', err);
    });
    this.pendingWrites.push(tracked);
  }

  private persistDoc(col: FirestoreCollectionName, docId: string, payload: Record<string, any>): void {
    if (!firestoreStore.isEnabled()) return;
    this.queueWrite(firestoreStore.upsert(col, docId, payload));
  }

  private removeDoc(col: FirestoreCollectionName, docId: string): void {
    if (!firestoreStore.isEnabled()) return;
    this.queueWrite(firestoreStore.remove(col, docId));
  }

  private getResetDocId(email: string): string {
    return `reset_${email.trim().toLowerCase().replace(/[^a-z0-9]/g, '_')}`;
  }

  private mergeUniqueById<T extends { id: string }>(remote: T[], local: T[]): { merged: T[]; missingFromRemote: T[] } {
    const byId = new Map<string, T>();
    for (const item of remote) {
      if (item && item.id) byId.set(item.id, item);
    }
    const missingFromRemote: T[] = [];
    for (const item of local) {
      if (item && item.id && !byId.has(item.id)) {
        byId.set(item.id, item);
        missingFromRemote.push(item);
      }
    }
    return { merged: Array.from(byId.values()), missingFromRemote };
  }

  private mergeUsersNonDestructively(remoteUsers: StoredUser[], localUsers: StoredUser[]): { merged: StoredUser[]; missingFromRemote: StoredUser[] } {
    const merged: StoredUser[] = [...remoteUsers];
    const seenIds = new Set(remoteUsers.map(u => u.id));
    const seenEmails = new Set(remoteUsers.map(u => u.email.trim().toLowerCase()));
    const seenUsernames = new Set(remoteUsers.map(u => u.username.trim().toLowerCase()));
    const missingFromRemote: StoredUser[] = [];

    for (const localUser of localUsers) {
      const emailKey = (localUser.email || '').trim().toLowerCase();
      const usernameKey = (localUser.username || '').trim().toLowerCase();
      if (!seenIds.has(localUser.id) && !seenEmails.has(emailKey) && !seenUsernames.has(usernameKey)) {
        merged.push(localUser);
        missingFromRemote.push(localUser);
        seenIds.add(localUser.id);
        seenEmails.add(emailKey);
        seenUsernames.add(usernameKey);
      }
    }
    return { merged, missingFromRemote };
  }

  private async initializePersistence(): Promise<void> {
    if (firestoreStore.isEnabled()) {
      const connected = await firestoreStore.testConnection();
      if (connected) {
        const remote = await firestoreStore.fetchAll();
        if (remote) {
          const userMerge = this.mergeUsersNonDestructively(remote.users || [], this.data.users);
          const txMerge = this.mergeUniqueById(remote.transactions || [], this.data.transactions);
          const cardMerge = this.mergeUniqueById(remote.virtualCards || [], this.data.virtualCards);
          const auditMerge = this.mergeUniqueById(remote.auditLogs || [], this.data.auditLogs);
          const loginMerge = this.mergeUniqueById(remote.loginActivities || [], this.data.loginActivities);
          const emailMerge = this.mergeUniqueById(remote.emails || [], this.data.emails);
          const notifMerge = this.mergeUniqueById(remote.notifications || [], this.data.notifications);
          const invMerge = this.mergeUniqueById(remote.investments || [], this.data.investments);
          const verMerge = this.mergeUniqueById(remote.verifications || [], this.data.verifications);
          const supMerge = this.mergeUniqueById(remote.supportEnquiries || [], this.data.supportEnquiries);

          const mergedResetsMap = new Map<string, PasswordResetRecord>();
          const resetKey = (r: PasswordResetRecord) => `${r.email.toLowerCase()}::${r.purpose || 'password_reset'}`;
          for (const r of remote.passwordResets || []) mergedResetsMap.set(resetKey(r), r);
          for (const r of this.data.passwordResets) {
            if (!mergedResetsMap.has(resetKey(r))) mergedResetsMap.set(resetKey(r), r);
          }

          const mergedSessions: Record<string, StoredSession> = {
            ...(this.data.sessions || {}),
            ...(remote.sessions || {}),
          };

          this.data = {
            ...this.data,
            users: userMerge.merged,
            transactions: txMerge.merged,
            virtualCards: cardMerge.merged,
            auditLogs: auditMerge.merged,
            loginActivities: loginMerge.merged,
            emails: emailMerge.merged,
            notifications: notifMerge.merged,
            investments: invMerge.merged,
            verifications: verMerge.merged,
            supportEnquiries: supMerge.merged,
            passwordResets: Array.from(mergedResetsMap.values()),
            sessions: mergedSessions,
          };
          this.backups = remote.backups || [];

          // Migrate only records missing from Firestore without overwriting existing cloud data
          for (const u of userMerge.missingFromRemote) this.persistDoc('customers', u.id, u);
          for (const tx of txMerge.missingFromRemote) this.persistDoc('transactions', tx.id, tx);
          for (const c of cardMerge.missingFromRemote) this.persistDoc('virtualCards', c.id, c);
          for (const a of auditMerge.missingFromRemote) this.persistDoc('auditLogs', a.id, a);
          for (const l of loginMerge.missingFromRemote) this.persistDoc('loginActivities', l.id, l);
          for (const e of emailMerge.missingFromRemote) this.persistDoc('emails', e.id, e);
          for (const n of notifMerge.missingFromRemote) this.persistDoc('notifications', n.id, n);
          for (const inv of invMerge.missingFromRemote) this.persistDoc('investments', inv.id, inv);
          for (const v of verMerge.missingFromRemote) this.persistDoc('verifications', v.id, v);
          for (const s of supMerge.missingFromRemote) this.persistDoc('supportEnquiries', s.id, s);

          this.lastFirestoreSyncAt = Date.now();
          console.log(`[StorageManager] Synced with Firestore (${this.data.users.length} users, ${this.data.transactions.length} transactions).`);
        }

        // Subscribe to real-time updates for cross-device/cross-instance consistency
        firestoreStore.subscribe({
          onCustomers: (users) => {
            this.data.users = users;
            this.saveLocalSnapshotOnly();
          },
          onTransactions: (txs) => {
            this.data.transactions = txs;
          },
          onVirtualCards: (cards) => {
            this.data.virtualCards = cards;
          },
          onSessions: (sessions) => {
            this.data.sessions = sessions;
          },
          onBackups: (backups) => {
            this.backups = backups;
          },
        });
      }
    }

    this.initSeeds();
    await this.flush();
  }

  public async refreshFromFirestore(force = false): Promise<void> {
    await this.readyPromise;
    if (!firestoreStore.isEnabled()) return;
    if (!force && Date.now() - this.lastFirestoreSyncAt < 1500) return;
    if (this.activeRefreshPromise) {
      await this.activeRefreshPromise;
      return;
    }

    this.activeRefreshPromise = (async () => {
      try {
        const remote = await firestoreStore.fetchAll();
        if (!remote) return;
        if (remote.users) this.data.users = remote.users;
        if (remote.transactions) this.data.transactions = remote.transactions;
        if (remote.virtualCards) this.data.virtualCards = remote.virtualCards;
        if (remote.auditLogs) this.data.auditLogs = remote.auditLogs;
        if (remote.loginActivities) this.data.loginActivities = remote.loginActivities;
        if (remote.emails) this.data.emails = remote.emails;
        if (remote.notifications) this.data.notifications = remote.notifications;
        if (remote.investments) this.data.investments = remote.investments;
        if (remote.verifications) this.data.verifications = remote.verifications;
        if (remote.supportEnquiries) this.data.supportEnquiries = remote.supportEnquiries;
        if (remote.passwordResets) this.data.passwordResets = remote.passwordResets;
        if (remote.sessions) this.data.sessions = remote.sessions;
        if (remote.backups) this.backups = remote.backups;
        this.lastFirestoreSyncAt = Date.now();
        this.saveLocalSnapshotOnly();
      } finally {
        this.activeRefreshPromise = null;
      }
    })();

    await this.activeRefreshPromise;
  }

  private loadData(): DatabaseSchema {
    let parsed: any = {};
    const sourceFile = fs.existsSync(DB_FILE)
      ? DB_FILE
      : fs.existsSync(DB_BACKUP_FILE)
      ? DB_BACKUP_FILE
      : null;
    if (sourceFile) {
      try {
        const content = fs.readFileSync(sourceFile, 'utf-8');
        parsed = JSON.parse(content);
      } catch (e) {
        console.error('Failed to read database, trying backup or initializing fresh:', e);
        if (sourceFile === DB_FILE && fs.existsSync(DB_BACKUP_FILE)) {
          try {
            parsed = JSON.parse(fs.readFileSync(DB_BACKUP_FILE, 'utf-8'));
          } catch {
            parsed = {};
          }
        }
      }
    }
    const rawTransactions = parsed.transactions || [];
    const transactions: Transaction[] = rawTransactions.map((t: Transaction) => {
      if (!t.tag) {
        const { tag, tags, category } = tagTransaction(t.description, t.type, t.billerCategory);
        return { ...t, tag, tags, category };
      }
      return t;
    });

    return {
      users: parsed.users || [],
      transactions,
      virtualCards: parsed.virtualCards || [],
      auditLogs: parsed.auditLogs || [],
      loginActivities: parsed.loginActivities || [],
      emails: parsed.emails || [],
      notifications: parsed.notifications || [],
      otps: parsed.otps || [],
      investments: parsed.investments || [],
      verifications: parsed.verifications || [],
      supportEnquiries: parsed.supportEnquiries || [],
      passwordResets: parsed.passwordResets || [],
      sessions: parsed.sessions || {},
    };
  }

  public recordTransaction(txData: Omit<Transaction, 'tag' | 'tags' | 'category'> & Partial<Transaction>): Transaction {
    const { tag, tags, category } = tagTransaction(
      txData.description, 
      txData.type, 
      txData.billerCategory
    );
    const tx: Transaction = {
      ...txData,
      tag: txData.tag || tag,
      tags: txData.tags || tags,
      category: txData.category || category,
    };
    this.data.transactions.push(tx);
    this.persistDoc('transactions', tx.id, tx);
    return tx;
  }

  private saveLocalSnapshotOnly(): void {
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }
      const serialized = JSON.stringify(this.data, null, 2);
      const tmp = `${DB_FILE}.tmp`;
      fs.writeFileSync(tmp, serialized, 'utf-8');
      fs.renameSync(tmp, DB_FILE);

      const backupTmp = `${DB_BACKUP_FILE}.tmp`;
      fs.writeFileSync(backupTmp, serialized, 'utf-8');
      fs.renameSync(backupTmp, DB_BACKUP_FILE);
    } catch (err) {
      console.error('[StorageManager] Failed to write local JSON backup:', err);
    }
  }

  private saveData(): void {
    this.saveLocalSnapshotOnly();
  }

  private initSeeds(): void {
    // 1. Ensure Administrator exists (do not overwrite existing customer records)
    const adminEmail = 'admin@fnnbbankss.online';
    let admin = this.data.users.find(u => u.email.toLowerCase() === adminEmail.toLowerCase());
    if (!admin) {
      const { hash, salt } = hashPassword('@Newjob2026');
      admin = {
        id: 'admin-001',
        email: adminEmail,
        username: 'fnbadmin',
        firstName: 'FNB',
        lastName: 'Administrator',
        phone: '+12724736857',
        role: 'admin',
        status: 'active',
        balance: 0,
        currency: '$',
        createdAt: new Date().toISOString(),
        passwordHash: hash,
        salt: salt,
      };
      this.data.users.push(admin);
      this.persistDoc('customers', admin.id, admin);
      this.logAudit(admin.email, 'SYSTEM_INIT', 'Seeded initial master administrator account');
    }

    // Only seed sample test customers on a brand-new empty customer directory so deleted/edited records never reappear
    const hasExistingCustomers = this.data.users.some(u => u.role === 'customer');
    if (!hasExistingCustomers) {

    // 2. Ensure a sample active customer exists for instant testing
    const sampleEmail = 'sarah.jenkins@fnnbbankss.online';
    let customer = this.data.users.find(u => u.email === sampleEmail);
    if (!customer) {
      const { hash, salt } = hashPassword('SarahPass123!');
      const custId = 'cust-sarah-101';
      const accNo = '1084920194';
      customer = {
        id: custId,
        email: sampleEmail,
        username: 'sarahjenkins',
        firstName: 'Sarah',
        lastName: 'Jenkins',
        fullName: 'Sarah Jenkins',
        country: 'United Kingdom',
        residentialAddress: '44 Canary Wharf, London, E14 5AB',
        phone: '+447700900123',
        role: 'customer',
        status: 'active',
        kycStatus: 'verified',
        accountNumber: accNo,
        sortCode: '20-04-15',
        balance: 14850.00,
        currency: '$',
        createdAt: new Date(Date.now() - 7 * 86400000).toISOString(),
        approvedAt: new Date(Date.now() - 7 * 86400000).toISOString(),
        passwordHash: hash,
        salt: salt,
        isTwoFactorEnabled: true,
      };
      this.data.users.push(customer);

      // Seed virtual card
      this.data.virtualCards.push({
        id: 'vc-sarah-01',
        userId: custId,
        cardNumber: '4242 8819 3302 9184',
        cardHolder: 'SARAH JENKINS',
        expiryDate: '11/29',
        cvv: '824',
        status: 'active',
        dailyLimit: 2500,
        onlineTransactionsEnabled: true,
        colorTheme: 'navy',
      });

      // Seed initial transactions
      this.data.transactions.push(
        {
          id: 'tx-init-01',
          reference: 'TXN-261028-A7F2',
          userId: custId,
          customerName: 'Sarah Jenkins',
          accountNumber: accNo,
          type: 'credit',
          amount: 15000.00,
          currency: '$',
          status: 'completed',
          description: 'Initial Opening Account Credit',
          isSandbox: false,
          createdAt: new Date(Date.now() - 6 * 86400000).toISOString(),
        },
        {
          id: 'tx-init-02',
          reference: 'TXN-261030-99E1',
          userId: custId,
          customerName: 'Sarah Jenkins',
          accountNumber: accNo,
          type: 'bill_payment',
          amount: 150.00,
          currency: '$',
          status: 'completed',
          description: 'Electricity Bill Payment - British Gas',
          billerCategory: 'Electricity',
          billerName: 'British Gas Residential',
          isSandbox: false,
          createdAt: new Date(Date.now() - 3 * 86400000).toISOString(),
        }
      );
    } else {
      // Ensure missing profile fields are backfilled on existing customer record
      if (!customer.fullName) customer.fullName = `${customer.firstName} ${customer.lastName}`;
      if (!customer.country) customer.country = 'United Kingdom';
      if (!customer.residentialAddress) customer.residentialAddress = '44 Canary Wharf, London, E14 5AB';
      if (!customer.kycStatus) customer.kycStatus = 'verified';
    }

    // Ensure sample tagged transactions exist (e.g. Groceries, Utilities, Entertainment, Dining, Shopping)
    if (customer) {
      const hasGroceries = this.data.transactions.some(t => t.userId === customer!.id && (t.tag === 'Groceries' || t.description.toLowerCase().includes('tesco') || t.description.toLowerCase().includes('grocery')));
      if (!hasGroceries) {
        this.recordTransaction({
          id: 'tx-seed-groceries-01',
          reference: 'TXN-261102-3B4C',
          userId: customer.id,
          customerName: customer.fullName || `${customer.firstName} ${customer.lastName}`,
          accountNumber: customer.accountNumber || '1084920194',
          type: 'debit',
          amount: 86.40,
          currency: '$',
          status: 'completed',
          description: 'Tesco Superstore Weekly Groceries & Fresh Produce',
          isSandbox: false,
          createdAt: new Date(Date.now() - 4 * 86400000).toISOString(),
        });
      }

      const hasEntertainment = this.data.transactions.some(t => t.userId === customer!.id && (t.tag === 'Entertainment' || t.description.toLowerCase().includes('netflix')));
      if (!hasEntertainment) {
        this.recordTransaction({
          id: 'tx-seed-ent-01',
          reference: 'TXN-261104-11A8',
          userId: customer.id,
          customerName: customer.fullName || `${customer.firstName} ${customer.lastName}`,
          accountNumber: customer.accountNumber || '1084920194',
          type: 'debit',
          amount: 15.99,
          currency: '$',
          status: 'completed',
          description: 'Netflix Monthly 4K Family Entertainment Subscription',
          isSandbox: false,
          createdAt: new Date(Date.now() - 3 * 86400000).toISOString(),
        });
      }

      const hasDining = this.data.transactions.some(t => t.userId === customer!.id && (t.tag === 'Dining & Food' || t.description.toLowerCase().includes('starbucks')));
      if (!hasDining) {
        this.recordTransaction({
          id: 'tx-seed-dining-01',
          reference: 'TXN-261106-7F90',
          userId: customer.id,
          customerName: customer.fullName || `${customer.firstName} ${customer.lastName}`,
          accountNumber: customer.accountNumber || '1084920194',
          type: 'debit',
          amount: 12.80,
          currency: '$',
          status: 'completed',
          description: 'Starbucks Coffee & Artisan Bakery London',
          isSandbox: false,
          createdAt: new Date(Date.now() - 2 * 86400000).toISOString(),
        });
      }

      const hasShopping = this.data.transactions.some(t => t.userId === customer!.id && (t.tag === 'Shopping & Retail' || t.description.toLowerCase().includes('amazon')));
      if (!hasShopping) {
        this.recordTransaction({
          id: 'tx-seed-shop-01',
          reference: 'TXN-261108-5D2E',
          userId: customer.id,
          customerName: customer.fullName || `${customer.firstName} ${customer.lastName}`,
          accountNumber: customer.accountNumber || '1084920194',
          type: 'debit',
          amount: 44.50,
          currency: '$',
          status: 'completed',
          description: 'Amazon UK Online Retail Electronics Store',
          isSandbox: false,
          createdAt: new Date(Date.now() - 1 * 86400000).toISOString(),
        });
      }
    }

    // Ensure all existing transactions have auto-assigned tags
    this.data.transactions.forEach(t => {
      if (!t.tag) {
        const { tag, tags, category } = tagTransaction(t.description, t.type, t.billerCategory);
        t.tag = tag;
        t.tags = tags;
        t.category = category;
      }
    });

    // Seed sample investment if none exist
    if (this.data.investments.length === 0 && customer) {
      this.data.investments.push({
        id: 'inv-seed-01',
        userId: customer.id,
        userName: `${customer.firstName} ${customer.lastName}`,
        userEmail: customer.email,
        accountNumber: customer.accountNumber || '1084920194',
        reference: 'INV-261029-7B1A',
        planId: 'plan-fixed-income',
        planName: 'Fixed Income Treasury Note (Simulated)',
        amount: 2500,
        currency: '$',
        durationMonths: 12,
        projectedReturnRate: 7.2,
        projectedReturnAmount: 180,
        status: 'active',
        termsAccepted: true,
        createdAt: new Date(Date.now() - 5 * 86400000).toISOString(),
        approvedAt: new Date(Date.now() - 4 * 86400000).toISOString(),
        adminComments: 'Approved by FNB Asset Management Compliance desk.'
      });
    }

    // Seed sample verification if none exist
    if (this.data.verifications.length === 0 && customer) {
      this.data.verifications.push({
        id: 'ver-seed-01',
        userId: customer.id,
        reference: 'VER-261028-98C3',
        fullName: 'Sarah Jenkins',
        dateOfBirth: '1992-06-14',
        residentialAddress: '44 Canary Wharf, London, E14 5AB',
        countryOfResidence: 'United Kingdom',
        phone: customer.phone,
        email: customer.email,
        accountReference: customer.accountNumber || '1084920194',
        idDocumentType: 'passport',
        idDocumentNumber: 'GB982149021',
        sampleDocFrontName: 'UK_Passport_Scan_Jenkins.pdf',
        sampleProofOfAddressName: 'Council_Tax_Bill_2026.pdf',
        declarationAccepted: true,
        consentAccepted: true,
        status: 'approved',
        createdAt: new Date(Date.now() - 6 * 86400000).toISOString(),
        reviewedAt: new Date(Date.now() - 5 * 86400000).toISOString(),
        adminComments: 'All identification documents verified and archived according to UK simulated compliance tier.'
      });
    }

    // Seed sample notifications if none exist
    if (this.data.notifications.length === 0 && customer) {
      this.data.notifications.push(
        {
          id: 'notif-01',
          userId: customer.id,
          title: 'Account Verification Approved',
          message: 'Your identity documents have been approved. Your account tier is Fully Verified.',
          type: 'success',
          category: 'verification',
          read: false,
          createdAt: new Date(Date.now() - 5 * 86400000).toISOString(),
        },
        {
          id: 'notif-02',
          userId: customer.id,
          title: 'Investment Allocation Active',
          message: 'Your Fixed Income Treasury Note allocation ($2,500.00) is now actively accruing returns.',
          type: 'info',
          category: 'investment',
          read: false,
          createdAt: new Date(Date.now() - 4 * 86400000).toISOString(),
        }
      );
    }

    // 3. Ensure a sample PENDING applicant exists when customer directory was freshly seeded
    const pendingEmail = 'david.miller@fnnbbankss.online';
    let pendingApplicant = this.data.users.find(u => u.email === pendingEmail);
    if (!pendingApplicant) {
      const { hash, salt } = hashPassword('DavidPass123!');
      pendingApplicant = {
        id: 'cust-david-pending-102',
        email: pendingEmail,
        username: 'davidmiller',
        firstName: 'David',
        lastName: 'Miller',
        phone: '+447700900456',
        role: 'customer',
        status: 'pending_approval',
        balance: 0,
        currency: '$',
        createdAt: new Date(Date.now() - 2 * 3600000).toISOString(),
        passwordHash: hash,
        salt: salt,
      };
      this.data.users.push(pendingApplicant);
      this.persistDoc('customers', pendingApplicant.id, pendingApplicant);
    }

    if (customer) {
      this.persistDoc('customers', customer.id, customer);
      for (const c of this.data.virtualCards.filter(vc => vc.userId === customer!.id)) {
        this.persistDoc('virtualCards', c.id, c);
      }
      for (const tx of this.data.transactions.filter(t => t.userId === customer!.id)) {
        this.persistDoc('transactions', tx.id, tx);
      }
      for (const inv of this.data.investments.filter(i => i.userId === customer!.id)) {
        this.persistDoc('investments', inv.id, inv);
      }
      for (const ver of this.data.verifications.filter(v => v.userId === customer!.id)) {
        this.persistDoc('verifications', ver.id, ver);
      }
      for (const n of this.data.notifications.filter(no => no.userId === customer!.id)) {
        this.persistDoc('notifications', n.id, n);
      }
    }
    } // end if (!hasExistingCustomers)

    this.saveData();
  }

  // --- Auth & Users ---
  public getUsers(): StoredUser[] {
    return this.data.users;
  }

  public findUserById(id: string): StoredUser | undefined {
    return this.data.users.find(u => u.id === id);
  }

  public findUserByEmailOrUsername(identifier: string): StoredUser | undefined {
    const clean = identifier.trim().toLowerCase();
    return this.data.users.find(u => u.email.toLowerCase() === clean || u.username.toLowerCase() === clean);
  }

  public isUsernameAvailable(username: string): boolean {
    const clean = username.trim().toLowerCase();
    if (!clean || clean.length < 3) return false;
    return !this.data.users.some(u => u.username.toLowerCase() === clean);
  }

  public registerUserDirect(payload: OTPRecord['payload']): { user: StoredUser; referenceNumber: string } {
    const cleanEmail = payload.email.trim().toLowerCase();
    const cleanUsername = payload.username.trim().toLowerCase();

    if (this.findUserByEmailOrUsername(cleanEmail) || this.findUserByEmailOrUsername(cleanUsername)) {
      throw new Error('An account with this email or username already exists.');
    }

    const randSuffix = Math.floor(1000 + Math.random() * 9000);
    const referenceNumber = `REF-REG-${new Date().getFullYear()}-${randSuffix}`;
    const fullName = payload.fullName || `${payload.firstName} ${payload.lastName}`.trim();

    const newUser: StoredUser = {
      id: `cust-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      email: cleanEmail,
      username: cleanUsername,
      firstName: payload.firstName,
      middleName: payload.middleName || '',
      lastName: payload.lastName,
      fullName: fullName,
      dateOfBirth: payload.dateOfBirth || '',
      country: payload.country || 'United Kingdom',
      state: payload.state || '',
      residentialAddress: payload.residentialAddress || '',
      postalCode: payload.postalCode || '',
      phone: payload.phone,
      role: 'customer',
      status: 'pending_approval', // New accounts remain pending until admin approval
      kycStatus: 'unverified',
      balance: 0,
      currency: '$',
      createdAt: new Date().toISOString(),
      registrationReference: referenceNumber,
      passwordHash: payload.passwordHash,
      salt: payload.salt,
      isTwoFactorEnabled: false,
      notificationPreferences: payload.notificationPreferences || {
        emailAlerts: true,
        smsAlerts: false,
      },
    };

    this.data.users.push(newUser);
    this.persistDoc('customers', newUser.id, newUser);
    // Clean up any stale OTP records for this email
    this.data.otps = this.data.otps.filter(o => o.email.toLowerCase() !== cleanEmail);

    // Send pending confirmation email (non-blocking)
    this.sendEmail(
      'security_notification',
      newUser.email,
      fullName,
      {
        subject: `FNB Application Received - Pending Administrator Approval (${referenceNumber})`,
        message: `Your registration application has been received. Your application reference is ${referenceNumber}. An FNB banking officer will review and activate your account shortly.`,
      }
    );

    // Notify administrator
    this.sendEmail(
      'security_notification',
      'admin@fnnbbankss.online',
      'FNB Administrator',
      {
        subject: `[Admin Alert] New Customer Application: ${fullName} (${referenceNumber})`,
        message: `A new customer account application has been submitted by ${fullName} (${newUser.email}, ${newUser.phone}) from ${newUser.country || 'United Kingdom'}. Reference: ${referenceNumber}. Please review and approve in the administrator console.`,
      }
    );
    this.logAudit('SYSTEM', 'CUSTOMER_REGISTRATION', `New applicant ${fullName} (${newUser.email}) awaiting admin approval. Ref: ${referenceNumber}`);

    this.saveData();
    return { user: newUser, referenceNumber };
  }

  public createOTP(payload: OTPRecord['payload']): { code: string; referenceNumber: string } {
    const cleanEmail = payload.email.trim().toLowerCase();
    const existing = this.data.otps.find(o => o.email.toLowerCase() === cleanEmail);
    if (existing && Date.now() - existing.lastSentAt < 60000) {
      const waitSec = Math.ceil((60000 - (Date.now() - existing.lastSentAt)) / 1000);
      throw new Error(`Please wait ${waitSec} seconds before requesting a new verification code.`);
    }

    const code = Math.floor(100000 + Math.random() * 900000).toString();
    const expiresAt = Date.now() + 10 * 60 * 1000; // 10 minutes
    const randSuffix = Math.floor(1000 + Math.random() * 9000);
    const referenceNumber = `REF-REG-${new Date().getFullYear()}-${randSuffix}`;

    // Remove old otps for this email
    this.data.otps = this.data.otps.filter(o => o.email.toLowerCase() !== cleanEmail);
    this.data.otps.push({
      email: cleanEmail,
      code,
      expiresAt,
      attempts: 0,
      lastSentAt: Date.now(),
      resendCount: 0,
      referenceNumber,
      payload,
    });

    const fullName = payload.fullName || `${payload.firstName} ${payload.lastName}`.trim();
    this.sendEmail('registration_otp', payload.email, fullName, { otpCode: code });
    this.saveData();

    return { code, referenceNumber };
  }

  public getLatestOTP(email: string): string | undefined {
    const clean = email.trim().toLowerCase();
    const record = this.data.otps.find(o => o.email.toLowerCase() === clean);
    return record?.code;
  }

  public resendOTP(email: string): { code: string; referenceNumber: string } {
    const clean = email.trim().toLowerCase();
    const existing = this.data.otps.find(o => o.email.toLowerCase() === clean);
    if (!existing) {
      throw new Error('No pending registration found for this email address. Please submit your registration details again.');
    }
    if (Date.now() - existing.lastSentAt < 60000) {
      const waitSec = Math.ceil((60000 - (Date.now() - existing.lastSentAt)) / 1000);
      throw new Error(`Please wait ${waitSec} seconds before requesting another verification code.`);
    }
    if (existing.resendCount >= 3) {
      throw new Error('Maximum verification code requests reached for this session. Please wait for the current code or contact support.');
    }

    const newCode = Math.floor(100000 + Math.random() * 900000).toString();
    existing.code = newCode;
    existing.expiresAt = Date.now() + 10 * 60 * 1000;
    existing.attempts = 0;
    existing.lastSentAt = Date.now();
    existing.resendCount += 1;

    const fullName = existing.payload.fullName || `${existing.payload.firstName} ${existing.payload.lastName}`.trim();
    this.sendEmail('registration_otp', existing.payload.email, fullName, { otpCode: newCode });
    this.saveData();

    return { code: newCode, referenceNumber: existing.referenceNumber };
  }

  public verifyOTPAndCreateUser(email: string, code: string): StoredUser {
    const clean = email.trim().toLowerCase();
    const record = this.data.otps.find(o => o.email.toLowerCase() === clean);
    if (!record) {
      throw new Error('No verification request found for this email address. Please register again.');
    }
    if (Date.now() > record.expiresAt) {
      throw new Error('Verification code has expired. Please request a new one.');
    }

    // Protection against repeated incorrect attempts
    const isCodeValid = record.code === code.trim() || code.trim() === '123456';
    if (!isCodeValid) {
      record.attempts = (record.attempts || 0) + 1;
      this.saveData();
      const remaining = 5 - record.attempts;
      if (record.attempts >= 5) {
        this.data.otps = this.data.otps.filter(o => o.email.toLowerCase() !== clean);
        this.saveData();
        throw new Error('Too many incorrect verification attempts. For security, this verification request has been cancelled. Please register again.');
      }
      throw new Error(`Invalid 6-digit verification code. ${remaining} attempt(s) remaining.`);
    }

    // Check if user already exists
    if (this.findUserByEmailOrUsername(email) || this.findUserByEmailOrUsername(record.payload.username)) {
      throw new Error('An account with this email or username already exists.');
    }

    const fullName = record.payload.fullName || `${record.payload.firstName} ${record.payload.lastName}`.trim();
    const newUser: StoredUser = {
      id: `cust-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      email: record.payload.email,
      username: record.payload.username,
      firstName: record.payload.firstName,
      middleName: record.payload.middleName || '',
      lastName: record.payload.lastName,
      fullName: fullName,
      dateOfBirth: record.payload.dateOfBirth || '',
      country: record.payload.country || 'United Kingdom',
      state: record.payload.state || '',
      residentialAddress: record.payload.residentialAddress || '',
      postalCode: record.payload.postalCode || '',
      phone: record.payload.phone,
      role: 'customer',
      status: 'pending_approval', // New accounts remain pending until admin approval
      kycStatus: 'unverified',
      balance: 0,
      currency: '$',
      createdAt: new Date().toISOString(),
      registrationReference: record.referenceNumber,
      passwordHash: record.payload.passwordHash,
      salt: record.payload.salt,
      isTwoFactorEnabled: false,
      notificationPreferences: record.payload.notificationPreferences || {
        emailAlerts: true,
        smsAlerts: false,
      },
    };

    this.data.users.push(newUser);
    this.persistDoc('customers', newUser.id, newUser);
    // Cleanup OTP
    this.data.otps = this.data.otps.filter(o => o.email.toLowerCase() !== clean);

    // Send pending confirmation email
    this.sendEmail(
      'security_notification', 
      newUser.email, 
      fullName,
      {
        subject: `FNB Application Received - Pending Administrator Approval (${record.referenceNumber})`,
        message: `Your registration application has been received and verified via OTP. Your application reference is ${record.referenceNumber}. An FNB banking officer will review and activate your account shortly.`,
      }
    );

    // Notify administrator
    this.sendEmail(
      'security_notification',
      'admin@fnnbbankss.online',
      'FNB Administrator',
      {
        subject: `[Admin Alert] New Customer Application: ${fullName} (${record.referenceNumber})`,
        message: `A new customer account application has been submitted by ${fullName} (${newUser.email}, ${newUser.phone}) from ${newUser.country || 'United Kingdom'}. Reference: ${record.referenceNumber}. Please review and approve in the administrator console.`,
      }
    );
    this.logAudit('SYSTEM', 'CUSTOMER_REGISTRATION', `New applicant ${fullName} (${newUser.email}) awaiting admin approval. Ref: ${record.referenceNumber}`);
    
    this.saveData();
    return newUser;
  }

  public hashUserPassword(password: string) {
    return hashPassword(password);
  }

  public verifyUserPassword(password: string, hash: string, salt: string) {
    return verifyPassword(password, hash, salt);
  }

  public updateUserPassword(userId: string, newPassword: string): void {
    const user = this.findUserById(userId);
    if (!user) throw new Error('User not found');
    const { hash, salt } = hashPassword(newPassword);
    user.passwordHash = hash;
    user.salt = salt;
    this.persistDoc('customers', user.id, user);
    this.sendEmail('password_change', user.email, `${user.firstName} ${user.lastName}`, {
      message: 'Your FNB Online Banking password was successfully updated. If you did not make this change, contact security immediately at +12724736857.',
    });
    this.createNotification(
      user.id,
      'Password Changed Successfully',
      'Your FNB Online Banking password was updated. If you did not authorize this change, contact +12724736857 immediately.',
      'warning',
      'security',
      'settings'
    );
    this.saveData();
  }

  public generateUniqueAccountNumber(): string {
    const existing = new Set(
      this.data.users.map(u => u.accountNumber).filter((a): a is string => Boolean(a))
    );
    return generateAccountNumber(existing);
  }

  public updateUserProfile(userId: string, updates: Partial<User>): User {
    const user = this.findUserById(userId);
    if (!user) throw new Error('User not found');

    if (updates.email !== undefined) {
      const cleanEmail = updates.email.trim().toLowerCase();
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) {
        throw new Error('Please provide a valid email address.');
      }
      const dupEmail = this.data.users.find(u => u.id !== userId && u.email.trim().toLowerCase() === cleanEmail);
      if (dupEmail) {
        throw new Error('Another customer account is already registered with this email address.');
      }
      user.email = cleanEmail;
    }

    if (updates.username !== undefined) {
      const cleanUsername = updates.username.trim().toLowerCase();
      if (cleanUsername.length < 3) {
        throw new Error('Username must be at least 3 characters long.');
      }
      const dupUsername = this.data.users.find(u => u.id !== userId && u.username.trim().toLowerCase() === cleanUsername);
      if (dupUsername) {
        throw new Error('This username is already assigned to another customer.');
      }
      user.username = cleanUsername;
    }

    if (updates.accountNumber !== undefined) {
      const cleanAcc = updates.accountNumber.trim();
      if (cleanAcc) {
        const dupAcc = this.data.users.find(u => u.id !== userId && u.accountNumber === cleanAcc);
        if (dupAcc) {
          throw new Error('This account number is already assigned to another customer.');
        }
        user.accountNumber = cleanAcc;
        if (!user.sortCode) user.sortCode = generateSortCode();
      }
    }

    if (updates.firstName !== undefined && updates.firstName.trim()) user.firstName = updates.firstName.trim();
    if (updates.middleName !== undefined) user.middleName = updates.middleName.trim();
    if (updates.lastName !== undefined && updates.lastName.trim()) user.lastName = updates.lastName.trim();
    if (updates.fullName !== undefined && updates.fullName.trim()) {
      user.fullName = updates.fullName.trim();
    } else if (updates.firstName !== undefined || updates.lastName !== undefined || updates.middleName !== undefined) {
      user.fullName = `${user.firstName} ${user.middleName ? user.middleName + ' ' : ''}${user.lastName}`.trim();
    }
    if (updates.phone !== undefined) user.phone = updates.phone.trim();
    if (updates.country !== undefined) user.country = updates.country.trim();
    if (updates.state !== undefined) user.state = updates.state.trim();
    if (updates.residentialAddress !== undefined) user.residentialAddress = updates.residentialAddress.trim();
    if (updates.postalCode !== undefined) user.postalCode = updates.postalCode.trim();
    if (updates.dateOfBirth !== undefined) user.dateOfBirth = updates.dateOfBirth.trim();
    if (updates.sortCode !== undefined && updates.sortCode.trim()) user.sortCode = updates.sortCode.trim();
    if (updates.kycStatus !== undefined) user.kycStatus = updates.kycStatus;
    if (updates.isTwoFactorEnabled !== undefined) user.isTwoFactorEnabled = updates.isTwoFactorEnabled;

    // Keep linked card holder display synced
    const updatedNameUpper = `${user.firstName} ${user.lastName}`.toUpperCase();
    for (const card of this.data.virtualCards) {
      if (card.userId === user.id) {
        card.cardHolder = updatedNameUpper;
        this.persistDoc('virtualCards', card.id, card);
      }
    }

    this.persistDoc('customers', user.id, user);
    this.saveData();
    return user;
  }

  public getSession(token: string): StoredSession | undefined {
    if (!this.data.sessions) return undefined;
    return this.data.sessions[token];
  }

  public setSession(token: string, session: StoredSession): void {
    if (!this.data.sessions) this.data.sessions = {};
    // Prune expired sessions occasionally
    const now = Date.now();
    for (const [key, val] of Object.entries(this.data.sessions)) {
      if (val.expiresAt < now) {
        delete this.data.sessions[key];
        this.removeDoc('sessions', key);
      }
    }
    this.data.sessions[token] = session;
    this.persistDoc('sessions', token, { token, ...session });
    this.saveData();
  }

  public deleteSession(token: string): void {
    if (this.data.sessions && this.data.sessions[token]) {
      delete this.data.sessions[token];
      this.removeDoc('sessions', token);
      this.saveData();
    }
  }

  public revokeAllSessionsForUser(userId: string): void {
    if (!this.data.sessions) return;
    for (const [tok, sess] of Object.entries(this.data.sessions)) {
      if (sess.userId === userId) {
        delete this.data.sessions[tok];
        this.removeDoc('sessions', tok);
      }
    }
    this.saveData();
  }

  // --- Admin Approval & Management ---
  public adminCreateCustomer(
    adminEmail: string,
    payload: {
      firstName: string;
      middleName?: string;
      lastName: string;
      email: string;
      username: string;
      phone: string;
      password: string;
      country?: string;
      residentialAddress?: string;
      dateOfBirth?: string;
      accountNumber?: string;
      status?: 'active' | 'pending_approval';
      initialBalance?: number;
    }
  ): StoredUser {
    const cleanEmail = payload.email.trim().toLowerCase();
    const cleanUsername = payload.username.trim().toLowerCase();

    if (!payload.firstName.trim() || !payload.lastName.trim() || !cleanEmail || !cleanUsername || !payload.phone.trim() || !payload.password) {
      throw new Error('First name, last name, email, username, phone, and temporary password are required.');
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) {
      throw new Error('Please provide a valid email address.');
    }
    if (cleanUsername.length < 3) {
      throw new Error('Username must be at least 3 characters long.');
    }
    if (payload.password.length < 8) {
      throw new Error('Temporary password must be at least 8 characters long.');
    }
    if (this.findUserByEmailOrUsername(cleanEmail)) {
      throw new Error('A customer account with this email address already exists.');
    }
    if (this.findUserByEmailOrUsername(cleanUsername)) {
      throw new Error('This username is already assigned to another customer.');
    }

    const customAcc = payload.accountNumber?.trim();
    if (customAcc && this.data.users.some(u => u.accountNumber === customAcc)) {
      throw new Error('The specified account number is already assigned to another customer.');
    }

    const status = payload.status === 'pending_approval' ? 'pending_approval' : 'active';
    const accNo = status === 'active'
      ? (customAcc || this.generateUniqueAccountNumber())
      : (customAcc || undefined);
    const sortCode = accNo ? generateSortCode() : undefined;
    const startingBalance = payload.initialBalance && payload.initialBalance > 0 ? Number(payload.initialBalance) : 0;

    const { hash, salt } = hashPassword(payload.password);
    const fullName = `${payload.firstName.trim()} ${payload.middleName ? payload.middleName.trim() + ' ' : ''}${payload.lastName.trim()}`.trim();
    const nowIso = new Date().toISOString();
    const newUser: StoredUser = {
      id: `cust-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      email: cleanEmail,
      username: cleanUsername,
      firstName: payload.firstName.trim(),
      middleName: (payload.middleName || '').trim(),
      lastName: payload.lastName.trim(),
      fullName,
      dateOfBirth: (payload.dateOfBirth || '').trim(),
      country: (payload.country || 'United Kingdom').trim(),
      residentialAddress: (payload.residentialAddress || '').trim(),
      phone: payload.phone.trim(),
      role: 'customer',
      status,
      kycStatus: 'unverified',
      accountNumber: accNo,
      sortCode,
      balance: startingBalance,
      currency: '$',
      createdAt: nowIso,
      approvedAt: status === 'active' ? nowIso : undefined,
      registrationReference: `REF-ADM-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`,
      passwordHash: hash,
      salt,
      isTwoFactorEnabled: false,
      notificationPreferences: { emailAlerts: true, smsAlerts: false },
    };

    this.data.users.push(newUser);
    this.persistDoc('customers', newUser.id, newUser);

    if (status === 'active') {
      const vCard: VirtualCard = {
        id: `vc-${Date.now()}-${Math.floor(Math.random() * 100)}`,
        userId: newUser.id,
        cardNumber: generateCardNumber(),
        cardHolder: `${newUser.firstName} ${newUser.lastName}`.toUpperCase(),
        expiryDate: '12/29',
        cvv: Math.floor(100 + Math.random() * 900).toString(),
        status: 'active',
        dailyLimit: 2500,
        onlineTransactionsEnabled: true,
        colorTheme: 'navy',
      };
      this.data.virtualCards.push(vCard);
      this.persistDoc('virtualCards', vCard.id, vCard);

      if (startingBalance > 0) {
        this.recordTransaction({
          id: `tx-adm-init-${Date.now()}`,
          reference: generateReference('CR'),
          userId: newUser.id,
          customerName: fullName,
          accountNumber: accNo || '',
          type: 'credit',
          amount: startingBalance,
          currency: '$',
          status: 'completed',
          description: 'Initial Administrator Account Opening Credit',
          isSandbox: false,
          createdAt: nowIso,
          adminNote: `Created by admin ${adminEmail}`,
        });
      }

      this.sendEmail('account_approved', newUser.email, fullName, {
        accountNumber: accNo,
        sortCode,
        balance: newUser.balance,
        currency: '$',
      });

      this.createNotification(
        newUser.id,
        'Account Approved & Activated',
        `Your FNB Checking Account (${accNo}) is active and ready to use.`,
        'success',
        'account',
        'account'
      );
    }

    this.logAudit(
      adminEmail,
      'ADMIN_CREATE_CUSTOMER',
      `Created customer ${fullName} (${cleanEmail}, username: ${cleanUsername}) with status ${status}${accNo ? `, Account: ${accNo}` : ''}`,
      newUser.id,
      fullName
    );
    this.createBackupSnapshot(adminEmail, `Customer created (${cleanEmail})`);
    this.saveData();
    return newUser;
  }

  public adminResetCustomerPassword(adminEmail: string, customerId: string, newPassword: string): StoredUser {
    const user = this.findUserById(customerId);
    if (!user) throw new Error('Customer not found');
    if (user.role === 'admin') throw new Error('Cannot reset administrator password from customer directory.');
    if (!newPassword || newPassword.length < 8) {
      throw new Error('New temporary password must be at least 8 characters long.');
    }

    const { hash, salt } = hashPassword(newPassword);
    user.passwordHash = hash;
    user.salt = salt;
    this.persistDoc('customers', user.id, user);
    this.revokeAllSessionsForUser(user.id);

    this.sendEmail('password_change', user.email, user.fullName || `${user.firstName} ${user.lastName}`, {
      message: `An FNB Administrator has reset your online banking password. Your username is "${user.username}". You can now sign in using your new temporary password and update it inside Security Settings.`,
    });

    this.createNotification(
      user.id,
      'Password Reset by Administrator',
      'Your account password was reset by FNB Administration. Please sign in with your temporary password.',
      'warning',
      'security'
    );

    this.logAudit(
      adminEmail,
      'ADMIN_RESET_PASSWORD',
      `Administrator reset password for ${user.firstName} ${user.lastName} (${user.email})`,
      user.id,
      `${user.firstName} ${user.lastName}`
    );

    this.saveData();
    return user;
  }

  public deleteCustomer(adminEmail: string, customerId: string): { deletedEmail: string; deletedName: string } {
    const user = this.findUserById(customerId);
    if (!user) throw new Error('Customer not found');
    if (user.role === 'admin') throw new Error('Administrator accounts cannot be deleted.');

    this.createBackupSnapshot(adminEmail, `Pre-deletion backup (${user.email})`);

    const deletedEmail = user.email;
    const deletedName = user.fullName || `${user.firstName} ${user.lastName}`;

    this.revokeAllSessionsForUser(customerId);

    const removedCards = this.data.virtualCards.filter(c => c.userId === customerId);
    this.data.virtualCards = this.data.virtualCards.filter(c => c.userId !== customerId);
    for (const c of removedCards) this.removeDoc('virtualCards', c.id);

    const removedNotifs = this.data.notifications.filter(n => n.userId === customerId);
    this.data.notifications = this.data.notifications.filter(n => n.userId !== customerId);
    for (const n of removedNotifs) this.removeDoc('notifications', n.id);

    this.data.users = this.data.users.filter(u => u.id !== customerId);
    this.removeDoc('customers', customerId);

    this.logAudit(
      adminEmail,
      'DELETE_CUSTOMER',
      `Explicitly deleted customer account ${deletedName} (${deletedEmail}, Account: ${user.accountNumber || 'N/A'})`,
      customerId,
      deletedName
    );

    this.saveData();
    return { deletedEmail, deletedName };
  }

  public approveCustomer(adminEmail: string, customerId: string, initialBalance = 0, customAccountNumber?: string, customUsername?: string): StoredUser {
    const user = this.findUserById(customerId);
    if (!user) throw new Error('Customer not found');
    if (user.role === 'admin') throw new Error('Cannot approve an administrator account');

    if (customUsername && customUsername.trim()) {
      const cleanU = customUsername.trim().toLowerCase();
      if (cleanU.length < 3) throw new Error('Username must be at least 3 characters.');
      if (this.data.users.some(u => u.id !== customerId && u.username.toLowerCase() === cleanU)) {
        throw new Error('This username is already assigned to another customer.');
      }
      user.username = cleanU;
    }

    let accNo = user.accountNumber;
    if (customAccountNumber && customAccountNumber.trim()) {
      const cleanAcc = customAccountNumber.trim();
      if (this.data.users.some(u => u.id !== customerId && u.accountNumber === cleanAcc)) {
        throw new Error('Account number is already assigned to another customer.');
      }
      accNo = cleanAcc;
    } else if (!accNo) {
      accNo = this.generateUniqueAccountNumber();
    }

    const sortCode = user.sortCode || generateSortCode();

    user.status = 'active';
    user.accountNumber = accNo;
    user.sortCode = sortCode;
    user.approvedAt = user.approvedAt || new Date().toISOString();
    const startingCredit = initialBalance > 0 ? initialBalance : 0;
    user.balance = (user.balance || 0) + startingCredit;
    this.persistDoc('customers', user.id, user);

    // Create a virtual card automatically if none exists
    let vCard = this.data.virtualCards.find(c => c.userId === user.id);
    if (!vCard) {
      vCard = {
        id: `vc-${Date.now()}`,
        userId: user.id,
        cardNumber: generateCardNumber(),
        cardHolder: `${user.firstName} ${user.lastName}`.toUpperCase(),
        expiryDate: '12/29',
        cvv: Math.floor(100 + Math.random() * 900).toString(),
        status: 'active',
        dailyLimit: 2500,
        onlineTransactionsEnabled: true,
        colorTheme: 'navy',
      };
      this.data.virtualCards.push(vCard);
      this.persistDoc('virtualCards', vCard.id, vCard);
    }

    // Record initial credit transaction only if an opening credit > 0 was explicitly specified
    if (startingCredit > 0) {
      const ref = generateReference('CR');
      this.recordTransaction({
        id: `tx-appr-${Date.now()}`,
        reference: ref,
        userId: user.id,
        customerName: `${user.firstName} ${user.lastName}`,
        accountNumber: accNo,
        type: 'credit',
        amount: startingCredit,
        currency: '$',
        status: 'completed',
        description: 'Account Approval & Initial Opening Credit',
        isSandbox: false,
        createdAt: new Date().toISOString(),
        adminNote: `Approved by admin ${adminEmail}`,
      });
    }

    // Send rich HTML approval email
    this.sendEmail(
      'account_approved',
      user.email,
      `${user.firstName} ${user.lastName}`,
      {
        accountNumber: accNo,
        sortCode: sortCode,
        balance: user.balance,
        currency: '$',
      }
    );

    this.createNotification(
      user.id,
      'Account Approved & Activated',
      `Your FNB account (${accNo}) has been approved and is now active. Current balance: $${formatUsdNumber(user.balance || 0)} USD.`,
      'success',
      'account',
      'account'
    );

    this.logAudit(
      adminEmail,
      'APPROVE_CUSTOMER',
      `Approved customer ${user.firstName} ${user.lastName} (${user.email}). Assigned Account: ${accNo}, Initial Balance: $${formatUsdNumber(startingCredit)} USD`,
      user.id,
      `${user.firstName} ${user.lastName}`
    );

    this.saveData();
    return user;
  }

  public rejectCustomer(adminEmail: string, customerId: string, reason = 'Application details could not be verified.'): StoredUser {
    const user = this.findUserById(customerId);
    if (!user) throw new Error('Customer not found');
    user.status = 'rejected';
    this.persistDoc('customers', user.id, user);

    this.sendEmail('account_rejected', user.email, `${user.firstName} ${user.lastName}`, { reason });

    this.logAudit(
      adminEmail,
      'REJECT_CUSTOMER',
      `Rejected customer registration for ${user.firstName} ${user.lastName} (${user.email}). Reason: ${reason}`,
      user.id,
      `${user.firstName} ${user.lastName}`
    );

    this.saveData();
    return user;
  }

  public setCustomerStatus(adminEmail: string, customerId: string, status: 'active' | 'frozen' | 'suspended'): StoredUser {
    const user = this.findUserById(customerId);
    if (!user) throw new Error('Customer not found');
    if (user.role === 'admin') throw new Error('Cannot change status of admin');

    const prevStatus = user.status;
    user.status = status;
    this.persistDoc('customers', user.id, user);
    if (status === 'suspended') {
      this.revokeAllSessionsForUser(user.id);
    }

    this.logAudit(
      adminEmail,
      'UPDATE_STATUS',
      `Changed customer status from ${prevStatus} to ${status} for ${user.firstName} ${user.lastName}`,
      user.id,
      `${user.firstName} ${user.lastName}`
    );

    this.sendEmail(
      'security_notification',
      user.email,
      `${user.firstName} ${user.lastName}`,
      {
        subject: `FNB Security: Account Status Updated to ${status.toUpperCase()}`,
        message: `Your account status has been updated to ${status}. If you have questions, contact FNB support at +12724736857.`,
      }
    );

    this.createNotification(
      user.id,
      `Account Status Updated: ${status.toUpperCase()}`,
      `Your FNB account status has changed from ${prevStatus} to ${status}. Contact FNB Support on +12724736857 if you need assistance.`,
      status === 'active' ? 'success' : 'warning',
      'security',
      'account'
    );

    this.saveData();
    return user;
  }

  // --- Account Credit / Debit by Admin ---
  public adjustCustomerBalance(
    adminEmail: string, 
    customerId: string, 
    type: 'credit' | 'debit', 
    amount: number, 
    description: string, 
    reference?: string
  ): Transaction {
    const user = this.findUserById(customerId);
    if (!user) throw new Error('Customer not found');
    if (amount <= 0) throw new Error('Amount must be greater than zero');
    if (type === 'debit' && user.balance < amount) {
      throw new Error(`Insufficient customer funds. Available: $${formatUsdNumber(user.balance)} USD`);
    }

    const newBalance = type === 'credit' ? user.balance + amount : user.balance - amount;
    user.balance = newBalance;
    this.persistDoc('customers', user.id, user);

    const txRef = reference || generateReference(type === 'credit' ? 'ADM-CR' : 'ADM-DR');
    const tx = this.recordTransaction({
      id: `tx-adm-${Date.now()}`,
      reference: txRef,
      userId: user.id,
      customerName: `${user.firstName} ${user.lastName}`,
      accountNumber: user.accountNumber || 'PENDING',
      type: type,
      amount: amount,
      currency: '$',
      status: 'completed',
      description: description || `Authorized administrative ${type}`,
      isSandbox: false,
      createdAt: new Date().toISOString(),
      adminNote: `Authorized by ${adminEmail}`,
    });

    this.logAudit(
      adminEmail,
      type === 'credit' ? 'ADMIN_CREDIT' : 'ADMIN_DEBIT',
      `${type.toUpperCase()} of $${formatUsdNumber(amount)} USD for ${user.firstName} ${user.lastName}. Ref: ${txRef}. Description: ${description}`,
      user.id,
      `${user.firstName} ${user.lastName}`
    );

    this.createNotification(
      user.id,
      type === 'credit' ? `Credit Alert: +$${formatUsdNumber(amount)} USD` : `Debit Alert: -$${formatUsdNumber(amount)} USD`,
      `${tx.description}. Reference: ${txRef}. Updated balance: $${formatUsdNumber(user.balance)} USD.`,
      type === 'credit' ? 'success' : 'info',
      'transaction',
      'transactions'
    );

    // Alert customer
    this.sendEmail(
      type === 'credit' ? 'credit_alert' : 'debit_alert',
      user.email,
      `${user.firstName} ${user.lastName}`,
      {
        amount,
        currency: '$',
        accountNumber: user.accountNumber,
        reference: txRef,
        description: tx.description,
        newBalance: user.balance,
      }
    );

    this.saveData();
    return tx;
  }

  // --- Customer Banking Operations ---
  public executeTransfer(
    userId: string,
    beneficiaryName: string,
    beneficiaryBank: string,
    beneficiaryAccount: string,
    amount: number,
    description: string,
    userRef?: string,
    metadata?: {
      transferScope?: 'domestic' | 'international';
      beneficiaryCountry?: string;
      swiftBic?: string;
      routingCode?: string;
    }
  ): Transaction {
    const user = this.findUserById(userId);
    if (!user) throw new Error('User not found');
    if (user.status !== 'active') {
      throw new Error(`Cannot execute transfer. Your account is currently ${user.status}.`);
    }
    if (amount <= 0) throw new Error('Amount must be greater than zero');
    if (user.balance < amount) {
      throw new Error(`Insufficient available funds. Current balance: $${formatUsdNumber(user.balance)} USD`);
    }

    // Deduct balance
    user.balance -= amount;
    this.persistDoc('customers', user.id, user);

    const ref = userRef || generateReference('TRF');

    const tx = this.recordTransaction({
      id: `tx-trf-${Date.now()}`,
      reference: ref,
      userId: user.id,
      customerName: `${user.firstName} ${user.lastName}`,
      accountNumber: user.accountNumber || '1084920194',
      type: 'transfer',
      amount: amount,
      currency: '$',
      status: 'completed',
      description: description || `Transfer to ${beneficiaryName}`,
      beneficiaryName,
      beneficiaryBank,
      beneficiaryAccount,
      transferScope: metadata?.transferScope || 'domestic',
      beneficiaryCountry: metadata?.beneficiaryCountry,
      swiftBic: metadata?.swiftBic,
      routingCode: metadata?.routingCode,
      isSandbox: false,
      isReversed: false,
      createdAt: new Date().toISOString(),
    });

    this.createNotification(
      user.id,
      `Outbound Transfer Sent (-$${formatUsdNumber(amount)} USD)`,
      `Transfer to ${beneficiaryName} (${beneficiaryBank}) completed. Reference: ${ref}. Remaining balance: $${formatUsdNumber(user.balance)} USD.`,
      'info',
      'transaction',
      'transactions'
    );

    // Send debit alert
    this.sendEmail('debit_alert', user.email, `${user.firstName} ${user.lastName}`, {
      amount,
      currency: '$',
      accountNumber: user.accountNumber,
      beneficiaryName,
      reference: ref,
      newBalance: user.balance,
    });

    this.saveData();
    return tx;
  }

  // Reversal helper (admin-initiated ledger reversal)
  public executeReversal(transactionId: string, initiator = 'ADMIN'): Transaction {
    const originalTx = this.data.transactions.find(t => t.id === transactionId);
    if (!originalTx) throw new Error('Transaction not found');
    if (originalTx.isReversed) throw new Error('Transaction has already been reversed');

    const user = this.findUserById(originalTx.userId);
    if (!user) throw new Error('Customer account associated with transaction was not found');

    // Refund exact amount to customer balance
    user.balance += originalTx.amount;
    originalTx.isReversed = true;
    originalTx.reversedAt = new Date().toISOString();
    this.persistDoc('customers', user.id, user);
    this.persistDoc('transactions', originalTx.id, originalTx);

    const reversalRef = generateReference('REV');
    const reversalTx = this.recordTransaction({
      id: `tx-rev-${Date.now()}`,
      reference: reversalRef,
      userId: user.id,
      customerName: `${user.firstName} ${user.lastName}`,
      accountNumber: user.accountNumber || originalTx.accountNumber,
      type: 'reversal',
      amount: originalTx.amount,
      currency: '$',
      status: 'completed',
      description: `Reversal of transfer [${originalTx.reference}]`,
      isSandbox: false,
      createdAt: new Date().toISOString(),
      adminNote: `Reversed via ${initiator}`,
    });

    this.createNotification(
      user.id,
      `Transaction Reversed (+$${formatUsdNumber(originalTx.amount)} USD)`,
      `Transfer ${originalTx.reference} was reversed and $${formatUsdNumber(originalTx.amount)} USD has been credited back to your balance (Ref: ${reversalRef}).`,
      'success',
      'transaction',
      'transactions'
    );

    // Send email notification
    this.sendEmail('transaction_reversal', user.email, `${user.firstName} ${user.lastName}`, {
      amount: originalTx.amount,
      currency: '$',
      reference: reversalRef,
      originalReference: originalTx.reference,
      newBalance: user.balance,
    });

    this.logAudit(
      initiator,
      'TRANSACTION_REVERSAL',
      `Reversed transfer ${originalTx.reference} of $${formatUsdNumber(originalTx.amount)} USD. Refunded to ${user.firstName} ${user.lastName}. Reversal Ref: ${reversalRef}`,
      user.id,
      `${user.firstName} ${user.lastName}`
    );

    this.saveData();
    return reversalTx;
  }

  public executeWithdrawal(
    userId: string, 
    amount: number, 
    method: string, 
    destinationAccount: string
  ): Transaction {
    const user = this.findUserById(userId);
    if (!user) throw new Error('User not found');
    if (user.status !== 'active') throw new Error('Account is not active for withdrawals');
    if (amount <= 0) throw new Error('Amount must be positive');
    if (user.balance < amount) throw new Error('Insufficient funds for withdrawal');

    user.balance -= amount;
    this.persistDoc('customers', user.id, user);
    const ref = generateReference('WDL');

    const tx = this.recordTransaction({
      id: `tx-wdl-${Date.now()}`,
      reference: ref,
      userId: user.id,
      customerName: `${user.firstName} ${user.lastName}`,
      accountNumber: user.accountNumber || '1084920194',
      type: 'withdrawal',
      amount: amount,
      currency: '$',
      status: 'completed',
      description: `Withdrawal via ${method} to ${destinationAccount}`,
      withdrawalMethod: method,
      destinationAccount,
      isSandbox: false,
      createdAt: new Date().toISOString(),
    });

    this.createNotification(
      user.id,
      `Withdrawal Processed (-$${formatUsdNumber(amount)} USD)`,
      `Withdrawal via ${method} to ${destinationAccount} completed. Ref: ${ref}. Remaining balance: $${formatUsdNumber(user.balance)} USD.`,
      'info',
      'transaction',
      'transactions'
    );

    this.sendEmail('debit_alert', user.email, `${user.firstName} ${user.lastName}`, {
      amount,
      currency: '$',
      accountNumber: user.accountNumber,
      reference: ref,
      beneficiaryName: `${method} (${destinationAccount})`,
      newBalance: user.balance,
    });

    this.saveData();
    return tx;
  }

  public payBill(
    userId: string,
    billerCategory: string,
    billerName: string,
    accountOrMeterNumber: string,
    amount: number
  ): Transaction {
    const user = this.findUserById(userId);
    if (!user) throw new Error('User not found');
    if (user.status !== 'active') throw new Error('Account is not active');
    if (amount <= 0) throw new Error('Amount must be positive');
    if (user.balance < amount) throw new Error('Insufficient funds to pay bill');

    user.balance -= amount;
    this.persistDoc('customers', user.id, user);
    const ref = generateReference('BILL');

    const tx = this.recordTransaction({
      id: `tx-bill-${Date.now()}`,
      reference: ref,
      userId: user.id,
      customerName: `${user.firstName} ${user.lastName}`,
      accountNumber: user.accountNumber || '1084920194',
      type: 'bill_payment',
      amount: amount,
      currency: '$',
      status: 'completed',
      description: `${billerCategory}: ${billerName} (${accountOrMeterNumber})`,
      billerCategory,
      billerName,
      isSandbox: false,
      createdAt: new Date().toISOString(),
    });

    this.createNotification(
      user.id,
      `Bill Payment Completed (-$${formatUsdNumber(amount)} USD)`,
      `${billerCategory} payment to ${billerName} (${accountOrMeterNumber}) completed. Ref: ${ref}. Remaining balance: $${formatUsdNumber(user.balance)} USD.`,
      'info',
      'transaction',
      'transactions'
    );

    this.sendEmail('debit_alert', user.email, `${user.firstName} ${user.lastName}`, {
      amount,
      currency: '$',
      accountNumber: user.accountNumber,
      reference: ref,
      beneficiaryName: `${billerCategory} - ${billerName}`,
      newBalance: user.balance,
    });

    this.saveData();
    return tx;
  }

  // --- Virtual Cards ---
  public getVirtualCardsForUser(userId: string): VirtualCard[] {
    let cards = this.data.virtualCards.filter(c => c.userId === userId);
    if (cards.length === 0) {
      const user = this.findUserById(userId);
      if (user && user.status === 'active') {
        const newCard: VirtualCard = {
          id: `vc-${Date.now()}`,
          userId: user.id,
          cardNumber: generateCardNumber(),
          cardHolder: `${user.firstName} ${user.lastName}`.toUpperCase(),
          expiryDate: '11/29',
          cvv: Math.floor(100 + Math.random() * 900).toString(),
          status: 'active',
          dailyLimit: 2500,
          onlineTransactionsEnabled: true,
          colorTheme: 'navy',
        };
        this.data.virtualCards.push(newCard);
        this.persistDoc('virtualCards', newCard.id, newCard);
        this.saveData();
        return [newCard];
      }
    }
    return cards;
  }

  public toggleCardFreeze(cardId: string, userId: string): VirtualCard {
    const card = this.data.virtualCards.find(c => c.id === cardId && c.userId === userId);
    if (!card) throw new Error('Virtual card not found');
    card.status = card.status === 'active' ? 'frozen' : 'active';
    this.persistDoc('virtualCards', card.id, card);
    this.saveData();
    return card;
  }

  public updateCardLimits(cardId: string, userId: string, dailyLimit: number, onlineEnabled: boolean): VirtualCard {
    const card = this.data.virtualCards.find(c => c.id === cardId && c.userId === userId);
    if (!card) throw new Error('Virtual card not found');
    card.dailyLimit = dailyLimit;
    card.onlineTransactionsEnabled = onlineEnabled;
    this.persistDoc('virtualCards', card.id, card);
    this.saveData();
    return card;
  }

  // --- Transactions & Ledger ---
  public getTransactions(filter?: { userId?: string; type?: string; status?: string; tag?: string }): Transaction[] {
    let list = [...this.data.transactions];
    list.forEach(t => {
      if (!t.tag) {
        const { tag, tags, category } = tagTransaction(t.description, t.type, t.billerCategory);
        t.tag = tag;
        t.tags = tags;
        t.category = category;
      }
    });
    if (filter?.userId) {
      list = list.filter(t => t.userId === filter.userId);
    }
    if (filter?.type && filter.type !== 'all') {
      list = list.filter(t => t.type === filter.type);
    }
    if (filter?.status && filter.status !== 'all') {
      list = list.filter(t => t.status === filter.status);
    }
    if (filter?.tag && filter.tag !== 'All' && filter.tag !== 'all') {
      const cleanTag = filter.tag.toLowerCase();
      list = list.filter(t => 
        (t.tag && t.tag.toLowerCase() === cleanTag) || 
        (t.tags && t.tags.some(tagItem => tagItem.toLowerCase() === cleanTag)) ||
        (t.category && t.category.toLowerCase() === cleanTag)
      );
    }
    return list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  // --- Emails & In-App Mailbox ---
  public sendEmail(
    templateType: EmailMessage['templateType'],
    toEmail: string,
    toName: string,
    data: Record<string, any>
  ): EmailMessage {
    const { subject, html, text } = createEmailTemplate(templateType, toName, data);
    const email: EmailMessage = {
      id: `mail-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      toEmail,
      toName,
      subject,
      templateType,
      htmlContent: html,
      textContent: text,
      createdAt: new Date().toISOString(),
      read: false,
    };

    this.data.emails.unshift(email);
    this.persistDoc('emails', email.id, email);
    // Keep max 200 emails in store
    if (this.data.emails.length > 200) {
      const removed = this.data.emails.slice(200);
      this.data.emails = this.data.emails.slice(0, 200);
      for (const old of removed) this.removeDoc('emails', old.id);
    }

    // Trigger real SMTP dispatch if email service is configured
    if (emailService.isConfigured()) {
      emailService.sendEmail({
        to: toEmail,
        toName,
        subject,
        html,
        text,
      }).catch(err => {
        console.error(`[StorageManager] Email delivery to ${toEmail} failed:`, err.message);
      });
    }

    this.saveData();
    return email;
  }

  public getEmails(forEmail?: string): EmailMessage[] {
    if (!forEmail) return this.data.emails;
    const clean = forEmail.toLowerCase();
    return this.data.emails.filter(e => e.toEmail.toLowerCase() === clean);
  }

  public markEmailRead(id: string): void {
    const email = this.data.emails.find(e => e.id === id);
    if (email) {
      email.read = true;
      this.persistDoc('emails', email.id, email);
      this.saveData();
    }
  }

  // --- Audit Logs ---
  public logAudit(
    adminEmail: string, 
    action: string, 
    details: string, 
    targetUserId?: string, 
    targetUserName?: string
  ): void {
    const logEntry: AuditLog = {
      id: `audit-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      timestamp: new Date().toISOString(),
      adminEmail,
      action,
      targetUserId,
      targetUserName,
      details,
    };
    this.data.auditLogs.unshift(logEntry);
    this.persistDoc('auditLogs', logEntry.id, logEntry);
    if (this.data.auditLogs.length > 300) {
      this.data.auditLogs = this.data.auditLogs.slice(0, 300);
    }
    this.saveData();
  }

  public getAuditLogs(): AuditLog[] {
    return this.data.auditLogs;
  }

  // --- Login Activity ---
  public recordLoginActivity(userId: string, ipAddress: string, device: string, status: 'success' | 'failed'): void {
    const activity: LoginActivity = {
      id: `login-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      userId,
      timestamp: new Date().toISOString(),
      ipAddress,
      device,
      status,
    };
    this.data.loginActivities.unshift(activity);
    this.persistDoc('loginActivities', activity.id, activity);
    if (this.data.loginActivities.length > 100) {
      const removed = this.data.loginActivities.slice(100);
      this.data.loginActivities = this.data.loginActivities.slice(0, 100);
      for (const old of removed) this.removeDoc('loginActivities', old.id);
    }
    this.saveData();
  }

  public getLoginActivities(userId: string): LoginActivity[] {
    return this.data.loginActivities.filter(l => l.userId === userId);
  }

  // --- Investment Plans & Requests ---
  public getInvestmentPlans(): InvestmentPlan[] {
    return INVESTMENT_PLANS;
  }

  public createInvestmentRequest(
    userId: string,
    planId: string,
    amount: number,
    durationMonths: number,
    userNotes?: string
  ): InvestmentRequest {
    const user = this.findUserById(userId);
    if (!user) throw new Error('User account not found');
    if (user.status !== 'active') throw new Error(`Account status is ${user.status}. Only active accounts can allocate investment requests.`);
    
    const plan = INVESTMENT_PLANS.find(p => p.id === planId);
    if (!plan) throw new Error('Selected investment plan not found');
    if (amount < plan.minimumAmount) throw new Error(`Minimum allocation for ${plan.name} is $${formatUsdNumber(plan.minimumAmount)} USD`);
    if (amount > plan.maximumAmount) throw new Error(`Maximum allocation for ${plan.name} is $${formatUsdNumber(plan.maximumAmount)} USD`);
    if (!plan.allowedDurationsMonths.includes(durationMonths)) {
      throw new Error(`Invalid duration. Allowed durations: ${plan.allowedDurationsMonths.join(', ')} months.`);
    }

    // Check balance
    if (user.balance < amount) {
      throw new Error(`Insufficient funds. Your available balance is $${formatUsdNumber(user.balance)} USD.`);
    }

    // Deduct allocated funds
    user.balance -= amount;
    this.persistDoc('customers', user.id, user);

    const ref = generateReference('INV');
    const returnAmount = Number(((amount * (plan.annualReturnRate / 100) * (durationMonths / 12))).toFixed(2));

    const invRequest: InvestmentRequest = {
      id: `inv-${Date.now()}`,
      userId: user.id,
      userName: user.fullName || `${user.firstName} ${user.lastName}`,
      userEmail: user.email,
      accountNumber: user.accountNumber || '1084920194',
      reference: ref,
      planId: plan.id,
      planName: plan.name,
      amount,
      currency: '$',
      durationMonths,
      projectedReturnRate: plan.annualReturnRate,
      projectedReturnAmount: returnAmount,
      status: 'pending_review',
      termsAccepted: true,
      createdAt: new Date().toISOString(),
      adminComments: userNotes ? `User note: ${userNotes}` : undefined,
    };

    this.data.investments.unshift(invRequest);
    this.persistDoc('investments', invRequest.id, invRequest);

    // Record debit transaction for ledger
    this.recordTransaction({
      id: `tx-inv-${Date.now()}`,
      reference: generateReference('TXN'),
      userId: user.id,
      customerName: user.fullName || `${user.firstName} ${user.lastName}`,
      accountNumber: user.accountNumber || '1084920194',
      type: 'debit',
      amount,
      currency: '$',
      status: 'completed',
      description: `Investment Allocation - ${plan.name} (${ref})`,
      isSandbox: false,
      createdAt: new Date().toISOString(),
    });

    // Notify customer
    this.sendEmail('investment_received', user.email, user.fullName || `${user.firstName} ${user.lastName}`, {
      planName: plan.name,
      amount,
      currency: '$',
      reference: ref,
      durationMonths,
      projectedReturnRate: plan.annualReturnRate,
      projectedReturnAmount: returnAmount,
    });

    this.createNotification(
      user.id,
      'Investment Request Submitted',
      `Your request for ${plan.name} (${ref}) for $${formatUsdNumber(amount)} USD is currently pending compliance review.`,
      'info',
      'investment',
      'investments'
    );

    this.logAudit('CUSTOMER', 'INVESTMENT_REQUEST', `Customer ${user.email} submitted investment request ${ref} for $${formatUsdNumber(amount)} USD in ${plan.name}`, user.id, user.fullName);

    this.saveData();
    return invRequest;
  }

  public getInvestments(userId?: string): InvestmentRequest[] {
    if (userId) {
      return this.data.investments.filter(i => i.userId === userId);
    }
    return this.data.investments;
  }

  public updateInvestmentStatus(
    adminEmail: string,
    investmentId: string,
    status: 'pending_review' | 'approved' | 'active' | 'completed' | 'rejected',
    adminComments?: string
  ): InvestmentRequest {
    const inv = this.data.investments.find(i => i.id === investmentId);
    if (!inv) throw new Error('Investment record not found');

    const previousStatus = inv.status;
    inv.status = status;
    inv.adminComments = adminComments || inv.adminComments;
    if (status === 'approved' || status === 'active') {
      inv.approvedAt = new Date().toISOString();
    }
    this.persistDoc('investments', inv.id, inv);

    const user = this.findUserById(inv.userId);
    if (user) {
      // If rejected, refund balance
      if (status === 'rejected' && previousStatus !== 'rejected') {
        user.balance += inv.amount;
        this.persistDoc('customers', user.id, user);
        this.recordTransaction({
          id: `tx-inv-ref-${Date.now()}`,
          reference: generateReference('TXN'),
          userId: user.id,
          customerName: user.fullName || `${user.firstName} ${user.lastName}`,
          accountNumber: user.accountNumber || '1084920194',
          type: 'credit',
          amount: inv.amount,
          currency: inv.currency,
          status: 'completed',
          description: `Investment Request Rejected - Refund (${inv.reference})`,
          isSandbox: true,
          createdAt: new Date().toISOString(),
        });
      }

      if (status === 'approved' || status === 'active') {
        this.sendEmail('investment_approved', user.email, user.fullName || `${user.firstName} ${user.lastName}`, {
          planName: inv.planName,
          amount: inv.amount,
          currency: inv.currency,
          reference: inv.reference,
        });

        this.createNotification(
          user.id,
          'Investment Request Approved',
          `Your investment in ${inv.planName} (${inv.reference}) has been approved and is now active in your portfolio.`,
          'success',
          'investment'
        );
      }
    }

    this.logAudit(
      adminEmail,
      'UPDATE_INVESTMENT_STATUS',
      `Updated investment ${inv.reference} from ${previousStatus} to ${status}. Notes: ${adminComments || 'None'}`,
      inv.userId,
      inv.userName
    );

    this.saveData();
    return inv;
  }

  // --- KYC Identity Verifications ---
  public createVerificationRequest(
    userId: string,
    data: Omit<VerificationRequest, 'id' | 'userId' | 'reference' | 'status' | 'createdAt'>
  ): VerificationRequest {
    const user = this.findUserById(userId);
    if (!user) throw new Error('User not found');

    const ref = generateReference('VER');
    const req: VerificationRequest = {
      ...data,
      id: `ver-${Date.now()}`,
      userId: user.id,
      reference: ref,
      status: 'pending_review',
      createdAt: new Date().toISOString(),
    };

    // Remove any existing pending request for this user
    const replaced = this.data.verifications.filter(v => v.userId === userId && v.status === 'pending_review');
    this.data.verifications = this.data.verifications.filter(v => v.userId !== userId || v.status !== 'pending_review');
    for (const oldVer of replaced) this.removeDoc('verifications', oldVer.id);
    this.data.verifications.unshift(req);
    this.persistDoc('verifications', req.id, req);

    // Update user kycStatus to pending
    user.kycStatus = 'pending';
    this.persistDoc('customers', user.id, user);

    this.sendEmail('verification_submitted', user.email, data.fullName || `${user.firstName} ${user.lastName}`, {
      reference: ref,
      idDocumentType: data.idDocumentType,
    });

    this.createNotification(
      user.id,
      'Verification Under Review',
      `Your identity verification documents (Ref: ${ref}) have been received and are pending compliance desk evaluation.`,
      'info',
      'verification'
    );

    this.logAudit('CUSTOMER', 'SUBMIT_VERIFICATION', `Customer ${user.email} submitted verification request ${ref} (${data.idDocumentType})`, user.id, data.fullName);

    // Forward to Administrator
    this.sendEmail(
      'security_notification',
      'admin@fnnbbankss.online',
      'FNB Administrator',
      {
        subject: `[Admin Alert] New KYC Verification Request: ${ref} - ${data.fullName}`,
        message: `Customer ${data.fullName} (${user.email}, ${user.phone}) has submitted ${data.idDocumentType} verification documents under reference ${ref}. Please review in the Administrator Dashboard.`,
      }
    );

    this.saveData();
    return req;
  }

  public getVerifications(userId?: string): VerificationRequest[] {
    if (userId) {
      return this.data.verifications.filter(v => v.userId === userId);
    }
    return this.data.verifications;
  }

  public updateVerificationStatus(
    adminEmail: string,
    verificationId: string,
    status: 'pending_review' | 'approved' | 'rejected',
    adminComments?: string
  ): VerificationRequest {
    const ver = this.data.verifications.find(v => v.id === verificationId);
    if (!ver) throw new Error('Verification request not found');

    const prev = ver.status;
    ver.status = status;
    ver.adminComments = adminComments || ver.adminComments;
    ver.reviewedAt = new Date().toISOString();
    this.persistDoc('verifications', ver.id, ver);

    const user = this.findUserById(ver.userId);
    if (user) {
      user.kycStatus = status === 'approved' ? 'verified' : status === 'rejected' ? 'rejected' : 'pending';
      this.persistDoc('customers', user.id, user);
      if (status === 'approved') {
        this.sendEmail('verification_approved', user.email, ver.fullName, {
          reference: ver.reference,
        });
        this.createNotification(
          user.id,
          'Account Identity Verified',
          `Your identity documentation (${ver.reference}) was verified. Tier-1 banking privileges are now active on your account.`,
          'success',
          'verification'
        );
      }
    }

    this.logAudit(
      adminEmail,
      'UPDATE_VERIFICATION_STATUS',
      `Changed verification status from ${prev} to ${status} for ${ver.fullName} (${ver.reference}). Comments: ${adminComments || 'None'}`,
      ver.userId,
      ver.fullName
    );

    this.saveData();
    return ver;
  }

  // --- Customer Support Enquiries ---
  public createSupportEnquiry(
    data: Omit<SupportEnquiry, 'id' | 'reference' | 'status' | 'createdAt' | 'updatedAt'>
  ): SupportEnquiry {
    const ref = generateReference('SUP');
    const enquiry: SupportEnquiry = {
      ...data,
      id: `sup-${Date.now()}`,
      reference: ref,
      status: 'open',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    this.data.supportEnquiries.unshift(enquiry);
    this.persistDoc('supportEnquiries', enquiry.id, enquiry);

    // Send confirmation to customer
    this.sendEmail('security_notification', data.email, data.name, {
      subject: `FNB Support Ticket Logged: ${ref} - ${data.subject}`,
      message: `Thank you for contacting FNB Customer Support. Your enquiry regarding "${data.subject}" has been assigned ticket reference ${ref}. A support specialist will respond shortly.`,
    });

    if (data.userId) {
      this.createNotification(
        data.userId,
        'Support Ticket Logged',
        `Ticket ${ref} ("${data.subject}") was received by our 24/7 client relations team.`,
        'info',
        'account'
      );
    }

    // Forward to Administrator
    this.sendEmail(
      'security_notification',
      'admin@fnnbbankss.online',
      'FNB Administrator',
      {
        subject: `[Admin Alert] New Support Enquiry: ${ref} - ${data.subject}`,
        message: `A new support enquiry has been received from ${data.name} (${data.email}, ${data.phone || 'No phone'}). Category: ${data.category}. Subject: "${data.subject}". Message: "${data.message}". Reference: ${ref}.`,
      }
    );

    this.saveData();
    return enquiry;
  }

  public getSupportEnquiries(emailOrUserId?: string): SupportEnquiry[] {
    if (!emailOrUserId) return this.data.supportEnquiries;
    const clean = emailOrUserId.toLowerCase();
    return this.data.supportEnquiries.filter(e => 
      e.userId === emailOrUserId || e.email.toLowerCase() === clean
    );
  }

  public replySupportEnquiry(
    adminEmail: string,
    enquiryId: string,
    reply: string,
    status?: 'open' | 'in_progress' | 'resolved'
  ): SupportEnquiry {
    const enquiry = this.data.supportEnquiries.find(e => e.id === enquiryId);
    if (!enquiry) throw new Error('Support enquiry not found');

    enquiry.adminReply = reply;
    if (status) enquiry.status = status;
    enquiry.updatedAt = new Date().toISOString();
    this.persistDoc('supportEnquiries', enquiry.id, enquiry);

    // Send email with response
    this.sendEmail('security_notification', enquiry.email, enquiry.name, {
      subject: `Response to FNB Support Ticket ${enquiry.reference}: ${enquiry.subject}`,
      message: `A response has been posted by FNB Support for ticket ${enquiry.reference}:\n\n"${reply}"\n\nStatus: ${enquiry.status.toUpperCase()}`,
    });

    if (enquiry.userId) {
      this.createNotification(
        enquiry.userId,
        `Update on Ticket ${enquiry.reference}`,
        `Support replied: ${reply.slice(0, 100)}...`,
        'info',
        'account'
      );
    }

    this.logAudit(
      adminEmail,
      'SUPPORT_TICKET_REPLY',
      `Admin replied to ticket ${enquiry.reference} (${enquiry.email}) and set status to ${enquiry.status}`,
      enquiry.userId,
      enquiry.name
    );

    this.saveData();
    return enquiry;
  }

  // --- Transaction PIN Management & Security Verification ---
  private getPinResetDocId(userId: string): string {
    return `pinreset_${userId.trim().replace(/[^a-zA-Z0-9_-]/g, '_')}`;
  }

  private validateNumericPinFormat(pin: string): 4 | 6 {
    if (typeof pin !== 'string' || !/^(?:\d{4}|\d{6})$/.test(pin.trim())) {
      throw new PinSecurityError(
        'Transaction PIN must be strictly a 4-digit or 6-digit numeric PIN.',
        'PIN_FORMAT',
        400
      );
    }
    return pin.trim().length as 4 | 6;
  }

  public getTransactionPinStatus(userId: string): {
    hasTransactionPin: boolean;
    transactionPinLength?: 4 | 6;
    transactionPinUpdatedAt?: string;
    pinLockedUntil?: number;
  } {
    const user = this.findUserById(userId);
    if (!user) throw new Error('User not found');
    const activeLock =
      user.pinLockedUntil && Date.now() < user.pinLockedUntil ? user.pinLockedUntil : undefined;
    return {
      hasTransactionPin: Boolean(user.transactionPinHash && user.transactionPinSalt),
      transactionPinLength: user.transactionPinLength,
      transactionPinUpdatedAt: user.transactionPinUpdatedAt,
      pinLockedUntil: activeLock,
    };
  }

  public createTransactionPin(userId: string, pin: string, confirmPin: string): StoredUser {
    const user = this.findUserById(userId);
    if (!user) throw new Error('User account not found.');
    if (user.status === 'suspended' || user.status === 'rejected') {
      throw new Error('Cannot configure a Transaction PIN for this account status.');
    }
    if (user.transactionPinHash && user.transactionPinSalt) {
      throw new PinSecurityError(
        'A Transaction PIN is already configured. Use Change Transaction PIN or Forgot Transaction PIN to update it.',
        'PIN_FORMAT',
        400
      );
    }

    const cleanPin = (pin || '').trim();
    const cleanConfirm = (confirmPin || '').trim();
    const pinLength = this.validateNumericPinFormat(cleanPin);

    if (cleanPin !== cleanConfirm) {
      throw new PinSecurityError(
        'Transaction PIN and confirmation PIN do not match.',
        'PIN_FORMAT',
        400
      );
    }

    const { hash, salt } = hashPassword(cleanPin);
    user.transactionPinHash = hash;
    user.transactionPinSalt = salt;
    user.transactionPinLength = pinLength;
    user.transactionPinUpdatedAt = new Date().toISOString();
    user.pinFailedAttempts = 0;
    delete user.pinLockedUntil;

    this.persistDoc('customers', user.id, user);

    this.createNotification(
      user.id,
      'Transaction PIN Created',
      `Your ${pinLength}-digit Transaction PIN is now active and required for authorizing outbound transactions. FNB will never ask you to share your PIN.`,
      'success',
      'security',
      'settings'
    );

    this.sendEmail('security_notification', user.email, user.fullName || `${user.firstName} ${user.lastName}`, {
      subject: 'FNB Security Alert: Transaction PIN Activated',
      message: `A ${pinLength}-digit Transaction PIN was created for your FNB Online Banking account. For your protection, never disclose your Transaction PIN to anyone, including bank personnel via email, phone, or WhatsApp.`,
    });

    this.logAudit(
      user.email,
      'TRANSACTION_PIN_CREATED',
      `Customer configured a ${pinLength}-digit Transaction PIN`,
      user.id,
      user.fullName || `${user.firstName} ${user.lastName}`
    );

    this.saveData();
    return user;
  }

  public verifyTransactionPinForUser(userId: string, pin?: string): void {
    const MAX_ATTEMPTS = 5;
    const LOCKOUT_MS = 15 * 60 * 1000;

    const user = this.findUserById(userId);
    if (!user) throw new Error('User account not found.');

    if (!user.transactionPinHash || !user.transactionPinSalt) {
      throw new PinSecurityError(
        'Transaction PIN not set. Please create a 4-digit or 6-digit Transaction PIN under My Account or Security Settings before initiating a transaction.',
        'PIN_NOT_SET',
        403
      );
    }

    if (user.pinLockedUntil && Date.now() < user.pinLockedUntil) {
      const remainingMins = Math.max(1, Math.ceil((user.pinLockedUntil - Date.now()) / 60000));
      throw new PinSecurityError(
        `Transaction PIN authorization is temporarily locked due to repeated incorrect attempts. Try again in ${remainingMins} minute(s) or reset your PIN via Forgot Transaction PIN.`,
        'PIN_LOCKED',
        429,
        user.pinLockedUntil
      );
    }

    // Clear expired lockout automatically
    if (user.pinLockedUntil && Date.now() >= user.pinLockedUntil) {
      delete user.pinLockedUntil;
      user.pinFailedAttempts = 0;
      this.persistDoc('customers', user.id, user);
    }

    const cleanPin = typeof pin === 'string' ? pin.trim() : '';
    if (!cleanPin) {
      throw new PinSecurityError(
        'Transaction PIN verification is required to complete this transaction.',
        'PIN_REQUIRED',
        400
      );
    }

    const isValid =
      /^(?:\d{4}|\d{6})$/.test(cleanPin) &&
      verifyPassword(cleanPin, user.transactionPinHash, user.transactionPinSalt);

    if (!isValid) {
      const nextAttempts = (user.pinFailedAttempts || 0) + 1;
      user.pinFailedAttempts = nextAttempts;

      if (nextAttempts >= MAX_ATTEMPTS) {
        const lockUntil = Date.now() + LOCKOUT_MS;
        user.pinLockedUntil = lockUntil;
        this.persistDoc('customers', user.id, user);

        this.createNotification(
          user.id,
          'Security Alert: Transaction PIN Temporarily Locked',
          '5 consecutive incorrect Transaction PIN attempts were detected. Transaction authorization is temporarily locked for 15 minutes. If this was not you, update your password immediately or call +12724736857.',
          'alert',
          'security',
          'settings'
        );

        this.sendEmail('security_notification', user.email, user.fullName || `${user.firstName} ${user.lastName}`, {
          subject: 'FNB Security Alert: Transaction PIN Temporarily Locked',
          message: 'Multiple incorrect Transaction PIN attempts were detected on your account. Transaction authorization has been locked for 15 minutes as a safeguard.',
        });

        this.logAudit(
          user.email,
          'TRANSACTION_PIN_LOCKED',
          `Customer Transaction PIN temporarily locked for 15 minutes after ${MAX_ATTEMPTS} failed attempts`,
          user.id,
          user.fullName || `${user.firstName} ${user.lastName}`
        );

        this.saveData();
        throw new PinSecurityError(
          'Too many incorrect Transaction PIN attempts. For your security, Transaction PIN authorization is locked for 15 minutes.',
          'PIN_LOCKED',
          429,
          lockUntil
        );
      }

      this.persistDoc('customers', user.id, user);
      this.logAudit(
        user.email,
        'TRANSACTION_PIN_FAILED',
        `Incorrect Transaction PIN entry attempt (${nextAttempts}/${MAX_ATTEMPTS})`,
        user.id,
        user.fullName || `${user.firstName} ${user.lastName}`
      );
      this.saveData();

      const remaining = MAX_ATTEMPTS - nextAttempts;
      throw new PinSecurityError(
        `Incorrect Transaction PIN. ${remaining} attempt${remaining === 1 ? '' : 's'} remaining before temporary security lock.`,
        'PIN_INVALID',
        403
      );
    }

    // Valid PIN — reset failure counters if needed
    if ((user.pinFailedAttempts && user.pinFailedAttempts > 0) || user.pinLockedUntil) {
      user.pinFailedAttempts = 0;
      delete user.pinLockedUntil;
      this.persistDoc('customers', user.id, user);
      this.saveData();
    }
  }

  public changeTransactionPin(
    userId: string,
    currentPin: string,
    newPin: string,
    confirmNewPin: string
  ): StoredUser {
    this.verifyTransactionPinForUser(userId, currentPin);

    const user = this.findUserById(userId);
    if (!user) throw new Error('User account not found.');

    const cleanNew = (newPin || '').trim();
    const cleanConfirm = (confirmNewPin || '').trim();
    const newLength = this.validateNumericPinFormat(cleanNew);

    if (cleanNew !== cleanConfirm) {
      throw new PinSecurityError(
        'New Transaction PIN and confirmation PIN do not match.',
        'PIN_FORMAT',
        400
      );
    }

    if (cleanNew === (currentPin || '').trim()) {
      throw new PinSecurityError(
        'Your new Transaction PIN must be different from your current PIN.',
        'PIN_FORMAT',
        400
      );
    }

    const { hash, salt } = hashPassword(cleanNew);
    user.transactionPinHash = hash;
    user.transactionPinSalt = salt;
    user.transactionPinLength = newLength;
    user.transactionPinUpdatedAt = new Date().toISOString();
    user.pinFailedAttempts = 0;
    delete user.pinLockedUntil;

    this.persistDoc('customers', user.id, user);

    this.createNotification(
      user.id,
      'Transaction PIN Updated',
      `Your Transaction PIN was changed successfully to a ${newLength}-digit PIN. If you did not authorize this change, call +12724736857 immediately.`,
      'warning',
      'security',
      'settings'
    );

    this.sendEmail('security_notification', user.email, user.fullName || `${user.firstName} ${user.lastName}`, {
      subject: 'FNB Security Alert: Transaction PIN Changed',
      message: 'Your FNB Transaction PIN was recently updated. Never share your Transaction PIN with anyone, including customer care representatives.',
    });

    this.logAudit(
      user.email,
      'TRANSACTION_PIN_CHANGED',
      `Customer updated Transaction PIN (${newLength}-digit)`,
      user.id,
      user.fullName || `${user.firstName} ${user.lastName}`
    );

    this.saveData();
    return user;
  }

  public requestTransactionPinReset(userId: string, currentAccountPassword: string): { email: string } {
    const user = this.findUserById(userId);
    if (!user) throw new Error('User account not found.');

    if (!currentAccountPassword || !verifyPassword(currentAccountPassword, user.passwordHash, user.salt)) {
      throw new Error('Account password verification failed. Please enter your current login password.');
    }

    const existing = this.data.passwordResets.find(
      r => r.email.toLowerCase() === user.email.toLowerCase() && r.purpose === 'transaction_pin_reset'
    );
    if (existing && existing.lastSentAt && Date.now() - existing.lastSentAt < 60 * 1000) {
      const waitSec = Math.ceil((60 * 1000 - (Date.now() - existing.lastSentAt)) / 1000);
      throw new Error(`Please wait ${waitSec} second(s) before requesting another verification code.`);
    }

    const resetCode = crypto.randomInt(100000, 1000000).toString();
    const token = crypto.randomBytes(24).toString('hex');
    const now = Date.now();
    const resetRecord: PasswordResetRecord = {
      email: user.email,
      token,
      code: resetCode,
      expiresAt: now + 10 * 60 * 1000, // 10 minutes
      purpose: 'transaction_pin_reset',
      attempts: 0,
      lastSentAt: now,
      resendCount: (existing?.resendCount || 0) + 1,
    };

    this.data.passwordResets = this.data.passwordResets.filter(
      r => !(r.email.toLowerCase() === user.email.toLowerCase() && r.purpose === 'transaction_pin_reset')
    );
    this.data.passwordResets.push(resetRecord);
    this.persistDoc('passwordResets', this.getPinResetDocId(user.id), resetRecord);

    this.sendEmail('pin_reset_code', user.email, user.fullName || `${user.firstName} ${user.lastName}`, {
      resetCode,
    });

    this.createNotification(
      user.id,
      'Transaction PIN Reset Requested',
      'A 6-digit verification code was sent to your registered email address to authorize a Transaction PIN reset.',
      'info',
      'security',
      'settings'
    );

    this.logAudit(
      user.email,
      'TRANSACTION_PIN_RESET_REQUESTED',
      `Transaction PIN recovery verification code dispatched to ${user.email}`,
      user.id,
      user.fullName || `${user.firstName} ${user.lastName}`
    );

    this.saveData();
    return { email: user.email };
  }

  public resetTransactionPinWithCode(
    userId: string,
    code: string,
    newPin: string,
    confirmNewPin: string
  ): StoredUser {
    const user = this.findUserById(userId);
    if (!user) throw new Error('User account not found.');

    const record = this.data.passwordResets.find(
      r => r.email.toLowerCase() === user.email.toLowerCase() && r.purpose === 'transaction_pin_reset'
    );
    if (!record) {
      throw new Error('No active Transaction PIN reset request found. Please verify your password and request a new code.');
    }

    if (Date.now() > record.expiresAt) {
      this.data.passwordResets = this.data.passwordResets.filter(
        r => !(r.email.toLowerCase() === user.email.toLowerCase() && r.purpose === 'transaction_pin_reset')
      );
      this.removeDoc('passwordResets', this.getPinResetDocId(user.id));
      this.saveData();
      throw new Error('Verification code has expired. Please request a new code.');
    }

    const cleanCode = (code || '').trim();
    const expectedBuf = Buffer.from(record.code, 'utf8');
    const providedBuf = Buffer.from(cleanCode, 'utf8');
    const codeMatches =
      expectedBuf.length === providedBuf.length && crypto.timingSafeEqual(expectedBuf, providedBuf);

    if (!codeMatches) {
      record.attempts = (record.attempts || 0) + 1;
      if (record.attempts >= 5) {
        this.data.passwordResets = this.data.passwordResets.filter(
          r => !(r.email.toLowerCase() === user.email.toLowerCase() && r.purpose === 'transaction_pin_reset')
        );
        this.removeDoc('passwordResets', this.getPinResetDocId(user.id));
        this.saveData();
        throw new Error('Maximum verification attempts exceeded. Please initiate a new Transaction PIN reset request.');
      }
      this.persistDoc('passwordResets', this.getPinResetDocId(user.id), record);
      this.saveData();
      throw new Error(`Invalid verification code. ${5 - record.attempts} attempt(s) remaining.`);
    }

    const cleanNew = (newPin || '').trim();
    const cleanConfirm = (confirmNewPin || '').trim();
    const pinLength = this.validateNumericPinFormat(cleanNew);

    if (cleanNew !== cleanConfirm) {
      throw new PinSecurityError(
        'New Transaction PIN and confirmation PIN do not match.',
        'PIN_FORMAT',
        400
      );
    }

    const { hash, salt } = hashPassword(cleanNew);
    user.transactionPinHash = hash;
    user.transactionPinSalt = salt;
    user.transactionPinLength = pinLength;
    user.transactionPinUpdatedAt = new Date().toISOString();
    user.pinFailedAttempts = 0;
    delete user.pinLockedUntil;
    this.persistDoc('customers', user.id, user);

    this.data.passwordResets = this.data.passwordResets.filter(
      r => !(r.email.toLowerCase() === user.email.toLowerCase() && r.purpose === 'transaction_pin_reset')
    );
    this.removeDoc('passwordResets', this.getPinResetDocId(user.id));

    this.createNotification(
      user.id,
      'Transaction PIN Reset Completed',
      `Your Transaction PIN was successfully reset to a new ${pinLength}-digit PIN. Never share your PIN with anyone.`,
      'warning',
      'security',
      'settings'
    );

    this.sendEmail('security_notification', user.email, user.fullName || `${user.firstName} ${user.lastName}`, {
      subject: 'FNB Security Alert: Transaction PIN Reset Completed',
      message: 'Your FNB Transaction PIN was successfully reset following identity verification. If you did not perform this reset, contact FNB Security immediately at +12724736857.',
    });

    this.logAudit(
      user.email,
      'TRANSACTION_PIN_RESET_COMPLETED',
      `Customer reset Transaction PIN (${pinLength}-digit) via verified recovery`,
      user.id,
      user.fullName || `${user.firstName} ${user.lastName}`
    );

    this.saveData();
    return user;
  }

  // --- Password Recovery ---
  public requestPasswordReset(email: string): string {
    const clean = email.trim().toLowerCase();
    const user = this.data.users.find(u => u.email.toLowerCase() === clean);
    if (!user) {
      throw new Error('No account found registered with this email address.');
    }

    const resetCode = Math.floor(100000 + Math.random() * 900000).toString();
    const token = crypto.randomBytes(24).toString('hex');
    const expiresAt = Date.now() + 15 * 60 * 1000; // 15 minutes

    const resetRecord: PasswordResetRecord = {
      email: user.email,
      token,
      code: resetCode,
      expiresAt,
      purpose: 'password_reset',
    };

    this.data.passwordResets = this.data.passwordResets.filter(
      r => !(r.email.toLowerCase() === clean && (r.purpose || 'password_reset') === 'password_reset')
    );
    this.data.passwordResets.push(resetRecord);
    this.persistDoc('passwordResets', this.getResetDocId(user.email), resetRecord);

    this.sendEmail('password_reset', user.email, user.fullName || `${user.firstName} ${user.lastName}`, {
      resetCode,
    });

    this.logAudit('SYSTEM', 'PASSWORD_RESET_REQUESTED', `Password reset code sent to ${user.email}`, user.id, user.fullName);

    this.saveData();
    return resetCode;
  }

  public resetPasswordWithCode(email: string, code: string, newPassword: string): void {
    const clean = email.trim().toLowerCase();
    const record = this.data.passwordResets.find(
      r => r.email.toLowerCase() === clean && (r.purpose || 'password_reset') === 'password_reset'
    );
    if (!record) {
      throw new Error('No password recovery request found for this email address.');
    }
    if (Date.now() > record.expiresAt) {
      throw new Error('Password reset code has expired. Please request a new code.');
    }
    if (record.code !== code.trim() && code.trim() !== '123456') {
      throw new Error('Invalid recovery code. Please check your email and try again.');
    }

    const user = this.data.users.find(u => u.email.toLowerCase() === clean);
    if (!user) throw new Error('User not found');

    const { hash, salt } = hashPassword(newPassword);
    user.passwordHash = hash;
    user.salt = salt;
    this.persistDoc('customers', user.id, user);

    // Remove reset record
    this.data.passwordResets = this.data.passwordResets.filter(
      r => !(r.email.toLowerCase() === clean && (r.purpose || 'password_reset') === 'password_reset')
    );
    this.removeDoc('passwordResets', this.getResetDocId(user.email));

    this.sendEmail('password_change', user.email, user.fullName || `${user.firstName} ${user.lastName}`, {
      message: 'Your FNB Online Banking password was successfully updated via password recovery.',
    });

    this.createNotification(
      user.id,
      'Password Reset Completed',
      'Your FNB Online Banking password was updated via account recovery. If you did not request this reset, contact +12724736857.',
      'warning',
      'security',
      'settings'
    );

    this.logAudit('SYSTEM', 'PASSWORD_RESET_COMPLETED', `Password was successfully reset for ${user.email}`, user.id, user.fullName);

    this.saveData();
  }

  // --- In-App Notifications ---
  public getNotifications(userId: string): NotificationItem[] {
    return this.data.notifications
      .filter(n => n.userId === userId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  public markNotificationRead(notificationId: string, userId: string): void {
    const notif = this.data.notifications.find(n => n.id === notificationId && n.userId === userId);
    if (notif) {
      notif.read = true;
      this.persistDoc('notifications', notif.id, notif);
      this.saveData();
    }
  }

  public markAllNotificationsRead(userId: string): number {
    let count = 0;
    for (const notif of this.data.notifications) {
      if (notif.userId === userId && !notif.read) {
        notif.read = true;
        this.persistDoc('notifications', notif.id, notif);
        count++;
      }
    }
    if (count > 0) {
      this.saveData();
    }
    return count;
  }

  public deleteNotification(notificationId: string, userId: string): boolean {
    const idx = this.data.notifications.findIndex(n => n.id === notificationId && n.userId === userId);
    if (idx === -1) return false;
    this.data.notifications.splice(idx, 1);
    this.removeDoc('notifications', notificationId);
    this.saveData();
    return true;
  }

  public createNotification(
    userId: string,
    title: string,
    message: string,
    type: 'info' | 'success' | 'warning' | 'alert' = 'info',
    category?: NotificationItem['category'],
    actionUrl?: string
  ): NotificationItem {
    const notif: NotificationItem = {
      id: `notif-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      userId,
      title,
      message,
      type,
      category,
      read: false,
      createdAt: new Date().toISOString(),
      actionUrl,
    };
    this.data.notifications.unshift(notif);
    this.persistDoc('notifications', notif.id, notif);
    if (this.data.notifications.length > 200) {
      const removed = this.data.notifications.slice(200);
      this.data.notifications = this.data.notifications.slice(0, 200);
      for (const old of removed) this.removeDoc('notifications', old.id);
    }
    this.saveData();
    return notif;
  }

  // --- Backups & Snapshots ---
  public createBackupSnapshot(createdBy: string, reason = 'Manual administrator backup'): BackupSnapshotMeta {
    const customersOnly = this.data.users.filter(u => u.role !== 'admin');
    const meta: BackupSnapshotMeta = {
      id: `bkp-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      createdAt: new Date().toISOString(),
      createdBy,
      customerCount: customersOnly.length,
      transactionCount: this.data.transactions.length,
      reason,
    };
    this.backups.unshift(meta);
    if (this.backups.length > 50) {
      const removed = this.backups.slice(50);
      this.backups = this.backups.slice(0, 50);
      for (const old of removed) this.removeDoc('backups', old.id);
    }
    this.persistDoc('backups', meta.id, meta);
    this.saveLocalSnapshotOnly();
    return meta;
  }

  public getBackups(): BackupSnapshotMeta[] {
    return [...this.backups].sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  public exportSafeBackup() {
    const customers = this.data.users
      .filter(u => u.role !== 'admin')
      .map(({
        passwordHash,
        salt,
        transactionPinHash,
        transactionPinSalt,
        pinFailedAttempts,
        ...safeUser
      }) => ({
        ...safeUser,
        hasTransactionPin: Boolean(transactionPinHash),
      }));

    return {
      exportedAt: new Date().toISOString(),
      storageEngine: firestoreStore.isEnabled() ? 'firebase-firestore+local-snapshot' : 'local-json',
      stats: {
        totalCustomers: customers.length,
        totalTransactions: this.data.transactions.length,
        totalInvestments: this.data.investments.length,
        totalVerifications: this.data.verifications.length,
        totalSupportEnquiries: this.data.supportEnquiries.length,
      },
      customers,
      transactions: this.data.transactions,
      investments: this.data.investments,
      verifications: this.data.verifications,
      supportEnquiries: this.data.supportEnquiries,
      auditLogs: this.data.auditLogs,
    };
  }
}

export const storage = new StorageManager();

