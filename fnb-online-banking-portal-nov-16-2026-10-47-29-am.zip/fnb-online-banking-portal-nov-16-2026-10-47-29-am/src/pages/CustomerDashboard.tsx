import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { useAuth } from '../context/AuthContext.tsx';
import { api } from '../services/api.ts';
import {
  Transaction,
  LoginActivity,
  InvestmentRequest,
  VerificationRequest,
  SupportEnquiry,
  NotificationItem,
} from '../types.ts';
import { INVESTMENT_PLANS } from '../constants/investments.ts';
import { ReceiptModal } from '../components/ReceiptModal.tsx';
import { StatementModal } from '../components/StatementModal.tsx';
import { TransactionTagBadge } from '../components/TransactionTagBadge.tsx';
import { BeneficiaryBankSelector, BankSelectionValue } from '../components/BeneficiaryBankSelector.tsx';
import { TransactionPinManager } from '../components/TransactionPinManager.tsx';
import { TransactionPinModal } from '../components/TransactionPinModal.tsx';
import { LanguageToggle } from '../components/LanguageToggle.tsx';
import {
  GLOBAL_BANK_DIRECTORY,
  CountryBankDirectory,
  getCountryDirectory,
  validateBankAccountIdentifier,
  validateSwiftBicCode,
} from '../constants/banks.ts';
import { tagTransaction, AVAILABLE_TRANSACTION_TAGS } from '../utils/transactionTagger.ts';
import { formatUsdNumber, USD_SYMBOL, USD_CODE } from '../utils/currency.ts';
import {
  Tag,
  ArrowUpRight,
  ArrowDownLeft,
  Send,
  Settings,
  Eye,
  EyeOff,
  Copy,
  Check,
  Lock,
  ShieldAlert,
  ShieldCheck,
  Search,
  History,
  Building2,
  Layers,
  FileSpreadsheet,
  TrendingUp,
  Bell,
  MessageSquare,
  FileCheck2,
  UploadCloud,
  CheckCircle2,
  AlertCircle,
  Phone,
  Mail,
  Globe,
  MapPin,
  Printer,
  Trash2,
  CheckCheck,
  X,
  KeyRound,
  LayoutDashboard,
  Menu,
  LogOut,
  Users,
  Receipt,
  PiggyBank,
  Landmark,
  Briefcase,
  User as UserIcon,
  FolderOpen,
  Plus,
  ChevronRight,
  Info,
} from 'lucide-react';

export type DashboardTab =
  | 'customer_menu'
  | 'overview'
  | 'account'
  | 'investments'
  | 'transfers'
  | 'international'
  | 'beneficiaries'
  | 'payments'
  | 'transactions'
  | 'savings'
  | 'fixed_deposits'
  | 'loans'
  | 'profile'
  | 'login_history'
  | 'statements'
  | 'verification'
  | 'notifications'
  | 'support'
  | 'settings';

interface SavedBeneficiary {
  id: string;
  name: string;
  bankName: string;
  accountNumber: string;
  scope: 'domestic' | 'international';
  countryCode: string;
  swiftBic?: string;
  addedAt: string;
}

interface CustomerDashboardProps {
  onLogout?: () => Promise<void> | void;
}

const NAVY_CARD = 'bg-[#0a1d3a] border border-blue-800/40 rounded-3xl shadow-xl';
const NAVY_SUBCARD = 'bg-[#07152b] border border-blue-800/40 rounded-2xl';
const NAVY_INPUT =
  'w-full px-3.5 py-2.5 text-xs sm:text-sm bg-[#041022] border border-blue-800/60 rounded-xl text-white placeholder-blue-300/40 focus:outline-none focus:ring-2 focus:ring-blue-400/50';
const NAVY_LABEL = 'block text-xs font-semibold text-blue-200 mb-1';

export const CustomerDashboard: React.FC<CustomerDashboardProps> = ({ onLogout }) => {
  const { user, refreshUser, logoutCustomer, setIsMailModalOpen } = useAuth();

  // Navigation & Sidebar state
  const [activeTab, setActiveTab] = useState<DashboardTab>('overview');
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);
  const [desktopSidebarOpen, setDesktopSidebarOpen] = useState(true);
  const [loggingOut, setLoggingOut] = useState(false);

  // Core Banking Data
  const [balanceVisible, setBalanceVisible] = useState(true);
  const [copiedAcc, setCopiedAcc] = useState(false);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loginActivities, setLoginActivities] = useState<LoginActivity[]>([]);
  const [investments, setInvestments] = useState<InvestmentRequest[]>([]);
  const [verifications, setVerifications] = useState<VerificationRequest[]>([]);
  const [supportEnquiries, setSupportEnquiries] = useState<SupportEnquiry[]>([]);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [bankDirectory, setBankDirectory] = useState<CountryBankDirectory[]>(GLOBAL_BANK_DIRECTORY);
  const [loading, setLoading] = useState(true);

  // Modals
  const [activeReceiptTx, setActiveReceiptTx] = useState<Transaction | null>(null);
  const [isStatementOpen, setIsStatementOpen] = useState(false);

  // Transaction PIN Verification Modal & Management State
  type PendingPinAction =
    | {
        kind: 'transfer';
        payload: {
          beneficiaryName: string;
          beneficiaryBank: string;
          beneficiaryAccount: string;
          transferScope: 'domestic' | 'international';
          beneficiaryCountry?: string;
          swiftBic?: string;
          routingCode?: string;
          amount: number;
          description: string;
          reference?: string;
        };
      }
    | {
        kind: 'investment';
        payload: {
          planId: string;
          planName: string;
          amount: number;
          durationMonths: number;
          userNotes?: string;
        };
      };

  const [pendingPinAction, setPendingPinAction] = useState<PendingPinAction | null>(null);
  const [pinModalLoading, setPinModalLoading] = useState(false);
  const [pinModalError, setPinModalError] = useState<string | null>(null);
  const [pinModalErrorCode, setPinModalErrorCode] = useState<string | undefined>(undefined);
  const [pinModalLockedUntil, setPinModalLockedUntil] = useState<number | undefined>(undefined);
  const [pinManagerMode, setPinManagerMode] = useState<'auto' | 'setup' | 'change' | 'forgot'>('auto');
  const [showAccountPinManager, setShowAccountPinManager] = useState(false);

  // Saved Beneficiaries (persisted per customer in localStorage + supplemented by past transfers)
  const [savedBeneficiaries, setSavedBeneficiaries] = useState<SavedBeneficiary[]>([]);
  const [beneficiaryForm, setBeneficiaryForm] = useState({
    name: '',
    bankName: 'First National Bank (Domestic)',
    accountNumber: '',
    scope: 'domestic' as 'domestic' | 'international',
    countryCode: 'US',
    swiftBic: '',
  });
  const [beneficiaryMsg, setBeneficiaryMsg] = useState<string | null>(null);

  // Transfers Form
  const [transferForm, setTransferForm] = useState({
    beneficiaryName: '',
    transferScope: 'domestic' as 'domestic' | 'international',
    beneficiaryCountryCode: 'GB',
    beneficiaryBank: 'First National Bank (Domestic)',
    swiftBic: 'FNBBGB2LXXX',
    routingCode: '',
    isCustomBank: false,
    beneficiaryAccount: '',
    amount: '',
    description: '',
    reference: '',
  });
  const [transferLoading, setTransferLoading] = useState(false);
  const [transferError, setTransferError] = useState<string | null>(null);

  // Investments Form
  const [selectedPlanId, setSelectedPlanId] = useState<string>('plan-fixed-income');
  const [invAmount, setInvAmount] = useState<string>('2500');
  const [invDuration, setInvDuration] = useState<number>(12);
  const [invNotes, setInvNotes] = useState<string>('');
  const [invTermsAccepted, setInvTermsAccepted] = useState<boolean>(true);
  const [invLoading, setInvLoading] = useState(false);
  const [invSuccessMsg, setInvSuccessMsg] = useState<string | null>(null);
  const [invErrorMsg, setInvErrorMsg] = useState<string | null>(null);

  // Loan Estimator & Request State
  const [loanAmount, setLoanAmount] = useState<string>('15000');
  const [loanTermMonths, setLoanTermMonths] = useState<number>(36);
  const [loanPurpose, setLoanPurpose] = useState<string>('Personal Expansion & Liquidity');
  const [loanSubmitting, setLoanSubmitting] = useState(false);
  const [loanFeedback, setLoanFeedback] = useState<string | null>(null);

  // KYC Verification Form
  const [kycForm, setKycForm] = useState({
    fullName: user?.fullName || `${user?.firstName || ''} ${user?.lastName || ''}`.trim(),
    dateOfBirth: user?.dateOfBirth || '1992-06-14',
    countryOfResidence: user?.country || 'United States',
    residentialAddress: user?.residentialAddress || '13586 US-90, Boutte, LA 70039, United States',
    phone: user?.phone || '',
    idDocumentType: 'passport' as 'passport' | 'national_id' | 'drivers_licence' | 'other',
    idDocumentNumber: '',
    sampleDocFrontName: 'Passport_Bio_Data_Page.pdf',
    sampleDocBackName: '',
    sampleProofOfAddressName: 'Utility_Bill_Proof_Of_Address.pdf',
    additionalComments: '',
    declarationAccepted: true,
    consentAccepted: true,
  });
  const [kycLoading, setKycLoading] = useState(false);
  const [kycSuccessMsg, setKycSuccessMsg] = useState<string | null>(null);
  const [kycErrorMsg, setKycErrorMsg] = useState<string | null>(null);

  // Support Enquiry Form
  const [supportForm, setSupportForm] = useState({
    category: 'general',
    subject: '',
    message: '',
  });
  const [supportLoading, setSupportLoading] = useState(false);
  const [supportSuccess, setSupportSuccess] = useState<string | null>(null);
  const [supportError, setSupportError] = useState<string | null>(null);

  // Security Settings Form (Password + 2FA ONLY — Personal Identity is Admin-Only)
  const [twoFactorEnabled, setTwoFactorEnabled] = useState<boolean>(!!user?.isTwoFactorEnabled);
  const [passwords, setPasswords] = useState({ current: '', new: '', confirm: '' });
  const [settingsMessage, setSettingsMessage] = useState<string | null>(null);
  const [settingsError, setSettingsError] = useState<string | null>(null);

  // Search & Filters for Transactions & Notifications
  const [txSearch, setTxSearch] = useState('');
  const [txFilterType, setTxFilterType] = useState<string>('all');
  const [txFilterTag, setTxFilterTag] = useState<string>('All');
  const [notifCategoryFilter, setNotifCategoryFilter] = useState<string>('all');
  const [selectedNotifDetail, setSelectedNotifDetail] = useState<NotificationItem | null>(null);

  // Sync two-factor toggle & KYC defaults when admin updates customer record
  useEffect(() => {
    if (!user) return;
    setTwoFactorEnabled(!!user.isTwoFactorEnabled);
    setKycForm(prev => ({
      ...prev,
      fullName: user.fullName || `${user.firstName} ${user.lastName}`.trim(),
      countryOfResidence: user.country || prev.countryOfResidence,
      residentialAddress: user.residentialAddress || prev.residentialAddress,
      phone: user.phone || prev.phone,
    }));
  }, [user]);

  // Load saved beneficiaries for this customer
  useEffect(() => {
    if (!user?.id) return;
    try {
      const raw = localStorage.getItem(`fnb_beneficiaries_${user.id}`);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) setSavedBeneficiaries(parsed);
      }
    } catch {
      // Ignore storage error
    }
  }, [user?.id]);

  const persistBeneficiaries = (next: SavedBeneficiary[]) => {
    setSavedBeneficiaries(next);
    if (user?.id) {
      try {
        localStorage.setItem(`fnb_beneficiaries_${user.id}`, JSON.stringify(next));
      } catch {
        // Ignore storage error
      }
    }
  };

  const fetchDashboardData = useCallback(async () => {
    try {
      setLoading(true);
      const [summary, actRes, invRes, verRes, supRes, notifRes, bankDirRes] = await Promise.all([
        api.getBankingSummary(),
        api.getLoginActivity().catch(() => ({ activities: [] })),
        api.getInvestments().catch(() => ({ investments: [] })),
        api.getVerifications().catch(() => ({ verifications: [] })),
        api.getSupportEnquiries().catch(() => ({ enquiries: [] })),
        api.getNotifications().catch(() => ({ notifications: [] })),
        api.getBankDirectory().catch(() => null),
      ]);

      setTransactions(summary.recentTransactions || []);
      setLoginActivities(actRes.activities || []);
      setInvestments(invRes.investments || []);
      setVerifications(verRes.verifications || []);
      setSupportEnquiries(supRes.enquiries || []);
      setNotifications(notifRes.notifications || []);
      if (bankDirRes?.countries && Array.isArray(bankDirRes.countries) && bankDirRes.countries.length > 0) {
        setBankDirectory(bankDirRes.countries as CountryBankDirectory[]);
      }
    } catch (err) {
      console.error('Error fetching dashboard data:', err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchDashboardData();
  }, [fetchDashboardData]);

  // Automatically sync customer profile (admin edits) and notifications in real time without page refresh
  useEffect(() => {
    const syncLive = async () => {
      try {
        await refreshUser(false);
        const res = await api.getNotifications();
        if (Array.isArray(res.notifications)) {
          setNotifications(res.notifications);
        }
      } catch {
        // Ignore transient background errors
      }
    };

    const interval = setInterval(syncLive, 10000);
    const onFocus = () => {
      syncLive();
    };
    window.addEventListener('focus', onFocus);
    return () => {
      clearInterval(interval);
      window.removeEventListener('focus', onFocus);
    };
  }, [refreshUser]);

  // Switch cleanly to International Payments tab with International Wire pre-selected
  const handleSelectNavTab = (tabId: DashboardTab) => {
    if (tabId === 'international') {
      const usDir = getCountryDirectory('US');
      const usBank = usDir?.banks[0];
      setTransferForm(prev => ({
        ...prev,
        transferScope: 'international',
        beneficiaryCountryCode: 'US',
        beneficiaryBank: usBank?.name || 'JPMorgan Chase',
        swiftBic: usBank?.swiftBic || 'CHASUS33XXX',
        isCustomBank: false,
      }));
    } else if (tabId === 'transfers') {
      setTransferForm(prev => ({
        ...prev,
        transferScope: 'domestic',
        beneficiaryCountryCode: 'GB',
        beneficiaryBank: 'First National Bank (Domestic)',
        swiftBic: 'FNBBGB2LXXX',
        isCustomBank: false,
      }));
    }
    setActiveTab(tabId);
    setMobileSidebarOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleLogoutClick = async () => {
    setLoggingOut(true);
    try {
      if (onLogout) {
        await onLogout();
      } else {
        await logoutCustomer();
      }
    } finally {
      setLoggingOut(false);
    }
  };

  const derivedRecipients = useMemo(() => {
    const seen = new Set(savedBeneficiaries.map(b => `${b.accountNumber}:${b.bankName}`.toLowerCase()));
    const fromHistory: SavedBeneficiary[] = [];
    for (const tx of transactions) {
      if (tx.beneficiaryName && tx.beneficiaryAccount && tx.beneficiaryBank) {
        const key = `${tx.beneficiaryAccount}:${tx.beneficiaryBank}`.toLowerCase();
        if (!seen.has(key)) {
          seen.add(key);
          fromHistory.push({
            id: `hist-${tx.id}`,
            name: tx.beneficiaryName,
            bankName: tx.beneficiaryBank,
            accountNumber: tx.beneficiaryAccount,
            scope: tx.transferScope || 'domestic',
            countryCode: 'US',
            swiftBic: tx.swiftBic,
            addedAt: tx.createdAt,
          });
        }
      }
    }
    return [...savedBeneficiaries, ...fromHistory];
  }, [savedBeneficiaries, transactions]);

  if (!user) return null;

  const isFrozen = user.status === 'frozen';

  const handleCopyAcc = () => {
    if (user.accountNumber) {
      navigator.clipboard.writeText(user.accountNumber);
      setCopiedAcc(true);
      setTimeout(() => setCopiedAcc(false), 2000);
    }
  };

  // Initiate Transfer -> Validate & prompt for Transaction PIN Verification
  const handleTransferSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setTransferError(null);

    if (!transferForm.beneficiaryBank.trim()) {
      setTransferError('Please select or enter a beneficiary bank.');
      return;
    }

    const accountCheck = validateBankAccountIdentifier(
      transferForm.beneficiaryAccount,
      transferForm.transferScope,
      transferForm.beneficiaryCountryCode
    );
    if (!accountCheck.valid) {
      setTransferError(accountCheck.message || 'Please enter a valid beneficiary account number or IBAN.');
      return;
    }

    let cleanSwift = transferForm.swiftBic.trim().toUpperCase();
    if (transferForm.transferScope === 'international') {
      const swiftCheck = validateSwiftBicCode(cleanSwift);
      if (!swiftCheck.valid) {
        setTransferError(swiftCheck.message || 'Please enter a valid 8 or 11 character SWIFT/BIC code.');
        return;
      }
      cleanSwift = swiftCheck.formatted;
    }

    const amt = parseFloat(transferForm.amount);
    if (isNaN(amt) || amt <= 0) {
      setTransferError('Please enter a valid amount.');
      return;
    }
    if (amt > user.balance) {
      setTransferError(`Insufficient funds. Your available balance is ${USD_SYMBOL}${formatUsdNumber(user.balance)} ${USD_CODE}.`);
      return;
    }

    const selectedCountry =
      bankDirectory.find(c => c.countryCode === transferForm.beneficiaryCountryCode) ||
      getCountryDirectory(transferForm.beneficiaryCountryCode);

    setPinModalError(null);
    setPinModalErrorCode(undefined);
    setPinModalLockedUntil(undefined);
    setPendingPinAction({
      kind: 'transfer',
      payload: {
        beneficiaryName: transferForm.beneficiaryName.trim(),
        beneficiaryBank: transferForm.beneficiaryBank.trim(),
        beneficiaryAccount: accountCheck.formatted,
        transferScope: transferForm.transferScope,
        beneficiaryCountry:
          transferForm.beneficiaryCountryCode === 'ALL'
            ? undefined
            : selectedCountry?.countryName || transferForm.beneficiaryCountryCode,
        swiftBic: cleanSwift || undefined,
        routingCode: transferForm.routingCode.trim() || undefined,
        amount: amt,
        description: transferForm.description || `Transfer to ${transferForm.beneficiaryName}`,
        reference: transferForm.reference || undefined,
      },
    });
  };

  // Initiate Investment Allocation -> Validate & prompt for Transaction PIN Verification
  const handleInvestmentSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setInvErrorMsg(null);
    setInvSuccessMsg(null);

    const amt = parseFloat(invAmount);
    if (isNaN(amt) || amt <= 0) {
      setInvErrorMsg('Please specify a valid allocation amount.');
      return;
    }

    const selectedPlan = INVESTMENT_PLANS.find(p => p.id === selectedPlanId);
    if (!selectedPlan) {
      setInvErrorMsg('Selected investment plan not found.');
      return;
    }
    if (amt < selectedPlan.minimumAmount) {
      setInvErrorMsg(`Minimum allocation for ${selectedPlan.name} is ${USD_SYMBOL}${formatUsdNumber(selectedPlan.minimumAmount)} ${USD_CODE}.`);
      return;
    }
    if (amt > selectedPlan.maximumAmount) {
      setInvErrorMsg(`Maximum allocation for ${selectedPlan.name} is ${USD_SYMBOL}${formatUsdNumber(selectedPlan.maximumAmount)} ${USD_CODE}.`);
      return;
    }
    if (amt > user.balance) {
      setInvErrorMsg(`Insufficient funds. Your available balance is ${USD_SYMBOL}${formatUsdNumber(user.balance)} ${USD_CODE}.`);
      return;
    }

    setPinModalError(null);
    setPinModalErrorCode(undefined);
    setPinModalLockedUntil(undefined);
    setPendingPinAction({
      kind: 'investment',
      payload: {
        planId: selectedPlanId,
        planName: selectedPlan.name,
        amount: amt,
        durationMonths: invDuration,
        userNotes: invNotes || undefined,
      },
    });
  };

  // Server-Verified Transaction Execution after Transaction PIN entry
  const handleConfirmTransactionPin = async (enteredPin: string) => {
    if (!pendingPinAction) return;
    setPinModalLoading(true);
    setPinModalError(null);
    setPinModalErrorCode(undefined);
    setPinModalLockedUntil(undefined);

    try {
      if (pendingPinAction.kind === 'transfer') {
        const res = await api.transfer({
          ...pendingPinAction.payload,
          transactionPin: enteredPin,
        });

        await refreshUser(false);
        await fetchDashboardData();

        setPendingPinAction(null);
        setActiveReceiptTx(res.transaction);
        setTransferForm({
          beneficiaryName: '',
          transferScope: 'domestic',
          beneficiaryCountryCode: 'GB',
          beneficiaryBank: 'First National Bank (Domestic)',
          swiftBic: 'FNBBGB2LXXX',
          routingCode: '',
          isCustomBank: false,
          beneficiaryAccount: '',
          amount: '',
          description: '',
          reference: '',
        });
        setActiveTab('overview');
      } else if (pendingPinAction.kind === 'investment') {
        const res = await api.createInvestment({
          planId: pendingPinAction.payload.planId,
          amount: pendingPinAction.payload.amount,
          durationMonths: pendingPinAction.payload.durationMonths,
          userNotes: pendingPinAction.payload.userNotes,
          transactionPin: enteredPin,
        });

        await refreshUser(false);
        await fetchDashboardData();
        setPendingPinAction(null);
        setInvSuccessMsg(
          `Investment request ${res.investment.reference} verified & submitted successfully for administrative compliance review.`
        );
        setInvNotes('');
      }
    } catch (err: any) {
      setPinModalError(err.message || 'Transaction PIN verification failed.');
      setPinModalErrorCode(err.code);
      setPinModalLockedUntil(err.lockedUntil);
      if (err.code === 'PIN_LOCKED' || err.code === 'PIN_NOT_SET') {
        await refreshUser(false);
      }
    } finally {
      setPinModalLoading(false);
    }
  };

  const handleAddBeneficiary = (e: React.FormEvent) => {
    e.preventDefault();
    if (!beneficiaryForm.name.trim() || !beneficiaryForm.bankName.trim() || !beneficiaryForm.accountNumber.trim()) {
      return;
    }
    const nextItem: SavedBeneficiary = {
      id: `ben-${Date.now()}`,
      name: beneficiaryForm.name.trim(),
      bankName: beneficiaryForm.bankName.trim(),
      accountNumber: beneficiaryForm.accountNumber.trim().toUpperCase(),
      scope: beneficiaryForm.scope,
      countryCode: beneficiaryForm.countryCode,
      swiftBic: beneficiaryForm.swiftBic.trim().toUpperCase() || undefined,
      addedAt: new Date().toISOString(),
    };
    persistBeneficiaries([nextItem, ...savedBeneficiaries]);
    setBeneficiaryForm({
      name: '',
      bankName: 'First National Bank (Domestic)',
      accountNumber: '',
      scope: 'domestic',
      countryCode: 'US',
      swiftBic: '',
    });
    setBeneficiaryMsg(`Beneficiary "${nextItem.name}" added to your saved directory.`);
    setTimeout(() => setBeneficiaryMsg(null), 4000);
  };

  const handleUseBeneficiary = (ben: SavedBeneficiary) => {
    setTransferForm({
      beneficiaryName: ben.name,
      transferScope: ben.scope,
      beneficiaryCountryCode: ben.countryCode || (ben.scope === 'international' ? 'US' : 'GB'),
      beneficiaryBank: ben.bankName,
      swiftBic: ben.swiftBic || '',
      routingCode: '',
      isCustomBank: true,
      beneficiaryAccount: ben.accountNumber,
      amount: '',
      description: `Transfer to ${ben.name}`,
      reference: '',
    });
    setActiveTab(ben.scope === 'international' ? 'international' : 'transfers');
  };

  const handleSubmitLoanInquiry = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoanSubmitting(true);
    setLoanFeedback(null);
    try {
      const amt = parseFloat(loanAmount) || 0;
      const res = await api.createSupportEnquiry({
        name: user.fullName || `${user.firstName} ${user.lastName}`,
        email: user.email,
        phone: user.phone,
        category: 'account',
        subject: `Loan Facility Request: ${USD_SYMBOL}${formatUsdNumber(amt)} (${loanTermMonths} months)`,
        message: `Customer ${user.fullName || user.firstName} (Account ${user.accountNumber || 'Pending'}) requested a formal credit assessment for ${USD_SYMBOL}${formatUsdNumber(amt)} ${USD_CODE} over ${loanTermMonths} months. Stated purpose: ${loanPurpose}.`,
      });
      await fetchDashboardData();
      setLoanFeedback(`Loan consultation request logged under reference ${res.enquiry.reference}. A lending specialist will review your eligibility.`);
    } catch (err: any) {
      setLoanFeedback(err.message || 'Unable to submit loan consultation request.');
    } finally {
      setLoanSubmitting(false);
    }
  };

  const handleKycSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setKycErrorMsg(null);
    setKycSuccessMsg(null);
    setKycLoading(true);
    try {
      const res = await api.createVerification({
        ...kycForm,
        email: user.email,
        accountReference: user.accountNumber || 'Pending',
      });
      await refreshUser(false);
      await fetchDashboardData();
      setKycSuccessMsg(
        `Identity verification submitted under reference ${res.verification.reference}! Your documents are now under compliance review.`
      );
    } catch (err: any) {
      setKycErrorMsg(err.message || 'Failed to submit verification request.');
    } finally {
      setKycLoading(false);
    }
  };

  const handleSupportSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSupportError(null);
    setSupportSuccess(null);
    setSupportLoading(true);
    try {
      const res = await api.createSupportEnquiry({
        name: user.fullName || `${user.firstName} ${user.lastName}`,
        email: user.email,
        phone: user.phone,
        category: supportForm.category,
        subject: supportForm.subject,
        message: supportForm.message,
      });
      await fetchDashboardData();
      setSupportSuccess(`Support ticket created! Reference: ${res.enquiry.reference}`);
      setSupportForm({ category: 'general', subject: '', message: '' });
    } catch (err: any) {
      setSupportError(err.message || 'Failed to submit ticket.');
    } finally {
      setSupportLoading(false);
    }
  };

  const handleToggleTwoFactor = async () => {
    setSettingsMessage(null);
    setSettingsError(null);
    const nextVal = !twoFactorEnabled;
    try {
      await api.updateProfile({ isTwoFactorEnabled: nextVal });
      setTwoFactorEnabled(nextVal);
      await refreshUser(false);
      setSettingsMessage(`Two-factor sign-in verification ${nextVal ? 'enabled' : 'disabled'}.`);
    } catch (err: any) {
      setSettingsError(err.message || 'Failed to update security setting.');
    }
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setSettingsMessage(null);
    setSettingsError(null);
    if (passwords.new !== passwords.confirm) {
      setSettingsError('New passwords do not match.');
      return;
    }
    try {
      await api.changePassword(passwords.current, passwords.new);
      setPasswords({ current: '', new: '', confirm: '' });
      setSettingsMessage('Password updated successfully.');
    } catch (err: any) {
      setSettingsError(err.message || 'Failed to change password.');
    }
  };

  const handleMarkNotifRead = async (id: string) => {
    try {
      await api.markNotificationRead(id);
      setNotifications(prev => prev.map(n => (n.id === id ? { ...n, read: true } : n)));
      setSelectedNotifDetail(prev => (prev && prev.id === id ? { ...prev, read: true } : prev));
    } catch (e) {
      console.error(e);
    }
  };

  const handleMarkAllNotifsRead = async () => {
    try {
      await api.markAllNotificationsRead();
      setNotifications(prev => prev.map(n => ({ ...n, read: true })));
    } catch (e) {
      console.error(e);
    }
  };

  const handleDeleteNotif = async (id: string) => {
    try {
      await api.deleteNotification(id);
      setNotifications(prev => prev.filter(n => n.id !== id));
      setSelectedNotifDetail(prev => (prev && prev.id === id ? null : prev));
    } catch (e) {
      console.error(e);
    }
  };

  const handleViewNotifDetails = async (notif: NotificationItem) => {
    setSelectedNotifDetail(notif);
    if (!notif.read) {
      await handleMarkNotifRead(notif.id);
    }
  };

  const filteredTransactions = transactions.filter(tx => {
    const q = txSearch.toLowerCase();
    const tag = tx.tag || tagTransaction(tx.description, tx.type, tx.billerCategory).tag;
    const matchesSearch =
      tx.reference.toLowerCase().includes(q) ||
      tx.description.toLowerCase().includes(q) ||
      (tx.beneficiaryName && tx.beneficiaryName.toLowerCase().includes(q)) ||
      (tag && tag.toLowerCase().includes(q));

    const matchesType = txFilterType === 'all' || tx.type === txFilterType;
    const matchesTag = txFilterTag === 'All' || tag.toLowerCase() === txFilterTag.toLowerCase();

    return matchesSearch && matchesType && matchesTag;
  });

  const paymentHistoryTxs = transactions.filter(
    tx => tx.type === 'transfer' || tx.type === 'bill_payment' || tx.type === 'withdrawal' || tx.type === 'debit'
  );

  const sortedNotifications = [...notifications].sort(
    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  );

  const filteredNotifications = sortedNotifications.filter(n => {
    if (notifCategoryFilter === 'all') return true;
    return (n.category || 'account') === notifCategoryFilter;
  });

  const unreadNotifsCount = notifications.filter(n => !n.read).length;

  // All 20 Sidebar Navigation Options grouped with category separators
  const sidebarCategories: Array<{
    groupTitle: string;
    items: Array<{ id: DashboardTab; label: string; icon: React.ComponentType<{ className?: string }>; badge?: number }>;
  }> = [
    {
      groupTitle: 'Core Banking',
      items: [
        { id: 'customer_menu', label: 'Customer Menu', icon: Menu },
        { id: 'overview', label: 'Dashboard', icon: LayoutDashboard },
      ],
    },
    {
      groupTitle: 'Payments & Ledger',
      items: [
        { id: 'transactions', label: 'Transaction History', icon: History },
        { id: 'transfers', label: 'Fund Transfers', icon: Send },
        { id: 'international', label: 'International Payments', icon: Globe },
        { id: 'beneficiaries', label: 'Beneficiary Management', icon: Users },
        { id: 'payments', label: 'Payment History', icon: Receipt },
        { id: 'statements', label: 'Account Statements', icon: FileSpreadsheet },
      ],
    },
    {
      groupTitle: 'Accounts & Products',
      items: [
        { id: 'savings', label: 'Savings Accounts', icon: PiggyBank },
        { id: 'fixed_deposits', label: 'Fixed Deposits', icon: Landmark },
        { id: 'loans', label: 'Loan Services', icon: Briefcase },
      ],
    },
    {
      groupTitle: 'Profile, Alerts & Care',
      items: [
        { id: 'account', label: 'Account Information', icon: Building2 },
        { id: 'profile', label: 'Personal Profile', icon: UserIcon },
        { id: 'settings', label: 'Security Settings', icon: Settings },
        { id: 'login_history', label: 'Login History', icon: ShieldCheck },
        { id: 'notifications', label: 'Notifications Centre', icon: Bell, badge: unreadNotifsCount },
        { id: 'support', label: 'Customer Support', icon: MessageSquare },
        { id: 'verification', label: 'Document Centre', icon: FolderOpen },
      ],
    },
  ];

  // Transfer section (shared by both domestic 'transfers' & 'international')
  const renderTransferForm = () => {
    const selectedCountryDir =
      bankDirectory.find(c => c.countryCode === transferForm.beneficiaryCountryCode) ||
      getCountryDirectory(transferForm.beneficiaryCountryCode);

    const isIntl = transferForm.transferScope === 'international';
    const expectsIban = isIntl && Boolean(selectedCountryDir?.usesIban);
    const accountLabel = isIntl
      ? selectedCountryDir?.internationalIdentifierLabel || 'Account Number / IBAN'
      : selectedCountryDir?.domesticIdentifierLabel || 'Account Number';
    const accountPlaceholder = isIntl
      ? selectedCountryDir?.internationalIdentifierPlaceholder || 'Enter IBAN or account number'
      : selectedCountryDir?.domesticIdentifierPlaceholder || 'e.g. 10849201';

    const routingLabel = isIntl
      ? selectedCountryDir?.internationalRoutingLabel ||
        (transferForm.beneficiaryCountryCode === 'ALL' ? 'Routing / Clearing Code (Optional)' : undefined)
      : selectedCountryDir?.domesticRoutingLabel || 'Sort Code (Optional)';
    const routingPlaceholder = isIntl
      ? selectedCountryDir?.internationalRoutingPlaceholder || 'e.g. ABA / Routing Number'
      : selectedCountryDir?.domesticRoutingPlaceholder || 'e.g. 20-04-15';

    const handleBankSelectionChange = (next: BankSelectionValue) => {
      setTransferForm(prev => ({
        ...prev,
        transferScope: next.transferScope,
        beneficiaryCountryCode: next.countryCode,
        beneficiaryBank: next.bankName,
        swiftBic: next.swiftBic,
        isCustomBank: next.isCustomBank,
      }));
    };

    return (
      <div className={`${NAVY_CARD} p-6 sm:p-8 max-w-3xl space-y-6`}>
        <div className="flex items-center justify-between gap-4 flex-wrap">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#c8102e] text-white flex items-center justify-center shrink-0">
              {isIntl ? <Globe className="w-5 h-5" /> : <Send className="w-5 h-5" />}
            </div>
            <div>
              <h2 className="text-xl font-bold text-white">
                {isIntl ? 'International SWIFT Wire Transfer' : 'Execute Fund Transfer'}
              </h2>
              <p className="text-xs text-blue-200/75">
                {isIntl
                  ? 'Send cross-border wires via SWIFT/BIC and IBAN clearing in US Dollars (USD)'
                  : 'Transfer US Dollars (USD) domestically or internationally with full verification'}
              </p>
            </div>
          </div>
          {derivedRecipients.length > 0 && (
            <button
              type="button"
              onClick={() => handleSelectNavTab('beneficiaries')}
              className="px-3 py-1.5 rounded-xl bg-[#07152b] hover:bg-[#0e2a54] border border-blue-800/50 text-xs font-bold text-blue-200 flex items-center gap-1.5"
            >
              <Users className="w-3.5 h-3.5" />
              <span>Saved Beneficiaries</span>
            </button>
          )}
        </div>

        {transferError && (
          <div className="p-4 bg-red-950/60 border border-red-700/60 rounded-2xl text-xs text-red-200 flex items-start gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-red-400" />
            <span>{transferError}</span>
          </div>
        )}

        <form onSubmit={handleTransferSubmit} className="space-y-4">
          <BeneficiaryBankSelector
            theme="navy"
            value={{
              transferScope: transferForm.transferScope,
              countryCode: transferForm.beneficiaryCountryCode,
              bankName: transferForm.beneficiaryBank,
              swiftBic: transferForm.swiftBic,
              isCustomBank: transferForm.isCustomBank,
            }}
            onChange={handleBankSelectionChange}
            directory={bankDirectory}
          />

          {isIntl && (
            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label className={NAVY_LABEL}>
                  SWIFT / BIC Code <span className="text-red-400">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. CHASUS33XXX"
                  value={transferForm.swiftBic}
                  onChange={e =>
                    setTransferForm({
                      ...transferForm,
                      swiftBic: e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, ''),
                    })
                  }
                  className={`${NAVY_INPUT} font-mono uppercase`}
                />
              </div>

              {routingLabel && (
                <div>
                  <label className={NAVY_LABEL}>{routingLabel}</label>
                  <input
                    type="text"
                    placeholder={routingPlaceholder}
                    value={transferForm.routingCode}
                    onChange={e => setTransferForm({ ...transferForm, routingCode: e.target.value })}
                    className={`${NAVY_INPUT} font-mono`}
                  />
                </div>
              )}
            </div>
          )}

          <div className="grid sm:grid-cols-2 gap-4">
            <div>
              <label className={NAVY_LABEL}>Beneficiary Full Name</label>
              <input
                type="text"
                required
                placeholder="e.g. Sarah Jenkins"
                value={transferForm.beneficiaryName}
                onChange={e => setTransferForm({ ...transferForm, beneficiaryName: e.target.value })}
                className={NAVY_INPUT}
              />
            </div>

            <div>
              <label className={NAVY_LABEL}>{accountLabel}</label>
              <input
                type="text"
                required
                placeholder={accountPlaceholder}
                value={transferForm.beneficiaryAccount}
                onChange={e =>
                  setTransferForm({
                    ...transferForm,
                    beneficiaryAccount: isIntl
                      ? e.target.value.toUpperCase().replace(/[^A-Z0-9\s-]/g, '')
                      : e.target.value.replace(/[^0-9\s-]/g, ''),
                  })
                }
                className={`${NAVY_INPUT} font-mono ${expectsIban ? 'uppercase' : ''}`}
              />
            </div>
          </div>

          <div className="grid sm:grid-cols-2 gap-4">
            <div>
              <label className={NAVY_LABEL}>Amount (USD $)</label>
              <input
                type="number"
                step="0.01"
                required
                placeholder="0.00"
                value={transferForm.amount}
                onChange={e => setTransferForm({ ...transferForm, amount: e.target.value })}
                className={`${NAVY_INPUT} font-mono`}
              />
            </div>

            <div>
              <label className={NAVY_LABEL}>Payment Description / Note</label>
              <input
                type="text"
                placeholder={isIntl ? 'e.g. Overseas wire settlement' : 'e.g. Monthly Rent Settlement'}
                value={transferForm.description}
                onChange={e => setTransferForm({ ...transferForm, description: e.target.value })}
                className={NAVY_INPUT}
              />
            </div>
          </div>

          {!isIntl && routingLabel && (
            <div>
              <label className={NAVY_LABEL}>{routingLabel}</label>
              <input
                type="text"
                placeholder={routingPlaceholder}
                value={transferForm.routingCode}
                onChange={e => setTransferForm({ ...transferForm, routingCode: e.target.value })}
                className={`${NAVY_INPUT} font-mono`}
              />
            </div>
          )}

          <div className="p-4 rounded-2xl bg-[#07152b] border border-blue-800/50 text-xs flex justify-between items-center text-blue-100">
            <span>Available Balance:</span>
            <strong className="text-white text-sm">
              {USD_SYMBOL}
              {formatUsdNumber(user.balance)} {USD_CODE}
            </strong>
          </div>

          <button
            type="submit"
            disabled={transferLoading || isFrozen}
            className="w-full py-3.5 bg-[#c8102e] hover:bg-[#a50d26] disabled:opacity-50 text-white font-bold rounded-xl text-sm shadow-lg transition-all flex items-center justify-center gap-2"
          >
            <Send className="w-4 h-4" />
            <span>
              {transferLoading
                ? 'Authorizing Transfer...'
                : isIntl
                ? 'Authorize International Wire'
                : 'Confirm & Execute Transfer'}
            </span>
          </button>
        </form>
      </div>
    );
  };

  // Monthly loan estimate
  const parsedLoanAmt = Math.max(500, parseFloat(loanAmount) || 0);
  const annualApr = 0.068;
  const monthlyRate = annualApr / 12;
  const estimatedMonthlyPayment =
    (parsedLoanAmt * monthlyRate) / (1 - Math.pow(1 + monthlyRate, -loanTermMonths));

  return (
    <div className="min-h-screen w-full max-w-full overflow-x-hidden bg-[#040f21] text-white font-['Plus_Jakarta_Sans',sans-serif] flex flex-col">
      {/* ================= TOP NAVIGATION ================= */}
      <header className="sticky top-0 z-40 h-16 bg-[#061428]/95 backdrop-blur-md border-b border-blue-900/60 px-3 sm:px-6 flex items-center justify-between gap-3">
        {/* Left: Sidebar Toggle + Brand Identification */}
        <div className="flex items-center gap-2.5 sm:gap-3 min-w-0">
          <button
            type="button"
            onClick={() => {
              if (window.innerWidth < 1024) {
                setMobileSidebarOpen(prev => !prev);
              } else {
                setDesktopSidebarOpen(prev => !prev);
              }
            }}
            aria-label="Toggle Menu"
            className="w-10 h-10 rounded-xl bg-[#0d2240] hover:bg-[#133059] border border-blue-800/60 flex items-center justify-center text-white transition-colors shrink-0"
          >
            <Menu className="w-5 h-5" />
          </button>

          <button
            type="button"
            onClick={() => handleSelectNavTab('overview')}
            className="flex items-center gap-2.5 text-left min-w-0"
          >
            <div className="w-9 h-9 rounded-xl bg-white p-1 flex items-center justify-center shadow shrink-0">
              <img
                src="/assets/aistudio/file_00000000763081f4a6c9438dcd4940cf_665e4923.png"
                alt="First National Bank Logo"
                className="w-full h-full object-contain"
              />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <span className="font-black text-sm sm:text-base tracking-tight text-white truncate">
                  First National Bank
                </span>
              </div>
              <span className="text-[10px] text-blue-300/70 hidden sm:block truncate">
                Personal Online Banking • USD ({USD_CODE})
              </span>
            </div>
          </button>
        </div>

        {/* Right: Dashboard shortcut icon, Language selector, Notification bell with count */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={() => handleSelectNavTab('overview')}
            title="Dashboard Overview"
            aria-label="Dashboard Shortcut"
            className={`w-9 h-9 rounded-xl border flex items-center justify-center transition-colors ${
              activeTab === 'overview'
                ? 'bg-[#c8102e] border-[#c8102e] text-white'
                : 'bg-[#0d2240] hover:bg-[#133059] border-blue-800/60 text-blue-100'
            }`}
          >
            <LayoutDashboard className="w-4 h-4" />
          </button>

          <LanguageToggle variant="navy" />

          <button
            type="button"
            onClick={() => handleSelectNavTab('notifications')}
            title="Notifications Centre"
            aria-label="Notifications"
            className={`relative w-9 h-9 rounded-xl border flex items-center justify-center transition-colors ${
              activeTab === 'notifications'
                ? 'bg-[#c8102e] border-[#c8102e] text-white'
                : 'bg-[#0d2240] hover:bg-[#133059] border-blue-800/60 text-blue-100'
            }`}
          >
            <Bell className="w-4 h-4" />
            {unreadNotifsCount > 0 && (
              <span className="absolute -top-1.5 -right-1.5 min-w-[18px] h-[18px] px-1 bg-[#c8102e] border border-[#061428] text-white text-[10px] font-black rounded-full flex items-center justify-center">
                {unreadNotifsCount > 99 ? '99+' : unreadNotifsCount}
              </span>
            )}
          </button>
        </div>
      </header>

      {/* ================= SHELL: LEFT SIDEBAR + MAIN CANVAS ================= */}
      <div className="flex-1 flex relative min-w-0">
        {/* Mobile Backdrop */}
        {mobileSidebarOpen && (
          <div
            className="fixed inset-0 z-40 bg-black/70 backdrop-blur-xs lg:hidden"
            onClick={() => setMobileSidebarOpen(false)}
          />
        )}

        {/* Left Sidebar Navigation (20 items vertically with category separators + red Logout button) */}
        <aside
          aria-label="Customer Dashboard Navigation"
          className={`fixed lg:sticky top-16 left-0 z-50 lg:z-30 h-[calc(100vh-4rem)] w-72 bg-[#071630] border-r border-blue-900/60 flex flex-col transition-all duration-200 shrink-0 ${
            mobileSidebarOpen ? 'translate-x-0' : '-translate-x-full'
          } ${desktopSidebarOpen ? 'lg:translate-x-0' : 'lg:hidden'}`}
        >
          {/* Mobile Drawer Header */}
          <div className="flex items-center justify-between px-4 py-3 border-b border-blue-900/50 lg:hidden">
            <span className="text-xs font-black uppercase tracking-wider text-blue-200">Navigation Menu</span>
            <button
              type="button"
              onClick={() => setMobileSidebarOpen(false)}
              className="p-1.5 rounded-lg bg-[#0d2240] text-blue-200"
              aria-label="Close Menu"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto px-3 py-4 space-y-4">
            {sidebarCategories.map((group, gIdx) => (
              <div key={group.groupTitle}>
                {gIdx > 0 && <div className="my-3 border-t border-blue-900/60" />}
                <p className="px-3 mb-1.5 text-[10px] font-bold uppercase tracking-widest text-blue-300/60">
                  {group.groupTitle}
                </p>
                <div className="space-y-1">
                  {group.items.map(item => {
                    const Icon = item.icon;
                    const isActive = activeTab === item.id;
                    return (
                      <button
                        key={item.id}
                        type="button"
                        onClick={() => handleSelectNavTab(item.id)}
                        className={`w-full px-3 py-2.5 rounded-xl text-xs font-semibold flex items-center justify-between gap-2 transition-all text-left ${
                          isActive
                            ? 'bg-gradient-to-r from-[#12396f] to-[#0d2c59] text-white border border-blue-500/40 shadow-md font-bold'
                            : 'text-blue-100/80 hover:text-white hover:bg-[#0d2240]/80'
                        }`}
                      >
                        <div className="flex items-center gap-2.5 min-w-0">
                          <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-red-400' : 'text-blue-300/80'}`} />
                          <span className="truncate">{item.label}</span>
                        </div>
                        {item.badge !== undefined && item.badge > 0 && (
                          <span className="px-1.5 py-0.5 rounded-full bg-[#c8102e] text-white text-[10px] font-black shrink-0">
                            {item.badge}
                          </span>
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>

          {/* Separator + 20. Prominent Red Logout Button at bottom of Sidebar */}
          <div className="p-3 border-t border-blue-900/60 bg-[#061329]">
            <button
              type="button"
              onClick={handleLogoutClick}
              disabled={loggingOut}
              className="w-full py-3 px-4 rounded-xl bg-[#c8102e] hover:bg-[#a50d26] disabled:opacity-60 text-white font-bold text-xs shadow-lg transition-all flex items-center justify-center gap-2"
            >
              <LogOut className="w-4 h-4" />
              <span>{loggingOut ? 'Signing Out...' : 'Logout'}</span>
            </button>
          </div>
        </aside>

        {/* ================= MAIN WORKSPACE AREA ================= */}
        <main className="flex-1 min-w-0 p-3 sm:p-6 lg:p-8 space-y-6 max-w-6xl mx-auto w-full">
          {/* Frozen Account Warning */}
          {isFrozen && (
            <div className="p-4 bg-red-950/70 border border-red-700/70 rounded-2xl flex items-center gap-3 text-red-200 text-xs sm:text-sm shadow-lg">
              <ShieldAlert className="w-5 h-5 text-red-400 shrink-0" />
              <div className="flex-1">
                <strong>Account Frozen for Security:</strong> Outbound transactions and transfers are temporarily paused. Contact client relations at{' '}
                <a href="tel:+12724736857" className="underline font-bold">
                  +12724736857
                </a>{' '}
                to reactivate.
              </div>
            </div>
          )}

          {/* Welcome Section Card */}
          <section className="rounded-3xl p-5 sm:p-7 bg-gradient-to-r from-[#0a2348] via-[#0b2854] to-[#081c3a] border border-blue-800/50 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-5">
            <div className="flex items-center gap-4 min-w-0">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-[#c8102e] to-[#0f3d7a] text-white font-black text-xl flex items-center justify-center shadow-lg shrink-0 border border-white/15">
                {user.firstName?.[0] || 'F'}
                {user.lastName?.[0] || 'N'}
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight">
                    Welcome back, {user.firstName}
                  </h1>
                  <span
                    className={`px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider ${
                      user.status === 'active'
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                        : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                    }`}
                  >
                    {user.status}
                  </span>
                  <span
                    className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                      user.kycStatus === 'verified'
                        ? 'bg-blue-500/20 text-blue-200 border border-blue-400/40'
                        : 'bg-slate-800/70 text-slate-300 border border-slate-600/50'
                    }`}
                  >
                    KYC: {user.kycStatus || 'Unverified'}
                  </span>
                </div>
                <p className="text-xs text-blue-200/80 mt-1 font-mono">
                  Account: <strong className="text-white">{user.accountNumber || 'PENDING'}</strong> • Sort Code:{' '}
                  <strong className="text-white">{user.sortCode || '20-04-15'}</strong> • Currency: {USD_CODE} ({USD_SYMBOL})
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2.5 flex-wrap shrink-0">
              <button
                type="button"
                onClick={() => handleSelectNavTab('notifications')}
                className="px-3.5 py-2 rounded-xl bg-[#07152b] hover:bg-[#10294d] border border-blue-800/60 text-xs font-bold text-blue-100 flex items-center gap-2 transition-colors"
              >
                <Bell className="w-4 h-4 text-blue-300" />
                <span>Alerts</span>
                {unreadNotifsCount > 0 && (
                  <span className="px-1.5 py-0.2 rounded-full bg-[#c8102e] text-white text-[10px] font-black">
                    {unreadNotifsCount}
                  </span>
                )}
              </button>
              <button
                type="button"
                onClick={() => setIsStatementOpen(true)}
                className="px-3.5 py-2 rounded-xl bg-[#c8102e] hover:bg-[#a50d26] text-white text-xs font-bold flex items-center gap-1.5 shadow transition-colors"
              >
                <FileSpreadsheet className="w-4 h-4" />
                <span>Statement</span>
              </button>
            </div>
          </section>

          {/* 3 Horizontal Main Dashboard Tabs: Overview | My Account | Investments */}
          <div className="bg-[#071630] rounded-2xl p-1.5 border border-blue-900/60 shadow-md overflow-x-auto">
            <div className="flex items-center gap-1.5 min-w-max">
              {[
                { id: 'overview' as DashboardTab, label: 'Overview', icon: Layers },
                { id: 'account' as DashboardTab, label: 'My Account', icon: Building2 },
                { id: 'investments' as DashboardTab, label: 'Investments', icon: TrendingUp },
              ].map(tab => {
                const Icon = tab.icon;
                const isSelected = activeTab === tab.id;
                return (
                  <button
                    key={tab.id}
                    type="button"
                    onClick={() => handleSelectNavTab(tab.id)}
                    className={`px-5 py-2.5 rounded-xl text-xs font-bold flex items-center gap-2 transition-all ${
                      isSelected
                        ? 'bg-[#c8102e] text-white shadow-lg'
                        : 'text-blue-200/80 hover:text-white hover:bg-[#0d2240]'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                    <span>{tab.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* ================= 1. CUSTOMER MENU HUB VIEW ================= */}
          {activeTab === 'customer_menu' && (
            <div className="space-y-6">
              <div className={`${NAVY_CARD} p-6 sm:p-8`}>
                <div className="flex items-center justify-between gap-4 mb-6">
                  <div>
                    <h2 className="text-xl font-bold text-white">Customer Services Menu</h2>
                    <p className="text-xs text-blue-200/75 mt-1">Direct access to every banking tool, payment channel, and security control</p>
                  </div>
                  <span className="px-2.5 py-1 rounded-lg bg-blue-900/50 border border-blue-700/50 text-[10px] font-bold text-blue-200 uppercase">
                    ACCOUNT SERVICES
                  </span>
                </div>

                <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {sidebarCategories.flatMap(g => g.items).filter(i => i.id !== 'customer_menu').map(item => {
                    const Icon = item.icon;
                    return (
                      <button
                        key={item.id}
                        type="button"
                        onClick={() => handleSelectNavTab(item.id)}
                        className="p-4 rounded-2xl bg-[#07152b] hover:bg-[#0e2a54] border border-blue-800/40 flex items-center justify-between gap-3 text-left transition-all group"
                      >
                        <div className="flex items-center gap-3 min-w-0">
                          <div className="w-10 h-10 rounded-xl bg-[#0e3266] text-blue-200 flex items-center justify-center shrink-0 group-hover:bg-[#c8102e] group-hover:text-white transition-colors">
                            <Icon className="w-5 h-5" />
                          </div>
                          <span className="font-bold text-xs sm:text-sm text-white truncate">{item.label}</span>
                        </div>
                        <ChevronRight className="w-4 h-4 text-blue-400 shrink-0" />
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {/* ================= 2. OVERVIEW TAB ================= */}
          {activeTab === 'overview' && (
            <div className="space-y-6">
              {/* Premium Blue Gradient Account Overview Card */}
              <div className="relative overflow-hidden rounded-3xl p-6 sm:p-8 bg-gradient-to-br from-[#0e3c7a] via-[#092b5a] to-[#051836] border border-blue-500/30 shadow-2xl">
                <div className="flex items-center justify-between text-xs text-blue-100 mb-3">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-bold uppercase tracking-wider text-blue-200">Available Balance</span>
                    <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-bold text-[10px] uppercase">
                      {user.accountType || 'Personal Checking'}
                    </span>
                    <span className="px-2 py-0.5 rounded-md bg-white/10 text-blue-100 text-[10px] font-bold">
                      {USD_CODE} ({USD_SYMBOL})
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setBalanceVisible(!balanceVisible)}
                    className="p-2 rounded-xl bg-white/10 hover:bg-white/20 transition-colors"
                    aria-label={balanceVisible ? 'Hide balance' : 'Show balance'}
                  >
                    {balanceVisible ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>

                <div className="my-3">
                  <div className="text-4xl sm:text-5xl font-black tracking-tight text-white">
                    {balanceVisible ? `${USD_SYMBOL}${formatUsdNumber(user.balance)}` : '••••••••'}
                  </div>
                  <p className="text-xs text-blue-200/80 mt-1 font-medium">
                    Account Reference:{' '}
                    <span className="font-mono text-white">{user.accountNumber || 'PENDING'}</span> • Ledger Currency: US Dollars ({USD_CODE} {USD_SYMBOL})
                  </p>
                </div>

                <div className="pt-5 mt-5 border-t border-white/15 grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs">
                  <div>
                    <span className="text-blue-200/70 block text-[10px] uppercase">Account Number</span>
                    <div className="flex items-center gap-1.5 font-mono font-bold text-white mt-0.5">
                      <span className="truncate">{user.accountNumber || 'PENDING'}</span>
                      <button type="button" onClick={handleCopyAcc} className="text-blue-200 hover:text-white shrink-0" aria-label="Copy account number">
                        {copiedAcc ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                  </div>
                  <div>
                    <span className="text-blue-200/70 block text-[10px] uppercase">Account Type</span>
                    <span className="font-bold text-white block mt-0.5">{user.accountType || 'Checking'}</span>
                  </div>
                  <div>
                    <span className="text-blue-200/70 block text-[10px] uppercase">Currency</span>
                    <span className="font-bold text-white block mt-0.5">USD ({USD_SYMBOL})</span>
                  </div>
                  <div>
                    <span className="text-blue-200/70 block text-[10px] uppercase">Account Status</span>
                    <span className="font-bold text-emerald-300 uppercase block mt-0.5">{user.status}</span>
                  </div>
                </div>
              </div>

              {/* 4 Quick Actions */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                {[
                  { label: 'Send Transfer', sub: 'Domestic & Wire', icon: Send, action: () => handleSelectNavTab('transfers'), accent: 'bg-[#c8102e] text-white' },
                  { label: 'Investments', sub: 'Wealth Plans', icon: TrendingUp, action: () => handleSelectNavTab('investments'), accent: 'bg-blue-600 text-white' },
                  { label: 'Account Statements', sub: 'Print & Export', icon: FileSpreadsheet, action: () => handleSelectNavTab('statements'), accent: 'bg-emerald-600 text-white' },
                  { label: 'Customer Support', sub: '24/7 Client Desk', icon: MessageSquare, action: () => handleSelectNavTab('support'), accent: 'bg-amber-600 text-white' },
                ].map((act, idx) => {
                  const Icon = act.icon;
                  return (
                    <button
                      key={idx}
                      type="button"
                      onClick={act.action}
                      className="p-4 bg-[#0a1d3a] hover:bg-[#0f2950] border border-blue-800/40 rounded-2xl shadow-md transition-all text-left flex items-center gap-3 group"
                    >
                      <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 shadow ${act.accent}`}>
                        <Icon className="w-5 h-5" />
                      </div>
                      <div className="min-w-0">
                        <h4 className="font-bold text-xs text-white truncate">{act.label}</h4>
                        <span className="text-[10px] text-blue-200/70 block truncate">{act.sub}</span>
                      </div>
                    </button>
                  );
                })}
              </div>

              {/* Recent Transactions Panel */}
              <div className={`${NAVY_CARD} p-6 sm:p-8`}>
                <div className="flex items-center justify-between mb-5">
                  <div>
                    <h3 className="text-lg font-bold text-white">Recent Transactions</h3>
                    <p className="text-xs text-blue-200/70">Recorded ledger entries in US Dollars ({USD_CODE})</p>
                  </div>
                  <button
                    type="button"
                    onClick={() => handleSelectNavTab('transactions')}
                    className="text-xs font-bold text-red-400 hover:text-red-300 hover:underline"
                  >
                    View All ({transactions.length})
                  </button>
                </div>

                {transactions.length === 0 ? (
                  <div className="text-center py-10 text-blue-200/60 text-xs">
                    {loading ? 'Loading recent activity...' : 'No transaction records found.'}
                  </div>
                ) : (
                  <div className="divide-y divide-blue-900/50">
                    {transactions.slice(0, 5).map(tx => (
                      <div key={tx.id} className="py-3.5 flex items-center justify-between gap-4">
                        <div className="flex items-center gap-3 min-w-0">
                          <div
                            className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                              tx.type === 'credit' || tx.type === 'reversal'
                                ? 'bg-emerald-500/20 text-emerald-400'
                                : 'bg-rose-500/20 text-rose-400'
                            }`}
                          >
                            {tx.type === 'credit' || tx.type === 'reversal' ? (
                              <ArrowDownLeft className="w-5 h-5" />
                            ) : (
                              <ArrowUpRight className="w-5 h-5" />
                            )}
                          </div>
                          <div className="min-w-0">
                            <div className="flex flex-wrap items-center gap-2">
                              <p className="font-bold text-xs sm:text-sm text-white truncate">{tx.description}</p>
                              <TransactionTagBadge
                                tag={tx.tag || tagTransaction(tx.description, tx.type, tx.billerCategory).tag}
                                showIcon
                              />
                            </div>
                            <div className="flex items-center gap-2 text-[11px] text-blue-200/60 mt-0.5 font-mono">
                              <span>{tx.reference}</span>
                              <span>•</span>
                              <span>{new Date(tx.createdAt).toLocaleDateString('en-US')}</span>
                            </div>
                          </div>
                        </div>

                        <div className="text-right shrink-0">
                          <p
                            className={`font-black text-xs sm:text-sm ${
                              tx.type === 'credit' || tx.type === 'reversal' ? 'text-emerald-400' : 'text-white'
                            }`}
                          >
                            {tx.type === 'credit' || tx.type === 'reversal' ? '+' : '-'}
                            {USD_SYMBOL}
                            {formatUsdNumber(tx.amount)}
                          </p>
                          <button
                            type="button"
                            onClick={() => setActiveReceiptTx(tx)}
                            className="text-[10px] text-blue-300 hover:text-white font-semibold"
                          >
                            Receipt
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* 2 Bottom Dashboard Cards: Customer Support & My Profile */}
              <div className="grid md:grid-cols-2 gap-6">
                {/* Bottom Card 1: Customer Support */}
                <div className={`${NAVY_CARD} p-6 flex flex-col justify-between space-y-5`}>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-[#c8102e] text-white flex items-center justify-center">
                          <MessageSquare className="w-5 h-5" />
                        </div>
                        <div>
                          <h3 className="font-bold text-base text-white">Customer Support</h3>
                          <p className="text-xs text-blue-200/75">Dedicated 24/7 Client Assistance</p>
                        </div>
                      </div>
                    </div>

                    <div className={`${NAVY_SUBCARD} p-4 space-y-2.5 text-xs`}>
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-blue-200/70 flex items-center gap-1.5">
                          <Phone className="w-3.5 h-3.5 text-red-400" /> Telephone / WhatsApp:
                        </span>
                        <a href="tel:+12724736857" className="font-mono font-bold text-white hover:underline">
                          +12724736857
                        </a>
                      </div>
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-blue-200/70 flex items-center gap-1.5">
                          <Mail className="w-3.5 h-3.5 text-red-400" /> Support Email:
                        </span>
                        <a href="mailto:info@fnnbbankss.online" className="font-semibold text-white hover:underline truncate">
                          info@fnnbbankss.online
                        </a>
                      </div>
                      <div className="flex items-start justify-between gap-2">
                        <span className="text-blue-200/70 flex items-center gap-1.5 shrink-0">
                          <MapPin className="w-3.5 h-3.5 text-red-400" /> Head Office:
                        </span>
                        <span className="text-blue-100 text-right">13586 US-90, Boutte, LA 70039, United States</span>
                      </div>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => handleSelectNavTab('support')}
                    className="w-full py-2.5 bg-[#c8102e] hover:bg-[#a50d26] text-white font-bold rounded-xl text-xs shadow transition-colors"
                  >
                    Open Support & Ticket Centre
                  </button>
                </div>

                {/* Bottom Card 2: My Profile (Strictly Read-Only Summary) */}
                <div className={`${NAVY_CARD} p-6 flex flex-col justify-between space-y-5`}>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-[#12396f] text-white flex items-center justify-center">
                          <UserIcon className="w-5 h-5" />
                        </div>
                        <div>
                          <h3 className="font-bold text-base text-white">My Profile</h3>
                          <p className="text-xs text-blue-200/75">Verified Customer Record (Read-Only)</p>
                        </div>
                      </div>
                      <span className="px-2 py-0.5 rounded-full bg-blue-900/70 border border-blue-700/50 text-[10px] font-bold text-blue-200 flex items-center gap-1">
                        <Lock className="w-3 h-3" /> Locked
                      </span>
                    </div>

                    <div className={`${NAVY_SUBCARD} p-4 space-y-2.5 text-xs`}>
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-blue-200/70">Full Name:</span>
                        <strong className="text-white text-right">
                          {user.firstName} {user.lastName}
                        </strong>
                      </div>
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-blue-200/70">Registered Email:</span>
                        <strong className="text-white text-right truncate">{user.email}</strong>
                      </div>
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-blue-200/70">Contact Phone:</span>
                        <strong className="text-white text-right font-mono">{user.phone || 'Not Assigned'}</strong>
                      </div>
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-blue-200/70">Account Number:</span>
                        <strong className="text-white text-right font-mono">{user.accountNumber || 'PENDING'}</strong>
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2.5">
                    <button
                      type="button"
                      onClick={() => handleSelectNavTab('profile')}
                      className="py-2.5 bg-[#0e3266] hover:bg-[#144387] text-white font-bold rounded-xl text-xs transition-colors"
                    >
                      View Full Profile
                    </button>
                    <button
                      type="button"
                      onClick={() => handleSelectNavTab('settings')}
                      className="py-2.5 bg-[#07152b] hover:bg-[#0d2447] border border-blue-800/60 text-blue-100 font-bold rounded-xl text-xs transition-colors"
                    >
                      Security & PIN
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ================= 3. MY ACCOUNT TAB ================= */}
          {activeTab === 'account' && (
            <div className={`${NAVY_CARD} p-6 sm:p-8 space-y-6`}>
              <div>
                <h2 className="text-xl font-bold text-white">My Account Details</h2>
                <p className="text-xs text-blue-200/75">Account credentials, routing details, and client support contacts</p>
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <div className={`${NAVY_SUBCARD} p-6 space-y-4`}>
                  <h3 className="font-bold text-sm text-blue-200 border-b border-blue-800/50 pb-2">
                    Account Information
                  </h3>
                  <div className="flex justify-between items-center text-xs gap-4">
                    <span className="text-blue-200/70">Account Holder:</span>
                    <strong className="text-white text-right">
                      {user.fullName || `${user.firstName} ${user.lastName}`}
                    </strong>
                  </div>
                  <div className="flex justify-between items-center text-xs gap-4">
                    <span className="text-blue-200/70">10-Digit Account Number:</span>
                    <div className="flex items-center gap-1.5 font-mono font-bold text-white">
                      <span>{user.accountNumber || 'PENDING'}</span>
                      <button type="button" onClick={handleCopyAcc} className="text-blue-300 hover:text-white" aria-label="Copy account number">
                        {copiedAcc ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                  </div>
                  <div className="flex justify-between items-center text-xs gap-4">
                    <span className="text-blue-200/70">Sort Code:</span>
                    <strong className="font-mono text-white">{user.sortCode || '20-04-15'}</strong>
                  </div>
                  <div className="flex justify-between items-center text-xs gap-4">
                    <span className="text-blue-200/70">Account Type:</span>
                    <span className="font-semibold text-white">{user.accountType || 'Personal Checking'}</span>
                  </div>
                  <div className="flex justify-between items-center text-xs gap-4">
                    <span className="text-blue-200/70">Currency:</span>
                    <span className="font-semibold text-white">USD ($)</span>
                  </div>
                </div>

                <div className={`${NAVY_SUBCARD} p-6 space-y-4`}>
                  <h3 className="font-bold text-sm text-blue-200 border-b border-blue-800/50 pb-2">
                    Branch & Regulatory Information
                  </h3>
                  <div className="flex justify-between items-center text-xs gap-4">
                    <span className="text-blue-200/70">Financial Institution:</span>
                    <strong className="text-white text-right">First National Bank (FNB)</strong>
                  </div>
                  <div className="flex justify-between items-center text-xs gap-4">
                    <span className="text-blue-200/70">Branch Location:</span>
                    <span className="text-white text-right">13586 US-90, Boutte, LA 70039, United States</span>
                  </div>
                  <div className="flex justify-between items-center text-xs gap-4">
                    <span className="text-blue-200/70">Account Tier:</span>
                    <span className="font-bold text-emerald-400">
                      {user.kycStatus === 'verified' ? 'Tier-1 Verified' : 'Standard Account'}
                    </span>
                  </div>
                  <div className="flex justify-between items-center text-xs gap-4">
                    <span className="text-blue-200/70">Telephone Helpline:</span>
                    <a href="tel:+12724736857" className="font-semibold text-white hover:underline">
                      +12724736857
                    </a>
                  </div>
                  <div className="flex justify-between items-center text-xs gap-4">
                    <span className="text-blue-200/70">Official Email:</span>
                    <a href="mailto:info@fnnbbankss.online" className="text-white hover:underline">
                      info@fnnbbankss.online
                    </a>
                  </div>
                </div>
              </div>

              {/* Transaction PIN Menu Option under My Account */}
              <div className="pt-2 border-t border-blue-800/50 space-y-4">
                <div className={`${NAVY_SUBCARD} p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4`}>
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-xl bg-[#12396f] text-white flex items-center justify-center shrink-0">
                      <KeyRound className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <h3 className="font-bold text-sm text-white">Transaction PIN</h3>
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                            user.pinLockedUntil && Date.now() < user.pinLockedUntil
                              ? 'bg-red-500/20 text-red-300'
                              : user.hasTransactionPin
                              ? 'bg-emerald-500/20 text-emerald-300'
                              : 'bg-amber-500/20 text-amber-300'
                          }`}
                        >
                          {user.pinLockedUntil && Date.now() < user.pinLockedUntil
                            ? 'Temporarily Locked'
                            : user.hasTransactionPin
                            ? `${user.transactionPinLength || 4}-Digit Active`
                            : 'Not Set'}
                        </span>
                      </div>
                      <p className="text-xs text-blue-200/75 mt-0.5">
                        Create, change, or recover the numeric security PIN required to authorize account transactions.
                      </p>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      setPinManagerMode('auto');
                      setShowAccountPinManager(prev => !prev);
                    }}
                    className="px-4 py-2 rounded-xl bg-[#c8102e] hover:bg-[#a50d26] text-white font-bold text-xs shadow-sm transition-colors shrink-0 self-start sm:self-center"
                  >
                    {showAccountPinManager
                      ? 'Hide Transaction PIN'
                      : user.hasTransactionPin
                      ? 'Manage Transaction PIN'
                      : 'Set Up Transaction PIN'}
                  </button>
                </div>

                {showAccountPinManager && (
                  <TransactionPinManager
                    theme="navy"
                    user={user}
                    initialMode={pinManagerMode}
                    onPinUpdated={async () => {
                      await refreshUser(false);
                    }}
                    onOpenMailbox={() => setIsMailModalOpen(true)}
                  />
                )}
              </div>
            </div>
          )}

          {/* ================= 4. INVESTMENTS TAB ================= */}
          {activeTab === 'investments' && (
            <div className="space-y-6">
              <div className={`${NAVY_CARD} p-6 sm:p-8`}>
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-10 h-10 bg-[#c8102e] text-white rounded-xl flex items-center justify-center">
                    <TrendingUp className="w-5 h-5" />
                  </div>
                  <div>
                    <h2 className="text-xl font-bold text-white">Portfolio Investment Allocation</h2>
                    <p className="text-xs text-blue-200/75">
                      Allocate available funds into an institutional investment plan in US Dollars ({USD_CODE}).
                    </p>
                  </div>
                </div>

                {invSuccessMsg && (
                  <div className="mb-6 p-4 bg-emerald-950/60 border border-emerald-700/60 rounded-2xl text-xs text-emerald-200 flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5 text-emerald-400" />
                    <span>{invSuccessMsg}</span>
                  </div>
                )}

                {invErrorMsg && (
                  <div className="mb-6 p-4 bg-red-950/60 border border-red-700/60 rounded-2xl text-xs text-red-200 flex items-start gap-2">
                    <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-red-400" />
                    <span>{invErrorMsg}</span>
                  </div>
                )}

                <form onSubmit={handleInvestmentSubmit} className="space-y-6">
                  <div>
                    <label className="block text-xs font-bold text-blue-200 uppercase tracking-wider mb-2">
                      Choose Investment Strategy
                    </label>
                    <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
                      {INVESTMENT_PLANS.map(plan => {
                        const isSel = plan.id === selectedPlanId;
                        return (
                          <button
                            key={plan.id}
                            type="button"
                            onClick={() => {
                              setSelectedPlanId(plan.id);
                              if (parseFloat(invAmount) < plan.minimumAmount) {
                                setInvAmount(plan.minimumAmount.toString());
                              }
                            }}
                            className={`p-4 rounded-2xl border text-left transition-all ${
                              isSel
                                ? 'border-red-500 bg-[#113163] ring-2 ring-red-500/30'
                                : 'border-blue-800/40 bg-[#07152b] hover:border-blue-600/60'
                            }`}
                          >
                            <span className="text-[10px] font-bold text-blue-300/70 block mb-1 uppercase">{plan.riskLevel}</span>
                            <h4 className="font-bold text-xs text-white mb-2 leading-tight">
                              {plan.name.replace(' (Simulated)', '')}
                            </h4>
                            <span className="text-sm font-black text-emerald-400 block">+{plan.annualReturnRate}% p.a.</span>
                            <span className="text-[10px] text-blue-200/70 mt-1 block">
                              Min: {USD_SYMBOL}
                              {plan.minimumAmount.toLocaleString('en-US')}
                            </span>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  <div className="grid sm:grid-cols-2 gap-4">
                    <div>
                      <label className={NAVY_LABEL}>Capital to Allocate (USD $)</label>
                      <input
                        type="number"
                        required
                        value={invAmount}
                        onChange={e => setInvAmount(e.target.value)}
                        className={NAVY_INPUT}
                      />
                    </div>

                    <div>
                      <label className={NAVY_LABEL}>Duration (Months)</label>
                      <select
                        value={invDuration}
                        onChange={e => setInvDuration(parseInt(e.target.value, 10))}
                        className={NAVY_INPUT}
                      >
                        <option value={3}>3 Months</option>
                        <option value={6}>6 Months</option>
                        <option value={12}>12 Months (Recommended)</option>
                        <option value={24}>24 Months</option>
                        <option value={36}>36 Months</option>
                      </select>
                    </div>
                  </div>

                  <div className={`${NAVY_SUBCARD} p-4 text-xs flex justify-between items-center`}>
                    <div>
                      <span className="text-blue-200/70 block">Projected Return</span>
                      <strong className="text-emerald-400 text-sm">
                        +{USD_SYMBOL}
                        {formatUsdNumber(
                          parseFloat(invAmount || '0') *
                            ((INVESTMENT_PLANS.find(p => p.id === selectedPlanId)?.annualReturnRate || 7.2) / 100) *
                            (invDuration / 12)
                        )}{' '}
                        {USD_CODE}
                      </strong>
                    </div>
                    <div className="text-right">
                      <span className="text-blue-200/70 block">Available Balance</span>
                      <strong className="text-white">
                        {USD_SYMBOL}
                        {formatUsdNumber(user.balance)} {USD_CODE}
                      </strong>
                    </div>
                  </div>

                  <div className="flex items-start gap-2">
                    <input
                      type="checkbox"
                      id="invConsent"
                      checked={invTermsAccepted}
                      onChange={e => setInvTermsAccepted(e.target.checked)}
                      className="mt-1"
                    />
                    <label htmlFor="invConsent" className="text-xs text-blue-200/80">
                      I confirm the investment terms. Upon submission, an investment reference (<code>INV-...</code>) will be logged and reviewed by administration.
                    </label>
                  </div>

                  <button
                    type="submit"
                    disabled={invLoading || !invTermsAccepted || isFrozen}
                    className="w-full py-3 bg-[#c8102e] hover:bg-[#a50d26] disabled:opacity-50 text-white font-bold rounded-xl text-sm shadow-md transition-all flex items-center justify-center gap-2"
                  >
                    <TrendingUp className="w-4 h-4" />
                    <span>{invLoading ? 'Submitting Allocation...' : 'Submit Investment Request'}</span>
                  </button>
                </form>
              </div>

              <div className={`${NAVY_CARD} p-6 sm:p-8`}>
                <h3 className="text-lg font-bold text-white mb-4">My Investment Requests</h3>
                {investments.length === 0 ? (
                  <p className="text-xs text-blue-200/60 py-6 text-center">No investment requests submitted yet.</p>
                ) : (
                  <div className="divide-y divide-blue-900/50">
                    {investments.map(inv => (
                      <div key={inv.id} className="py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
                        <div>
                          <div className="flex items-center gap-2">
                            <strong className="font-bold text-white">{inv.planName}</strong>
                            <span
                              className={`px-2 py-0.5 rounded-full font-bold uppercase text-[9px] ${
                                inv.status === 'active' || inv.status === 'approved'
                                  ? 'bg-emerald-500/20 text-emerald-300'
                                  : inv.status === 'rejected'
                                  ? 'bg-red-500/20 text-red-300'
                                  : 'bg-amber-500/20 text-amber-300'
                              }`}
                            >
                              {inv.status.replace('_', ' ')}
                            </span>
                          </div>
                          <p className="text-blue-200/70 mt-0.5">
                            Ref: <span className="font-mono">{inv.reference}</span> • Duration: {inv.durationMonths} Months • Projected: +
                            {USD_SYMBOL}
                            {formatUsdNumber(inv.projectedReturnAmount)} {USD_CODE}
                          </p>
                        </div>
                        <div className="sm:text-right">
                          <span className="font-black text-sm text-white">
                            {USD_SYMBOL}
                            {formatUsdNumber(inv.amount)} {USD_CODE}
                          </span>
                          <span className="block text-[10px] text-blue-200/60">
                            {new Date(inv.createdAt).toLocaleDateString('en-US')}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* ================= 5. FUND TRANSFERS & INTERNATIONAL PAYMENTS ================= */}
          {(activeTab === 'transfers' || activeTab === 'international') && renderTransferForm()}

          {/* ================= 6. BENEFICIARY MANAGEMENT ================= */}
          {activeTab === 'beneficiaries' && (
            <div className="space-y-6">
              <div className={`${NAVY_CARD} p-6 sm:p-8 space-y-6`}>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-[#c8102e] text-white flex items-center justify-center">
                    <Users className="w-5 h-5" />
                  </div>
                  <div>
                    <h2 className="text-xl font-bold text-white">Beneficiary Management</h2>
                    <p className="text-xs text-blue-200/75">Save verified domestic and international payees for rapid transfers</p>
                  </div>
                </div>

                {beneficiaryMsg && (
                  <div className="p-3.5 rounded-xl bg-emerald-950/60 border border-emerald-700/60 text-xs text-emerald-200 flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span>{beneficiaryMsg}</span>
                  </div>
                )}

                <form onSubmit={handleAddBeneficiary} className={`${NAVY_SUBCARD} p-5 space-y-4`}>
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <Plus className="w-4 h-4 text-red-400" />
                    <span>Add New Beneficiary</span>
                  </h3>
                  <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    <div>
                      <label className={NAVY_LABEL}>Beneficiary Full Name *</label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. Michael Carter"
                        value={beneficiaryForm.name}
                        onChange={e => setBeneficiaryForm({ ...beneficiaryForm, name: e.target.value })}
                        className={NAVY_INPUT}
                      />
                    </div>
                    <div>
                      <label className={NAVY_LABEL}>Transfer Network</label>
                      <select
                        value={beneficiaryForm.scope}
                        onChange={e =>
                          setBeneficiaryForm({
                            ...beneficiaryForm,
                            scope: e.target.value as 'domestic' | 'international',
                          })
                        }
                        className={NAVY_INPUT}
                      >
                        <option value="domestic">Domestic Transfer</option>
                        <option value="international">International Wire (SWIFT)</option>
                      </select>
                    </div>
                    <div>
                      <label className={NAVY_LABEL}>Receiving Bank Name *</label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. JPMorgan Chase"
                        value={beneficiaryForm.bankName}
                        onChange={e => setBeneficiaryForm({ ...beneficiaryForm, bankName: e.target.value })}
                        className={NAVY_INPUT}
                      />
                    </div>
                    <div>
                      <label className={NAVY_LABEL}>Account Number / IBAN *</label>
                      <input
                        type="text"
                        required
                        placeholder="Account No. or IBAN"
                        value={beneficiaryForm.accountNumber}
                        onChange={e => setBeneficiaryForm({ ...beneficiaryForm, accountNumber: e.target.value })}
                        className={`${NAVY_INPUT} font-mono`}
                      />
                    </div>
                    <div>
                      <label className={NAVY_LABEL}>SWIFT / BIC (Optional)</label>
                      <input
                        type="text"
                        placeholder="e.g. CHASUS33XXX"
                        value={beneficiaryForm.swiftBic}
                        onChange={e => setBeneficiaryForm({ ...beneficiaryForm, swiftBic: e.target.value.toUpperCase() })}
                        className={`${NAVY_INPUT} font-mono uppercase`}
                      />
                    </div>
                    <div className="flex items-end">
                      <button
                        type="submit"
                        className="w-full py-2.5 px-4 bg-[#c8102e] hover:bg-[#a50d26] text-white font-bold rounded-xl text-xs shadow transition-colors"
                      >
                        Save Beneficiary
                      </button>
                    </div>
                  </div>
                </form>

                {derivedRecipients.length === 0 ? (
                  <p className="text-center py-8 text-xs text-blue-200/60">
                    No beneficiaries saved yet. Add one above or complete a transfer to populate recipients automatically.
                  </p>
                ) : (
                  <div className="grid sm:grid-cols-2 gap-4">
                    {derivedRecipients.map(ben => {
                      const isManuallySaved = savedBeneficiaries.some(b => b.id === ben.id);
                      return (
                        <div key={ben.id} className={`${NAVY_SUBCARD} p-4 flex items-center justify-between gap-3`}>
                          <div className="min-w-0">
                            <div className="flex items-center gap-2">
                              <strong className="text-sm font-bold text-white truncate">{ben.name}</strong>
                              <span className="px-2 py-0.5 rounded-full text-[9px] font-bold uppercase bg-blue-900/60 text-blue-200">
                                {ben.scope}
                              </span>
                            </div>
                            <p className="text-xs text-blue-200/75 truncate mt-0.5">{ben.bankName}</p>
                            <p className="text-[11px] font-mono text-blue-300/70 mt-0.5">
                              {ben.accountNumber}
                              {ben.swiftBic ? ` • ${ben.swiftBic}` : ''}
                            </p>
                          </div>
                          <div className="flex items-center gap-1.5 shrink-0">
                            <button
                              type="button"
                              onClick={() => handleUseBeneficiary(ben)}
                              className="px-3 py-1.5 rounded-lg bg-[#c8102e] hover:bg-[#a50d26] text-white text-xs font-bold"
                            >
                              Send
                            </button>
                            {isManuallySaved && (
                              <button
                                type="button"
                                onClick={() => persistBeneficiaries(savedBeneficiaries.filter(b => b.id !== ben.id))}
                                aria-label="Remove beneficiary"
                                className="p-1.5 rounded-lg text-blue-300/70 hover:text-red-400 hover:bg-red-950/40"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* ================= 7. PAYMENT HISTORY ================= */}
          {activeTab === 'payments' && (
            <div className={`${NAVY_CARD} p-6 sm:p-8 space-y-6`}>
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h2 className="text-xl font-bold text-white">Payment History</h2>
                  <p className="text-xs text-blue-200/75">All outgoing wire transfers, domestic payments, and debit settlements</p>
                </div>
                <button
                  type="button"
                  onClick={() => handleSelectNavTab('transfers')}
                  className="px-4 py-2 bg-[#c8102e] hover:bg-[#a50d26] text-white font-bold text-xs rounded-xl flex items-center gap-1.5 self-start sm:self-auto"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>New Payment</span>
                </button>
              </div>

              {paymentHistoryTxs.length === 0 ? (
                <p className="text-center py-12 text-blue-200/60 text-xs">No outgoing payments recorded yet.</p>
              ) : (
                <div className="divide-y divide-blue-900/50">
                  {paymentHistoryTxs.map(tx => (
                    <div key={tx.id} className="py-4 flex items-center justify-between gap-4 text-xs">
                      <div className="flex items-center gap-3 min-w-0">
                        <div className="w-10 h-10 rounded-xl bg-rose-500/20 text-rose-400 flex items-center justify-center shrink-0">
                          <ArrowUpRight className="w-5 h-5" />
                        </div>
                        <div className="min-w-0">
                          <p className="font-bold text-white text-sm truncate">{tx.description}</p>
                          <p className="text-blue-200/70 text-[11px] font-mono mt-0.5">
                            {tx.reference} • {tx.beneficiaryBank || 'FNB Clearing'} • {new Date(tx.createdAt).toLocaleString('en-US')}
                          </p>
                        </div>
                      </div>
                      <div className="text-right shrink-0">
                        <p className="font-black text-sm text-white">
                          -{USD_SYMBOL}
                          {formatUsdNumber(tx.amount)} {USD_CODE}
                        </p>
                        <button
                          type="button"
                          onClick={() => setActiveReceiptTx(tx)}
                          className="text-[10px] text-blue-300 hover:text-white font-bold hover:underline"
                        >
                          View Receipt
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* ================= 8. TRANSACTION HISTORY ================= */}
          {activeTab === 'transactions' && (
            <div className={`${NAVY_CARD} p-6 sm:p-8 space-y-6`}>
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h2 className="text-xl font-bold text-white">Transaction History & Ledger</h2>
                  <p className="text-xs text-blue-200/75">Filter, search, and download official receipts with automatic category tags</p>
                </div>
                <button
                  type="button"
                  onClick={() => setIsStatementOpen(true)}
                  className="px-4 py-2 bg-[#c8102e] hover:bg-[#a50d26] text-white font-bold text-xs rounded-xl flex items-center gap-2 shadow self-start sm:self-auto"
                >
                  <FileSpreadsheet className="w-4 h-4" />
                  <span>Export Statement</span>
                </button>
              </div>

              {/* Spending Breakdown by Auto-Tag */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {['Groceries', 'Utilities', 'Entertainment', 'Dining & Food'].map(cat => {
                  const catTxs = transactions.filter(
                    t =>
                      (t.tag === cat || tagTransaction(t.description, t.type, t.billerCategory).tag === cat) &&
                      (t.type === 'debit' || t.type === 'bill_payment')
                  );
                  const catTotal = catTxs.reduce((sum, t) => sum + t.amount, 0);
                  const isSelected = txFilterTag === cat;
                  return (
                    <button
                      key={cat}
                      type="button"
                      onClick={() => setTxFilterTag(prev => (prev === cat ? 'All' : cat))}
                      className={`p-3 rounded-2xl border text-left transition-all ${
                        isSelected
                          ? 'bg-[#12396f] border-red-500 ring-2 ring-red-500/20'
                          : 'bg-[#07152b] border-blue-800/40 hover:border-blue-600/60'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1.5">
                        <TransactionTagBadge tag={cat} size="sm" />
                        <span className="text-[10px] text-blue-300/70 font-semibold">{catTxs.length} txs</span>
                      </div>
                      <p className="text-sm sm:text-base font-extrabold text-white">
                        {USD_SYMBOL}
                        {formatUsdNumber(catTotal)}
                      </p>
                    </button>
                  );
                })}
              </div>

              {/* Filter Bar */}
              <div className="flex flex-col sm:flex-row gap-3">
                <div className="relative flex-1">
                  <Search className="w-4 h-4 absolute left-3 top-3 text-blue-300/60" />
                  <input
                    type="text"
                    placeholder="Search by reference, description, beneficiary, or tag..."
                    value={txSearch}
                    onChange={e => setTxSearch(e.target.value)}
                    className={`${NAVY_INPUT} pl-9`}
                  />
                </div>
                <select
                  value={txFilterType}
                  onChange={e => setTxFilterType(e.target.value)}
                  className="px-3.5 py-2.5 text-xs bg-[#041022] border border-blue-800/60 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-blue-400/50"
                >
                  <option value="all">All Types</option>
                  <option value="credit">Credits</option>
                  <option value="debit">Debits</option>
                  <option value="transfer">Transfers</option>
                  <option value="reversal">Reversals</option>
                  <option value="bill_payment">Bill Payments</option>
                </select>
              </div>

              {/* Automatic Category Tag Filters */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
                <span className="text-[11px] font-bold text-blue-200/70 uppercase tracking-wider shrink-0 mr-1 flex items-center gap-1">
                  <Tag className="w-3 h-3 text-red-400" />
                  Tag:
                </span>
                {AVAILABLE_TRANSACTION_TAGS.map(tag => {
                  const isSelected = txFilterTag === tag;
                  return (
                    <button
                      key={tag}
                      type="button"
                      onClick={() => setTxFilterTag(tag)}
                      className={`px-3 py-1 rounded-full text-xs font-semibold whitespace-nowrap transition-all ${
                        isSelected
                          ? 'bg-[#c8102e] text-white shadow-sm'
                          : 'bg-[#07152b] text-blue-200 hover:bg-[#0e2a54] border border-blue-800/40'
                      }`}
                    >
                      {tag}
                    </button>
                  );
                })}
              </div>

              {filteredTransactions.length === 0 ? (
                <p className="text-center py-12 text-blue-200/60 text-xs">No matching transactions found.</p>
              ) : (
                <div className="divide-y divide-blue-900/50">
                  {filteredTransactions.map(tx => (
                    <div key={tx.id} className="py-4 flex items-center justify-between gap-4 text-xs">
                      <div className="flex items-center gap-3 min-w-0">
                        <div
                          className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                            tx.type === 'credit' || tx.type === 'reversal'
                              ? 'bg-emerald-500/20 text-emerald-400'
                              : 'bg-rose-500/20 text-rose-400'
                          }`}
                        >
                          {tx.type === 'credit' || tx.type === 'reversal' ? (
                            <ArrowDownLeft className="w-5 h-5" />
                          ) : (
                            <ArrowUpRight className="w-5 h-5" />
                          )}
                        </div>
                        <div className="min-w-0">
                          <div className="flex flex-wrap items-center gap-2">
                            <p className="font-bold text-white text-sm truncate">{tx.description}</p>
                            <TransactionTagBadge
                              tag={tx.tag || tagTransaction(tx.description, tx.type, tx.billerCategory).tag}
                              showIcon
                            />
                          </div>
                          <div className="flex items-center gap-2 text-blue-200/60 mt-1 font-mono text-[11px] flex-wrap">
                            <span>{tx.reference}</span>
                            <span>•</span>
                            <span>{new Date(tx.createdAt).toLocaleString('en-US')}</span>
                            {tx.isReversed && (
                              <span className="px-1.5 py-0.2 bg-amber-500/20 text-amber-300 rounded font-sans text-[9px]">
                                REVERSED
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                      <div className="text-right shrink-0">
                        <p
                          className={`font-black text-sm ${
                            tx.type === 'credit' || tx.type === 'reversal' ? 'text-emerald-400' : 'text-white'
                          }`}
                        >
                          {tx.type === 'credit' || tx.type === 'reversal' ? '+' : '-'}
                          {USD_SYMBOL}
                          {formatUsdNumber(tx.amount)}
                        </p>
                        <button
                          type="button"
                          onClick={() => setActiveReceiptTx(tx)}
                          className="text-[10px] text-blue-300 hover:text-white font-bold hover:underline"
                        >
                          View Official Receipt
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* ================= SAVINGS ACCOUNTS ================= */}
          {activeTab === 'savings' && (
            <div className={`${NAVY_CARD} p-6 sm:p-8 space-y-6`}>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center">
                  <PiggyBank className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-xl font-bold text-white">Savings Accounts ({USD_CODE})</h2>
                  <p className="text-xs text-blue-200/75">High-yield USD liquidity options tied directly to your verified customer balance</p>
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <div className="rounded-2xl p-6 bg-gradient-to-br from-[#0d356b] to-[#071c3c] border border-blue-600/40 space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold uppercase tracking-wider text-blue-200">Primary Account Available</span>
                    <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-bold">USD</span>
                  </div>
                  <p className="text-3xl font-black text-white">
                    {USD_SYMBOL}
                    {formatUsdNumber(user.balance)} <span className="text-sm font-bold text-blue-200">{USD_CODE}</span>
                  </p>
                  <p className="text-xs text-blue-200/75">
                    Your live ledger balance can be allocated toward Premier High-Yield Savings or Money Market plans at any time.
                  </p>
                  <button
                    type="button"
                    onClick={() => handleSelectNavTab('investments')}
                    className="px-5 py-2.5 rounded-xl bg-[#c8102e] hover:bg-[#a50d26] text-white text-xs font-bold transition-colors"
                  >
                    Explore High-Yield Allocations
                  </button>
                </div>

                <div className={`${NAVY_SUBCARD} p-6 space-y-3 text-xs`}>
                  <h3 className="font-bold text-sm text-white">Available FNB Savings Tiers</h3>
                  <div className="p-3 rounded-xl bg-[#041022] border border-blue-900/50 flex justify-between items-center">
                    <div>
                      <strong className="text-white block">FNB Treasury Reserve Vault</strong>
                      <span className="text-blue-200/70">Flexible USD withdrawal access</span>
                    </div>
                    <span className="text-emerald-400 font-black">4.75% APY</span>
                  </div>
                  <div className="p-3 rounded-xl bg-[#041022] border border-blue-900/50 flex justify-between items-center">
                    <div>
                      <strong className="text-white block">Premier Wealth Goal Saver</strong>
                      <span className="text-blue-200/70">Dedicated medium-term accumulation</span>
                    </div>
                    <span className="text-emerald-400 font-black">5.40% APY</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ================= 11. FIXED DEPOSITS ================= */}
          {activeTab === 'fixed_deposits' && (
            <div className={`${NAVY_CARD} p-6 sm:p-8 space-y-6`}>
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-[#12396f] text-white flex items-center justify-center">
                    <Landmark className="w-5 h-5" />
                  </div>
                  <div>
                    <h2 className="text-xl font-bold text-white">Fixed Deposits & Term Certificates</h2>
                    <p className="text-xs text-blue-200/75">Fixed-term USD capital allocations with predictable yield schedules</p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => handleSelectNavTab('investments')}
                  className="px-4 py-2 rounded-xl bg-[#c8102e] hover:bg-[#a50d26] text-white text-xs font-bold self-start sm:self-auto"
                >
                  Open New Term Deposit
                </button>
              </div>

              {investments.length === 0 ? (
                <div className={`${NAVY_SUBCARD} p-8 text-center space-y-3`}>
                  <p className="text-sm font-bold text-white">No Active Fixed Deposits Recorded</p>
                  <p className="text-xs text-blue-200/70 max-w-md mx-auto">
                    You do not have any fixed-term deposits allocated yet. Visit Investments to lock funds into a 3–36 month term.
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  {investments.map(inv => (
                    <div key={inv.id} className={`${NAVY_SUBCARD} p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs`}>
                      <div>
                        <strong className="text-white text-sm">{inv.planName}</strong>
                        <p className="text-blue-200/70 mt-0.5">
                          Certificate Ref: <span className="font-mono">{inv.reference}</span> • {inv.durationMonths} Months • Est. Yield: +
                          {USD_SYMBOL}
                          {formatUsdNumber(inv.projectedReturnAmount)} {USD_CODE}
                        </p>
                      </div>
                      <div className="sm:text-right">
                        <strong className="text-white text-sm block">
                          {USD_SYMBOL}
                          {formatUsdNumber(inv.amount)} {USD_CODE}
                        </strong>
                        <span className="uppercase text-[10px] font-bold text-emerald-400">{inv.status.replace('_', ' ')}</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* ================= 12. LOAN SERVICES ================= */}
          {activeTab === 'loans' && (
            <div className={`${NAVY_CARD} p-6 sm:p-8 space-y-6 max-w-3xl`}>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-amber-600 text-white flex items-center justify-center">
                  <Briefcase className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-xl font-bold text-white">Loan Services & Credit Estimator</h2>
                  <p className="text-xs text-blue-200/75">Estimate monthly installments in USD ({USD_CODE}) and submit an official lending consultation</p>
                </div>
              </div>

              {loanFeedback && (
                <div className="p-4 rounded-2xl bg-emerald-950/60 border border-emerald-700/60 text-xs text-emerald-200 flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <span>{loanFeedback}</span>
                </div>
              )}

              <form onSubmit={handleSubmitLoanInquiry} className="space-y-4">
                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label className={NAVY_LABEL}>Requested Principal (USD $)</label>
                    <input
                      type="number"
                      min={500}
                      max={500000}
                      required
                      value={loanAmount}
                      onChange={e => setLoanAmount(e.target.value)}
                      className={NAVY_INPUT}
                    />
                  </div>
                  <div>
                    <label className={NAVY_LABEL}>Repayment Term</label>
                    <select
                      value={loanTermMonths}
                      onChange={e => setLoanTermMonths(parseInt(e.target.value, 10))}
                      className={NAVY_INPUT}
                    >
                      <option value={12}>12 Months</option>
                      <option value={24}>24 Months</option>
                      <option value={36}>36 Months</option>
                      <option value={48}>48 Months</option>
                      <option value={60}>60 Months</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className={NAVY_LABEL}>Purpose of Credit Facility</label>
                  <input
                    type="text"
                    required
                    value={loanPurpose}
                    onChange={e => setLoanPurpose(e.target.value)}
                    className={NAVY_INPUT}
                  />
                </div>

                <div className={`${NAVY_SUBCARD} p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4`}>
                  <div>
                    <span className="text-[11px] uppercase tracking-wider text-blue-200/70 block">Indicative Monthly Payment (6.8% APR)</span>
                    <strong className="text-2xl font-black text-white">
                      {USD_SYMBOL}
                      {formatUsdNumber(estimatedMonthlyPayment)} <span className="text-xs text-blue-200">/ month</span>
                    </strong>
                  </div>
                  <button
                    type="submit"
                    disabled={loanSubmitting}
                    className="px-5 py-2.5 bg-[#c8102e] hover:bg-[#a50d26] disabled:opacity-50 text-white font-bold rounded-xl text-xs shadow"
                  >
                    {loanSubmitting ? 'Submitting Enquiry...' : 'Request Credit Assessment'}
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* ================= 13. PERSONAL PROFILE (STRICTLY READ-ONLY — ADMIN EDIT ONLY) ================= */}
          {activeTab === 'profile' && (
            <div className={`${NAVY_CARD} p-6 sm:p-8 max-w-2xl space-y-6`}>
              <div className="flex items-start justify-between gap-3 flex-wrap">
                <div>
                  <h2 className="text-xl font-bold text-white">Personal Profile</h2>
                  <p className="text-xs text-blue-200/75 mt-1">
                    Verified identity & contact details on file with First National Bank
                  </p>
                </div>
                <span className="px-3 py-1 rounded-full bg-blue-900/70 border border-blue-700/60 text-blue-200 text-[11px] font-bold flex items-center gap-1.5">
                  <Lock className="w-3.5 h-3.5 text-red-400" />
                  <span>Read-Only (Admin Controlled)</span>
                </span>
              </div>

              <div className="p-4 rounded-2xl bg-[#07152b] border border-blue-700/50 text-xs text-blue-100 flex items-start gap-2.5">
                <Info className="w-4 h-4 text-blue-300 shrink-0 mt-0.5" />
                <span>
                  To protect your identity, personal profile fields cannot be altered directly by customers. Contact an authorized administrator via{' '}
                  <button
                    type="button"
                    onClick={() => handleSelectNavTab('support')}
                    className="underline font-bold text-red-400"
                  >
                    Customer Support
                  </button>{' '}
                  if your name, email address, or telephone number needs to be updated.
                </span>
              </div>

              <div className="grid sm:grid-cols-2 gap-4">
                <div>
                  <label className={NAVY_LABEL}>First Name (Read-Only)</label>
                  <input
                    type="text"
                    readOnly
                    aria-readonly="true"
                    value={user.firstName}
                    className={`${NAVY_INPUT} opacity-80 cursor-not-allowed`}
                  />
                </div>
                <div>
                  <label className={NAVY_LABEL}>Last Name (Read-Only)</label>
                  <input
                    type="text"
                    readOnly
                    aria-readonly="true"
                    value={user.lastName}
                    className={`${NAVY_INPUT} opacity-80 cursor-not-allowed`}
                  />
                </div>
                <div>
                  <label className={NAVY_LABEL}>Registered Email Address (Read-Only)</label>
                  <input
                    type="email"
                    readOnly
                    aria-readonly="true"
                    value={user.email}
                    className={`${NAVY_INPUT} opacity-80 cursor-not-allowed`}
                  />
                </div>
                <div>
                  <label className={NAVY_LABEL}>Contact Phone Number (Read-Only)</label>
                  <input
                    type="text"
                    readOnly
                    aria-readonly="true"
                    value={user.phone || ''}
                    className={`${NAVY_INPUT} font-mono opacity-80 cursor-not-allowed`}
                  />
                </div>
                <div>
                  <label className={NAVY_LABEL}>Country (Read-Only)</label>
                  <input
                    type="text"
                    readOnly
                    aria-readonly="true"
                    value={user.country || 'United States'}
                    className={`${NAVY_INPUT} opacity-80 cursor-not-allowed`}
                  />
                </div>
                <div>
                  <label className={NAVY_LABEL}>Residential Address (Read-Only)</label>
                  <input
                    type="text"
                    readOnly
                    aria-readonly="true"
                    value={user.residentialAddress || 'Not Specified'}
                    className={`${NAVY_INPUT} opacity-80 cursor-not-allowed`}
                  />
                </div>
              </div>
            </div>
          )}

          {/* ================= 14. LOGIN HISTORY ================= */}
          {activeTab === 'login_history' && (
            <div className={`${NAVY_CARD} p-6 sm:p-8 space-y-6`}>
              <div>
                <h2 className="text-xl font-bold text-white">Login History & Device Audit</h2>
                <p className="text-xs text-blue-200/75">Chronological record of authentication attempts for your account</p>
              </div>

              {loginActivities.length === 0 ? (
                <p className="text-center py-10 text-xs text-blue-200/60">No login events recorded yet.</p>
              ) : (
                <div className="space-y-3">
                  {loginActivities.map(act => (
                    <div key={act.id} className={`${NAVY_SUBCARD} p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs`}>
                      <div>
                        <div className="flex items-center gap-2">
                          <strong className="text-white">{act.device || 'Authorized Browser'}</strong>
                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                              act.status === 'success'
                                ? 'bg-emerald-500/20 text-emerald-300'
                                : 'bg-red-500/20 text-red-300'
                            }`}
                          >
                            {act.status}
                          </span>
                        </div>
                        <span className="text-blue-200/60 font-mono text-[11px] block mt-1">IP: {act.ipAddress}</span>
                      </div>
                      <span className="text-blue-200/75 font-mono text-[11px]">
                        {new Date(act.timestamp).toLocaleString('en-US')}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* ================= 15. ACCOUNT STATEMENTS ================= */}
          {activeTab === 'statements' && (
            <div className={`${NAVY_CARD} p-6 sm:p-8 space-y-6`}>
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h2 className="text-xl font-bold text-white">Account Statements & Reports</h2>
                  <p className="text-xs text-blue-200/75">Generate, print, and export official statement certificates in US Dollars ({USD_CODE})</p>
                </div>
                <button
                  type="button"
                  onClick={() => setIsStatementOpen(true)}
                  className="px-5 py-2.5 bg-[#c8102e] hover:bg-[#a50d26] text-white font-bold text-xs rounded-xl flex items-center gap-2 shadow self-start sm:self-auto"
                >
                  <Printer className="w-4 h-4" />
                  <span>Open Printable Statement</span>
                </button>
              </div>

              <div className={`${NAVY_SUBCARD} p-6 space-y-4 text-xs`}>
                <h3 className="font-bold text-sm text-blue-200">Statement Period Summary</h3>
                <div className="grid sm:grid-cols-3 gap-4">
                  <div className="p-4 bg-[#041022] rounded-xl border border-blue-900/50">
                    <span className="text-blue-200/70 block text-[10px] uppercase">Total Recorded Credits</span>
                    <span className="text-base font-black text-white">
                      {USD_SYMBOL}
                      {formatUsdNumber(
                        transactions
                          .filter(t => t.type === 'credit' || t.type === 'reversal')
                          .reduce((sum, t) => sum + t.amount, 0)
                      )}{' '}
                      {USD_CODE}
                    </span>
                  </div>
                  <div className="p-4 bg-[#041022] rounded-xl border border-blue-900/50">
                    <span className="text-blue-200/70 block text-[10px] uppercase">Current Net Balance</span>
                    <span className="text-base font-black text-emerald-400">
                      {USD_SYMBOL}
                      {formatUsdNumber(user.balance)} {USD_CODE}
                    </span>
                  </div>
                  <div className="p-4 bg-[#041022] rounded-xl border border-blue-900/50">
                    <span className="text-blue-200/70 block text-[10px] uppercase">Total Recorded Transactions</span>
                    <span className="text-base font-black text-white">{transactions.length}</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ================= 16. DOCUMENT CENTRE / KYC VERIFICATION ================= */}
          {activeTab === 'verification' && (
            <div className={`${NAVY_CARD} p-6 sm:p-8 max-w-2xl space-y-6`}>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-emerald-600/30 border border-emerald-500/40 text-emerald-300 rounded-xl flex items-center justify-center">
                  <FileCheck2 className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-xl font-bold text-white">Document Centre & Identity Verification (KYC)</h2>
                  <p className="text-xs text-blue-200/75">Tier-1 customer due diligence and compliance documentation</p>
                </div>
              </div>

              {kycSuccessMsg && (
                <div className="p-4 bg-emerald-950/60 border border-emerald-700/60 rounded-2xl text-xs text-emerald-200 flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5 text-emerald-400" />
                  <span>{kycSuccessMsg}</span>
                </div>
              )}

              {kycErrorMsg && (
                <div className="p-4 bg-red-950/60 border border-red-700/60 rounded-2xl text-xs text-red-200 flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-red-400" />
                  <span>{kycErrorMsg}</span>
                </div>
              )}

              <form onSubmit={handleKycSubmit} className="space-y-4">
                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label className={NAVY_LABEL}>Legal Full Name (On Record)</label>
                    <input
                      type="text"
                      readOnly
                      value={kycForm.fullName}
                      className={`${NAVY_INPUT} opacity-80 cursor-not-allowed`}
                    />
                  </div>
                  <div>
                    <label className={NAVY_LABEL}>Date of Birth</label>
                    <input
                      type="date"
                      required
                      value={kycForm.dateOfBirth}
                      onChange={e => setKycForm({ ...kycForm, dateOfBirth: e.target.value })}
                      className={NAVY_INPUT}
                    />
                  </div>
                </div>

                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label className={NAVY_LABEL}>Country of Residence</label>
                    <input
                      type="text"
                      required
                      value={kycForm.countryOfResidence}
                      onChange={e => setKycForm({ ...kycForm, countryOfResidence: e.target.value })}
                      className={NAVY_INPUT}
                    />
                  </div>
                  <div>
                    <label className={NAVY_LABEL}>ID Document Type</label>
                    <select
                      value={kycForm.idDocumentType}
                      onChange={e => setKycForm({ ...kycForm, idDocumentType: e.target.value as any })}
                      className={NAVY_INPUT}
                    >
                      <option value="passport">International Passport</option>
                      <option value="national_id">National ID Card</option>
                      <option value="drivers_licence">Driving Licence</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className={NAVY_LABEL}>Residential Street Address</label>
                  <input
                    type="text"
                    required
                    value={kycForm.residentialAddress}
                    onChange={e => setKycForm({ ...kycForm, residentialAddress: e.target.value })}
                    className={NAVY_INPUT}
                  />
                </div>

                <div className="grid sm:grid-cols-2 gap-4">
                  <div className={`${NAVY_SUBCARD} p-4 border-dashed text-xs text-center space-y-1`}>
                    <UploadCloud className="w-6 h-6 mx-auto text-blue-300" />
                    <span className="font-bold block text-white">Front ID Scan</span>
                    <span className="text-[10px] text-blue-200/70 font-mono">{kycForm.sampleDocFrontName}</span>
                  </div>
                  <div className={`${NAVY_SUBCARD} p-4 border-dashed text-xs text-center space-y-1`}>
                    <UploadCloud className="w-6 h-6 mx-auto text-blue-300" />
                    <span className="font-bold block text-white">Proof of Address</span>
                    <span className="text-[10px] text-blue-200/70 font-mono">{kycForm.sampleProofOfAddressName}</span>
                  </div>
                </div>

                <div className="space-y-2 pt-2">
                  <label className="flex items-start gap-2 text-xs text-blue-200/80">
                    <input
                      type="checkbox"
                      checked={kycForm.declarationAccepted}
                      onChange={e => setKycForm({ ...kycForm, declarationAccepted: e.target.checked })}
                      className="mt-1"
                    />
                    <span>I declare that all personal identification details provided herein are accurate and true.</span>
                  </label>
                  <label className="flex items-start gap-2 text-xs text-blue-200/80">
                    <input
                      type="checkbox"
                      checked={kycForm.consentAccepted}
                      onChange={e => setKycForm({ ...kycForm, consentAccepted: e.target.checked })}
                      className="mt-1"
                    />
                    <span>I consent to institutional electronic verification by FNB compliance officers.</span>
                  </label>
                </div>

                <button
                  type="submit"
                  disabled={kycLoading || !kycForm.declarationAccepted || !kycForm.consentAccepted}
                  className="w-full py-3 bg-[#c8102e] hover:bg-[#a50d26] disabled:opacity-50 text-white font-bold rounded-xl text-sm shadow-md transition-all flex items-center justify-center gap-2"
                >
                  <FileCheck2 className="w-4 h-4" />
                  <span>{kycLoading ? 'Submitting Documents...' : 'Submit Verification Application'}</span>
                </button>
              </form>
            </div>
          )}

          {/* ================= 17. NOTIFICATIONS CENTRE ================= */}
          {activeTab === 'notifications' && (
            <div className={`${NAVY_CARD} p-6 sm:p-8 space-y-6`}>
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2.5 flex-wrap">
                    <h2 className="text-xl font-bold text-white">Account Alerts & Notifications</h2>
                    {unreadNotifsCount > 0 ? (
                      <span className="px-2.5 py-0.5 rounded-full bg-[#c8102e] text-white text-[10px] font-bold">
                        {unreadNotifsCount} Unread
                      </span>
                    ) : (
                      <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-bold">
                        All Caught Up
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-blue-200/75 mt-1">
                    Security alerts, verification updates, investment notices, and transaction activity
                  </p>
                </div>

                <div className="flex items-center gap-2 flex-wrap">
                  <button
                    type="button"
                    onClick={handleMarkAllNotifsRead}
                    disabled={unreadNotifsCount === 0}
                    className="px-3.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 bg-[#c8102e] hover:bg-[#a50d26] text-white disabled:opacity-40 disabled:cursor-not-allowed transition-colors shadow-sm"
                  >
                    <CheckCheck className="w-3.5 h-3.5" />
                    <span>Mark All as Read</span>
                  </button>
                </div>
              </div>

              <div className="flex items-center gap-2 overflow-x-auto pb-1">
                {[
                  { id: 'all', label: 'All' },
                  { id: 'verification', label: 'Verification' },
                  { id: 'investment', label: 'Investment' },
                  { id: 'account', label: 'Account' },
                  { id: 'security', label: 'Security' },
                  { id: 'transaction', label: 'Transaction' },
                ].map(cat => {
                  const catCount =
                    cat.id === 'all'
                      ? sortedNotifications.length
                      : sortedNotifications.filter(n => (n.category || 'account') === cat.id).length;
                  return (
                    <button
                      key={cat.id}
                      type="button"
                      onClick={() => setNotifCategoryFilter(cat.id)}
                      className={`px-3.5 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all flex items-center gap-1.5 ${
                        notifCategoryFilter === cat.id
                          ? 'bg-[#c8102e] text-white shadow-sm'
                          : 'bg-[#07152b] text-blue-200 hover:bg-[#0e2a54] border border-blue-800/40'
                      }`}
                    >
                      <span>{cat.label}</span>
                      <span
                        className={`text-[10px] px-1.5 py-0.2 rounded-full ${
                          notifCategoryFilter === cat.id ? 'bg-white/20 text-white' : 'bg-[#041022] text-blue-300'
                        }`}
                      >
                        {catCount}
                      </span>
                    </button>
                  );
                })}
              </div>

              {filteredNotifications.length === 0 ? (
                <div className="text-center py-12 text-blue-200/60 text-xs space-y-2">
                  <Bell className="w-8 h-8 mx-auto opacity-30" />
                  <p>No notifications recorded in this category.</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {filteredNotifications.map(n => {
                    const category = n.category || 'account';
                    const CategoryIcon =
                      category === 'verification'
                        ? FileCheck2
                        : category === 'investment'
                        ? TrendingUp
                        : category === 'security'
                        ? ShieldAlert
                        : category === 'transaction'
                        ? ArrowUpRight
                        : Building2;

                    const iconStyle =
                      category === 'security'
                        ? 'bg-amber-500/20 text-amber-300'
                        : category === 'verification'
                        ? 'bg-emerald-500/20 text-emerald-300'
                        : category === 'investment'
                        ? 'bg-indigo-500/20 text-indigo-300'
                        : category === 'transaction'
                        ? 'bg-rose-500/20 text-rose-300'
                        : 'bg-blue-500/20 text-blue-300';

                    return (
                      <div
                        key={n.id}
                        className={`p-4 rounded-2xl border transition-all flex flex-col sm:flex-row sm:items-start justify-between gap-4 text-xs ${
                          !n.read
                            ? 'bg-[#0f2950] border-blue-500/50 shadow-sm'
                            : 'bg-[#07152b] border-blue-800/40'
                        }`}
                      >
                        <div className="flex items-start gap-3.5 flex-1">
                          <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${iconStyle}`}>
                            <CategoryIcon className="w-5 h-5" />
                          </div>
                          <div className="min-w-0 flex-1">
                            <div className="flex items-center gap-2 flex-wrap">
                              <strong className="font-bold text-white text-sm">{n.title}</strong>
                              <span className="px-2 py-0.5 rounded-full bg-[#041022] text-blue-200 text-[10px] font-bold uppercase tracking-wider">
                                {category}
                              </span>
                              {!n.read ? (
                                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-red-500/20 text-red-300 text-[10px] font-bold">
                                  <span className="w-1.5 h-1.5 rounded-full bg-[#c8102e]" />
                                  Unread
                                </span>
                              ) : (
                                <span className="text-[10px] text-blue-300/60 font-medium">Read</span>
                              )}
                            </div>
                            <p className="text-blue-100/85 mt-1.5 leading-relaxed">{n.message}</p>
                            <span className="text-[11px] text-blue-300/60 mt-2 block font-mono">
                              {new Date(n.createdAt).toLocaleString('en-US')}
                            </span>
                          </div>
                        </div>

                        <div className="flex items-center gap-2 shrink-0 sm:pt-0.5 flex-wrap">
                          <button
                            type="button"
                            onClick={() => handleViewNotifDetails(n)}
                            className="px-3 py-1.5 rounded-lg bg-[#12396f] hover:bg-[#17488a] text-white font-semibold transition-colors"
                          >
                            View Details
                          </button>
                          {!n.read && (
                            <button
                              type="button"
                              onClick={() => handleMarkNotifRead(n.id)}
                              className="px-3 py-1.5 rounded-lg bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 font-semibold transition-colors flex items-center gap-1"
                            >
                              <Check className="w-3.5 h-3.5" />
                              <span>Mark as Read</span>
                            </button>
                          )}
                          <button
                            type="button"
                            onClick={() => handleDeleteNotif(n.id)}
                            aria-label="Delete notification"
                            className="p-1.5 rounded-lg text-blue-300/60 hover:text-red-400 hover:bg-red-950/40 transition-colors"
                            title="Delete Notification"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* ================= 18. CUSTOMER SUPPORT ================= */}
          {activeTab === 'support' && (
            <div className={`${NAVY_CARD} p-6 sm:p-8 max-w-2xl space-y-6`}>
              <div>
                <h2 className="text-xl font-bold text-white">Customer Support & Direct Tickets</h2>
                <p className="text-xs text-blue-200/75">
                  Contact our 24/7 client relations desk at +12724736857 or info@fnnbbankss.online
                </p>
              </div>

              {supportSuccess && (
                <div className="p-4 bg-emerald-950/60 border border-emerald-700/60 rounded-2xl text-xs text-emerald-200 flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5 text-emerald-400" />
                  <span>{supportSuccess}</span>
                </div>
              )}

              {supportError && (
                <div className="p-4 bg-red-950/60 border border-red-700/60 rounded-2xl text-xs text-red-200 flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-red-400" />
                  <span>{supportError}</span>
                </div>
              )}

              <form onSubmit={handleSupportSubmit} className="space-y-4">
                <div>
                  <label className={NAVY_LABEL}>Enquiry Category</label>
                  <select
                    value={supportForm.category}
                    onChange={e => setSupportForm({ ...supportForm, category: e.target.value })}
                    className={NAVY_INPUT}
                  >
                    <option value="general">General Banking Assistance</option>
                    <option value="technical">Technical / Security Issue</option>
                    <option value="account">Account, Profile Update & Wire Query</option>
                    <option value="complaint">Formal Complaint</option>
                  </select>
                </div>

                <div>
                  <label className={NAVY_LABEL}>Subject Line</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Question about my account or profile record"
                    value={supportForm.subject}
                    onChange={e => setSupportForm({ ...supportForm, subject: e.target.value })}
                    className={NAVY_INPUT}
                  />
                </div>

                <div>
                  <label className={NAVY_LABEL}>Message Details</label>
                  <textarea
                    rows={4}
                    required
                    placeholder="Describe your issue or query..."
                    value={supportForm.message}
                    onChange={e => setSupportForm({ ...supportForm, message: e.target.value })}
                    className={NAVY_INPUT}
                  />
                </div>

                <button
                  type="submit"
                  disabled={supportLoading}
                  className="w-full py-3 bg-[#c8102e] hover:bg-[#a50d26] text-white font-bold rounded-xl text-sm shadow-md transition-all flex items-center justify-center gap-2"
                >
                  <MessageSquare className="w-4 h-4" />
                  <span>{supportLoading ? 'Submitting Ticket...' : 'Submit Support Ticket'}</span>
                </button>
              </form>

              {supportEnquiries.length > 0 && (
                <div className="pt-6 border-t border-blue-800/50 space-y-3">
                  <h3 className="font-bold text-sm text-white">My Support Tickets</h3>
                  <div className="space-y-3">
                    {supportEnquiries.map(ticket => (
                      <div key={ticket.id} className={`${NAVY_SUBCARD} p-4 text-xs space-y-1`}>
                        <div className="flex justify-between items-center gap-2">
                          <strong className="text-white">{ticket.subject}</strong>
                          <span className="px-2 py-0.5 rounded-full font-bold uppercase text-[9px] bg-blue-500/20 text-blue-200">
                            {ticket.status}
                          </span>
                        </div>
                        <p className="text-blue-200/60">
                          Ref: {ticket.reference} • {new Date(ticket.createdAt).toLocaleDateString('en-US')}
                        </p>
                        {ticket.adminReply && (
                          <div className="mt-2 p-2.5 bg-emerald-950/50 rounded-xl border border-emerald-700/50 text-emerald-200">
                            <strong>Admin Reply:</strong> {ticket.adminReply}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* ================= 19. SECURITY SETTINGS (NO PROFILE SAVE BUTTON; READ-ONLY IDENTITY + PASSWORD + PIN) ================= */}
          {activeTab === 'settings' && (
            <div className={`${NAVY_CARD} p-6 sm:p-8 max-w-2xl space-y-8`}>
              <div>
                <h2 className="text-xl font-bold text-white">Security & Account Settings</h2>
                <p className="text-xs text-blue-200/75">
                  Manage your confidential password, two-factor protection, and Transaction PIN
                </p>
              </div>

              {settingsMessage && (
                <div className="p-4 bg-emerald-950/60 border border-emerald-700/60 rounded-2xl text-xs text-emerald-200">
                  {settingsMessage}
                </div>
              )}

              {settingsError && (
                <div className="p-4 bg-red-950/60 border border-red-700/60 rounded-2xl text-xs text-red-200">
                  {settingsError}
                </div>
              )}

              {/* Read-Only Registered Identity Notice (Admin-Only Editing) */}
              <div className="space-y-4">
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <h3 className="font-bold text-sm text-blue-200">Registered Personal Information (Read-Only)</h3>
                  <span className="text-[11px] font-bold text-blue-300 flex items-center gap-1">
                    <Lock className="w-3.5 h-3.5 text-red-400" /> Admin-Editable Only
                  </span>
                </div>
                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label className={NAVY_LABEL}>First Name</label>
                    <input
                      type="text"
                      readOnly
                      aria-readonly="true"
                      value={user.firstName}
                      className={`${NAVY_INPUT} opacity-80 cursor-not-allowed`}
                    />
                  </div>
                  <div>
                    <label className={NAVY_LABEL}>Last Name</label>
                    <input
                      type="text"
                      readOnly
                      aria-readonly="true"
                      value={user.lastName}
                      className={`${NAVY_INPUT} opacity-80 cursor-not-allowed`}
                    />
                  </div>
                  <div>
                    <label className={NAVY_LABEL}>Registered Email Address</label>
                    <input
                      type="email"
                      readOnly
                      aria-readonly="true"
                      value={user.email}
                      className={`${NAVY_INPUT} opacity-80 cursor-not-allowed`}
                    />
                  </div>
                  <div>
                    <label className={NAVY_LABEL}>Contact Phone Number</label>
                    <input
                      type="tel"
                      readOnly
                      aria-readonly="true"
                      value={user.phone || ''}
                      className={`${NAVY_INPUT} font-mono opacity-80 cursor-not-allowed`}
                    />
                  </div>
                </div>
                <p className="text-[11px] text-blue-200/70">
                  Only authorized bank administrators can modify customer names, registered email addresses, and phone numbers.
                </p>
              </div>

              {/* Two-Factor Authentication Preference */}
              <div className={`${NAVY_SUBCARD} p-4 flex items-center justify-between gap-4`}>
                <div>
                  <h4 className="font-bold text-xs sm:text-sm text-white">Enhanced Session Verification</h4>
                  <p className="text-[11px] text-blue-200/70">Require security verification prompts on unrecognized devices</p>
                </div>
                <button
                  type="button"
                  onClick={handleToggleTwoFactor}
                  className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-colors ${
                    twoFactorEnabled ? 'bg-emerald-600 text-white' : 'bg-[#041022] border border-blue-800 text-blue-200'
                  }`}
                >
                  {twoFactorEnabled ? 'Enabled' : 'Disabled'}
                </button>
              </div>

              {/* Change Confidential Password */}
              <form onSubmit={handleChangePassword} className="space-y-4 pt-6 border-t border-blue-800/50">
                <h3 className="font-bold text-sm text-blue-200">Change Confidential Password</h3>
                <div>
                  <label className={NAVY_LABEL}>Current Password</label>
                  <input
                    type="password"
                    required
                    value={passwords.current}
                    onChange={e => setPasswords({ ...passwords, current: e.target.value })}
                    className={NAVY_INPUT}
                  />
                </div>
                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label className={NAVY_LABEL}>New Password</label>
                    <input
                      type="password"
                      required
                      value={passwords.new}
                      onChange={e => setPasswords({ ...passwords, new: e.target.value })}
                      className={NAVY_INPUT}
                    />
                  </div>
                  <div>
                    <label className={NAVY_LABEL}>Confirm New Password</label>
                    <input
                      type="password"
                      required
                      value={passwords.confirm}
                      onChange={e => setPasswords({ ...passwords, confirm: e.target.value })}
                      className={NAVY_INPUT}
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="px-6 py-2.5 bg-[#c8102e] hover:bg-[#a50d26] text-white font-bold rounded-xl text-xs shadow"
                >
                  Update Password
                </button>
              </form>

              {/* Transaction PIN Security Settings */}
              <div id="transaction-pin-section" className="pt-6 border-t border-blue-800/50 space-y-3">
                <h3 className="font-bold text-sm text-blue-200">Transaction PIN Security</h3>
                <TransactionPinManager
                  theme="navy"
                  user={user}
                  initialMode={pinManagerMode}
                  onPinUpdated={async () => {
                    await refreshUser(false);
                  }}
                  onOpenMailbox={() => setIsMailModalOpen(true)}
                />
              </div>
            </div>
          )}

          {/* Portal Footer */}
          <footer className="pt-4 pb-6 border-t border-blue-900/50 flex flex-col sm:flex-row items-center justify-between gap-2 text-[11px] text-blue-200/60">
            <div className="flex items-center gap-2">
              <span className="font-semibold text-blue-100">First National Bank — Online Banking Portal</span>
              <span>• 13586 US-90, Boutte, LA 70039, United States</span>
            </div>
            <div className="flex items-center gap-3">
              <a href="tel:+12724736857" className="hover:text-white">+12724736857</a>
              <span>•</span>
              <a href="mailto:info@fnnbbankss.online" className="hover:text-white">info@fnnbbankss.online</a>
            </div>
          </footer>
        </main>
      </div>

      {/* Receipts & Statements Modals */}
      {activeReceiptTx && (
        <ReceiptModal
          transaction={activeReceiptTx}
          onClose={() => setActiveReceiptTx(null)}
          onReversalSuccess={async () => {
            await refreshUser(false);
            await fetchDashboardData();
          }}
        />
      )}

      {isStatementOpen && (
        <StatementModal
          user={user}
          transactions={transactions}
          onClose={() => setIsStatementOpen(false)}
        />
      )}

      {/* Notification Detail Modal */}
      {selectedNotifDetail && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fade-in">
          <div className="w-full max-w-md bg-[#0a1d3a] rounded-3xl shadow-2xl border border-blue-800/60 overflow-hidden text-white">
            <div className="p-5 bg-[#061428] border-b border-blue-900/60 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <Bell className="w-5 h-5 text-red-400" />
                <div>
                  <h3 className="font-bold text-sm">Notification Details</h3>
                  <p className="text-[11px] text-blue-200/75 uppercase tracking-wider">
                    {(selectedNotifDetail.category || 'account').toUpperCase()} ALERT
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setSelectedNotifDetail(null)}
                className="p-1.5 rounded-lg text-blue-200 hover:text-white hover:bg-white/10"
                aria-label="Close notification details"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-6 space-y-4 text-xs">
              <div>
                <span className="text-[10px] uppercase tracking-wider font-bold text-blue-300/70 block mb-1">Subject</span>
                <h4 className="text-base font-bold text-white">{selectedNotifDetail.title}</h4>
              </div>

              <div className="p-4 rounded-2xl bg-[#07152b] border border-blue-800/50 text-blue-100 leading-relaxed">
                {selectedNotifDetail.message}
              </div>

              <div className="grid grid-cols-2 gap-3 pt-2 text-[11px]">
                <div className="p-3 rounded-xl bg-[#07152b] border border-blue-800/50">
                  <span className="text-blue-200/70 block">Date & Time</span>
                  <strong className="text-white font-mono">
                    {new Date(selectedNotifDetail.createdAt).toLocaleString('en-US')}
                  </strong>
                </div>
                <div className="p-3 rounded-xl bg-[#07152b] border border-blue-800/50">
                  <span className="text-blue-200/70 block">Status</span>
                  <strong className="text-emerald-400">{selectedNotifDetail.read ? 'Read' : 'Unread'}</strong>
                </div>
              </div>
            </div>

            <div className="p-4 bg-[#07152b] border-t border-blue-900/60 flex items-center justify-between gap-2">
              <button
                type="button"
                onClick={() => handleDeleteNotif(selectedNotifDetail.id)}
                className="px-3.5 py-2 rounded-xl text-xs font-bold text-red-400 hover:bg-red-950/40 flex items-center gap-1.5 transition-colors"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Delete</span>
              </button>

              <div className="flex items-center gap-2">
                {selectedNotifDetail.actionUrl && (
                  <button
                    type="button"
                    onClick={() => {
                      const dest = selectedNotifDetail.actionUrl as DashboardTab;
                      setSelectedNotifDetail(null);
                      if (
                        [
                          'overview',
                          'account',
                          'investments',
                          'transfers',
                          'transactions',
                          'statements',
                          'verification',
                          'notifications',
                          'support',
                          'settings',
                        ].includes(dest)
                      ) {
                        setActiveTab(dest);
                      }
                    }}
                    className="px-4 py-2 rounded-xl text-xs font-bold bg-[#c8102e] hover:bg-[#a50d26] text-white transition-colors"
                  >
                    Go to Section
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => setSelectedNotifDetail(null)}
                  className="px-4 py-2 rounded-xl text-xs font-bold bg-[#12396f] hover:bg-[#17488a] text-white transition-colors"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Transaction PIN Verification Modal */}
      {pendingPinAction && (
        <TransactionPinModal
          isOpen={Boolean(pendingPinAction)}
          user={user}
          transactionTitle={
            pendingPinAction.kind === 'transfer'
              ? 'Electronic Transfer Authorization'
              : 'Investment Allocation Authorization'
          }
          summaryItems={
            pendingPinAction.kind === 'transfer'
              ? [
                  {
                    label: 'Transfer Type',
                    value:
                      pendingPinAction.payload.transferScope === 'international'
                        ? 'International Wire'
                        : 'Domestic Transfer',
                  },
                  { label: 'Beneficiary', value: pendingPinAction.payload.beneficiaryName },
                  { label: 'Receiving Bank', value: pendingPinAction.payload.beneficiaryBank },
                  {
                    label: 'Amount',
                    value: `${USD_SYMBOL}${formatUsdNumber(pendingPinAction.payload.amount)} ${USD_CODE}`,
                    highlight: true,
                  },
                ]
              : [
                  { label: 'Investment Plan', value: pendingPinAction.payload.planName },
                  { label: 'Term Duration', value: `${pendingPinAction.payload.durationMonths} Months` },
                  {
                    label: 'Capital Allocation',
                    value: `${USD_SYMBOL}${formatUsdNumber(pendingPinAction.payload.amount)} ${USD_CODE}`,
                    highlight: true,
                  },
                ]
          }
          loading={pinModalLoading}
          error={pinModalError}
          errorCode={pinModalErrorCode}
          lockedUntil={pinModalLockedUntil}
          onConfirm={handleConfirmTransactionPin}
          onCancel={() => {
            if (!pinModalLoading) {
              setPendingPinAction(null);
              setPinModalError(null);
            }
          }}
          onNavigatePinSetup={targetMode => {
            setPendingPinAction(null);
            setPinModalError(null);
            setPinManagerMode(targetMode);
            setActiveTab('settings');
            setTimeout(() => {
              document.getElementById('transaction-pin-section')?.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }, 100);
          }}
        />
      )}
    </div>
  );
};
