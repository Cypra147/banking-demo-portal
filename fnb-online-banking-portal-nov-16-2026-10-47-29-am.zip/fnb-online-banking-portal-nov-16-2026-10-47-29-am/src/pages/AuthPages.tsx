import React, { useState, useEffect, useMemo } from 'react';
import { useAuth } from '../context/AuthContext.tsx';
import { api } from '../services/api.ts';
import { COUNTRIES, CountryData } from '../constants/countries.ts';
import { 
  Lock, 
  Mail, 
  User as UserIcon, 
  Phone, 
  ArrowRight, 
  AlertCircle, 
  Clock, 
  Eye,
  EyeOff,
  Globe,
  MapPin,
  CheckCircle2,
  Calendar,
  ShieldCheck,
  Search,
  BellRing
} from 'lucide-react';

interface AuthPagesProps {
  initialMode?: 'login' | 'register' | 'forgot';
  sessionNotice?: string | null;
  onClose?: () => void;
  onSuccess?: () => void;
}

export const AuthPages: React.FC<AuthPagesProps> = ({ 
  initialMode = 'login', 
  sessionNotice,
  onClose,
  onSuccess 
}) => {
  const { loginCustomer } = useAuth();
  const [mode, setMode] = useState<'login' | 'register' | 'forgot'>(initialMode);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  // Customer Login Form State
  const [loginIdentifier, setLoginIdentifier] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [loginError, setLoginError] = useState<string | null>(null);
  const [loginLoading, setLoginLoading] = useState(false);

  // Customer Registration State
  const [regStep, setRegStep] = useState<'form' | 'pending_success'>('form');
  const [regForm, setRegForm] = useState({
    firstName: '',
    middleName: '',
    lastName: '',
    dateOfBirth: '',
    email: '',
    username: '',
    phone: '+44 ',
    country: 'United Kingdom',
    state: '',
    residentialAddress: '',
    postalCode: '',
    password: '',
    confirmPassword: '',
    agreeTerms: false,
    agreePrivacy: false,
    emailAlerts: true,
    smsAlerts: true,
  });

  // Country search state
  const [countrySearch, setCountrySearch] = useState('');
  const [isCountryDropdownOpen, setIsCountryDropdownOpen] = useState(false);

  // Username validation state
  const [usernameStatus, setUsernameStatus] = useState<{
    checking: boolean;
    available?: boolean;
    message?: string;
  }>({ checking: false });

  // Registration feedback state
  const [regError, setRegError] = useState<string | null>(null);
  const [regLoading, setRegLoading] = useState(false);
  const [referenceNumber, setReferenceNumber] = useState<string>('');

  // Forgot Password State
  const [forgotStep, setForgotStep] = useState<'request' | 'verify' | 'done'>('request');
  const [forgotEmail, setForgotEmail] = useState('');
  const [forgotCode, setForgotCode] = useState('');
  const [forgotNewPassword, setForgotNewPassword] = useState('');
  const [forgotConfirmPassword, setForgotConfirmPassword] = useState('');
  const [forgotError, setForgotError] = useState<string | null>(null);
  const [forgotLoading, setForgotLoading] = useState(false);
  const [forgotCooldown, setForgotCooldown] = useState<number>(0);
  const [forgotResendStatus, setForgotResendStatus] = useState<string | null>(null);

  useEffect(() => {
    if (forgotCooldown > 0) {
      const timer = setTimeout(() => setForgotCooldown(forgotCooldown - 1), 1000);
      return () => clearTimeout(timer);
    }
  }, [forgotCooldown]);

  // Filtered countries for searchable dropdown
  const filteredCountries = useMemo(() => {
    const q = countrySearch.trim().toLowerCase();
    if (!q) return COUNTRIES;
    return COUNTRIES.filter(c => 
      c.name.toLowerCase().includes(q) || 
      c.code.toLowerCase().includes(q) ||
      c.dialCode.includes(q)
    );
  }, [countrySearch]);

  // Handle Country selection with auto phone dial code
  const handleSelectCountry = (country: CountryData) => {
    setRegForm(prev => {
      // If phone starts with old dial code or is blank, replace dial code
      const currentPhone = prev.phone.trim();
      let updatedPhone = `${country.dialCode} `;
      if (currentPhone.startsWith('+')) {
        const parts = currentPhone.split(' ');
        if (parts.length > 1) {
          updatedPhone = `${country.dialCode} ${parts.slice(1).join(' ')}`;
        }
      }
      return {
        ...prev,
        country: country.name,
        phone: updatedPhone,
      };
    });
    setIsCountryDropdownOpen(false);
    setCountrySearch('');
  };

  // Username availability check with debounce
  useEffect(() => {
    const username = regForm.username.trim();
    if (username.length < 3) {
      setUsernameStatus({ checking: false });
      return;
    }

    setUsernameStatus({ checking: true });
    const handle = setTimeout(async () => {
      try {
        const res = await api.checkUsername(username);
        setUsernameStatus({
          checking: false,
          available: res.available,
          message: res.message,
        });
      } catch (err: any) {
        setUsernameStatus({
          checking: false,
          available: false,
          message: 'Unable to verify username availability.',
        });
      }
    }, 400);

    return () => clearTimeout(handle);
  }, [regForm.username]);

  // Password strength calculation
  const passwordStrength = useMemo(() => {
    const pwd = regForm.password;
    if (!pwd) return { score: 0, label: '', color: 'bg-slate-200 dark:bg-slate-700' };
    
    let score = 0;
    if (pwd.length >= 8) score += 1;
    if (pwd.length >= 12) score += 1;
    if (/[A-Z]/.test(pwd) && /[a-z]/.test(pwd)) score += 1;
    if (/\d/.test(pwd)) score += 1;
    if (/[^A-Za-z0-9]/.test(pwd)) score += 1;

    if (score <= 2) return { score: 1, label: 'Weak', color: 'bg-red-500' };
    if (score <= 3) return { score: 2, label: 'Fair', color: 'bg-amber-500' };
    if (score === 4) return { score: 3, label: 'Good', color: 'bg-blue-500' };
    return { score: 4, label: 'Strong', color: 'bg-emerald-500' };
  }, [regForm.password]);

  // Customer Login Submit
  const handleCustomerLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);
    setLoginLoading(true);

    try {
      await loginCustomer(loginIdentifier, loginPassword);
      if (onSuccess) onSuccess();
      if (onClose) onClose();
    } catch (err: any) {
      setLoginError(err.message || 'Login failed. Please verify your credentials.');
    } finally {
      setLoginLoading(false);
    }
  };

  // Submit Registration Form directly for Administrative Review
  const handleRegisterFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setRegError(null);

    // Validate fields
    if (!regForm.firstName.trim() || !regForm.lastName.trim()) {
      setRegError('Please provide both first and last name.');
      return;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(regForm.email.trim())) {
      setRegError('Please enter a valid email address.');
      return;
    }

    if (!regForm.username.trim() || regForm.username.length < 3) {
      setRegError('Username must be at least 3 characters.');
      return;
    }

    if (usernameStatus.available === false) {
      setRegError('Please choose an available username before submitting.');
      return;
    }

    if (regForm.password !== regForm.confirmPassword) {
      setRegError('Passwords do not match.');
      return;
    }
    if (regForm.password.length < 8) {
      setRegError('Password must be at least 8 characters long.');
      return;
    }

    if (!regForm.agreeTerms || !regForm.agreePrivacy) {
      setRegError('You must agree to the Terms and Conditions and Privacy Policy to register.');
      return;
    }

    setRegLoading(true);
    try {
      const res = await api.registerRequest({
        firstName: regForm.firstName.trim(),
        middleName: regForm.middleName.trim() || undefined,
        lastName: regForm.lastName.trim(),
        fullName: `${regForm.firstName.trim()} ${regForm.middleName.trim() ? regForm.middleName.trim() + ' ' : ''}${regForm.lastName.trim()}`.trim(),
        dateOfBirth: regForm.dateOfBirth || undefined,
        email: regForm.email.trim().toLowerCase(),
        username: regForm.username.trim().toLowerCase(),
        phone: regForm.phone.trim(),
        country: regForm.country,
        state: regForm.state.trim() || undefined,
        residentialAddress: regForm.residentialAddress.trim() || undefined,
        postalCode: regForm.postalCode.trim() || undefined,
        password: regForm.password,
        confirmPassword: regForm.confirmPassword,
        notificationPreferences: {
          emailAlerts: regForm.emailAlerts,
          smsAlerts: regForm.smsAlerts,
        },
      });

      if (res.referenceNumber) {
        setReferenceNumber(res.referenceNumber);
      }
      setRegStep('pending_success');
    } catch (err: any) {
      setRegError(err.message || 'Registration request failed.');
    } finally {
      setRegLoading(false);
    }
  };

  // Password Recovery Handlers
  const handleForgotRequestSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setForgotError(null);
    setForgotLoading(true);
    try {
      await api.forgotPassword(forgotEmail);
      setForgotCooldown(60);
      setForgotStep('verify');
    } catch (err: any) {
      setForgotError(err.message || 'Failed to request password reset code.');
    } finally {
      setForgotLoading(false);
    }
  };

  const handleResendForgotCode = async () => {
    if (forgotCooldown > 0) return;
    setForgotError(null);
    try {
      await api.forgotPassword(forgotEmail);
      setForgotCooldown(60);
      setForgotResendStatus('A new recovery code has been sent to your email.');
      setTimeout(() => setForgotResendStatus(null), 6000);
    } catch (err: any) {
      setForgotError(err.message || 'Failed to resend recovery code.');
    }
  };

  const handleForgotVerifySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setForgotError(null);
    if (forgotNewPassword !== forgotConfirmPassword) {
      setForgotError('New passwords do not match.');
      return;
    }
    if (forgotNewPassword.length < 8) {
      setForgotError('New password must be at least 8 characters long.');
      return;
    }
    setForgotLoading(true);
    try {
      await api.resetPassword({
        email: forgotEmail,
        code: forgotCode,
        newPassword: forgotNewPassword,
        confirmPassword: forgotConfirmPassword,
      });
      setForgotStep('done');
    } catch (err: any) {
      setForgotError(err.message || 'Failed to reset password.');
    } finally {
      setForgotLoading(false);
    }
  };

  return (
    <div className="w-full max-w-xl mx-auto bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden transition-all">
      
      {/* Brand Header */}
      <div className="bg-[#002752] p-6 text-white text-center relative">
        <div className="flex justify-center mb-3">
          <img
            src="/fnb-logo.png"
            alt="First National Bank"
            className="w-14 h-14 object-contain rounded-2xl bg-white p-1.5 shadow-md"
            onError={(e) => {
              e.currentTarget.onerror = null;
              e.currentTarget.src = "/assets/aistudio/file_00000000763081f4a6c9438dcd4940cf_665e4923.png";
            }}
          />
        </div>
        <h2 className="text-xl sm:text-2xl font-black tracking-tight">FIRST NATIONAL BANK</h2>
        <p className="text-xs text-red-400 font-semibold uppercase tracking-wider mt-0.5">
          Secure Online Banking Portal
        </p>

        {/* Tab Switcher */}
        <div className="flex bg-white/10 p-1 rounded-2xl mt-5 text-xs font-bold">
          <button
            type="button"
            onClick={() => { setMode('login'); setLoginError(null); }}
            className={`flex-1 py-2 rounded-xl transition-all ${
              mode === 'login' ? 'bg-white text-[#002752] shadow-sm' : 'text-slate-200 hover:text-white'
            }`}
          >
            Customer Sign In
          </button>
          <button
            type="button"
            onClick={() => { setMode('register'); setRegError(null); }}
            className={`flex-1 py-2 rounded-xl transition-all ${
              mode === 'register' ? 'bg-[#c8102e] text-white shadow-sm' : 'text-slate-200 hover:text-white'
            }`}
          >
            Open An Account
          </button>
        </div>
      </div>

      {/* Main Body */}
      <div className="p-4 sm:p-7">
        
        {/* ================= MODE 1: CUSTOMER LOGIN ================= */}
        {mode === 'login' && (
          <form onSubmit={handleCustomerLoginSubmit} className="space-y-4">

            {sessionNotice && !loginError && (
              <div className="p-3.5 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 rounded-2xl text-xs text-amber-800 dark:text-amber-200 flex items-start gap-2 leading-relaxed">
                <Clock className="w-4 h-4 mt-0.5 shrink-0 text-amber-600" />
                <span>{sessionNotice}</span>
              </div>
            )}

            {loginError && (
              <div className="p-3.5 bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 rounded-2xl text-xs text-red-700 dark:text-red-300 flex items-start gap-2 leading-relaxed">
                <AlertCircle className="w-4 h-4 mt-0.5 shrink-0 text-red-600" />
                <span>{loginError}</span>
              </div>
            )}

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-1.5">
                Username or Email Address
              </label>
              <div className="relative">
                <UserIcon className="w-4 h-4 absolute left-3.5 top-3.5 text-slate-400" />
                <input
                  type="text"
                  required
                  placeholder="Enter registered username or email"
                  value={loginIdentifier}
                  onChange={e => setLoginIdentifier(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#002752]"
                />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider">
                  Password
                </label>
                <button
                  type="button"
                  onClick={() => { setMode('forgot'); setForgotStep('request'); setForgotError(null); }}
                  className="text-xs font-semibold text-[#c8102e] hover:underline"
                >
                  Forgot Password?
                </button>
              </div>
              <div className="relative">
                <Lock className="w-4 h-4 absolute left-3.5 top-3.5 text-slate-400" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  placeholder="Enter your confidential password"
                  value={loginPassword}
                  onChange={e => setLoginPassword(e.target.value)}
                  className="w-full pl-10 pr-10 py-2.5 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#002752]"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(p => !p)}
                  className="absolute right-3.5 top-3 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <div className="pt-2">
              <button
                type="submit"
                disabled={loginLoading}
                className="w-full py-3 bg-[#002752] hover:bg-[#001d3d] text-white font-bold rounded-xl text-sm shadow-md transition-all flex items-center justify-center gap-2 disabled:opacity-50"
              >
                <span>{loginLoading ? 'Authenticating...' : 'Sign In to Banking'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>

            <div className="text-center pt-2 text-xs text-slate-500">
              Don't have an account yet?{' '}
              <button
                type="button"
                onClick={() => setMode('register')}
                className="font-bold text-[#c8102e] hover:underline"
              >
                Apply for an Account
              </button>
            </div>
          </form>
        )}

        {/* ================= MODE 2: CUSTOMER REGISTRATION ================= */}
        {mode === 'register' && (
          <div>
            {/* Step 1: 4-Section User Registration Form */}
            {regStep === 'form' && (
              <form onSubmit={handleRegisterFormSubmit} className="space-y-5">
                
                {regError && (
                  <div className="p-3 bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 rounded-2xl text-xs text-red-700 dark:text-red-300 flex items-start gap-2">
                    <AlertCircle className="w-4 h-4 mt-0.5 shrink-0 text-red-600" />
                    <span>{regError}</span>
                  </div>
                )}

                {/* SECTION A: Personal Information */}
                <div className="border border-slate-200 dark:border-slate-800 rounded-2xl p-4 bg-slate-50/60 dark:bg-slate-950/40 space-y-3">
                  <div className="flex items-center gap-2 pb-1 border-b border-slate-200 dark:border-slate-800">
                    <span className="w-6 h-6 rounded-full bg-[#002752] text-white text-xs font-bold flex items-center justify-center">A</span>
                    <h3 className="text-xs font-bold uppercase tracking-wider text-[#002752] dark:text-blue-300">
                      Personal Information
                    </h3>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                        First Name <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="John"
                        value={regForm.firstName}
                        onChange={e => setRegForm({ ...regForm, firstName: e.target.value })}
                        className="w-full px-3 py-2 text-xs sm:text-sm bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#002752]"
                      />
                    </div>

                    <div>
                      <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                        Middle Name <span className="text-slate-400 text-[10px]">(Optional)</span>
                      </label>
                      <input
                        type="text"
                        placeholder="Edward"
                        value={regForm.middleName}
                        onChange={e => setRegForm({ ...regForm, middleName: e.target.value })}
                        className="w-full px-3 py-2 text-xs sm:text-sm bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#002752]"
                      />
                    </div>

                    <div>
                      <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                        Last Name <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="Smith"
                        value={regForm.lastName}
                        onChange={e => setRegForm({ ...regForm, lastName: e.target.value })}
                        className="w-full px-3 py-2 text-xs sm:text-sm bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#002752]"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Date of Birth
                    </label>
                    <div className="relative">
                      <Calendar className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-400" />
                      <input
                        type="date"
                        value={regForm.dateOfBirth}
                        onChange={e => setRegForm({ ...regForm, dateOfBirth: e.target.value })}
                        className="w-full pl-9 pr-3 py-2 text-xs sm:text-sm bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#002752]"
                      />
                    </div>
                  </div>
                </div>

                {/* SECTION B: Contact Information */}
                <div className="border border-slate-200 dark:border-slate-800 rounded-2xl p-4 bg-slate-50/60 dark:bg-slate-950/40 space-y-3">
                  <div className="flex items-center gap-2 pb-1 border-b border-slate-200 dark:border-slate-800">
                    <span className="w-6 h-6 rounded-full bg-[#002752] text-white text-xs font-bold flex items-center justify-center">B</span>
                    <h3 className="text-xs font-bold uppercase tracking-wider text-[#002752] dark:text-blue-300">
                      Contact Information
                    </h3>
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Email Address <span className="text-red-500">*</span>
                    </label>
                    <div className="relative">
                      <Mail className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
                      <input
                        type="email"
                        required
                        placeholder="name@example.com"
                        value={regForm.email}
                        onChange={e => setRegForm({ ...regForm, email: e.target.value })}
                        className="w-full pl-9 pr-3 py-2 text-xs sm:text-sm bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#002752]"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    {/* Searchable Country Dropdown */}
                    <div className="relative">
                      <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                        Country of Residence <span className="text-red-500">*</span>
                      </label>
                      <button
                        type="button"
                        onClick={() => setIsCountryDropdownOpen(!isCountryDropdownOpen)}
                        className="w-full px-3 py-2 text-xs sm:text-sm bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white flex items-center justify-between focus:outline-none focus:ring-2 focus:ring-[#002752]"
                      >
                        <div className="flex items-center gap-2 truncate">
                          <Globe className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                          <span className="truncate">{regForm.country}</span>
                        </div>
                        <span className="text-[10px] text-slate-400 shrink-0">▼</span>
                      </button>

                      {isCountryDropdownOpen && (
                        <div className="absolute z-30 left-0 right-0 mt-1 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-2xl shadow-2xl p-2 max-h-60 overflow-y-auto">
                          <div className="relative mb-2">
                            <Search className="w-3 h-3 absolute left-2.5 top-2.5 text-slate-400" />
                            <input
                              type="text"
                              placeholder="Search country or code..."
                              value={countrySearch}
                              onChange={e => setCountrySearch(e.target.value)}
                              className="w-full pl-7 pr-2 py-1.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:outline-none"
                              autoFocus
                            />
                          </div>
                          <div className="space-y-0.5">
                            {filteredCountries.map(c => (
                              <button
                                key={c.code}
                                type="button"
                                onClick={() => handleSelectCountry(c)}
                                className={`w-full text-left px-2.5 py-1.5 text-xs rounded-lg flex items-center justify-between hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors ${
                                  regForm.country === c.name ? 'bg-blue-50 dark:bg-blue-950/60 font-bold text-[#002752] dark:text-blue-300' : 'text-slate-700 dark:text-slate-300'
                                }`}
                              >
                                <span>{c.name}</span>
                                <span className="font-mono text-[10px] text-slate-400">{c.dialCode}</span>
                              </button>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Phone Number with auto code */}
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                        Phone Number <span className="text-red-500">*</span>
                      </label>
                      <div className="relative">
                        <Phone className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-400" />
                        <input
                          type="tel"
                          required
                          placeholder="+44 7700 900077"
                          value={regForm.phone}
                          onChange={e => setRegForm({ ...regForm, phone: e.target.value })}
                          className="w-full pl-9 pr-3 py-2 text-xs sm:text-sm bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#002752]"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                        State / Province
                      </label>
                      <input
                        type="text"
                        placeholder="e.g. Greater London"
                        value={regForm.state}
                        onChange={e => setRegForm({ ...regForm, state: e.target.value })}
                        className="w-full px-3 py-2 text-xs sm:text-sm bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#002752]"
                      />
                    </div>

                    <div className="sm:col-span-2">
                      <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                        Residential Address
                      </label>
                      <div className="relative">
                        <MapPin className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-400" />
                        <input
                          type="text"
                          placeholder="Street name, flat, house number"
                          value={regForm.residentialAddress}
                          onChange={e => setRegForm({ ...regForm, residentialAddress: e.target.value })}
                          className="w-full pl-9 pr-3 py-2 text-xs sm:text-sm bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#002752]"
                        />
                      </div>
                    </div>
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Postal Code / ZIP
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. EC2N 2DB"
                      value={regForm.postalCode}
                      onChange={e => setRegForm({ ...regForm, postalCode: e.target.value })}
                      className="w-full px-3 py-2 text-xs sm:text-sm bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#002752]"
                    />
                  </div>
                </div>

                {/* SECTION C: Login Credentials */}
                <div className="border border-slate-200 dark:border-slate-800 rounded-2xl p-4 bg-slate-50/60 dark:bg-slate-950/40 space-y-3">
                  <div className="flex items-center gap-2 pb-1 border-b border-slate-200 dark:border-slate-800">
                    <span className="w-6 h-6 rounded-full bg-[#002752] text-white text-xs font-bold flex items-center justify-center">C</span>
                    <h3 className="text-xs font-bold uppercase tracking-wider text-[#002752] dark:text-blue-300">
                      Login Credentials
                    </h3>
                  </div>

                  {/* Username with Live Availability Checker */}
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300">
                        Username <span className="text-red-500">*</span>
                      </label>
                      {usernameStatus.checking && (
                        <span className="text-[10px] text-slate-500 animate-pulse">Checking availability...</span>
                      )}
                      {!usernameStatus.checking && usernameStatus.available === true && (
                        <span className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
                          <CheckCircle2 className="w-3 h-3" /> Available
                        </span>
                      )}
                      {!usernameStatus.checking && usernameStatus.available === false && (
                        <span className="text-[10px] font-bold text-red-600 dark:text-red-400 flex items-center gap-1">
                          <AlertCircle className="w-3 h-3" /> Taken
                        </span>
                      )}
                    </div>
                    <div className="relative">
                      <UserIcon className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-400" />
                      <input
                        type="text"
                        required
                        placeholder="Choose unique username (e.g. johnsmith)"
                        value={regForm.username}
                        onChange={e => setRegForm({ ...regForm, username: e.target.value.toLowerCase().replace(/\s+/g, '') })}
                        className={`w-full pl-9 pr-3 py-2 text-xs sm:text-sm bg-white dark:bg-slate-900 border rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 ${
                          usernameStatus.available === true 
                            ? 'border-emerald-500 focus:ring-emerald-500' 
                            : usernameStatus.available === false 
                            ? 'border-red-500 focus:ring-red-500' 
                            : 'border-slate-300 dark:border-slate-700 focus:ring-[#002752]'
                        }`}
                      />
                    </div>
                  </div>

                  {/* Password & Confirm Password */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                        Password (min 8 chars) <span className="text-red-500">*</span>
                      </label>
                      <div className="relative">
                        <Lock className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-400" />
                        <input
                          type={showPassword ? 'text' : 'password'}
                          required
                          placeholder="••••••••"
                          value={regForm.password}
                          onChange={e => setRegForm({ ...regForm, password: e.target.value })}
                          className="w-full pl-9 pr-9 py-2 text-xs sm:text-sm bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#002752]"
                        />
                        <button
                          type="button"
                          onClick={() => setShowPassword(p => !p)}
                          className="absolute right-2.5 top-2.5 text-slate-400 hover:text-slate-600"
                        >
                          {showPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                        </button>
                      </div>
                    </div>

                    <div>
                      <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                        Confirm Password <span className="text-red-500">*</span>
                      </label>
                      <div className="relative">
                        <Lock className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-400" />
                        <input
                          type={showConfirmPassword ? 'text' : 'password'}
                          required
                          placeholder="••••••••"
                          value={regForm.confirmPassword}
                          onChange={e => setRegForm({ ...regForm, confirmPassword: e.target.value })}
                          className={`w-full pl-9 pr-9 py-2 text-xs sm:text-sm bg-white dark:bg-slate-900 border rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 ${
                            regForm.confirmPassword && regForm.password !== regForm.confirmPassword
                              ? 'border-red-500 focus:ring-red-500'
                              : 'border-slate-300 dark:border-slate-700 focus:ring-[#002752]'
                          }`}
                        />
                        <button
                          type="button"
                          onClick={() => setShowConfirmPassword(p => !p)}
                          className="absolute right-2.5 top-2.5 text-slate-400 hover:text-slate-600"
                        >
                          {showConfirmPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Password Strength Indicator & Match status */}
                  {regForm.password && (
                    <div className="space-y-1.5 pt-0.5">
                      <div className="flex items-center justify-between text-[10px]">
                        <span className="text-slate-500">Strength: <strong className="text-slate-700 dark:text-slate-200">{passwordStrength.label}</strong></span>
                        {regForm.confirmPassword && (
                          <span className={regForm.password === regForm.confirmPassword ? 'text-emerald-600 font-bold' : 'text-red-500 font-bold'}>
                            {regForm.password === regForm.confirmPassword ? '✓ Passwords match' : '✕ Passwords do not match'}
                          </span>
                        )}
                      </div>
                      <div className="h-1.5 w-full bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden flex gap-0.5">
                        <div className={`h-full ${passwordStrength.score >= 1 ? passwordStrength.color : 'bg-transparent'} flex-1`} />
                        <div className={`h-full ${passwordStrength.score >= 2 ? passwordStrength.color : 'bg-transparent'} flex-1`} />
                        <div className={`h-full ${passwordStrength.score >= 3 ? passwordStrength.color : 'bg-transparent'} flex-1`} />
                        <div className={`h-full ${passwordStrength.score >= 4 ? passwordStrength.color : 'bg-transparent'} flex-1`} />
                      </div>
                      <p className="text-[10px] text-slate-400">
                        Use 8+ characters including uppercase, lowercase, numbers, and symbols.
                      </p>
                    </div>
                  )}
                </div>

                {/* SECTION D: Consent & Preferences */}
                <div className="border border-slate-200 dark:border-slate-800 rounded-2xl p-4 bg-slate-50/60 dark:bg-slate-950/40 space-y-3">
                  <div className="flex items-center gap-2 pb-1 border-b border-slate-200 dark:border-slate-800">
                    <span className="w-6 h-6 rounded-full bg-[#002752] text-white text-xs font-bold flex items-center justify-center">D</span>
                    <h3 className="text-xs font-bold uppercase tracking-wider text-[#002752] dark:text-blue-300">
                      Consent & Preferences
                    </h3>
                  </div>

                  {/* Administrative Review Notice */}
                  <div className="p-3 bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-900 rounded-xl text-xs text-blue-900 dark:text-blue-200 flex items-start gap-2">
                    <ShieldCheck className="w-4 h-4 mt-0.5 shrink-0 text-blue-600" />
                    <div className="leading-snug">
                      <span className="font-bold">Administrative Review:</span>
                      <p className="text-[11px] mt-0.5 text-blue-800 dark:text-blue-300">
                        Your application will be submitted directly to our administration team for review and account number assignment.
                      </p>
                    </div>
                  </div>

                  {/* Consents */}
                  <div className="space-y-2 pt-1 text-xs">
                    <label className="flex items-start gap-2 text-slate-700 dark:text-slate-300 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={regForm.agreeTerms}
                        onChange={e => setRegForm({ ...regForm, agreeTerms: e.target.checked })}
                        className="mt-0.5 rounded text-[#002752] focus:ring-[#002752]"
                      />
                      <span className="leading-tight">
                        I accept the <strong className="text-slate-900 dark:text-white">Terms and Conditions</strong> for digital banking service access.
                      </span>
                    </label>

                    <label className="flex items-start gap-2 text-slate-700 dark:text-slate-300 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={regForm.agreePrivacy}
                        onChange={e => setRegForm({ ...regForm, agreePrivacy: e.target.checked })}
                        className="mt-0.5 rounded text-[#002752] focus:ring-[#002752]"
                      />
                      <span className="leading-tight">
                        I agree to the <strong className="text-slate-900 dark:text-white">Privacy Policy</strong> and data processing standards.
                      </span>
                    </label>
                  </div>

                  {/* Notification Preferences */}
                  <div className="pt-2 border-t border-slate-200 dark:border-slate-800">
                    <p className="text-[11px] font-bold text-slate-600 dark:text-slate-300 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
                      <BellRing className="w-3.5 h-3.5" />
                      <span>Notification Preferences</span>
                    </p>
                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <label className="flex items-center gap-2 text-slate-600 dark:text-slate-400">
                        <input
                          type="checkbox"
                          checked={regForm.emailAlerts}
                          onChange={e => setRegForm({ ...regForm, emailAlerts: e.target.checked })}
                          className="rounded text-[#002752]"
                        />
                        <span>Email Transaction Alerts</span>
                      </label>
                      <label className="flex items-center gap-2 text-slate-600 dark:text-slate-400">
                        <input
                          type="checkbox"
                          checked={regForm.smsAlerts}
                          onChange={e => setRegForm({ ...regForm, smsAlerts: e.target.checked })}
                          className="rounded text-[#002752]"
                        />
                        <span>SMS Security Alerts</span>
                      </label>
                    </div>
                  </div>
                </div>

                <div className="pt-1">
                  <button
                    type="submit"
                    disabled={regLoading}
                    className="w-full py-3 bg-[#c8102e] hover:bg-[#b00d27] text-white font-bold rounded-xl text-sm shadow-md transition-all flex items-center justify-center gap-2 disabled:opacity-50"
                  >
                    <span>{regLoading ? 'Submitting Application...' : 'Submit Application'}</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </form>
            )}

            {/* Step 2: Pending Administrator Approval Success State */}
            {regStep === 'pending_success' && (
              <div className="text-center py-4 space-y-4">
                <div className="w-16 h-16 bg-blue-100 dark:bg-blue-950/60 text-[#002752] dark:text-blue-400 rounded-full flex items-center justify-center mx-auto">
                  <Clock className="w-8 h-8" />
                </div>
                <h3 className="text-xl font-black text-slate-900 dark:text-white">
                  Application Under Administrative Review
                </h3>
                <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed max-w-md mx-auto">
                  Thank you, <strong>{regForm.firstName} {regForm.lastName}</strong>! Your registration application has been submitted. In accordance with banking security guidelines, an administrator will review your application before your unique account number is generated and portal is activated.
                </p>

                <div className="p-4 bg-slate-50 dark:bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-800 text-xs text-left space-y-2">
                  <div className="flex items-center justify-between pb-1.5 border-b border-slate-200 dark:border-slate-800">
                    <span className="text-slate-500">Registration Reference:</span>
                    <span className="font-mono font-bold text-[#002752] dark:text-blue-400">{referenceNumber || 'REF-REG-2026-PENDING'}</span>
                  </div>
                  <p className="text-slate-500">Applicant: <strong className="text-slate-800 dark:text-slate-200">{regForm.firstName} {regForm.middleName ? regForm.middleName + ' ' : ''}{regForm.lastName}</strong></p>
                  <p className="text-slate-500">Registered Email: <strong className="text-slate-800 dark:text-slate-200">{regForm.email}</strong></p>
                  <p className="text-slate-500">Country: <strong className="text-slate-800 dark:text-slate-200">{regForm.country}</strong></p>
                  <p className="text-slate-500">Status: <span className="font-bold text-amber-600 uppercase">PENDING_APPROVAL</span></p>
                </div>

                <div className="pt-2">
                  <button
                    type="button"
                    onClick={() => { setMode('login'); setRegStep('form'); }}
                    className="w-full py-2.5 bg-[#002752] hover:bg-[#001d3d] text-white font-semibold rounded-xl text-xs transition-colors"
                  >
                    Return to Customer Sign In
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* ================= MODE 3: FORGOT PASSWORD ================= */}
        {mode === 'forgot' && (
          <div className="space-y-4">
            {forgotStep === 'request' && (
              <form onSubmit={handleForgotRequestSubmit} className="space-y-4">
                <div className="text-center space-y-1">
                  <h3 className="text-lg font-bold text-slate-900 dark:text-white">
                    Reset Your Password
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Enter your registered email address to receive an authorization recovery code.
                  </p>
                </div>

                {forgotError && (
                  <div className="p-3 bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 rounded-2xl text-xs text-red-700 dark:text-red-300">
                    {forgotError}
                  </div>
                )}

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Email Address
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                    <input
                      type="email"
                      required
                      placeholder="e.g. sarah.jenkins@fnnbbankss.online"
                      value={forgotEmail}
                      onChange={e => setForgotEmail(e.target.value)}
                      className="w-full pl-9 pr-3 py-2.5 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#002752]"
                    />
                  </div>
                </div>

                <div className="flex gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setMode('login')}
                    className="flex-1 py-2.5 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-semibold rounded-xl text-xs hover:bg-slate-200"
                  >
                    Back to Sign In
                  </button>
                  <button
                    type="submit"
                    disabled={forgotLoading}
                    className="flex-1 py-2.5 bg-[#002752] hover:bg-[#001d3d] text-white font-bold rounded-xl text-xs shadow-md disabled:opacity-50"
                  >
                    {forgotLoading ? 'Sending...' : 'Send Recovery Code'}
                  </button>
                </div>
              </form>
            )}

            {forgotStep === 'verify' && (
              <form onSubmit={handleForgotVerifySubmit} className="space-y-3.5">
                <div className="text-center space-y-1">
                  <h3 className="text-lg font-bold text-slate-900 dark:text-white">
                    Set New Password
                  </h3>
                  <div className="p-3 bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800 rounded-xl text-xs text-blue-900 dark:text-blue-200 font-medium">
                    We have sent a 6-digit recovery code to your registered email address. Please check your inbox or spam folder.
                  </div>
                </div>

                {forgotResendStatus && (
                  <div className="p-3 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-300 dark:border-emerald-800 rounded-xl text-xs text-emerald-800 dark:text-emerald-300 flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>{forgotResendStatus}</span>
                  </div>
                )}

                {forgotError && (
                  <div className="p-3 bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 rounded-2xl text-xs text-red-700 dark:text-red-300">
                    {forgotError}
                  </div>
                )}

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1 text-center">
                    6-Digit Recovery Code
                  </label>
                  <input
                    type="text"
                    maxLength={6}
                    required
                    placeholder="• • • • • •"
                    value={forgotCode}
                    onChange={e => setForgotCode(e.target.value.replace(/\D/g, ''))}
                    className="w-full py-2.5 text-center font-mono font-bold text-xl tracking-widest bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#002752]"
                    autoFocus
                  />
                </div>

                <div className="flex items-center justify-center text-xs">
                  <button
                    type="button"
                    onClick={handleResendForgotCode}
                    disabled={forgotCooldown > 0}
                    className="font-bold text-[#c8102e] hover:underline disabled:opacity-50"
                  >
                    {forgotCooldown > 0 ? `Resend Code in ${forgotCooldown}s` : 'Resend Recovery Code'}
                  </button>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    New Password (min 8 chars)
                  </label>
                  <input
                    type="password"
                    required
                    placeholder="••••••••"
                    value={forgotNewPassword}
                    onChange={e => setForgotNewPassword(e.target.value)}
                    className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#002752]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Confirm New Password
                  </label>
                  <input
                    type="password"
                    required
                    placeholder="••••••••"
                    value={forgotConfirmPassword}
                    onChange={e => setForgotConfirmPassword(e.target.value)}
                    className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#002752]"
                  />
                </div>

                <div className="flex gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setForgotStep('request')}
                    className="flex-1 py-2.5 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-semibold rounded-xl text-xs hover:bg-slate-200"
                  >
                    Back
                  </button>
                  <button
                    type="submit"
                    disabled={forgotLoading}
                    className="flex-1 py-2.5 bg-[#002752] hover:bg-[#001d3d] disabled:opacity-50 text-white font-bold rounded-xl text-xs shadow-md"
                  >
                    {forgotLoading ? 'Updating...' : 'Update Password'}
                  </button>
                </div>
              </form>
            )}

            {forgotStep === 'done' && (
              <div className="text-center py-6 space-y-3">
                <CheckCircle2 className="w-14 h-14 text-emerald-500 mx-auto" />
                <h3 className="text-xl font-bold text-slate-900 dark:text-white">Password Updated</h3>
                <p className="text-xs text-slate-500">
                  Your account password has been successfully reset. You may now sign in using your new credentials.
                </p>
                <div className="pt-2">
                  <button
                    type="button"
                    onClick={() => { setMode('login'); setForgotStep('request'); }}
                    className="w-full py-2.5 bg-[#002752] hover:bg-[#001d3d] text-white font-bold rounded-xl text-xs shadow-md"
                  >
                    Sign In Now
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

      </div>

    </div>
  );
};
