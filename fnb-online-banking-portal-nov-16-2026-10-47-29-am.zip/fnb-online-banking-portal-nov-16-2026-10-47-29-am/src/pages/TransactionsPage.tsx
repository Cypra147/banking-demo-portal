import React, { useState, useEffect } from 'react';
import { api } from '../services/api.ts';
import { Transaction } from '../types.ts';
import { ReceiptModal } from '../components/ReceiptModal.tsx';
import { TransactionTagBadge } from '../components/TransactionTagBadge.tsx';
import { tagTransaction, AVAILABLE_TRANSACTION_TAGS } from '../utils/transactionTagger.ts';
import { formatUsdNumber, USD_SYMBOL } from '../utils/currency.ts';
import { 
  History, 
  Search, 
  ArrowDownLeft, 
  ArrowUpRight, 
  ShieldCheck, 
  Clock, 
  RotateCcw, 
  FileText, 
  ArrowRight,
  Filter,
  CheckCircle2,
  Sparkles,
  Tag
} from 'lucide-react';

interface TransactionsPageProps {
  onOpenAuth: (mode?: 'login' | 'register') => void;
  onNavigate: (page: string) => void;
  isAuthenticated: boolean;
}

export const TransactionsPage: React.FC<TransactionsPageProps> = ({ 
  onOpenAuth, 
  onNavigate,
  isAuthenticated 
}) => {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState('all');
  const [filterTag, setFilterTag] = useState<string>('All');
  const [activeReceiptTx, setActiveReceiptTx] = useState<Transaction | null>(null);

  useEffect(() => {
    async function loadLedger() {
      if (!isAuthenticated) {
        setTransactions([]);
        setLoading(false);
        return;
      }
      try {
        setLoading(true);
        const res = await api.getTransactions().catch(async () => {
          return { transactions: [] };
        });
        setTransactions(res.transactions || []);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    }
    loadLedger();
  }, [isAuthenticated]);

  const filtered = transactions.filter(t => {
    const q = searchQuery.toLowerCase();
    const tag = t.tag || tagTransaction(t.description, t.type, t.billerCategory).tag;
    const matchesSearch = 
      t.reference.toLowerCase().includes(q) ||
      t.description.toLowerCase().includes(q) ||
      (t.beneficiaryName && t.beneficiaryName.toLowerCase().includes(q)) ||
      (tag && tag.toLowerCase().includes(q));

    const matchesType = filterType === 'all' || t.type === filterType;
    const matchesTag = filterTag === 'All' || tag.toLowerCase() === filterTag.toLowerCase();

    return matchesSearch && matchesType && matchesTag;
  });

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 pb-20">
      
      {/* Header Banner */}
      <section className="bg-gradient-to-r from-[#001833] via-[#002752] to-[#003875] text-white py-16 px-4 sm:px-6 lg:px-8 border-b border-blue-900/50">
        <div className="max-w-6xl mx-auto">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-red-600/20 border border-red-500/30 text-red-300 text-xs font-semibold mb-4">
            <History className="w-4 h-4 text-red-400" />
            <span>Audited Electronic Transactions & Ledgers</span>
          </div>
          <h1 className="text-3xl sm:text-5xl font-black tracking-tight leading-tight max-w-3xl">
            Verifiable Transactions & Instant Receipts
          </h1>
          <p className="mt-4 text-base sm:text-lg text-slate-300 max-w-2xl leading-relaxed">
            Every transaction executed on the FNB platform produces an immutable reference code, clear USD ($) ledger tracking, and a printable official receipt.
          </p>
        </div>
      </section>

      {/* Ledger Security Highlights */}
      <div className="max-w-6xl mx-auto px-4 -mt-6">
        <div className="grid md:grid-cols-2 gap-4">
          <div className="bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-900 rounded-2xl p-4 sm:p-5 text-xs text-blue-900 dark:text-blue-200 flex items-start gap-3 shadow-sm">
            <Clock className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
            <div>
              <strong className="font-bold block text-sm mb-0.5">Real-Time USD ($) Ledger Settlement</strong>
              Domestic and international transfers record an immutable timestamp, beneficiary institution details, and full reference verification.
            </div>
          </div>
          <div className="bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900 rounded-2xl p-4 sm:p-5 text-xs text-emerald-900 dark:text-emerald-200 flex items-start gap-3 shadow-sm">
            <ShieldCheck className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
            <div>
              <strong className="font-bold block text-sm mb-0.5">Printable Transaction Receipts</strong>
              Open any completed debit, credit, bill payment, or transfer entry to inspect itemized details and print an official transaction receipt.
            </div>
          </div>
        </div>
      </div>

      {/* Transactions Container */}
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 mt-12">
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 shadow-sm space-y-6">
          
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h2 className="text-xl font-bold text-slate-900 dark:text-white">Transaction Search & Reference Lookup</h2>
              <p className="text-xs text-slate-500">Query references (e.g. <code>TXN-261028-A7F2</code>) or view your transaction feed</p>
            </div>
            {!isAuthenticated && (
              <button
                onClick={() => onOpenAuth('login')}
                className="px-4 py-2 bg-[#002752] text-white font-bold text-xs rounded-xl shadow transition-all flex items-center gap-1.5"
              >
                <span>Sign In to View Full Account Ledger</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Search Bar & Filter */}
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
              <input
                type="text"
                placeholder="Search reference, description, recipient, or category tag..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-3 py-2.5 text-xs sm:text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl"
              />
            </div>
            <select
              value={filterType}
              onChange={e => setFilterType(e.target.value)}
              className="px-3.5 py-2.5 text-xs sm:text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl"
            >
              <option value="all">All Types</option>
              <option value="transfer">Transfers</option>
              <option value="credit">Credits</option>
              <option value="debit">Debits</option>
              <option value="reversal">Reversals</option>
              <option value="bill_payment">Bill Payments</option>
            </select>
          </div>

          {/* Automatic Category Tag Filter Pills */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none text-xs">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider shrink-0 mr-1 flex items-center gap-1">
              <Tag className="w-3 h-3 text-[#c8102e]" />
              Tag:
            </span>
            {AVAILABLE_TRANSACTION_TAGS.map(tag => {
              const isSelected = filterTag === tag;
              return (
                <button
                  key={tag}
                  type="button"
                  onClick={() => setFilterTag(tag)}
                  className={`px-3 py-1 rounded-full text-xs font-semibold whitespace-nowrap transition-all ${
                    isSelected
                      ? 'bg-[#002752] text-white shadow-sm ring-2 ring-[#002752]/20'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                  }`}
                >
                  {tag}
                </button>
              );
            })}
          </div>

          {/* Transaction Table / List */}
          {loading ? (
            <p className="text-center py-12 text-slate-400 text-xs">Loading transaction records...</p>
          ) : !isAuthenticated ? (
            <div className="text-center py-12 space-y-3">
              <FileText className="w-10 h-10 text-slate-300 mx-auto" />
              <p className="text-xs text-slate-500">Sign in to your FNB Online Banking account to inspect your private transaction history and receipts.</p>
              <button
                onClick={() => onOpenAuth('login')}
                className="px-4 py-2 bg-[#c8102e] text-white font-bold text-xs rounded-xl shadow"
              >
                Sign In to Online Banking
              </button>
            </div>
          ) : filtered.length === 0 ? (
            <div className="text-center py-12 space-y-3">
              <FileText className="w-10 h-10 text-slate-300 mx-auto" />
              <p className="text-xs text-slate-500">No transactions matching your query or selected tag.</p>
            </div>
          ) : (
            <div className="divide-y divide-slate-100 dark:divide-slate-800">
              {filtered.map(tx => (
                <div key={tx.id} className="py-4 flex items-center justify-between gap-4 text-xs">
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                      tx.type === 'credit' || tx.type === 'reversal'
                        ? 'bg-emerald-50 dark:bg-emerald-950 text-emerald-600'
                        : 'bg-red-50 dark:bg-red-950 text-red-600'
                    }`}>
                      {tx.type === 'credit' || tx.type === 'reversal' ? <ArrowDownLeft className="w-5 h-5" /> : <ArrowUpRight className="w-5 h-5" />}
                    </div>
                    <div>
                      <div className="flex flex-wrap items-center gap-2">
                        <strong className="text-sm font-bold text-slate-900 dark:text-white">
                          {tx.description}
                        </strong>
                        <TransactionTagBadge 
                          tag={tx.tag || tagTransaction(tx.description, tx.type, tx.billerCategory).tag} 
                          showIcon 
                        />
                      </div>
                      <div className="flex items-center gap-2 text-slate-400 font-mono text-[11px] mt-1">
                        <span>{tx.reference}</span>
                        <span>•</span>
                        <span>{new Date(tx.createdAt).toLocaleDateString()}</span>
                        {tx.isReversed && (
                          <span className="px-1.5 py-0.2 bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 rounded font-sans text-[9px] font-bold">
                            REVERSED
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="text-right shrink-0">
                    <p className={`font-black text-sm ${
                      tx.type === 'credit' || tx.type === 'reversal' ? 'text-emerald-600' : 'text-slate-900 dark:text-white'
                    }`}>
                      {tx.type === 'credit' || tx.type === 'reversal' ? '+' : '-'}
                      {USD_SYMBOL}{formatUsdNumber(tx.amount)}
                    </p>
                    <button
                      onClick={() => setActiveReceiptTx(tx)}
                      className="text-[10px] text-[#002752] dark:text-blue-400 font-bold hover:underline"
                    >
                      Receipt
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}

        </div>
      </div>

      {/* Receipt Modal */}
      {activeReceiptTx && (
        <ReceiptModal
          transaction={activeReceiptTx}
          onClose={() => setActiveReceiptTx(null)}
          onReversalSuccess={() => {
            // refresh
            api.getTransactions().then(res => setTransactions(res.transactions || []));
          }}
        />
      )}

    </div>
  );
};
