import React from 'react';
import { ShieldCheck, Award, Building2, Globe2, Lock, Users, ArrowRight, CheckCircle2 } from 'lucide-react';

interface AboutPageProps {
  onOpenAuth: (mode?: 'login' | 'register') => void;
  onNavigate: (page: string) => void;
}

export const AboutPage: React.FC<AboutPageProps> = ({ onOpenAuth, onNavigate }) => {
  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 pb-20">
      
      {/* Hero Banner */}
      <section className="bg-gradient-to-r from-[#001833] via-[#002752] to-[#003875] text-white py-16 px-4 sm:px-6 lg:px-8 border-b border-blue-900/50">
        <div className="max-w-6xl mx-auto">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-red-600/20 border border-red-500/30 text-red-300 text-xs font-semibold mb-4">
            <ShieldCheck className="w-4 h-4 text-red-400" />
            <span>Institutional Excellence & Digital Precision</span>
          </div>
          <h1 className="text-3xl sm:text-5xl font-black tracking-tight leading-tight max-w-3xl">
            Empowering Modern Commerce, Protecting Every Transaction.
          </h1>
          <p className="mt-4 text-base sm:text-lg text-slate-300 max-w-2xl leading-relaxed">
            First National Bank (FNB) provides resilient financial architecture, next-generation online banking systems, and disciplined asset security for individuals and global enterprises.
          </p>
          <div className="mt-8 flex flex-wrap gap-4">
            <button
              onClick={() => onOpenAuth('register')}
              className="px-6 py-3 bg-[#c8102e] hover:bg-[#a50d26] text-white font-bold rounded-xl text-sm shadow-lg shadow-red-900/30 transition-all flex items-center gap-2"
            >
              <span>Open Customer Account</span>
              <ArrowRight className="w-4 h-4" />
            </button>
            <button
              onClick={() => onNavigate('services')}
              className="px-6 py-3 bg-white/10 hover:bg-white/20 text-white font-semibold rounded-xl text-sm border border-white/20 transition-all"
            >
              Explore Banking Services
            </button>
          </div>
        </div>
      </section>

      {/* Platform Overview Notice Card */}
      <div className="max-w-6xl mx-auto px-4 -mt-6">
        <div className="bg-amber-50 dark:bg-amber-950/40 border border-amber-300/80 dark:border-amber-700/60 rounded-2xl p-4 sm:p-5 shadow-sm text-xs sm:text-sm text-amber-900 dark:text-amber-200 flex items-start gap-3">
          <div className="p-2 bg-amber-500/20 rounded-xl shrink-0">
            <Lock className="w-5 h-5 text-amber-700 dark:text-amber-400" />
          </div>
          <div className="leading-relaxed">
            <strong className="font-bold block text-sm mb-0.5 text-amber-950 dark:text-amber-100">
              Platform Architecture & Account Disclosure
            </strong>
            This independent digital banking platform provides account management, multi-factor verification, USD ($) transfers, and compliance workflows within a secure online banking environment.
          </div>
        </div>
      </div>

      {/* Mission & Values */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 mt-16">
        <div className="grid md:grid-cols-3 gap-8">
          
          <div className="bg-white dark:bg-slate-900 p-8 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-md transition-shadow">
            <div className="w-12 h-12 bg-blue-100 dark:bg-blue-950 text-[#002752] dark:text-blue-400 rounded-xl flex items-center justify-center mb-5">
              <Building2 className="w-6 h-6" />
            </div>
            <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2">Our Mission</h3>
            <p className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
              To deliver uncompromising financial reliability, seamless mobile accessibility, and transparent wealth management tools that safeguard capital while accelerating individual and commercial progress.
            </p>
          </div>

          <div className="bg-white dark:bg-slate-900 p-8 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-md transition-shadow">
            <div className="w-12 h-12 bg-red-100 dark:bg-red-950 text-red-600 rounded-xl flex items-center justify-center mb-5">
              <Award className="w-6 h-6" />
            </div>
            <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2">Our Vision</h3>
            <p className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
              To define the global benchmark in digital financial infrastructure — blending institutional trust with intuitive software interfaces that eliminate friction in transfers and savings.
            </p>
          </div>

          <div className="bg-white dark:bg-slate-900 p-8 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-md transition-shadow">
            <div className="w-12 h-12 bg-emerald-100 dark:bg-emerald-950 text-emerald-600 rounded-xl flex items-center justify-center mb-5">
              <Globe2 className="w-6 h-6" />
            </div>
            <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2">Global Governance</h3>
            <p className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
              Operating with multi-layer cryptographic safeguards, end-to-end data encryption, and robust Know-Your-Customer (KYC) identity protocols that protect consumer rights worldwide.
            </p>
          </div>

        </div>
      </section>

      {/* Key Pillars */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 mt-20">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <h2 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white">
            Built on Five Pillars of Institutional Trust
          </h2>
          <p className="mt-2 text-sm text-slate-600 dark:text-slate-400">
            How FNB maintains structural integrity and customer protection across every touchpoint.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {[
            {
              title: '256-Bit Cryptographic Security',
              desc: 'Military-grade encryption protects data at rest and in transit across all web and mobile banking sessions.'
            },
            {
              title: 'Email OTP Multi-Factor Verification',
              desc: 'Every account registration, sensitive configuration update, and password recovery is authenticated with dynamic OTPs.'
            },
            {
              title: 'Instant Virtual Cards',
              desc: 'Customers can generate, configure daily spending caps, and instantly freeze or unfreeze digital cards for secure online purchases.'
            },
            {
              title: 'Transparent Transaction Ledger',
              desc: 'Clear USD ($) debit and credit records, full account statements, and verifiable reference numbers for every entry.'
            },
            {
              title: 'Dedicated Human Support',
              desc: 'Direct access to support agents via telephone, WhatsApp, live chat, and a registered support ticket queue.'
            },
            {
              title: 'Tiered Verification (KYC)',
              desc: 'Strict identification compliance ensuring safe customer environments, fraud prevention, and regulatory alignment.'
            }
          ].map((pillar, idx) => (
            <div key={idx} className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 flex gap-4">
              <CheckCircle2 className="w-5 h-5 text-emerald-500 shrink-0 mt-0.5" />
              <div>
                <h4 className="font-bold text-slate-900 dark:text-white text-sm mb-1">{pillar.title}</h4>
                <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">{pillar.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Leadership & Contact Summary Banner */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 mt-20">
        <div className="bg-[#002752] text-white rounded-3xl p-8 sm:p-12 relative overflow-hidden">
          <div className="relative z-10 max-w-2xl">
            <h3 className="text-2xl sm:text-3xl font-black">Ready to Experience Modern Online Banking?</h3>
            <p className="mt-3 text-sm text-slate-300 leading-relaxed">
              Open an account in under three minutes, verify your details, and manage checking accounts, high-yield investment allocations, and electronic transfers.
            </p>
            <div className="mt-6 flex flex-wrap gap-4">
              <button
                onClick={() => onOpenAuth('register')}
                className="px-6 py-3 bg-[#c8102e] hover:bg-[#a50d26] font-bold text-sm rounded-xl transition-all shadow-lg"
              >
                Register Now
              </button>
              <button
                onClick={() => onNavigate('support')}
                className="px-6 py-3 bg-white/10 hover:bg-white/20 font-semibold text-sm rounded-xl border border-white/20 transition-all"
              >
                Contact Client Relations
              </button>
            </div>
          </div>
        </div>
      </section>

    </div>
  );
};
