import React, { useState, useEffect, useCallback } from 'react';
import { useAuth } from '../context/AuthContext.tsx';
import { api } from '../services/api.ts';
import { 
  User, 
  Transaction, 
  AuditLog, 
  InvestmentRequest, 
  VerificationRequest, 
  SupportEnquiry 
} from '../types.ts';
import { StatementModal } from '../components/StatementModal.tsx';
import { ReceiptModal } from '../components/ReceiptModal.tsx';
import { TransactionTagBadge } from '../components/TransactionTagBadge.tsx';
import { tagTransaction } from '../utils/transactionTagger.ts';
import { formatUsdNumber, USD_SYMBOL, USD_CODE } from '../utils/currency.ts';
import { 
  ShieldCheck, 
  Users, 
  Clock, 
  CheckCircle2, 
  XCircle, 
  Snowflake, 
  Ban, 
  Edit, 
  PlusCircle, 
  MinusCircle, 
  FileText, 
  RotateCcw, 
  Search, 
  Filter, 
  AlertTriangle,
  CreditCard,
  Building2,
  DollarSign,
  TrendingUp,
  Activity,
  UserCheck,
  UserPlus,
  Download,
  Mail,
  Shield,
  Eye,
  EyeOff,
  FileCheck2,
  MessageSquare,
  MessageCircle,
  HelpCircle,
  Send,
  Layers,
  ArrowRight,
  History,
  KeyRound,
  Trash2,
  Database,
  RefreshCw,
  Wand2
} from 'lucide-react';

interface AdminBackupMeta {
  id: string;
  createdAt: string;
  createdBy: string;
  customerCount: number;
  transactionCount: number;
  reason?: string;
}

function generateClientAccountNumber(): string {
  const randomDigits = Math.floor(10000000 + Math.random() * 90000000).toString();
  return `10${randomDigits.slice(0, 8)}`;
}

function generateStrongTempPassword(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$';
  let out = 'Fnb!';
  for (let i = 0; i < 8; i++) {
    out += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return out;
}

interface AdminDashboardProps {
  onLogout?: () => Promise<void> | void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ onLogout }) => {
  const { setIsMailModalOpen, logoutAdmin } = useAuth();
  const handleAdminLogout = async () => {
    if (onLogout) {
      await onLogout();
    } else {
      await logoutAdmin();
    }
  };

  // Navigation sub-tabs
  const [activeTab, setActiveTab] = useState<'overview' | 'customers' | 'verifications' | 'investments' | 'transactions' | 'support' | 'audit'>('overview');

  // Data states
  const [stats, setStats] = useState<any>(null);
  const [customers, setCustomers] = useState<User[]>([]);
  const [ledger, setLedger] = useState<Transaction[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [investments, setInvestments] = useState<InvestmentRequest[]>([]);
  const [verifications, setVerifications] = useState<VerificationRequest[]>([]);
  const [supportEnquiries, setSupportEnquiries] = useState<SupportEnquiry[]>([]);
  const [backups, setBackups] = useState<AdminBackupMeta[]>([]);
  const [loading, setLoading] = useState(true);

  // Search & Filter
  const [customerSearch, setCustomerSearch] = useState('');
  const [customerStatusFilter, setCustomerStatusFilter] = useState<'all' | 'pending_approval' | 'active' | 'frozen' | 'suspended' | 'rejected'>('all');

  // Modals state
  // 1. Credit / Debit Modal
  const [creditDebitModal, setCreditDebitModal] = useState<{
    isOpen: boolean;
    customer: User | null;
    type: 'credit' | 'debit';
    amount: string;
    description: string;
    reference: string;
    error?: string;
  }>({
    isOpen: false,
    customer: null,
    type: 'credit',
    amount: '',
    description: '',
    reference: '',
  });

  // 2. Edit Profile Modal
  const [editProfileModal, setEditProfileModal] = useState<{
    isOpen: boolean;
    customer: User | null;
    firstName: string;
    middleName: string;
    lastName: string;
    email: string;
    phone: string;
    username: string;
    accountNumber: string;
    sortCode: string;
    country: string;
    residentialAddress: string;
    kycStatus: 'unverified' | 'pending' | 'pending_review' | 'verified' | 'rejected';
    error?: string;
  }>({
    isOpen: false,
    customer: null,
    firstName: '',
    middleName: '',
    lastName: '',
    email: '',
    phone: '',
    username: '',
    accountNumber: '',
    sortCode: '',
    country: '',
    residentialAddress: '',
    kycStatus: 'unverified',
  });

  // 3. View Customer Details Modal
  const [viewCustomerModal, setViewCustomerModal] = useState<User | null>(null);

  // 4. Create / Register New Customer Modal
  const [createCustomerModal, setCreateCustomerModal] = useState<{
    isOpen: boolean;
    firstName: string;
    middleName: string;
    lastName: string;
    email: string;
    username: string;
    phone: string;
    password: string;
    country: string;
    residentialAddress: string;
    accountNumber: string;
    status: 'active' | 'pending_approval';
    error?: string;
    submitting?: boolean;
  }>({
    isOpen: false,
    firstName: '',
    middleName: '',
    lastName: '',
    email: '',
    username: '',
    phone: '',
    password: '',
    country: 'United Kingdom',
    residentialAddress: '',
    accountNumber: '',
    status: 'active',
  });

  // 5. Approve & Assign Account Number Modal
  const [approveModal, setApproveModal] = useState<{
    isOpen: boolean;
    customer: User | null;
    accountNumber: string;
    username: string;
    error?: string;
    submitting?: boolean;
  }>({
    isOpen: false,
    customer: null,
    accountNumber: '',
    username: '',
  });

  // 6. Reset Password Modal
  const [resetPasswordModal, setResetPasswordModal] = useState<{
    isOpen: boolean;
    customer: User | null;
    newPassword: string;
    showPassword: boolean;
    error?: string;
    submitting?: boolean;
  }>({
    isOpen: false,
    customer: null,
    newPassword: '',
    showPassword: false,
  });

  // 7. Explicitly Authorized Delete Modal
  const [deleteModal, setDeleteModal] = useState<{
    isOpen: boolean;
    customer: User | null;
    confirmText: string;
    error?: string;
    submitting?: boolean;
  }>({
    isOpen: false,
    customer: null,
    confirmText: '',
  });

  // 8. Database Backups Modal
  const [backupsModalOpen, setBackupsModalOpen] = useState(false);
  const [backupActionLoading, setBackupActionLoading] = useState(false);

  // 9. Reject Registration Modal
  const [rejectModal, setRejectModal] = useState<{
    isOpen: boolean;
    customer: User | null;
    reason: string;
  }>({
    isOpen: false,
    customer: null,
    reason: 'Application details could not be verified.',
  });

  // 10. Support Reply Modal
  const [replyTicketModal, setReplyTicketModal] = useState<{
    isOpen: boolean;
    ticket: SupportEnquiry | null;
    replyText: string;
    status: 'open' | 'in_progress' | 'resolved';
    error?: string;
  }>({
    isOpen: false,
    ticket: null,
    replyText: '',
    status: 'resolved',
  });

  // 11. Statement Modal for a selected customer
  const [statementCustomer, setStatementCustomer] = useState<User | null>(null);

  // 12. Receipt Modal
  const [activeReceiptTx, setActiveReceiptTx] = useState<Transaction | null>(null);

  // Action status notification
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  const fetchAdminData = useCallback(async () => {
    try {
      setLoading(true);
      const [statsRes, custRes, ledgerRes, auditRes, invRes, verRes, supRes, bkpRes] = await Promise.all([
        api.getAdminStats(),
        api.getAdminCustomers(),
        api.getAdminLedger(),
        api.getAdminAuditLogs(),
        api.getInvestments(true).catch(() => ({ investments: [] })),
        api.getVerifications(true).catch(() => ({ verifications: [] })),
        api.getSupportEnquiries(undefined, true).catch(() => ({ enquiries: [] })),
        api.getAdminBackups().catch(() => ({ backups: [] })),
      ]);

      setStats(statsRes);
      setCustomers(custRes.customers || []);
      setLedger(ledgerRes.ledger || []);
      setAuditLogs(auditRes.auditLogs || []);
      setInvestments(invRes.investments || []);
      setVerifications(verRes.verifications || []);
      setSupportEnquiries(supRes.enquiries || []);
      setBackups(bkpRes.backups || []);
    } catch (err: any) {
      console.error(err);
      setFeedback({ type: 'error', message: err.message || 'Failed to load administrator data.' });
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchAdminData();
  }, [fetchAdminData]);

  const showNotification = (type: 'success' | 'error', message: string) => {
    setFeedback({ type, message });
    setTimeout(() => setFeedback(null), 5000);
  };

  // --- Customer Actions ---
  const openApproveModal = (cust: User) => {
    setApproveModal({
      isOpen: true,
      customer: cust,
      accountNumber: cust.accountNumber || generateClientAccountNumber(),
      username: cust.username || '',
      error: undefined,
      submitting: false,
    });
  };

  const handleApproveSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!approveModal.customer) return;
    setApproveModal((prev) => ({ ...prev, submitting: true, error: undefined }));
    try {
      const res = await api.approveCustomer(approveModal.customer.id, 0, {
        accountNumber: approveModal.accountNumber.trim() || undefined,
        username: approveModal.username.trim() || undefined,
      });
      showNotification('success', res.message);
      setApproveModal({ isOpen: false, customer: null, accountNumber: '', username: '' });
      await fetchAdminData();
    } catch (err: any) {
      setApproveModal((prev) => ({ ...prev, submitting: false, error: err.message || 'Approval failed' }));
    }
  };

  const handleApprove = async (customerId: string) => {
    try {
      const res = await api.approveCustomer(customerId, 0); // newly approved accounts start at $0.00 till credited
      showNotification('success', res.message);
      await fetchAdminData();
    } catch (err: any) {
      showNotification('error', err.message || 'Approval failed');
    }
  };

  const openRejectModal = (cust: User) => {
    setRejectModal({
      isOpen: true,
      customer: cust,
      reason: 'Application details could not be verified.',
    });
  };

  const handleRejectSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!rejectModal.customer) return;
    try {
      const res = await api.rejectCustomer(rejectModal.customer.id, rejectModal.reason.trim() || 'Application details could not be verified.');
      showNotification('success', res.message);
      setRejectModal({ isOpen: false, customer: null, reason: '' });
      await fetchAdminData();
    } catch (err: any) {
      showNotification('error', err.message || 'Rejection failed');
    }
  };

  const handleToggleFreeze = async (customer: User) => {
    const nextStatus = customer.status === 'frozen' ? 'active' : 'frozen';
    try {
      const res = await api.setCustomerStatus(customer.id, nextStatus);
      showNotification('success', res.message);
      if (viewCustomerModal?.id === customer.id) setViewCustomerModal(res.user);
      await fetchAdminData();
    } catch (err: any) {
      showNotification('error', err.message || 'Status update failed');
    }
  };

  const handleToggleSuspend = async (customer: User) => {
    const nextStatus = customer.status === 'suspended' ? 'active' : 'suspended';
    try {
      const res = await api.setCustomerStatus(customer.id, nextStatus);
      showNotification('success', res.message);
      if (viewCustomerModal?.id === customer.id) setViewCustomerModal(res.user);
      await fetchAdminData();
    } catch (err: any) {
      showNotification('error', err.message || 'Status update failed');
    }
  };

  const openEditProfileModal = (cust: User) => {
    setEditProfileModal({
      isOpen: true,
      customer: cust,
      firstName: cust.firstName || '',
      middleName: cust.middleName || '',
      lastName: cust.lastName || '',
      email: cust.email || '',
      phone: cust.phone || '',
      username: cust.username || '',
      accountNumber: cust.accountNumber || '',
      sortCode: cust.sortCode || '20-04-15',
      country: cust.country || 'United Kingdom',
      residentialAddress: cust.residentialAddress || '',
      kycStatus: cust.kycStatus || 'unverified',
      error: undefined,
    });
  };

  // Submit Credit / Debit
  const handleCreditDebitSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!creditDebitModal.customer) return;

    const amt = parseFloat(creditDebitModal.amount);
    if (isNaN(amt) || amt <= 0) {
      setCreditDebitModal((prev) => ({ ...prev, error: 'Please enter a valid positive amount.' }));
      return;
    }

    try {
      const res = await api.adminCreditDebit({
        customerId: creditDebitModal.customer.id,
        type: creditDebitModal.type,
        amount: amt,
        description: creditDebitModal.description || `Administrative ${creditDebitModal.type}`,
        reference: creditDebitModal.reference || undefined,
      });

      showNotification('success', res.message);
      setCreditDebitModal({ isOpen: false, customer: null, type: 'credit', amount: '', description: '', reference: '' });
      await fetchAdminData();
    } catch (err: any) {
      setCreditDebitModal((prev) => ({ ...prev, error: err.message || 'Action failed' }));
    }
  };

  // Submit Profile Edit
  const handleEditProfileSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editProfileModal.customer) return;
    try {
      const res = await api.updateCustomerProfile(editProfileModal.customer.id, {
        firstName: editProfileModal.firstName.trim(),
        middleName: editProfileModal.middleName.trim(),
        lastName: editProfileModal.lastName.trim(),
        email: editProfileModal.email.trim(),
        phone: editProfileModal.phone.trim(),
        username: editProfileModal.username.trim(),
        accountNumber: editProfileModal.accountNumber.trim() || undefined,
        sortCode: editProfileModal.sortCode.trim() || undefined,
        country: editProfileModal.country.trim(),
        residentialAddress: editProfileModal.residentialAddress.trim(),
        kycStatus: editProfileModal.kycStatus,
      });
      showNotification('success', 'Customer account record updated permanently.');
      if (viewCustomerModal?.id === editProfileModal.customer.id) {
        setViewCustomerModal(res.user);
      }
      setEditProfileModal((prev) => ({ ...prev, isOpen: false, customer: null, error: undefined }));
      await fetchAdminData();
    } catch (err: any) {
      setEditProfileModal((prev) => ({ ...prev, error: err.message || 'Profile update failed' }));
    }
  };

  // Submit Create Customer
  const handleCreateCustomerSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setCreateCustomerModal((prev) => ({ ...prev, submitting: true, error: undefined }));
    try {
      const res = await api.adminCreateCustomer({
        firstName: createCustomerModal.firstName.trim(),
        middleName: createCustomerModal.middleName.trim(),
        lastName: createCustomerModal.lastName.trim(),
        email: createCustomerModal.email.trim(),
        username: createCustomerModal.username.trim(),
        phone: createCustomerModal.phone.trim(),
        password: createCustomerModal.password,
        country: createCustomerModal.country.trim() || 'United Kingdom',
        residentialAddress: createCustomerModal.residentialAddress.trim(),
        accountNumber: createCustomerModal.accountNumber.trim() || undefined,
        status: createCustomerModal.status,
        initialBalance: 0,
      });
      showNotification('success', res.message);
      setCreateCustomerModal({
        isOpen: false,
        firstName: '',
        middleName: '',
        lastName: '',
        email: '',
        username: '',
        phone: '',
        password: '',
        country: 'United Kingdom',
        residentialAddress: '',
        accountNumber: '',
        status: 'active',
      });
      await fetchAdminData();
    } catch (err: any) {
      setCreateCustomerModal((prev) => ({ ...prev, submitting: false, error: err.message || 'Customer creation failed' }));
    }
  };

  // Submit Reset Password
  const handleResetPasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!resetPasswordModal.customer) return;
    setResetPasswordModal((prev) => ({ ...prev, submitting: true, error: undefined }));
    try {
      const res = await api.adminResetCustomerPassword(resetPasswordModal.customer.id, resetPasswordModal.newPassword);
      showNotification('success', res.message);
      setResetPasswordModal({ isOpen: false, customer: null, newPassword: '', showPassword: false });
      await fetchAdminData();
    } catch (err: any) {
      setResetPasswordModal((prev) => ({ ...prev, submitting: false, error: err.message || 'Password reset failed' }));
    }
  };

  // Submit Authorized Delete
  const handleDeleteCustomerSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!deleteModal.customer) return;
    if (deleteModal.confirmText.trim() !== 'DELETE') {
      setDeleteModal((prev) => ({ ...prev, error: 'Type DELETE in uppercase to authorize permanent deletion.' }));
      return;
    }
    setDeleteModal((prev) => ({ ...prev, submitting: true, error: undefined }));
    try {
      const res = await api.adminDeleteCustomer(deleteModal.customer.id);
      showNotification('success', res.message);
      if (viewCustomerModal?.id === deleteModal.customer.id) setViewCustomerModal(null);
      setDeleteModal({ isOpen: false, customer: null, confirmText: '' });
      await fetchAdminData();
    } catch (err: any) {
      setDeleteModal((prev) => ({ ...prev, submitting: false, error: err.message || 'Deletion failed' }));
    }
  };

  // Database Backup Actions
  const handleCreateBackup = async () => {
    try {
      setBackupActionLoading(true);
      const res = await api.createAdminBackup('Manual administrator backup');
      showNotification('success', `Snapshot ${res.backup.id} stored permanently (${res.backup.customerCount} customers).`);
      await fetchAdminData();
    } catch (err: any) {
      showNotification('error', err.message || 'Backup creation failed');
    } finally {
      setBackupActionLoading(false);
    }
  };

  const handleDownloadBackup = async () => {
    try {
      setBackupActionLoading(true);
      const payload = await api.exportAdminBackup();
      const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `fnb_customer_directory_backup_${new Date().toISOString().slice(0, 10)}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      showNotification('success', 'Encrypted-safe JSON directory backup downloaded.');
    } catch (err: any) {
      showNotification('error', err.message || 'Export failed');
    } finally {
      setBackupActionLoading(false);
    }
  };

  // Manual Reversal
  const handleAdminReversal = async (txId: string) => {
    try {
      const res = await api.adminReversal(txId);
      showNotification('success', res.message);
      await fetchAdminData();
    } catch (err: any) {
      showNotification('error', err.message || 'Reversal failed');
    }
  };

  // Verification Status Update
  const handleUpdateVerification = async (id: string, status: 'approved' | 'rejected') => {
    const comments = status === 'approved' ? 'Verified by compliance officer.' : 'Document details could not be verified.';
    try {
      await api.updateVerificationStatus(id, status, comments);
      showNotification('success', `Verification marked as ${status}.`);
      await fetchAdminData();
    } catch (err: any) {
      showNotification('error', err.message || 'Failed to update verification status.');
    }
  };

  // Investment Status Update
  const handleUpdateInvestment = async (id: string, status: 'approved' | 'active' | 'rejected') => {
    const comments = status === 'rejected' ? 'Declined by FNB Asset Management.' : 'Authorized by FNB Asset Management.';
    try {
      await api.updateInvestmentStatus(id, status, comments);
      showNotification('success', `Investment marked as ${status}.`);
      await fetchAdminData();
    } catch (err: any) {
      showNotification('error', err.message || 'Failed to update investment status.');
    }
  };

  // Support Reply Submit
  const handleSupportReplySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!replyTicketModal.ticket) return;
    try {
      await api.replySupportEnquiry(
        replyTicketModal.ticket.id, 
        replyTicketModal.replyText, 
        replyTicketModal.status
      );
      showNotification('success', 'Reply dispatched to customer email and dashboard.');
      setReplyTicketModal({ isOpen: false, ticket: null, replyText: '', status: 'resolved' });
      await fetchAdminData();
    } catch (err: any) {
      setReplyTicketModal((prev) => ({ ...prev, error: err.message || 'Failed to send reply' }));
    }
  };

  // Filter customers defensively so records never disappear
  const filteredCustomers = customers.filter(c => {
    if (!c) return false;
    const query = (customerSearch || '').trim().toLowerCase();
    const fName = (c.firstName || '').toLowerCase();
    const lName = (c.lastName || '').toLowerCase();
    const fullName = (c.fullName || `${c.firstName || ''} ${c.lastName || ''}`).toLowerCase();
    const email = (c.email || '').toLowerCase();
    const username = (c.username || '').toLowerCase();
    const accNo = (c.accountNumber || '').toLowerCase();
    const phone = (c.phone || '').toLowerCase();

    const matchesSearch = !query || 
      fName.includes(query) ||
      lName.includes(query) ||
      fullName.includes(query) ||
      email.includes(query) ||
      username.includes(query) ||
      accNo.includes(query) ||
      phone.includes(query);

    if (customerStatusFilter === 'all') return matchesSearch;
    return matchesSearch && c.status === customerStatusFilter;
  });

  const pendingCustomers = customers.filter(c => c && c.status === 'pending_approval');
  const pendingVerifications = verifications.filter(v => v && v.status === 'pending_review');
  const pendingInvestments = investments.filter(i => i && i.status === 'pending_review');
  const openTickets = supportEnquiries.filter(s => s && (s.status === 'open' || s.status === 'in_progress'));

  return (
    <div className="min-h-screen w-full max-w-full overflow-x-hidden bg-slate-100 dark:bg-slate-950 text-slate-800 dark:text-slate-100 py-4 sm:py-6 px-3 sm:px-8 transition-colors">
      <div className="w-full max-w-7xl mx-auto space-y-6">

        {/* Status Notification Toast */}
        {feedback && (
          <div className={`p-4 rounded-2xl flex items-center justify-between text-xs sm:text-sm font-semibold shadow-md ${
            feedback.type === 'success' 
              ? 'bg-emerald-600 text-white' 
              : 'bg-red-600 text-white'
          }`}>
            <span>{feedback.message}</span>
            <button onClick={() => setFeedback(null)} className="ml-4 font-bold">×</button>
          </div>
        )}

        {/* Master Admin Header Card */}
        <div className="bg-[#002752] text-white rounded-3xl p-5 sm:p-8 shadow-xl border border-blue-900/50 flex flex-col md:flex-row items-start md:items-center justify-between gap-6 w-full">
          <div className="flex items-center gap-3 sm:gap-4">
            <div className="w-12 h-12 sm:w-14 sm:h-14 bg-gradient-to-br from-red-600 to-amber-500 rounded-2xl flex items-center justify-center text-white shadow-lg shrink-0">
              <ShieldCheck className="w-6 h-6 sm:w-7 sm:h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 rounded-full bg-red-600/30 border border-red-500/40 text-red-300 font-bold text-[10px] tracking-wider uppercase">
                  MASTER ADMINISTRATOR
                </span>
                <span className="text-xs text-slate-400">fnbadmin</span>
              </div>
              <h1 className="text-lg sm:text-2xl font-black mt-1">
                FNB Central Banking Administrator Console
              </h1>
              <p className="text-xs text-slate-300 mt-0.5">
                Session: <strong className="text-white">admin@fnnbbankss.online</strong> • Sovereign Control Desk
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <button
              onClick={() => setIsMailModalOpen(true)}
              className="px-3.5 py-2 bg-white/10 hover:bg-white/20 text-white font-bold rounded-xl text-xs border border-white/20 transition-all flex items-center gap-1.5"
            >
              <Mail className="w-3.5 h-3.5" />
              <span>Admin Mailbox</span>
            </button>
            <button
              type="button"
              onClick={handleAdminLogout}
              className="px-4 py-2 bg-[#c8102e] hover:bg-[#a50d26] text-white font-bold rounded-xl text-xs shadow-md transition-all flex items-center gap-1.5"
            >
              <span>Logout</span>
            </button>
          </div>
        </div>

        {/* Sub-Navigation Tabs */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-2 border border-slate-200 dark:border-slate-800 shadow-sm overflow-x-auto w-full max-w-full">
          <div className="flex items-center gap-2 min-w-max text-xs font-bold">
            {[
              { id: 'overview', label: 'Overview Stats', icon: Layers },
              { id: 'customers', label: `Customers (${customers.length})`, icon: Users, badge: pendingCustomers.length },
              { id: 'verifications', label: `KYC Verifications (${verifications.length})`, icon: FileCheck2, badge: pendingVerifications.length },
              { id: 'investments', label: `Investments (${investments.length})`, icon: TrendingUp, badge: pendingInvestments.length },
              { id: 'transactions', label: `Ledger (${ledger.length})`, icon: History },
              { id: 'support', label: `Support Tickets (${supportEnquiries.length})`, icon: MessageSquare, badge: openTickets.length },
              { id: 'audit', label: `Audit Trail (${auditLogs.length})`, icon: Shield },
            ].map(tab => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`px-3.5 py-2 rounded-xl transition-all flex items-center gap-1.5 whitespace-nowrap ${
                    isActive
                      ? 'bg-[#002752] text-white shadow-sm'
                      : 'hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{tab.label}</span>
                  {tab.badge !== undefined && tab.badge > 0 && (
                    <span className="w-4 h-4 rounded-full bg-red-600 text-white text-[9px] flex items-center justify-center font-bold">
                      {tab.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* ================= TAB: OVERVIEW STATS ================= */}
        {activeTab === 'overview' && (
          <div className="space-y-6">
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Total Customer Accounts</span>
                <p className="text-3xl font-black text-slate-900 dark:text-white mt-1">{customers.length}</p>
                <span className="text-[11px] text-emerald-600 font-semibold mt-1 block">
                  {customers.filter(c => c.status === 'active').length} Active Accounts
                </span>
              </div>

              <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Pending Registrations</span>
                <p className="text-3xl font-black text-amber-600 mt-1">{pendingCustomers.length}</p>
                <button onClick={() => setActiveTab('customers')} className="text-[11px] text-[#002752] dark:text-blue-400 font-bold hover:underline mt-1 block">
                  Review Applications →
                </button>
              </div>

              <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Pending KYC Reviews</span>
                <p className="text-3xl font-black text-red-600 mt-1">{pendingVerifications.length}</p>
                <button onClick={() => setActiveTab('verifications')} className="text-[11px] text-[#002752] dark:text-blue-400 font-bold hover:underline mt-1 block">
                  Review KYC Docs →
                </button>
              </div>

              <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Pending Investments</span>
                <p className="text-3xl font-black text-[#002752] dark:text-blue-400 mt-1">{pendingInvestments.length}</p>
                <button onClick={() => setActiveTab('investments')} className="text-[11px] text-[#002752] dark:text-blue-400 font-bold hover:underline mt-1 block">
                  Review Allocations →
                </button>
              </div>
            </div>

            {/* Quick Pending Applicants List */}
            {pendingCustomers.length > 0 && (
              <div className="bg-amber-50 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-700/60 rounded-3xl p-6 shadow-sm">
                <h3 className="font-bold text-base text-amber-900 dark:text-amber-200 mb-2 flex items-center gap-2">
                  <Clock className="w-5 h-5 text-amber-700 dark:text-amber-400" />
                  <span>Applicant Registrations Awaiting Approval ({pendingCustomers.length})</span>
                </h3>
                <div className="divide-y divide-amber-200 dark:divide-amber-800 mt-4">
                  {pendingCustomers.map(applicant => (
                    <div key={applicant.id} className="py-3 flex items-center justify-between gap-4 text-xs">
                      <div>
                        <strong className="text-slate-900 dark:text-white text-sm">{applicant.firstName} {applicant.lastName}</strong>
                        <p className="text-slate-600 dark:text-slate-400">{applicant.email} • {applicant.phone}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => openApproveModal(applicant)}
                          className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow-sm text-xs"
                        >
                          Approve & Assign Account
                        </button>
                        <button
                          onClick={() => openRejectModal(applicant)}
                          className="px-3.5 py-1.5 bg-red-600 hover:bg-red-700 text-white font-bold rounded-xl shadow-sm text-xs"
                        >
                          Reject
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* ================= TAB: CUSTOMER MANAGEMENT ================= */}
        {activeTab === 'customers' && (
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-4 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-sm space-y-6">
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
              <div>
                <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <span>Customer Account Directory</span>
                  <span className="px-2.5 py-0.5 rounded-full bg-[#002752] text-white text-xs font-bold">
                    {filteredCustomers.length} / {customers.length}
                  </span>
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Permanent cross-device customer registry • Approve applications, assign account numbers, edit records, reset passwords, suspend/activate, or create backups
                </p>
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={fetchAdminData}
                  className="px-3 py-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 font-bold rounded-xl text-xs flex items-center gap-1.5 transition-colors"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
                  <span>Sync</span>
                </button>
                <button
                  type="button"
                  onClick={() => setBackupsModalOpen(true)}
                  className="px-3 py-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 font-bold rounded-xl text-xs flex items-center gap-1.5 transition-colors"
                >
                  <Database className="w-3.5 h-3.5 text-[#002752] dark:text-blue-400" />
                  <span>Backups ({backups.length})</span>
                </button>
                <button
                  type="button"
                  onClick={() =>
                    setCreateCustomerModal({
                      isOpen: true,
                      firstName: '',
                      middleName: '',
                      lastName: '',
                      email: '',
                      username: '',
                      phone: '',
                      password: generateStrongTempPassword(),
                      country: 'United Kingdom',
                      residentialAddress: '',
                      accountNumber: generateClientAccountNumber(),
                      status: 'active',
                    })
                  }
                  className="px-3.5 py-2 bg-[#c8102e] hover:bg-[#a50d26] text-white font-bold rounded-xl text-xs shadow-sm flex items-center gap-1.5 transition-colors"
                >
                  <UserPlus className="w-3.5 h-3.5" />
                  <span>Register Customer</span>
                </button>
              </div>
            </div>

            {/* Search and Status Filters */}
            <div className="flex flex-col sm:flex-row gap-3">
              <div className="relative flex-1">
                <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search by full name, email address, account number, username, or phone..."
                  value={customerSearch}
                  onChange={e => setCustomerSearch(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 text-xs sm:text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl"
                />
              </div>
              <select
                value={customerStatusFilter}
                onChange={e => setCustomerStatusFilter(e.target.value as any)}
                className="px-3 py-2 text-xs sm:text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl font-semibold"
              >
                <option value="all">All Statuses ({customers.length})</option>
                <option value="pending_approval">Pending Approval ({customers.filter(c => c.status === 'pending_approval').length})</option>
                <option value="active">Active ({customers.filter(c => c.status === 'active').length})</option>
                <option value="frozen">Frozen ({customers.filter(c => c.status === 'frozen').length})</option>
                <option value="suspended">Suspended ({customers.filter(c => c.status === 'suspended').length})</option>
                <option value="rejected">Rejected ({customers.filter(c => c.status === 'rejected').length})</option>
              </select>
            </div>

            {filteredCustomers.length === 0 ? (
              <div className="text-center py-12 bg-slate-50 dark:bg-slate-950 rounded-2xl border border-dashed border-slate-300 dark:border-slate-800 space-y-2">
                <Users className="w-8 h-8 text-slate-400 mx-auto" />
                <p className="text-sm font-bold text-slate-700 dark:text-slate-300">No matching customer accounts found</p>
                <p className="text-xs text-slate-500">Adjust your search term or status filter, or register a new customer above.</p>
              </div>
            ) : (
              <>
                {/* Mobile / Tablet Responsive Cards */}
                <div className="grid grid-cols-1 gap-4 lg:hidden">
                  {filteredCustomers.map(cust => {
                    const displayFullName = cust.fullName || `${cust.firstName} ${cust.lastName}`;
                    const regDate = cust.createdAt ? new Date(cust.createdAt).toLocaleDateString('en-US', { day: '2-digit', month: 'short', year: 'numeric' }) : '—';
                    return (
                      <div key={cust.id} className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-950 p-4 space-y-3">
                        <div className="flex items-start justify-between gap-2">
                          <div className="min-w-0">
                            <h3 className="font-bold text-sm text-slate-900 dark:text-white truncate">{displayFullName}</h3>
                            <p className="text-xs text-slate-500 truncate">{cust.email}</p>
                            <p className="text-[11px] text-slate-500 mt-0.5">@{cust.username} • {cust.phone || 'No phone'}</p>
                          </div>
                          <span className={`px-2.5 py-0.5 rounded-full font-bold uppercase text-[10px] shrink-0 ${
                            cust.status === 'active'
                              ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                              : cust.status === 'frozen'
                              ? 'bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300'
                              : cust.status === 'suspended' || cust.status === 'rejected'
                              ? 'bg-red-100 text-red-800 dark:bg-red-950 dark:text-red-300'
                              : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                          }`}>
                            {cust.status.replace('_', ' ')}
                          </span>
                        </div>

                        <div className="grid grid-cols-2 gap-2 text-xs bg-white dark:bg-slate-900 p-3 rounded-xl border border-slate-200/80 dark:border-slate-800">
                          <div>
                            <span className="text-[10px] uppercase text-slate-400 block font-semibold">Account Number</span>
                            <span className="font-mono font-bold text-slate-800 dark:text-slate-200">
                              {cust.accountNumber || 'Not Assigned'}
                            </span>
                          </div>
                          <div>
                            <span className="text-[10px] uppercase text-slate-400 block font-semibold">Balance</span>
                            <span className="font-black text-slate-900 dark:text-white">
                              {USD_SYMBOL}{formatUsdNumber(cust.balance || 0)}
                            </span>
                          </div>
                          <div>
                            <span className="text-[10px] uppercase text-slate-400 block font-semibold">Registered</span>
                            <span className="text-slate-700 dark:text-slate-300">{regDate}</span>
                          </div>
                          <div>
                            <span className="text-[10px] uppercase text-slate-400 block font-semibold">Country</span>
                            <span className="text-slate-700 dark:text-slate-300 truncate block">{cust.country || 'United Kingdom'}</span>
                          </div>
                        </div>

                        <div className="flex flex-wrap gap-1.5 pt-1">
                          <button
                            onClick={() => setViewCustomerModal(cust)}
                            className="px-2.5 py-1.5 bg-[#002752] text-white rounded-lg font-bold text-[11px] flex items-center gap-1"
                          >
                            <Eye className="w-3 h-3" /> Details
                          </button>
                          <button
                            onClick={() => openEditProfileModal(cust)}
                            className="px-2.5 py-1.5 bg-slate-200 dark:bg-slate-800 text-slate-800 dark:text-slate-200 rounded-lg font-bold text-[11px] flex items-center gap-1"
                          >
                            <Edit className="w-3 h-3" /> Edit
                          </button>
                          <button
                            onClick={() => setResetPasswordModal({ isOpen: true, customer: cust, newPassword: generateStrongTempPassword(), showPassword: true })}
                            className="px-2.5 py-1.5 bg-amber-100 text-amber-900 dark:bg-amber-950 dark:text-amber-300 rounded-lg font-bold text-[11px] flex items-center gap-1"
                          >
                            <KeyRound className="w-3 h-3" /> Reset PW
                          </button>
                          {cust.status === 'pending_approval' ? (
                            <>
                              <button
                                onClick={() => openApproveModal(cust)}
                                className="px-2.5 py-1.5 bg-emerald-600 text-white rounded-lg font-bold text-[11px]"
                              >
                                Approve & Assign
                              </button>
                              <button
                                onClick={() => openRejectModal(cust)}
                                className="px-2.5 py-1.5 bg-red-600 text-white rounded-lg font-bold text-[11px]"
                              >
                                Reject
                              </button>
                            </>
                          ) : (
                            <>
                              <button
                                onClick={() => setCreditDebitModal({ isOpen: true, customer: cust, type: 'credit', amount: '', description: '', reference: '' })}
                                className="px-2.5 py-1.5 bg-emerald-50 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300 rounded-lg font-bold text-[11px]"
                              >
                                + Credit
                              </button>
                              <button
                                onClick={() => setCreditDebitModal({ isOpen: true, customer: cust, type: 'debit', amount: '', description: '', reference: '' })}
                                className="px-2.5 py-1.5 bg-red-50 text-red-700 dark:bg-red-950 dark:text-red-300 rounded-lg font-bold text-[11px]"
                              >
                                - Debit
                              </button>
                              <button
                                onClick={() => handleToggleSuspend(cust)}
                                className={`px-2.5 py-1.5 rounded-lg font-bold text-[11px] ${
                                  cust.status === 'suspended'
                                    ? 'bg-emerald-600 text-white'
                                    : 'bg-red-100 text-red-800 dark:bg-red-950 dark:text-red-300'
                                }`}
                              >
                                {cust.status === 'suspended' ? 'Activate' : 'Suspend'}
                              </button>
                              <button
                                onClick={() => setStatementCustomer(cust)}
                                className="px-2.5 py-1.5 bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-lg font-bold text-[11px]"
                              >
                                Statement
                              </button>
                            </>
                          )}
                          <button
                            onClick={() => setDeleteModal({ isOpen: true, customer: cust, confirmText: '' })}
                            className="px-2.5 py-1.5 bg-red-600/10 hover:bg-red-600 hover:text-white text-red-600 rounded-lg font-bold text-[11px] flex items-center gap-1"
                          >
                            <Trash2 className="w-3 h-3" /> Delete
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* Desktop Table */}
                <div className="hidden lg:block overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-50 dark:bg-slate-950 text-slate-400 uppercase text-[10px] font-bold border-b border-slate-200 dark:border-slate-800">
                      <tr>
                        <th className="py-3 px-3">Customer & Contact</th>
                        <th className="py-3 px-3">Account Number</th>
                        <th className="py-3 px-3">Registered</th>
                        <th className="py-3 px-3">Balance</th>
                        <th className="py-3 px-3">Status</th>
                        <th className="py-3 px-3 text-right">Administrative Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                      {filteredCustomers.map(cust => {
                        const displayFullName = cust.fullName || `${cust.firstName} ${cust.lastName}`;
                        const regDate = cust.createdAt ? new Date(cust.createdAt).toLocaleDateString('en-US', { day: '2-digit', month: 'short', year: 'numeric' }) : '—';
                        return (
                          <tr key={cust.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-950/40">
                            <td className="py-3.5 px-3">
                              <strong className="font-bold text-slate-900 dark:text-white text-sm block">
                                {displayFullName}
                              </strong>
                              <span className="text-slate-500 text-[11px] block">{cust.email}</span>
                              <span className="text-slate-400 text-[11px] block">
                                @{cust.username} • {cust.phone || 'No phone'} • {cust.country || 'United Kingdom'}
                              </span>
                            </td>
                            <td className="py-3.5 px-3">
                              {cust.accountNumber ? (
                                <div>
                                  <span className="font-mono font-bold text-slate-800 dark:text-slate-200 block">{cust.accountNumber}</span>
                                  {cust.sortCode && <span className="font-mono text-[10px] text-slate-400">Sort: {cust.sortCode}</span>}
                                </div>
                              ) : (
                                <span className="text-amber-600 font-sans text-[11px] italic">Not Assigned</span>
                              )}
                            </td>
                            <td className="py-3.5 px-3 text-slate-600 dark:text-slate-400 whitespace-nowrap">
                              <span className="block font-medium">{regDate}</span>
                              <span className="text-[10px] text-slate-400 uppercase">{cust.kycStatus || 'unverified'} KYC</span>
                            </td>
                            <td className="py-3.5 px-3 font-black text-slate-900 dark:text-white whitespace-nowrap">
                              {USD_SYMBOL}{formatUsdNumber(cust.balance || 0)}
                            </td>
                            <td className="py-3.5 px-3">
                              <span className={`px-2.5 py-0.5 rounded-full font-bold uppercase text-[10px] whitespace-nowrap ${
                                cust.status === 'active'
                                  ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                                  : cust.status === 'frozen'
                                  ? 'bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300'
                                  : cust.status === 'suspended' || cust.status === 'rejected'
                                  ? 'bg-red-100 text-red-800 dark:bg-red-950 dark:text-red-300'
                                  : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                              }`}>
                                {cust.status.replace('_', ' ')}
                              </span>
                            </td>
                            <td className="py-3.5 px-3 text-right">
                              <div className="flex items-center justify-end gap-1.5 flex-wrap">
                                <button
                                  onClick={() => setViewCustomerModal(cust)}
                                  title="View Customer Details"
                                  className="px-2 py-1 bg-[#002752] hover:bg-[#001d3d] text-white rounded-lg font-bold text-[11px] flex items-center gap-1"
                                >
                                  <Eye className="w-3 h-3" /> Details
                                </button>
                                <button
                                  onClick={() => openEditProfileModal(cust)}
                                  title="Edit Customer Record"
                                  className="px-2 py-1 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-200 rounded-lg font-bold text-[11px] flex items-center gap-1"
                                >
                                  <Edit className="w-3 h-3" /> Edit
                                </button>
                                <button
                                  onClick={() => setResetPasswordModal({
                                    isOpen: true,
                                    customer: cust,
                                    newPassword: generateStrongTempPassword(),
                                    showPassword: true,
                                  })}
                                  title="Reset Customer Password"
                                  className="px-2 py-1 bg-amber-50 hover:bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 rounded-lg font-bold text-[11px] flex items-center gap-1"
                                >
                                  <KeyRound className="w-3 h-3" /> Password
                                </button>

                                {cust.status === 'pending_approval' ? (
                                  <>
                                    <button
                                      onClick={() => openApproveModal(cust)}
                                      className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-bold text-[11px]"
                                    >
                                      Approve
                                    </button>
                                    <button
                                      onClick={() => openRejectModal(cust)}
                                      className="px-2.5 py-1 bg-red-600 hover:bg-red-700 text-white rounded-lg font-bold text-[11px]"
                                    >
                                      Reject
                                    </button>
                                  </>
                                ) : (
                                  <>
                                    <button
                                      onClick={() => setCreditDebitModal({
                                        isOpen: true,
                                        customer: cust,
                                        type: 'credit',
                                        amount: '',
                                        description: '',
                                        reference: '',
                                      })}
                                      className="px-2 py-1 bg-emerald-50 text-emerald-700 hover:bg-emerald-100 dark:bg-emerald-950 dark:text-emerald-300 rounded-lg font-bold text-[11px]"
                                    >
                                      + Credit
                                    </button>
                                    <button
                                      onClick={() => setCreditDebitModal({
                                        isOpen: true,
                                        customer: cust,
                                        type: 'debit',
                                        amount: '',
                                        description: '',
                                        reference: '',
                                      })}
                                      className="px-2 py-1 bg-red-50 text-red-700 hover:bg-red-100 dark:bg-red-950 dark:text-red-300 rounded-lg font-bold text-[11px]"
                                    >
                                      - Debit
                                    </button>
                                    {cust.status !== 'rejected' && (
                                      <>
                                        <button
                                          onClick={() => handleToggleFreeze(cust)}
                                          className="px-2 py-1 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-lg font-semibold text-[11px]"
                                        >
                                          {cust.status === 'frozen' ? 'Unfreeze' : 'Freeze'}
                                        </button>
                                        <button
                                          onClick={() => handleToggleSuspend(cust)}
                                          className={`px-2 py-1 rounded-lg font-bold text-[11px] ${
                                            cust.status === 'suspended'
                                              ? 'bg-emerald-600 hover:bg-emerald-700 text-white'
                                              : 'bg-red-50 hover:bg-red-100 text-red-700 dark:bg-red-950 dark:text-red-300'
                                          }`}
                                        >
                                          {cust.status === 'suspended' ? 'Activate' : 'Suspend'}
                                        </button>
                                      </>
                                    )}
                                    <button
                                      onClick={() => setStatementCustomer(cust)}
                                      className="px-2 py-1 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-lg font-semibold text-[11px]"
                                    >
                                      Statement
                                    </button>
                                  </>
                                )}
                                <button
                                  onClick={() => setDeleteModal({ isOpen: true, customer: cust, confirmText: '' })}
                                  title="Authorize Deletion"
                                  className="px-2 py-1 bg-red-600/10 hover:bg-red-600 hover:text-white text-red-600 rounded-lg font-bold text-[11px]"
                                >
                                  <Trash2 className="w-3 h-3" />
                                </button>
                              </div>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </>
            )}
          </div>
        )}

        {/* ================= TAB: KYC VERIFICATIONS ================= */}
        {activeTab === 'verifications' && (
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-sm space-y-6">
            <div>
              <h2 className="text-xl font-bold text-slate-900 dark:text-white">KYC Identity Verifications</h2>
              <p className="text-xs text-slate-500">Review identification scans, proofs of address, and compliance declarations</p>
            </div>

            {verifications.length === 0 ? (
              <p className="text-center py-12 text-slate-400 text-xs">No verification requests submitted.</p>
            ) : (
              <div className="divide-y divide-slate-100 dark:divide-slate-800">
                {verifications.map(ver => (
                  <div key={ver.id} className="py-5 flex flex-col md:flex-row md:items-center justify-between gap-4 text-xs">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <strong className="text-sm font-bold text-slate-900 dark:text-white">{ver.fullName}</strong>
                        <span className="font-mono text-slate-400">({ver.reference})</span>
                        <span className={`px-2 py-0.5 rounded-full font-bold uppercase text-[9px] ${
                          ver.status === 'approved' ? 'bg-emerald-100 text-emerald-800' : ver.status === 'rejected' ? 'bg-red-100 text-red-800' : 'bg-amber-100 text-amber-800'
                        }`}>
                          {ver.status.replace('_', ' ')}
                        </span>
                      </div>
                      <p className="text-slate-500">
                        DOB: {ver.dateOfBirth} • Country: {ver.countryOfResidence} • Address: {ver.residentialAddress}
                      </p>
                      <p className="text-slate-500">
                        Document: <strong className="capitalize">{ver.idDocumentType}</strong> ({ver.sampleDocFrontName}) • Proof of Address: ({ver.sampleProofOfAddressName})
                      </p>
                    </div>

                    <div className="flex items-center gap-2">
                      {ver.status === 'pending_review' && (
                        <>
                          <button
                            onClick={() => handleUpdateVerification(ver.id, 'approved')}
                            className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs shadow-sm"
                          >
                            Approve KYC
                          </button>
                          <button
                            onClick={() => handleUpdateVerification(ver.id, 'rejected')}
                            className="px-3.5 py-2 bg-red-600 hover:bg-red-700 text-white font-bold rounded-xl text-xs shadow-sm"
                          >
                            Reject
                          </button>
                        </>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ================= TAB: INVESTMENTS ================= */}
        {activeTab === 'investments' && (
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-sm space-y-6">
            <div>
              <h2 className="text-xl font-bold text-slate-900 dark:text-white">Customer Investment Portfolios</h2>
              <p className="text-xs text-slate-500">Approve or reject customer investment allocations</p>
            </div>

            {investments.length === 0 ? (
              <p className="text-center py-12 text-slate-400 text-xs">No investment applications logged.</p>
            ) : (
              <div className="divide-y divide-slate-100 dark:divide-slate-800">
                {investments.map(inv => (
                  <div key={inv.id} className="py-4 flex flex-col md:flex-row md:items-center justify-between gap-4 text-xs">
                    <div>
                      <div className="flex items-center gap-2">
                        <strong className="text-sm font-bold text-slate-900 dark:text-white">{inv.planName}</strong>
                        <span className="font-mono text-slate-400">({inv.reference})</span>
                        <span className={`px-2 py-0.5 rounded-full font-bold uppercase text-[9px] ${
                          inv.status === 'approved' || inv.status === 'active'
                            ? 'bg-emerald-100 text-emerald-800'
                            : inv.status === 'rejected'
                            ? 'bg-red-100 text-red-800'
                            : 'bg-amber-100 text-amber-800'
                        }`}>
                          {inv.status.replace('_', ' ')}
                        </span>
                      </div>
                      <p className="text-slate-500 mt-1">
                        Customer: <strong className="text-slate-800 dark:text-slate-200">{inv.userName}</strong> ({inv.userEmail}) • Amount: <strong className="text-slate-900 dark:text-white">{USD_SYMBOL}{formatUsdNumber(inv.amount)}</strong> • Projected: +{USD_SYMBOL}{formatUsdNumber(inv.projectedReturnAmount)}
                      </p>
                    </div>

                    <div className="flex items-center gap-2">
                      {inv.status === 'pending_review' && (
                        <>
                          <button
                            onClick={() => handleUpdateInvestment(inv.id, 'approved')}
                            className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs shadow-sm"
                          >
                            Approve Portfolio
                          </button>
                          <button
                            onClick={() => handleUpdateInvestment(inv.id, 'rejected')}
                            className="px-3.5 py-2 bg-red-600 hover:bg-red-700 text-white font-bold rounded-xl text-xs shadow-sm"
                          >
                            Reject & Refund
                          </button>
                        </>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ================= TAB: TRANSACTIONS & REVERSALS ================= */}
        {activeTab === 'transactions' && (
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-sm space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h2 className="text-xl font-bold text-slate-900 dark:text-white">Bank-wide Transaction Ledger</h2>
                <p className="text-xs text-slate-500">Inspect all customer debits, credits, transfers, and trigger administrative reversals</p>
              </div>
            </div>

            <div className="divide-y divide-slate-100 dark:divide-slate-800">
              {ledger.map(tx => (
                <div key={tx.id} className="py-4 flex items-center justify-between gap-4 text-xs">
                  <div>
                    <div className="flex flex-wrap items-center gap-2">
                      <strong className="text-slate-900 dark:text-white text-sm block">{tx.description}</strong>
                      <TransactionTagBadge 
                        tag={tx.tag || tagTransaction(tx.description, tx.type, tx.billerCategory).tag} 
                        showIcon 
                      />
                    </div>
                    <div className="flex items-center gap-2 text-slate-400 font-mono text-[11px] mt-0.5">
                      <span>{tx.reference}</span>
                      <span>•</span>
                      <span>{tx.customerName}</span>
                      <span>•</span>
                      <span>{new Date(tx.createdAt).toLocaleString()}</span>
                      {tx.isReversed && (
                        <span className="px-1.5 py-0.2 bg-amber-100 text-amber-800 rounded font-sans text-[9px]">
                          REVERSED
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <span className="font-black text-sm text-slate-900 dark:text-white">
                      {USD_SYMBOL}{formatUsdNumber(tx.amount)}
                    </span>
                    {tx.type === 'transfer' && !tx.isReversed && (
                      <button
                        onClick={() => handleAdminReversal(tx.id)}
                        className="px-3 py-1 bg-red-600 hover:bg-red-700 text-white font-bold rounded-lg text-[11px]"
                      >
                        Force Reversal
                      </button>
                    )}
                    <button
                      onClick={() => setActiveReceiptTx(tx)}
                      className="text-[#002752] dark:text-blue-400 font-bold hover:underline"
                    >
                      Receipt
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ================= TAB: SUPPORT TICKETS ================= */}
        {activeTab === 'support' && (
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-sm space-y-6">
            <div>
              <h2 className="text-xl font-bold text-slate-900 dark:text-white">Support & Complaints Queue</h2>
              <p className="text-xs text-slate-500">Manage client tickets, dispatch email replies, and resolve customer complaints</p>
            </div>

            {supportEnquiries.length === 0 ? (
              <p className="text-center py-12 text-slate-400 text-xs">No customer support tickets received.</p>
            ) : (
              <div className="divide-y divide-slate-100 dark:divide-slate-800">
                {supportEnquiries.map(ticket => (
                  <div key={ticket.id} className="py-4 flex flex-col md:flex-row md:items-center justify-between gap-4 text-xs">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <strong className="text-sm font-bold text-slate-900 dark:text-white">{ticket.subject}</strong>
                        <span className="font-mono text-slate-400">({ticket.reference})</span>
                        <span className="px-2 py-0.5 rounded-full font-bold uppercase text-[9px] bg-blue-100 text-blue-800">
                          {ticket.category}
                        </span>
                        <span className="px-2 py-0.5 rounded-full font-bold uppercase text-[9px] bg-slate-100 text-slate-800">
                          {ticket.status}
                        </span>
                      </div>
                      <p className="text-slate-600 dark:text-slate-300">"{ticket.message}"</p>
                      <p className="text-slate-400 text-[11px]">From: {ticket.name} ({ticket.email}) • {new Date(ticket.createdAt).toLocaleString()}</p>
                      {ticket.adminReply && (
                        <p className="text-emerald-700 dark:text-emerald-300 italic pt-1">Reply: "{ticket.adminReply}"</p>
                      )}
                    </div>

                    <button
                      onClick={() => setReplyTicketModal({
                        isOpen: true,
                        ticket,
                        replyText: ticket.adminReply || '',
                        status: 'resolved',
                      })}
                      className="px-4 py-2 bg-[#002752] hover:bg-[#001d3d] text-white font-bold rounded-xl text-xs shadow-sm whitespace-nowrap"
                    >
                      Reply to Ticket
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ================= TAB: AUDIT TRAIL ================= */}
        {activeTab === 'audit' && (
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
            <div>
              <h2 className="text-xl font-bold text-slate-900 dark:text-white">Administrative Audit Trail</h2>
              <p className="text-xs text-slate-500">Immutable ledger of every administrative action executed</p>
            </div>

            <div className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
              {auditLogs.map(log => (
                <div key={log.id} className="py-3 flex items-start justify-between gap-4">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 rounded-md font-mono font-bold text-[10px] bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200">
                        {log.action}
                      </span>
                      <strong className="text-slate-800 dark:text-slate-200">{log.adminEmail}</strong>
                    </div>
                    <p className="text-slate-600 dark:text-slate-400 mt-1">{log.details}</p>
                  </div>
                  <span className="text-[10px] text-slate-400 whitespace-nowrap font-mono">
                    {new Date(log.timestamp).toLocaleString()}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

      </div>

      {/* Credit / Debit Modal */}
      {creditDebitModal.isOpen && creditDebitModal.customer && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200 dark:border-slate-800 space-y-4">
            <h3 className="text-lg font-bold text-slate-900 dark:text-white">
              Authorize {creditDebitModal.type === 'credit' ? 'Credit' : 'Debit'}
            </h3>
            <p className="text-xs text-slate-500">
              Customer: <strong>{creditDebitModal.customer.fullName || `${creditDebitModal.customer.firstName} ${creditDebitModal.customer.lastName}`}</strong> ({creditDebitModal.customer.accountNumber || 'Pending'})
            </p>
            {creditDebitModal.error && (
              <div className="p-3 rounded-xl bg-red-50 dark:bg-red-950/60 border border-red-200 dark:border-red-800 text-xs text-red-700 dark:text-red-300 font-semibold">
                {creditDebitModal.error}
              </div>
            )}

            <form onSubmit={handleCreditDebitSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold mb-1">Amount ({USD_CODE} {USD_SYMBOL})</label>
                <input
                  type="number"
                  step="0.01"
                  required
                  placeholder="0.00"
                  value={creditDebitModal.amount}
                  onChange={e => setCreditDebitModal({ ...creditDebitModal, amount: e.target.value })}
                  className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold mb-1">Description</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Authorized wire credit"
                  value={creditDebitModal.description}
                  onChange={e => setCreditDebitModal({ ...creditDebitModal, description: e.target.value })}
                  className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setCreditDebitModal({ ...creditDebitModal, isOpen: false })}
                  className="flex-1 py-2.5 bg-slate-100 dark:bg-slate-800 font-bold text-xs rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-[#002752] hover:bg-[#001d3d] text-white font-bold text-xs rounded-xl"
                >
                  Confirm {creditDebitModal.type === 'credit' ? 'Credit' : 'Debit'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* View Customer Details Modal */}
      {viewCustomerModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-2xl w-full p-6 shadow-2xl border border-slate-200 dark:border-slate-800 space-y-5 my-8">
            <div className="flex items-start justify-between gap-4">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-[#c8102e]">Customer Record Profile</span>
                <h3 className="text-xl font-black text-slate-900 dark:text-white mt-0.5">
                  {viewCustomerModal.fullName || `${viewCustomerModal.firstName} ${viewCustomerModal.lastName}`}
                </h3>
                <p className="text-xs text-slate-500">ID: {viewCustomerModal.id} • Ref: {viewCustomerModal.registrationReference || 'N/A'}</p>
              </div>
              <span className={`px-3 py-1 rounded-full font-bold uppercase text-xs ${
                viewCustomerModal.status === 'active'
                  ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                  : viewCustomerModal.status === 'frozen'
                  ? 'bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300'
                  : viewCustomerModal.status === 'suspended' || viewCustomerModal.status === 'rejected'
                  ? 'bg-red-100 text-red-800 dark:bg-red-950 dark:text-red-300'
                  : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
              }`}>
                {viewCustomerModal.status.replace('_', ' ')}
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs bg-slate-50 dark:bg-slate-950 p-4 rounded-2xl border border-slate-200 dark:border-slate-800">
              <div><span className="text-slate-400 block">Email Address</span><strong className="text-slate-900 dark:text-white">{viewCustomerModal.email}</strong></div>
              <div><span className="text-slate-400 block">Username</span><strong className="font-mono text-slate-900 dark:text-white">@{viewCustomerModal.username}</strong></div>
              <div><span className="text-slate-400 block">Assigned Account Number</span><strong className="font-mono text-slate-900 dark:text-white">{viewCustomerModal.accountNumber || 'Not Assigned'}</strong></div>
              <div><span className="text-slate-400 block">Sort Code & Currency Balance</span><strong className="text-slate-900 dark:text-white">{viewCustomerModal.sortCode || '—'} • {USD_SYMBOL}{formatUsdNumber(viewCustomerModal.balance || 0)} {USD_CODE}</strong></div>
              <div><span className="text-slate-400 block">Phone Number</span><strong className="text-slate-900 dark:text-white">{viewCustomerModal.phone || '—'}</strong></div>
              <div><span className="text-slate-400 block">Country</span><strong className="text-slate-900 dark:text-white">{viewCustomerModal.country || 'United Kingdom'}</strong></div>
              <div className="sm:col-span-2"><span className="text-slate-400 block">Residential Address</span><strong className="text-slate-900 dark:text-white">{viewCustomerModal.residentialAddress || 'Not provided'}</strong></div>
              <div><span className="text-slate-400 block">Registration Date</span><strong className="text-slate-900 dark:text-white">{new Date(viewCustomerModal.createdAt).toLocaleString()}</strong></div>
              <div><span className="text-slate-400 block">KYC Tier / Approved At</span><strong className="text-slate-900 dark:text-white capitalize">{viewCustomerModal.kycStatus || 'unverified'}{viewCustomerModal.approvedAt ? ` • ${new Date(viewCustomerModal.approvedAt).toLocaleDateString()}` : ''}</strong></div>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
              <div className="flex flex-wrap gap-2">
                <button
                  type="button"
                  onClick={() => openEditProfileModal(viewCustomerModal)}
                  className="px-3.5 py-2 bg-[#002752] text-white font-bold text-xs rounded-xl flex items-center gap-1.5"
                >
                  <Edit className="w-3.5 h-3.5" /> Edit Information
                </button>
                <button
                  type="button"
                  onClick={() => setResetPasswordModal({
                    isOpen: true,
                    customer: viewCustomerModal,
                    newPassword: generateStrongTempPassword(),
                    showPassword: true,
                  })}
                  className="px-3.5 py-2 bg-amber-100 text-amber-900 dark:bg-amber-950 dark:text-amber-300 font-bold text-xs rounded-xl flex items-center gap-1.5"
                >
                  <KeyRound className="w-3.5 h-3.5" /> Reset Password
                </button>
                {viewCustomerModal.status === 'pending_approval' ? (
                  <button
                    type="button"
                    onClick={() => openApproveModal(viewCustomerModal)}
                    className="px-3.5 py-2 bg-emerald-600 text-white font-bold text-xs rounded-xl"
                  >
                    Approve & Assign Account
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={() => handleToggleSuspend(viewCustomerModal)}
                    className={`px-3.5 py-2 font-bold text-xs rounded-xl ${
                      viewCustomerModal.status === 'suspended' ? 'bg-emerald-600 text-white' : 'bg-red-100 text-red-800 dark:bg-red-950 dark:text-red-300'
                    }`}
                  >
                    {viewCustomerModal.status === 'suspended' ? 'Activate Account' : 'Suspend Account'}
                  </button>
                )}
              </div>
              <button
                type="button"
                onClick={() => setViewCustomerModal(null)}
                className="px-4 py-2 bg-slate-100 dark:bg-slate-800 font-bold text-xs rounded-xl"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Edit Customer Profile Modal */}
      {editProfileModal.isOpen && editProfileModal.customer && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-xl w-full p-6 shadow-2xl border border-slate-200 dark:border-slate-800 space-y-4 my-8">
            <h3 className="text-lg font-bold text-slate-900 dark:text-white">
              Edit Customer Account Record
            </h3>
            <p className="text-xs text-slate-500">
              Updates persist permanently across all sessions and devices.
            </p>
            {editProfileModal.error && (
              <div className="p-3 rounded-xl bg-red-50 dark:bg-red-950/60 border border-red-200 dark:border-red-800 text-xs text-red-700 dark:text-red-300 font-semibold">
                {editProfileModal.error}
              </div>
            )}

            <form onSubmit={handleEditProfileSubmit} className="space-y-3 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block font-semibold mb-1">First Name</label>
                  <input
                    type="text"
                    required
                    value={editProfileModal.firstName}
                    onChange={e => setEditProfileModal({ ...editProfileModal, firstName: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl"
                  />
                </div>
                <div>
                  <label className="block font-semibold mb-1">Middle Name</label>
                  <input
                    type="text"
                    value={editProfileModal.middleName}
                    onChange={e => setEditProfileModal({ ...editProfileModal, middleName: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl"
                  />
                </div>
                <div>
                  <label className="block font-semibold mb-1">Last Name</label>
                  <input
                    type="text"
                    required
                    value={editProfileModal.lastName}
                    onChange={e => setEditProfileModal({ ...editProfileModal, lastName: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1">Email Address</label>
                  <input
                    type="email"
                    required
                    value={editProfileModal.email}
                    onChange={e => setEditProfileModal({ ...editProfileModal, email: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl"
                  />
                </div>
                <div>
                  <label className="block font-semibold mb-1">Username</label>
                  <input
                    type="text"
                    required
                    minLength={3}
                    value={editProfileModal.username}
                    onChange={e => setEditProfileModal({ ...editProfileModal, username: e.target.value })}
                    className="w-full px-3 py-2 font-mono bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1">Assigned Account Number</label>
                  <div className="flex gap-1.5">
                    <input
                      type="text"
                      placeholder="10-digit account number"
                      value={editProfileModal.accountNumber}
                      onChange={e => setEditProfileModal({ ...editProfileModal, accountNumber: e.target.value })}
                      className="flex-1 px-3 py-2 font-mono bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl"
                    />
                    <button
                      type="button"
                      onClick={() => setEditProfileModal({ ...editProfileModal, accountNumber: generateClientAccountNumber() })}
                      className="px-2.5 py-2 bg-slate-200 dark:bg-slate-800 rounded-xl font-bold flex items-center gap-1"
                      title="Generate Unique Account Number"
                    >
                      <Wand2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
                <div>
                  <label className="block font-semibold mb-1">Sort Code & KYC Tier</label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={editProfileModal.sortCode}
                      onChange={e => setEditProfileModal({ ...editProfileModal, sortCode: e.target.value })}
                      className="w-24 px-3 py-2 font-mono bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl"
                    />
                    <select
                      value={editProfileModal.kycStatus}
                      onChange={e => setEditProfileModal({ ...editProfileModal, kycStatus: e.target.value as any })}
                      className="flex-1 px-2.5 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl"
                    >
                      <option value="unverified">Unverified</option>
                      <option value="pending">Pending</option>
                      <option value="verified">Verified</option>
                      <option value="rejected">Rejected</option>
                    </select>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1">Phone Number</label>
                  <input
                    type="text"
                    required
                    value={editProfileModal.phone}
                    onChange={e => setEditProfileModal({ ...editProfileModal, phone: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl"
                  />
                </div>
                <div>
                  <label className="block font-semibold mb-1">Country</label>
                  <input
                    type="text"
                    value={editProfileModal.country}
                    onChange={e => setEditProfileModal({ ...editProfileModal, country: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold mb-1">Residential Address</label>
                <input
                  type="text"
                  value={editProfileModal.residentialAddress}
                  onChange={e => setEditProfileModal({ ...editProfileModal, residentialAddress: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setEditProfileModal({ ...editProfileModal, isOpen: false })}
                  className="flex-1 py-2.5 bg-slate-100 dark:bg-slate-800 font-bold text-xs rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-[#002752] hover:bg-[#001d3d] text-white font-bold text-xs rounded-xl"
                >
                  Save Permanent Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Approve & Assign Account Number Modal */}
      {approveModal.isOpen && approveModal.customer && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200 dark:border-slate-800 space-y-4">
            <h3 className="text-lg font-bold text-slate-900 dark:text-white">
              Approve Registration & Assign Account
            </h3>
            <p className="text-xs text-slate-500">
              Applicant: <strong>{approveModal.customer.fullName || `${approveModal.customer.firstName} ${approveModal.customer.lastName}`}</strong> ({approveModal.customer.email})
            </p>
            {approveModal.error && (
              <div className="p-3 rounded-xl bg-red-50 dark:bg-red-950/60 border border-red-200 dark:border-red-800 text-xs text-red-700 dark:text-red-300 font-semibold">
                {approveModal.error}
              </div>
            )}

            <form onSubmit={handleApproveSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold mb-1">Assigned 10-Digit Account Number</label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    required
                    value={approveModal.accountNumber}
                    onChange={e => setApproveModal({ ...approveModal, accountNumber: e.target.value })}
                    className="flex-1 px-3 py-2 font-mono text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl"
                  />
                  <button
                    type="button"
                    onClick={() => setApproveModal({ ...approveModal, accountNumber: generateClientAccountNumber() })}
                    className="px-3 py-2 bg-slate-200 dark:bg-slate-800 rounded-xl font-bold flex items-center gap-1"
                  >
                    <Wand2 className="w-3.5 h-3.5" /> Generate
                  </button>
                </div>
              </div>

              <div>
                <label className="block font-semibold mb-1">Assigned Login Username</label>
                <input
                  type="text"
                  required
                  minLength={3}
                  value={approveModal.username}
                  onChange={e => setApproveModal({ ...approveModal, username: e.target.value })}
                  className="w-full px-3 py-2 font-mono text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl"
                />
              </div>

              <div className="p-3 rounded-xl bg-blue-50 dark:bg-blue-950/40 text-[11px] text-blue-900 dark:text-blue-200">
                Opening balance starts at <strong>$0.00</strong> until credited. Customer login credentials remain active immediately after approval.
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setApproveModal({ isOpen: false, customer: null, accountNumber: '', username: '' })}
                  className="flex-1 py-2.5 bg-slate-100 dark:bg-slate-800 font-bold text-xs rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={approveModal.submitting}
                  className="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl"
                >
                  {approveModal.submitting ? 'Approving...' : 'Approve & Activate'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Reject Registration Modal */}
      {rejectModal.isOpen && rejectModal.customer && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200 dark:border-slate-800 space-y-4">
            <h3 className="text-lg font-bold text-slate-900 dark:text-white">Reject Customer Application</h3>
            <p className="text-xs text-slate-500">
              Applicant: <strong>{rejectModal.customer.firstName} {rejectModal.customer.lastName}</strong> ({rejectModal.customer.email})
            </p>
            <form onSubmit={handleRejectSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold mb-1">Reason for Rejection</label>
                <textarea
                  rows={3}
                  required
                  value={rejectModal.reason}
                  onChange={e => setRejectModal({ ...rejectModal, reason: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl"
                />
              </div>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setRejectModal({ isOpen: false, customer: null, reason: '' })}
                  className="flex-1 py-2.5 bg-slate-100 dark:bg-slate-800 font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-red-600 hover:bg-red-700 text-white font-bold rounded-xl"
                >
                  Confirm Rejection
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Register / Create New Customer Modal */}
      {createCustomerModal.isOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-xl w-full p-6 shadow-2xl border border-slate-200 dark:border-slate-800 space-y-4 my-8">
            <h3 className="text-lg font-bold text-slate-900 dark:text-white">
              Register New Customer Account
            </h3>
            <p className="text-xs text-slate-500">
              Create a permanent customer record stored directly in the cloud database with login credentials.
            </p>
            {createCustomerModal.error && (
              <div className="p-3 rounded-xl bg-red-50 dark:bg-red-950/60 border border-red-200 dark:border-red-800 text-xs text-red-700 dark:text-red-300 font-semibold">
                {createCustomerModal.error}
              </div>
            )}

            <form onSubmit={handleCreateCustomerSubmit} className="space-y-3 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block font-semibold mb-1">First Name *</label>
                  <input
                    type="text"
                    required
                    value={createCustomerModal.firstName}
                    onChange={e => setCreateCustomerModal({ ...createCustomerModal, firstName: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl"
                  />
                </div>
                <div>
                  <label className="block font-semibold mb-1">Middle Name</label>
                  <input
                    type="text"
                    value={createCustomerModal.middleName}
                    onChange={e => setCreateCustomerModal({ ...createCustomerModal, middleName: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl"
                  />
                </div>
                <div>
                  <label className="block font-semibold mb-1">Last Name *</label>
                  <input
                    type="text"
                    required
                    value={createCustomerModal.lastName}
                    onChange={e => setCreateCustomerModal({ ...createCustomerModal, lastName: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1">Email Address *</label>
                  <input
                    type="email"
                    required
                    value={createCustomerModal.email}
                    onChange={e => setCreateCustomerModal({ ...createCustomerModal, email: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl"
                  />
                </div>
                <div>
                  <label className="block font-semibold mb-1">Login Username *</label>
                  <input
                    type="text"
                    required
                    minLength={3}
                    placeholder="e.g. johnsmith"
                    value={createCustomerModal.username}
                    onChange={e => setCreateCustomerModal({ ...createCustomerModal, username: e.target.value })}
                    className="w-full px-3 py-2 font-mono bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1">Phone Number *</label>
                  <input
                    type="text"
                    required
                    value={createCustomerModal.phone}
                    onChange={e => setCreateCustomerModal({ ...createCustomerModal, phone: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl"
                  />
                </div>
                <div>
                  <label className="block font-semibold mb-1">Country</label>
                  <input
                    type="text"
                    value={createCustomerModal.country}
                    onChange={e => setCreateCustomerModal({ ...createCustomerModal, country: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold mb-1">Residential Address</label>
                <input
                  type="text"
                  value={createCustomerModal.residentialAddress}
                  onChange={e => setCreateCustomerModal({ ...createCustomerModal, residentialAddress: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1">Temporary Password (min 8 chars) *</label>
                  <div className="flex gap-1.5">
                    <input
                      type="text"
                      required
                      minLength={8}
                      value={createCustomerModal.password}
                      onChange={e => setCreateCustomerModal({ ...createCustomerModal, password: e.target.value })}
                      className="flex-1 px-3 py-2 font-mono bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl"
                    />
                    <button
                      type="button"
                      onClick={() => setCreateCustomerModal({ ...createCustomerModal, password: generateStrongTempPassword() })}
                      className="px-2.5 py-2 bg-slate-200 dark:bg-slate-800 rounded-xl font-bold"
                      title="Generate Strong Password"
                    >
                      <Wand2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
                <div>
                  <label className="block font-semibold mb-1">Initial Status & Account Number</label>
                  <div className="flex gap-1.5">
                    <select
                      value={createCustomerModal.status}
                      onChange={e => setCreateCustomerModal({ ...createCustomerModal, status: e.target.value as any })}
                      className="px-2.5 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl"
                    >
                      <option value="active">Active</option>
                      <option value="pending_approval">Pending</option>
                    </select>
                    <input
                      type="text"
                      placeholder="Auto Account #"
                      value={createCustomerModal.accountNumber}
                      onChange={e => setCreateCustomerModal({ ...createCustomerModal, accountNumber: e.target.value })}
                      className="flex-1 px-2.5 py-2 font-mono bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl"
                    />
                  </div>
                </div>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setCreateCustomerModal({ ...createCustomerModal, isOpen: false })}
                  className="flex-1 py-2.5 bg-slate-100 dark:bg-slate-800 font-bold text-xs rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={createCustomerModal.submitting}
                  className="flex-1 py-2.5 bg-[#c8102e] hover:bg-[#a50d26] text-white font-bold text-xs rounded-xl"
                >
                  {createCustomerModal.submitting ? 'Creating Account...' : 'Create Customer Account'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Reset Customer Password Modal */}
      {resetPasswordModal.isOpen && resetPasswordModal.customer && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200 dark:border-slate-800 space-y-4">
            <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <KeyRound className="w-5 h-5 text-amber-500" />
              <span>Reset Customer Password</span>
            </h3>
            <p className="text-xs text-slate-500">
              Setting a new password for <strong>{resetPasswordModal.customer.fullName || `${resetPasswordModal.customer.firstName} ${resetPasswordModal.customer.lastName}`}</strong> (@{resetPasswordModal.customer.username}).
            </p>
            {resetPasswordModal.error && (
              <div className="p-3 rounded-xl bg-red-50 dark:bg-red-950/60 border border-red-200 dark:border-red-800 text-xs text-red-700 dark:text-red-300 font-semibold">
                {resetPasswordModal.error}
              </div>
            )}

            <form onSubmit={handleResetPasswordSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold mb-1">New Temporary Password (min 8 chars)</label>
                <div className="flex gap-1.5">
                  <div className="relative flex-1">
                    <input
                      type={resetPasswordModal.showPassword ? 'text' : 'password'}
                      required
                      minLength={8}
                      value={resetPasswordModal.newPassword}
                      onChange={e => setResetPasswordModal({ ...resetPasswordModal, newPassword: e.target.value })}
                      className="w-full pl-3 pr-9 py-2 font-mono text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl"
                    />
                    <button
                      type="button"
                      onClick={() => setResetPasswordModal({ ...resetPasswordModal, showPassword: !resetPasswordModal.showPassword })}
                      className="absolute right-2.5 top-2 text-slate-400 hover:text-slate-600"
                    >
                      {resetPasswordModal.showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                  <button
                    type="button"
                    onClick={() => setResetPasswordModal({ ...resetPasswordModal, newPassword: generateStrongTempPassword() })}
                    className="px-3 py-2 bg-slate-200 dark:bg-slate-800 rounded-xl font-bold flex items-center gap-1"
                  >
                    <Wand2 className="w-3.5 h-3.5" /> Generate
                  </button>
                </div>
              </div>

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setResetPasswordModal({ isOpen: false, customer: null, newPassword: '', showPassword: false })}
                  className="flex-1 py-2.5 bg-slate-100 dark:bg-slate-800 font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={resetPasswordModal.submitting}
                  className="flex-1 py-2.5 bg-[#002752] hover:bg-[#001d3d] text-white font-bold rounded-xl"
                >
                  {resetPasswordModal.submitting ? 'Saving...' : 'Save New Password'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Explicitly Authorized Delete Customer Modal */}
      {deleteModal.isOpen && deleteModal.customer && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-md w-full p-6 shadow-2xl border border-red-300 dark:border-red-900 space-y-4">
            <div className="flex items-center gap-3 text-red-600">
              <AlertTriangle className="w-6 h-6 shrink-0" />
              <h3 className="text-lg font-bold">Authorize Permanent Deletion</h3>
            </div>
            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              You are about to permanently remove <strong>{deleteModal.customer.fullName || `${deleteModal.customer.firstName} ${deleteModal.customer.lastName}`}</strong> ({deleteModal.customer.email}, Account: <strong>{deleteModal.customer.accountNumber || 'N/A'}</strong>). A pre-deletion backup snapshot will be recorded first.
            </p>
            {deleteModal.error && (
              <div className="p-3 rounded-xl bg-red-50 dark:bg-red-950/60 border border-red-200 dark:border-red-800 text-xs text-red-700 dark:text-red-300 font-semibold">
                {deleteModal.error}
              </div>
            )}

            <form onSubmit={handleDeleteCustomerSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold mb-1">
                  Type <code className="px-1.5 py-0.5 bg-red-100 text-red-800 rounded font-bold">DELETE</code> to authorize removal:
                </label>
                <input
                  type="text"
                  required
                  placeholder="Type DELETE"
                  value={deleteModal.confirmText}
                  onChange={e => setDeleteModal({ ...deleteModal, confirmText: e.target.value })}
                  className="w-full px-3 py-2 font-mono text-sm bg-slate-50 dark:bg-slate-950 border border-red-300 dark:border-red-800 rounded-xl"
                />
              </div>

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setDeleteModal({ isOpen: false, customer: null, confirmText: '' })}
                  className="flex-1 py-2.5 bg-slate-100 dark:bg-slate-800 font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={deleteModal.submitting || deleteModal.confirmText.trim() !== 'DELETE'}
                  className="flex-1 py-2.5 bg-red-600 hover:bg-red-700 disabled:opacity-40 text-white font-bold rounded-xl"
                >
                  {deleteModal.submitting ? 'Deleting...' : 'Permanently Delete'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Database Backups & Snapshots Modal */}
      {backupsModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 dark:border-slate-800 space-y-4 my-8">
            <div className="flex items-start justify-between gap-3">
              <div>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <Database className="w-5 h-5 text-[#002752] dark:text-blue-400" />
                  <span>Permanent Cloud Database & Backups</span>
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  All customer records are permanently persisted in Firebase Firestore with recovery snapshots.
                </p>
              </div>
            </div>

            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                onClick={handleCreateBackup}
                disabled={backupActionLoading}
                className="flex-1 py-2.5 px-3 bg-[#002752] hover:bg-[#001d3d] text-white font-bold text-xs rounded-xl flex items-center justify-center gap-1.5"
              >
                <Database className="w-3.5 h-3.5" />
                <span>Create Cloud Snapshot</span>
              </button>
              <button
                type="button"
                onClick={handleDownloadBackup}
                disabled={backupActionLoading}
                className="flex-1 py-2.5 px-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-1.5"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Download JSON Backup</span>
              </button>
            </div>

            <div className="max-h-64 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800 text-xs border border-slate-200 dark:border-slate-800 rounded-2xl p-3 bg-slate-50 dark:bg-slate-950">
              {backups.length === 0 ? (
                <p className="text-center py-6 text-slate-400">No backup snapshots recorded yet. Click "Create Cloud Snapshot" above.</p>
              ) : (
                backups.map(b => (
                  <div key={b.id} className="py-2.5 flex items-center justify-between gap-3">
                    <div>
                      <strong className="text-slate-800 dark:text-slate-200 block">{b.reason || 'Backup Snapshot'}</strong>
                      <span className="text-[11px] text-slate-500 font-mono">{b.id} • {b.createdBy}</span>
                    </div>
                    <div className="text-right shrink-0">
                      <span className="font-bold text-slate-900 dark:text-white block">{b.customerCount} Customers</span>
                      <span className="text-[10px] text-slate-400">{new Date(b.createdAt).toLocaleString()}</span>
                    </div>
                  </div>
                ))
              )}
            </div>

            <div className="flex justify-end">
              <button
                type="button"
                onClick={() => setBackupsModalOpen(false)}
                className="px-4 py-2 bg-slate-100 dark:bg-slate-800 font-bold text-xs rounded-xl"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Support Reply Modal */}
      {replyTicketModal.isOpen && replyTicketModal.ticket && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 dark:border-slate-800 space-y-4">
            <h3 className="text-lg font-bold text-slate-900 dark:text-white">
              Reply to Support Ticket ({replyTicketModal.ticket.reference})
            </h3>
            <p className="text-xs text-slate-500">
              To: <strong>{replyTicketModal.ticket.name}</strong> ({replyTicketModal.ticket.email})
            </p>
            <div className="p-3 bg-slate-50 dark:bg-slate-950 rounded-xl text-xs text-slate-600 dark:text-slate-400">
              <strong>Customer Enquiry:</strong> "{replyTicketModal.ticket.message}"
            </div>
            {replyTicketModal.error && (
              <div className="p-3 rounded-xl bg-red-50 dark:bg-red-950/60 border border-red-200 dark:border-red-800 text-xs text-red-700 dark:text-red-300 font-semibold">
                {replyTicketModal.error}
              </div>
            )}

            <form onSubmit={handleSupportReplySubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold mb-1">Your Response Message</label>
                <textarea
                  rows={4}
                  required
                  placeholder="Write clear official response to customer..."
                  value={replyTicketModal.replyText}
                  onChange={e => setReplyTicketModal({ ...replyTicketModal, replyText: e.target.value })}
                  className="w-full px-3 py-2 text-xs sm:text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold mb-1">Ticket Resolution Status</label>
                <select
                  value={replyTicketModal.status}
                  onChange={e => setReplyTicketModal({ ...replyTicketModal, status: e.target.value as any })}
                  className="w-full px-3 py-2 text-xs sm:text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl"
                >
                  <option value="resolved">Resolved (Closed)</option>
                  <option value="in_progress">In Progress (Under Review)</option>
                  <option value="open">Keep Open</option>
                </select>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setReplyTicketModal({ ...replyTicketModal, isOpen: false })}
                  className="flex-1 py-2.5 bg-slate-100 dark:bg-slate-800 font-bold text-xs rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-[#002752] hover:bg-[#001d3d] text-white font-bold text-xs rounded-xl"
                >
                  Dispatch Reply
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Customer Statement Modal */}
      {statementCustomer && (
        <StatementModal
          user={statementCustomer}
          transactions={ledger.filter(t => t.userId === statementCustomer.id)}
          onClose={() => setStatementCustomer(null)}
        />
      )}

      {/* Active Receipt Modal */}
      {activeReceiptTx && (
        <ReceiptModal
          transaction={activeReceiptTx}
          onClose={() => setActiveReceiptTx(null)}
          onReversalSuccess={fetchAdminData}
        />
      )}

    </div>
  );
};
