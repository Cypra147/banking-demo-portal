import React, { useState } from 'react';
import { 
  CreditCard, 
  Send, 
  TrendingUp, 
  ShieldCheck, 
  FileText, 
  Smartphone, 
  ArrowRight, 
  Check, 
  Lock, 
  Zap, 
  ChevronRight,
  Info
} from 'lucide-react';

interface ServicesPageProps {
  onOpenAuth: (mode?: 'login' | 'register') => void;
  onNavigate: (page: string) => void;
}

export const ServicesPage: React.FC<ServicesPageProps> = ({ onOpenAuth, onNavigate }) => {
  const [activeModal, setActiveModal] = useState<string | null>(null);

  const services = [
    {
      id: 'current-account',
      icon: Smartphone,
      title: 'Personal & Business Current Accounts',
      category: 'Daily Banking',
      description: 'Streamlined account management with real-time balance tracking, unique UK sort codes (20-04-15), 10-digit account numbers, and instant notification alerts.',
      features: [
        'Zero monthly account maintenance fee',
        'Real-time credit and debit notifications',
        'Full PDF and downloadable transaction ledgers',
        '24/7 self-service customer portal access'
      ],
      badge: 'Core Banking',
      actionText: 'Open Account',
      actionPage: 'register'
    },
    {
      id: 'transfers',
      icon: Send,
      title: 'Fast Electronic Transfers',
      category: 'Payments',
      description: 'Send and receive USD ($) funds globally with instant digital settlement, beneficiary validation, SWIFT/BIC support, and verifiable transaction reference tags.',
      features: [
        'Domestic & international electronic bank transfers',
        'Support for IBAN, SWIFT/BIC, and routing codes',
        'Printable official transaction receipts',
        'Beneficiary lookup and transfer description records'
      ],
      badge: 'Instant Settlement',
      actionText: 'View Transfers',
      actionPage: 'transactions'
    },
    {
      id: 'investments',
      icon: TrendingUp,
      title: 'Wealth & Investment Portfolios',
      category: 'Asset Management',
      description: 'High-conviction investment strategies across sovereign treasury bonds, blue-chip global dividends, renewable energy, and artificial intelligence growth equities.',
      features: [
        'Projected yields ranging from 7.2% to 18.5% p.a.',
        'Compounding return calculations with term flexibility',
        'Strict administrative compliance verification',
        'Portfolio performance tracking dashboard'
      ],
      badge: 'High Yield Portfolio',
      actionText: 'Explore Plans',
      actionPage: 'investments'
    },
    {
      id: 'virtual-cards',
      icon: CreditCard,
      title: 'Secure Virtual Debit Cards',
      category: 'Digital Cards',
      description: 'Instantly issue digital Visa / Mastercard cards directly from your dashboard. Toggle security freeze in one tap and adjust daily limits for total spend control.',
      features: [
        '16-digit card numbering with CVV & expiry controls',
        'Instant one-tap freeze / unfreeze protection',
        'Custom daily spending limit thresholds',
        'Cardholder name customization'
      ],
      badge: 'Instant Provisioning',
      actionText: 'Explore Cards',
      actionPage: 'register'
    },
    {
      id: 'kyc-verification',
      icon: ShieldCheck,
      title: 'Identity Verification (KYC)',
      category: 'Compliance & Safety',
      description: 'Institutional-grade identity verification protecting accounts against fraudulent access while unlocking Tier-1 unlimited banking privileges.',
      features: [
        'Multi-document support: Passport, National ID, Driving Licence',
        'Proof of residential address verification',
        'Direct compliance desk review & status updates',
        'Encrypted document record retention'
      ],
      badge: 'Tier-1 Security',
      actionText: 'Verification Guide',
      actionPage: 'verification'
    },
    {
      id: 'statements',
      icon: FileText,
      title: 'Transaction Ledgers & Statements',
      category: 'Financial Reporting',
      description: 'Comprehensive financial reporting tools allowing customers and administrators to review, filter, audit, and print formal statements of account.',
      features: [
        'Custom date range and transaction type filtering',
        'Audit-ready reference numbering for every entry',
        'Print-optimized clean banking statement layout',
        'Real-time synchronization across devices'
      ],
      badge: 'Audited Records',
      actionText: 'Review History',
      actionPage: 'transactions'
    }
  ];

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 pb-20">
      
      {/* Header Banner */}
      <section className="bg-gradient-to-r from-[#001833] via-[#002752] to-[#003875] text-white py-16 px-4 sm:px-6 lg:px-8 border-b border-blue-900/50">
        <div className="max-w-6xl mx-auto">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-red-600/20 border border-red-500/30 text-red-300 text-xs font-semibold mb-4">
            <Zap className="w-4 h-4 text-red-400" />
            <span>Comprehensive Digital Banking Solutions</span>
          </div>
          <h1 className="text-3xl sm:text-5xl font-black tracking-tight leading-tight max-w-3xl">
            Tailored Financial Products Built for Simplicity and Growth.
          </h1>
          <p className="mt-4 text-base sm:text-lg text-slate-300 max-w-2xl leading-relaxed">
            Whether managing everyday expenses, transferring capital, or building investment portfolios, FNB provides institutional-grade precision at your fingertips.
          </p>
        </div>
      </section>

      {/* Platform Notice */}
      <div className="max-w-6xl mx-auto px-4 -mt-6">
        <div className="bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-900/60 rounded-2xl p-4 sm:p-5 text-xs sm:text-sm text-blue-900 dark:text-blue-200 flex items-start gap-3 shadow-sm">
          <Info className="w-5 h-5 text-blue-600 dark:text-blue-400 shrink-0 mt-0.5" />
          <div className="leading-relaxed">
            <strong className="font-bold block text-sm mb-0.5">Independent Platform Overview</strong>
            All customer accounts, balances, electronic transfers, and investment allocations on FNB Online Banking operate within an independent digital banking platform and are not affiliated with any external commercial institution.
          </div>
        </div>
      </div>

      {/* Services Grid */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 mt-14">
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((srv) => {
            const Icon = srv.icon;
            return (
              <div 
                key={srv.id}
                className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-7 shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all duration-300 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-5">
                    <div className="w-12 h-12 bg-[#002752]/10 dark:bg-blue-950 text-[#002752] dark:text-blue-400 rounded-2xl flex items-center justify-center">
                      <Icon className="w-6 h-6" />
                    </div>
                    <span className="text-xs font-bold px-2.5 py-1 bg-red-50 dark:bg-red-950/40 text-red-600 dark:text-red-400 rounded-full border border-red-200 dark:border-red-900/60">
                      {srv.badge}
                    </span>
                  </div>

                  <span className="text-[11px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider block mb-1">
                    {srv.category}
                  </span>
                  <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-3">
                    {srv.title}
                  </h3>
                  <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed mb-6">
                    {srv.description}
                  </p>

                  <div className="space-y-2 mb-6 pt-2 border-t border-slate-100 dark:border-slate-800">
                    {srv.features.map((feat, i) => (
                      <div key={i} className="flex items-start gap-2 text-xs text-slate-600 dark:text-slate-300">
                        <Check className="w-3.5 h-3.5 text-emerald-500 shrink-0 mt-0.5" />
                        <span>{feat}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                  <button
                    onClick={() => {
                      if (srv.actionPage === 'register') {
                        onOpenAuth('register');
                      } else {
                        onNavigate(srv.actionPage);
                      }
                    }}
                    className="w-full py-2.5 bg-[#002752] hover:bg-[#001d3d] text-white font-bold rounded-xl text-xs transition-colors flex items-center justify-center gap-1.5 shadow-sm"
                  >
                    <span>{srv.actionText}</span>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Call to Action Card */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 mt-20">
        <div className="bg-[#002752] rounded-3xl p-8 sm:p-12 text-white flex flex-col md:flex-row items-center justify-between gap-8">
          <div className="max-w-xl">
            <span className="text-xs font-bold text-amber-400 uppercase tracking-widest block mb-2">
              Get Started In Minutes
            </span>
            <h3 className="text-2xl sm:text-3xl font-black">
              Start Your Digital Banking Experience Today
            </h3>
            <p className="mt-2 text-sm text-slate-300 leading-relaxed">
              Open your account, pass security verification, and gain immediate access to our personal online banking and investment suite.
            </p>
          </div>
          <div className="flex flex-col sm:flex-row gap-3 shrink-0 w-full sm:w-auto">
            <button
              onClick={() => onOpenAuth('register')}
              className="px-6 py-3 bg-[#c8102e] hover:bg-[#a50d26] text-white font-bold rounded-xl text-sm shadow-md transition-all text-center"
            >
              Open An Account
            </button>
            <button
              onClick={() => onOpenAuth('login')}
              className="px-6 py-3 bg-white/10 hover:bg-white/20 text-white font-bold rounded-xl text-sm border border-white/20 transition-all text-center"
            >
              Customer Sign In
            </button>
          </div>
        </div>
      </section>

    </div>
  );
};
