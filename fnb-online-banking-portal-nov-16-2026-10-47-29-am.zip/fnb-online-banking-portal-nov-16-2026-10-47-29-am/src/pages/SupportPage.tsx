import React, { useState } from 'react';
import { 
  Phone, 
  Mail, 
  MessageSquare, 
  MessageCircle, 
  HelpCircle, 
  Send, 
  CheckCircle2, 
  ChevronDown, 
  ChevronUp, 
  Clock, 
  ShieldCheck, 
  AlertCircle 
} from 'lucide-react';
import { api } from '../services/api.ts';

interface SupportPageProps {
  onOpenAuth: (mode?: 'login' | 'register') => void;
  userEmail?: string;
  userName?: string;
}

export const SupportPage: React.FC<SupportPageProps> = ({ userEmail = '', userName = '' }) => {
  // Support Form State
  const [formData, setFormData] = useState({
    name: userName || '',
    email: userEmail || '',
    phone: '',
    category: 'general',
    subject: '',
    message: '',
  });
  const [submitting, setSubmitting] = useState(false);
  const [submittedTicket, setSubmittedTicket] = useState<any>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // FAQ Accordion State
  const [expandedFaq, setExpandedFaq] = useState<number | null>(0);

  const faqs = [
    {
      q: 'How long does new account approval take?',
      a: 'Following application submission, our banking operations team reviews applicant details. Applications are reviewed and approved by an authorized system administrator, after which your unique 10-digit account number and sort code are generated.'
    },
    {
      q: 'How are domestic and international electronic transfers processed?',
      a: 'Transfers can be sent to domestic and international banking institutions using your destination account number, IBAN, SWIFT/BIC, or routing details. Every completed transfer generates a verifiable transaction reference and printable official receipt.'
    },
    {
      q: 'How do virtual cards function in FNB Online Banking?',
      a: 'Virtual cards are issued instantly with 16-digit card numbers, CVVs, and expiry dates. You can customize daily spending limits and freeze/unfreeze cards in real time to prevent unauthorized transactions.'
    },
    {
      q: 'What are the requirements for Tier-1 Account Verification (KYC)?',
      a: 'Tier-1 verification requires a valid government-issued photo ID (passport, national identity card, or driving licence) alongside proof of residential address (utility bill or bank statement issued within 90 days).'
    },
    {
      q: 'How do investment portfolios track projected returns?',
      a: 'FNB offers 4 curated portfolio strategies ranging from 7.2% to 18.5% annualized target yield across chosen tenures (3 to 36 months), tracked inside your Investments portal in USD ($).'
    },
    {
      q: 'How do I contact customer support outside business hours?',
      a: 'Our digital desk operates 24/7. You can reach us via WhatsApp (+12724736857), telephone helpline (+12724736857), live chat widget on the bottom right, or by submitting a ticket on this page.'
    }
  ];

  const handleSupportSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSubmitting(true);

    try {
      const res = await api.createSupportEnquiry(formData);
      setSubmittedTicket(res.enquiry);
      setFormData({
        name: userName || '',
        email: userEmail || '',
        phone: '',
        category: 'general',
        subject: '',
        message: '',
      });
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to submit enquiry. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleOpenLiveChat = () => {
    try {
      const tawk = (window as any).Tawk_API;
      if (tawk && typeof tawk.maximize === 'function') {
        tawk.maximize();
        return;
      }
    } catch {
      // Fallback to support enquiry form below
    }
    window.scrollTo({ top: 400, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen w-full max-w-full overflow-x-hidden bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 pb-20">
      
      {/* Header Banner */}
      <section className="bg-gradient-to-r from-[#001833] via-[#002752] to-[#003875] text-white py-16 px-4 sm:px-6 lg:px-8 border-b border-blue-900/50">
        <div className="max-w-6xl mx-auto">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-red-600/20 border border-red-500/30 text-red-300 text-xs font-semibold mb-4">
            <MessageSquare className="w-4 h-4 text-red-400" />
            <span>24/7 Client Relations & Technical Assistance</span>
          </div>
          <h1 className="text-3xl sm:text-5xl font-black tracking-tight leading-tight max-w-3xl">
            We Are Here to Assist You, Anytime, Anywhere.
          </h1>
          <p className="mt-4 text-base sm:text-lg text-slate-300 max-w-2xl leading-relaxed">
            Have questions regarding your account, wire transfers, virtual cards, or verification? Contact our dedicated support desk across our direct telephone, WhatsApp, or instant ticketing channels.
          </p>
        </div>
      </section>

      {/* Contact Channels Grid */}
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 -mt-8">
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          
          <a 
            href="tel:+12724736857"
            className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-md hover:shadow-lg transition-all group"
          >
            <div className="w-12 h-12 bg-red-50 dark:bg-red-950/40 text-red-600 rounded-xl flex items-center justify-center mb-4 group-hover:scale-105 transition-transform">
              <Phone className="w-6 h-6" />
            </div>
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">Telephone Helpline</span>
            <p className="font-bold text-sm text-slate-900 dark:text-white mt-1">+12724736857</p>
            <span className="text-[11px] text-emerald-600 font-semibold mt-1 block">24/7 Direct Line</span>
          </a>

          <a 
            href="https://wa.me/12724736857"
            target="_blank"
            rel="noopener noreferrer"
            className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-md hover:shadow-lg transition-all group"
          >
            <div className="w-12 h-12 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 rounded-xl flex items-center justify-center mb-4 group-hover:scale-105 transition-transform">
              <MessageCircle className="w-6 h-6" />
            </div>
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">WhatsApp Support</span>
            <p className="font-bold text-sm text-slate-900 dark:text-white mt-1">+12724736857</p>
            <span className="text-[11px] text-emerald-600 font-semibold mt-1 block">Instant Chat Available</span>
          </a>

          <a 
            href="mailto:info@fnnbbankss.online"
            className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-md hover:shadow-lg transition-all group"
          >
            <div className="w-12 h-12 bg-blue-50 dark:bg-blue-950/40 text-[#002752] dark:text-blue-400 rounded-xl flex items-center justify-center mb-4 group-hover:scale-105 transition-transform">
              <Mail className="w-6 h-6" />
            </div>
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">Email Assistance</span>
            <p className="font-bold text-xs sm:text-sm text-slate-900 dark:text-white mt-1 truncate">info@fnnbbankss.online</p>
            <span className="text-[11px] text-slate-500 mt-1 block">Fast Response Desk</span>
          </a>

          <button 
            type="button"
            onClick={handleOpenLiveChat}
            className="bg-[#002752] text-white p-6 rounded-2xl border border-blue-900 shadow-md hover:bg-[#001d3d] transition-all text-left group"
          >
            <div className="w-12 h-12 bg-white/10 text-amber-400 rounded-xl flex items-center justify-center mb-4 group-hover:scale-105 transition-transform">
              <MessageSquare className="w-6 h-6" />
            </div>
            <span className="text-[11px] font-bold text-slate-300 uppercase tracking-wider block">Tawk.to Live Chat</span>
            <p className="font-bold text-sm text-white mt-1">Start Live Discussion</p>
            <span className="text-[11px] text-emerald-400 font-semibold mt-1 block">Agent Online Now</span>
          </button>

        </div>
      </div>

      {/* Form & FAQs Container */}
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 mt-14">
        <div className="grid lg:grid-cols-12 gap-8">
          
          {/* Support Ticket Submission Form */}
          <div className="lg:col-span-7">
            <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 shadow-sm">
              <h2 className="text-xl font-bold text-slate-900 dark:text-white mb-2">
                Submit an Enquiry or Complaint
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 mb-6">
                Fill in your details below to log an official support request. A tracking ticket reference will be generated immediately.
              </p>

              {submittedTicket && (
                <div className="mb-6 p-4 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 rounded-2xl text-xs space-y-2">
                  <div className="flex items-center gap-2 text-emerald-700 dark:text-emerald-300 font-bold">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Support Ticket Successfully Created!</span>
                  </div>
                  <p className="text-slate-600 dark:text-slate-300">
                    Your request has been logged under reference: <strong className="font-mono text-emerald-700 dark:text-emerald-300">{submittedTicket.reference}</strong>. A copy has been dispatched to {submittedTicket.email}.
                  </p>
                </div>
              )}

              {errorMsg && (
                <div className="mb-6 p-4 bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 rounded-2xl text-xs text-red-700 dark:text-red-300 flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  <span>{errorMsg}</span>
                </div>
              )}

              <form onSubmit={handleSupportSubmit} className="space-y-4">
                
                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Your Full Name
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Sarah Jenkins"
                      value={formData.name}
                      onChange={e => setFormData({ ...formData, name: e.target.value })}
                      className="w-full px-3.5 py-2.5 text-xs sm:text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#002752]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Email Address
                    </label>
                    <input
                      type="email"
                      required
                      placeholder="e.g. sarah.jenkins@fnnbbankss.online"
                      value={formData.email}
                      onChange={e => setFormData({ ...formData, email: e.target.value })}
                      className="w-full px-3.5 py-2.5 text-xs sm:text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#002752]"
                    />
                  </div>
                </div>

                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Contact Phone (Optional)
                    </label>
                    <input
                      type="tel"
                      placeholder="+44 7700 000000"
                      value={formData.phone}
                      onChange={e => setFormData({ ...formData, phone: e.target.value })}
                      className="w-full px-3.5 py-2.5 text-xs sm:text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#002752]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Enquiry Category
                    </label>
                    <select
                      value={formData.category}
                      onChange={e => setFormData({ ...formData, category: e.target.value })}
                      className="w-full px-3.5 py-2.5 text-xs sm:text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#002752]"
                    >
                      <option value="general">General Banking Assistance</option>
                      <option value="technical">Technical / Login Issue</option>
                      <option value="account">Account & Transfer Query</option>
                      <option value="complaint">Formal Complaint</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Subject Line
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Brief description of your request"
                    value={formData.subject}
                    onChange={e => setFormData({ ...formData, subject: e.target.value })}
                    className="w-full px-3.5 py-2.5 text-xs sm:text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#002752]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Detailed Message
                  </label>
                  <textarea
                    rows={4}
                    required
                    placeholder="Please provide all pertinent details, including reference numbers or transaction dates..."
                    value={formData.message}
                    onChange={e => setFormData({ ...formData, message: e.target.value })}
                    className="w-full px-3.5 py-2.5 text-xs sm:text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#002752]"
                  />
                </div>

                <div className="pt-2">
                  <button
                    type="submit"
                    disabled={submitting}
                    className="w-full py-3 bg-[#c8102e] hover:bg-[#a50d26] text-white font-bold rounded-xl text-sm shadow-md transition-all flex items-center justify-center gap-2"
                  >
                    <Send className="w-4 h-4" />
                    <span>{submitting ? 'Submitting Ticket...' : 'Submit Support Request'}</span>
                  </button>
                </div>

              </form>
            </div>
          </div>

          {/* Frequently Asked Questions */}
          <div className="lg:col-span-5 space-y-4">
            <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 shadow-sm">
              <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2 flex items-center gap-2">
                <HelpCircle className="w-5 h-5 text-[#002752] dark:text-blue-400" />
                <span>Frequently Asked Questions</span>
              </h3>
              <p className="text-xs text-slate-500 mb-6">
                Quick solutions to the most common customer banking queries.
              </p>

              <div className="space-y-3">
                {faqs.map((faq, idx) => {
                  const isOpen = expandedFaq === idx;
                  return (
                    <div 
                      key={idx}
                      className="border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden transition-all"
                    >
                      <button
                        type="button"
                        onClick={() => setExpandedFaq(isOpen ? null : idx)}
                        className="w-full p-4 text-left flex items-center justify-between gap-3 bg-slate-50/50 dark:bg-slate-950/40 hover:bg-slate-100 dark:hover:bg-slate-900 transition-colors"
                      >
                        <span className="text-xs sm:text-sm font-bold text-slate-800 dark:text-slate-200">
                          {faq.q}
                        </span>
                        {isOpen ? (
                          <ChevronUp className="w-4 h-4 text-slate-400 shrink-0" />
                        ) : (
                          <ChevronDown className="w-4 h-4 text-slate-400 shrink-0" />
                        )}
                      </button>
                      {isOpen && (
                        <div className="p-4 text-xs text-slate-600 dark:text-slate-400 leading-relaxed bg-white dark:bg-slate-900 border-t border-slate-100 dark:border-slate-800">
                          {faq.a}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Quick Summary Card */}
            <div className="bg-[#002752] text-white rounded-3xl p-6 sm:p-7 shadow-md">
              <div className="flex items-center gap-2 mb-2 text-red-400">
                <Clock className="w-4 h-4" />
                <span className="text-xs font-bold uppercase tracking-wider">Service Level Guarantee</span>
              </div>
              <h4 className="text-base font-bold mb-2">Prompt Human Assistance</h4>
              <p className="text-xs text-slate-300 leading-relaxed">
                Tickets are reviewed by dedicated support personnel within 15 minutes during standard operating hours.
              </p>
              <p className="text-xs text-slate-300 mt-3 pt-3 border-t border-white/15">
                <span className="font-semibold text-white">Branch Office:</span> 13586 US-90, Boutte, LA 70039, United States
              </p>
            </div>
          </div>

        </div>
      </div>

    </div>
  );
};
