import React from 'react';
import { useLanguage } from '../context/LanguageContext.tsx';
import { 
  ShieldCheck, 
  ArrowRight, 
  CreditCard, 
  Send, 
  Smartphone, 
  PiggyBank,
  CheckCircle2,
  Phone,
  MessageCircle,
  Zap,
  FileCheck
} from 'lucide-react';

interface HomePageProps {
  onOpenAuth: (mode: 'login' | 'register') => void;
  onNavigate?: (page: string) => void;
}

export const HomePage: React.FC<HomePageProps> = ({ onOpenAuth, onNavigate }) => {
  const { t } = useLanguage();

  return (
    <div className="min-h-screen w-full max-w-full overflow-x-hidden bg-slate-50 dark:bg-slate-950 text-slate-800 dark:text-slate-100 transition-colors">
      
      {/* Full-Width Hero Banner Section */}
      <section className="relative w-full overflow-hidden bg-slate-100 dark:bg-slate-950 border-b border-slate-200 dark:border-slate-800">
        <h1 className="sr-only">
          {t('hero.titleLine1', 'Your Goals. Our Priority.')} {t('hero.titleLine2', 'Banking for a Brighter Tomorrow.')}
        </h1>

        {/* Full-width cropped hero banner (crops out baked-in mockup header bar at top 13.07%) */}
        <div className="relative w-full aspect-[1672/818] overflow-hidden select-none">
          <img
            src="/assets/aistudio/file_0000000054f081f4866ec5cc812ae909_e675e9e3.png"
            alt="Your Goals. Our Priority. Banking for a Brighter Tomorrow."
            className="absolute left-0 top-[-15.04%] w-full h-auto max-w-none pointer-events-none"
          />

          {/* Interactive CTA Hitboxes aligned to banner buttons */}
          <button
            type="button"
            onClick={() => onOpenAuth('login')}
            aria-label={t('hero.signIn', 'Login to Online Banking')}
            className="hidden sm:block absolute left-[3.47%] top-[67.11%] w-[21.29%] h-[7.95%] rounded-full hover:bg-white/15 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white transition-colors cursor-pointer"
          />
          <button
            type="button"
            onClick={() => onOpenAuth('register')}
            aria-label={t('hero.openAccount', 'Open an Account')}
            className="hidden sm:block absolute left-[26.50%] top-[67.11%] w-[17.46%] h-[7.95%] rounded-full hover:bg-[#002752]/10 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#002752] transition-colors cursor-pointer"
          />
        </div>

        {/* Mobile Touch-Friendly Action Bar */}
        <div className="sm:hidden bg-white dark:bg-slate-900 px-4 py-4 border-t border-slate-200 dark:border-slate-800 flex flex-col gap-2.5">
          <button
            type="button"
            onClick={() => onOpenAuth('login')}
            className="w-full py-3 bg-[#c8102e] hover:bg-[#b00d27] text-white font-bold rounded-full shadow-md transition-all flex items-center justify-center gap-2 text-sm"
          >
            <span>{t('hero.signIn', 'Login to Online Banking')}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={() => onOpenAuth('register')}
            className="w-full py-3 bg-white dark:bg-slate-950 border-2 border-[#002752] dark:border-slate-600 text-[#002752] dark:text-white font-bold rounded-full transition-all flex items-center justify-center gap-2 text-sm"
          >
            <span>{t('hero.openAccount', 'Open an Account')}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </section>

      {/* Core Banking Pillars */}
      <section id="features" className="py-20 bg-white dark:bg-slate-900 border-y border-slate-200 dark:border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-8">
          
          <div className="text-center max-w-2xl mx-auto mb-16">
            <span className="text-xs font-extrabold uppercase tracking-widest text-[#c8102e]">
              {t('features.tag', 'BANKING CAPABILITIES')}
            </span>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-[#002752] dark:text-white mt-2">
              {t('features.heading', 'Modern Banking Services for Everyday Life')}
            </h2>
            <p className="text-slate-600 dark:text-slate-400 text-sm mt-3">
              {t('features.subheading', 'Engineered with advanced financial technology, robust security safeguards, and seamless cross-device compatibility.')}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            
            {/* Feature 1 */}
            <div 
              onClick={() => onNavigate ? onNavigate('services') : onOpenAuth('login')}
              role="button"
              tabIndex={0}
              className="p-7 rounded-3xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 hover:border-red-400 dark:hover:border-red-700 hover:shadow-xl hover:-translate-y-1.5 transition-all cursor-pointer group text-left flex flex-col justify-between"
            >
              <div>
                <div className="w-12 h-12 rounded-2xl bg-red-100 dark:bg-red-950/60 text-red-600 flex items-center justify-center mb-5 group-hover:scale-110 transition-transform shadow-sm">
                  <Send className="w-6 h-6" />
                </div>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-2 group-hover:text-[#c8102e] transition-colors">
                  {t('features.transfersTitle', 'Domestic & International Transfers')}
                </h3>
                <p className="text-slate-600 dark:text-slate-400 text-xs leading-relaxed">
                  {t('features.transfersDesc', 'Send funds to any beneficiary with validated sort codes and account numbers. Complete with rapid processing, cryptographic reference tags, and instant downloadable receipts.')}
                </p>
              </div>
              <div className="mt-4 pt-3 border-t border-slate-200/60 dark:border-slate-800/60 flex items-center gap-1.5 text-xs font-bold text-[#002752] dark:text-blue-400 group-hover:translate-x-1 transition-transform">
                <span>{t('features.exploreTransfers', 'Explore Transfers')}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </div>
            </div>

            {/* Feature 2 */}
            <div 
              onClick={() => onNavigate ? onNavigate('services') : onOpenAuth('login')}
              role="button"
              tabIndex={0}
              className="p-7 rounded-3xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 hover:border-red-400 dark:hover:border-red-700 hover:shadow-xl hover:-translate-y-1.5 transition-all cursor-pointer group text-left flex flex-col justify-between"
            >
              <div>
                <div className="w-12 h-12 rounded-2xl bg-blue-100 dark:bg-blue-950/60 text-[#002752] dark:text-blue-400 flex items-center justify-center mb-5 group-hover:scale-110 transition-transform shadow-sm">
                  <CreditCard className="w-6 h-6" />
                </div>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-2 group-hover:text-[#c8102e] transition-colors">
                  {t('features.cardsTitle', 'Virtual Visa & Mastercard Cards')}
                </h3>
                <p className="text-slate-600 dark:text-slate-400 text-xs leading-relaxed">
                  {t('features.cardsDesc', 'Instantly provision debit cards with customizable daily limits, one-tap freeze/unfreeze controls, and dynamic CVV security.')}
                </p>
              </div>
              <div className="mt-4 pt-3 border-t border-slate-200/60 dark:border-slate-800/60 flex items-center gap-1.5 text-xs font-bold text-[#002752] dark:text-blue-400 group-hover:translate-x-1 transition-transform">
                <span>{t('features.viewCards', 'View Card Solutions')}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </div>
            </div>

            {/* Feature 3 */}
            <div 
              onClick={() => onNavigate ? onNavigate('services') : onOpenAuth('login')}
              role="button"
              tabIndex={0}
              className="p-7 rounded-3xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 hover:border-red-400 dark:hover:border-red-700 hover:shadow-xl hover:-translate-y-1.5 transition-all cursor-pointer group text-left flex flex-col justify-between"
            >
              <div>
                <div className="w-12 h-12 rounded-2xl bg-amber-100 dark:bg-amber-950/60 text-amber-600 flex items-center justify-center mb-5 group-hover:scale-110 transition-transform shadow-sm">
                  <Zap className="w-6 h-6" />
                </div>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-2 group-hover:text-[#c8102e] transition-colors">
                  {t('features.billsTitle', 'Utility Bill Payments & Top-Ups')}
                </h3>
                <p className="text-slate-600 dark:text-slate-400 text-xs leading-relaxed">
                  {t('features.billsDesc', 'Pay electricity, internet broadband, airtime, and mobile data packages directly from your account balance with official receipts.')}
                </p>
              </div>
              <div className="mt-4 pt-3 border-t border-slate-200/60 dark:border-slate-800/60 flex items-center gap-1.5 text-xs font-bold text-[#002752] dark:text-blue-400 group-hover:translate-x-1 transition-transform">
                <span>{t('features.learnMore', 'Learn More')}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </div>
            </div>

            {/* Feature 4 */}
            <div 
              onClick={() => onNavigate ? onNavigate('security') : onOpenAuth('login')}
              role="button"
              tabIndex={0}
              className="p-7 rounded-3xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 hover:border-red-400 dark:hover:border-red-700 hover:shadow-xl hover:-translate-y-1.5 transition-all cursor-pointer group text-left flex flex-col justify-between"
            >
              <div>
                <div className="w-12 h-12 rounded-2xl bg-emerald-100 dark:bg-emerald-950/60 text-emerald-600 flex items-center justify-center mb-5 group-hover:scale-110 transition-transform shadow-sm">
                  <ShieldCheck className="w-6 h-6" />
                </div>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-2 group-hover:text-[#c8102e] transition-colors">
                  {t('features.otpTitle', 'Multi-Factor OTP Authentication')}
                </h3>
                <p className="text-slate-600 dark:text-slate-400 text-xs leading-relaxed">
                  {t('features.otpDesc', 'Secure registration and banking access protected by 6-digit email OTP verification, server-side password hashing, and administrative review.')}
                </p>
              </div>
              <div className="mt-4 pt-3 border-t border-slate-200/60 dark:border-slate-800/60 flex items-center gap-1.5 text-xs font-bold text-[#002752] dark:text-blue-400 group-hover:translate-x-1 transition-transform">
                <span>{t('features.securityStandards', 'Security Standards')}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </div>
            </div>

            {/* Feature 5 */}
            <div 
              onClick={() => onNavigate ? onNavigate('about') : onOpenAuth('login')}
              role="button"
              tabIndex={0}
              className="p-7 rounded-3xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 hover:border-red-400 dark:hover:border-red-700 hover:shadow-xl hover:-translate-y-1.5 transition-all cursor-pointer group text-left flex flex-col justify-between"
            >
              <div>
                <div className="w-12 h-12 rounded-2xl bg-purple-100 dark:bg-purple-950/60 text-purple-600 flex items-center justify-center mb-5 group-hover:scale-110 transition-transform shadow-sm">
                  <Smartphone className="w-6 h-6" />
                </div>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-2 group-hover:text-[#c8102e] transition-colors">
                  {t('features.crossDeviceTitle', 'Cross-Device Experience')}
                </h3>
                <p className="text-slate-600 dark:text-slate-400 text-xs leading-relaxed">
                  {t('features.crossDeviceDesc', 'Fully responsive layout engineered to perform smoothly across iOS, Android, tablets, and desktop computers.')}
                </p>
              </div>
              <div className="mt-4 pt-3 border-t border-slate-200/60 dark:border-slate-800/60 flex items-center gap-1.5 text-xs font-bold text-[#002752] dark:text-blue-400 group-hover:translate-x-1 transition-transform">
                <span>{t('features.aboutPlatform', 'About Our Platform')}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </div>
            </div>

            {/* Feature 6 */}
            <div 
              onClick={() => onNavigate ? onNavigate('services') : onOpenAuth('login')}
              role="button"
              tabIndex={0}
              className="p-7 rounded-3xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 hover:border-red-400 dark:hover:border-red-700 hover:shadow-xl hover:-translate-y-1.5 transition-all cursor-pointer group text-left flex flex-col justify-between"
            >
              <div>
                <div className="w-12 h-12 rounded-2xl bg-rose-100 dark:bg-rose-950/60 text-rose-600 flex items-center justify-center mb-5 group-hover:scale-110 transition-transform shadow-sm">
                  <FileCheck className="w-6 h-6" />
                </div>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-2 group-hover:text-[#c8102e] transition-colors">
                  {t('features.statementsTitle', 'Certified Account Statements')}
                </h3>
                <p className="text-slate-600 dark:text-slate-400 text-xs leading-relaxed">
                  {t('features.statementsDesc', 'Generate official printable account statements and CSV records complete with Sort Code 20-04-15 and transaction references.')}
                </p>
              </div>
              <div className="mt-4 pt-3 border-t border-slate-200/60 dark:border-slate-800/60 flex items-center gap-1.5 text-xs font-bold text-[#002752] dark:text-blue-400 group-hover:translate-x-1 transition-transform">
                <span>{t('features.generateStatements', 'Generate Statements')}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </div>
            </div>

          </div>

        </div>
      </section>

      {/* Children & Youth Savings Section (User Attachment 3) */}
      <section id="savings" className="py-20 bg-gradient-to-br from-slate-100 via-white to-blue-50/50 dark:from-slate-950 dark:via-slate-900 dark:to-slate-950">
        <div className="max-w-7xl mx-auto px-4 sm:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            {/* Visual Attachment 3 */}
            <div className="lg:col-span-5 order-2 lg:order-1">
              <div className="relative rounded-3xl overflow-hidden shadow-2xl border-4 border-white dark:border-slate-800 bg-white dark:bg-slate-900 group">
                <img
                  src="/assets/aistudio/file_0000000001888210a364b9b0694cab78_6a6bbbe5.png"
                  alt="FNB Little Steps, Big Dreams Savings"
                  className="w-full h-auto object-cover group-hover:scale-102 transition-transform duration-500"
                />
              </div>
            </div>

            {/* Content Details */}
            <div className="lg:col-span-7 order-1 lg:order-2 space-y-6">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300 text-xs font-bold uppercase tracking-wider">
                <PiggyBank className="w-4 h-4 text-amber-600" />
                CHILD & FUTURE SAVINGS
              </div>

              <h2 className="text-3xl sm:text-5xl font-black text-[#002752] dark:text-white tracking-tight leading-tight">
                Little Steps, <br />
                <span className="text-[#c8102e]">Big Dreams!</span>
              </h2>

              <p className="text-base text-slate-600 dark:text-slate-300 leading-relaxed">
                Open a savings account for your child today. Because their future deserves a great start. Teach smart money management, build solid savings habits, and prepare for long-term growth.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                  <h4 className="font-bold text-sm text-[#002752] dark:text-white flex items-center gap-2 mb-1">
                    <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                    Build Good Habits
                  </h4>
                  <p className="text-xs text-slate-500">
                    Teach your child the value of saving and smart financial habits from an early age.
                  </p>
                </div>

                <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                  <h4 className="font-bold text-sm text-[#002752] dark:text-white flex items-center gap-2 mb-1">
                    <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                    Secure Their Future
                  </h4>
                  <p className="text-xs text-slate-500">
                    Consistent savings today unlock future education and life opportunities tomorrow.
                  </p>
                </div>
              </div>

              <div className="pt-2">
                <button
                  onClick={() => onOpenAuth('register')}
                  className="px-6 py-3.5 bg-[#c8102e] hover:bg-[#b00d27] text-white font-bold rounded-2xl shadow-lg transition-all flex items-center gap-2"
                >
                  <span>Open a Child Savings Account</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>

            </div>

          </div>
        </div>
      </section>

      {/* Security & Regulatory Compliance */}
      <section id="security" className="py-20 bg-[#002752] text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            
            <div className="space-y-4">
              <span className="text-xs font-bold text-red-400 uppercase tracking-widest">
                FINANCIAL INSTITUTION PROTECTION
              </span>
              <h2 className="text-3xl font-extrabold tracking-tight">
                Institutional Security Built into Every Layer
              </h2>
              <p className="text-slate-300 text-sm leading-relaxed">
                From server-side cryptographic scrypt password hashing and email OTP authentication to rate limiting and comprehensive administrative audit trails, customer records and funds are protected by industry-standard encryption protocols.
              </p>
              
              <div className="pt-4 flex flex-wrap gap-6 text-xs text-slate-200">
                <div className="flex items-center gap-2">
                  <Phone className="w-4 h-4 text-red-400" />
                  <span>Telephone Helpline: <strong>+12724736857</strong></span>
                </div>
                <div className="flex items-center gap-2">
                  <MessageCircle className="w-4 h-4 text-emerald-400" />
                  <span>WhatsApp: <strong>+12724736857</strong></span>
                </div>
              </div>
            </div>

            <div className="bg-white/10 p-7 rounded-3xl border border-white/15 backdrop-blur-md space-y-4">
              <h3 className="font-bold text-lg text-white">Banking Coordinates & Support</h3>
              <p className="text-xs text-slate-200 leading-relaxed">
                Official contact and registration records for First National Bank.
              </p>
              <div className="space-y-2.5 text-xs">
                <div className="flex justify-between py-2 border-b border-white/10">
                  <span className="text-slate-300">Bank Name</span>
                  <span className="font-bold text-white">FNB (First National Bank)</span>
                </div>
                <div className="flex justify-between py-2 border-b border-white/10">
                  <span className="text-slate-300">Official Inquiries</span>
                  <span className="font-mono text-white">info@fnnbbankss.online</span>
                </div>
                <div className="flex justify-between py-2 border-b border-white/10">
                  <span className="text-slate-300">Branch Sort Code</span>
                  <span className="font-mono font-bold text-white">20-04-15</span>
                </div>
                <div className="flex justify-between py-2">
                  <span className="text-slate-300">Customer Helpline</span>
                  <span className="font-bold text-emerald-300">+12724736857</span>
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>

    </div>
  );
};
