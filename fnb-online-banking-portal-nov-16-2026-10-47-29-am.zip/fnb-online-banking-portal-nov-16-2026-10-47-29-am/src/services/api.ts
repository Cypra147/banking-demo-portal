import { 
  User, 
  Transaction, 
  VirtualCard, 
  AuditLog, 
  EmailMessage, 
  LoginActivity, 
  InvestmentPlan, 
  InvestmentRequest, 
  VerificationRequest, 
  SupportEnquiry, 
  NotificationItem 
} from '../types.ts';

const TOKEN_KEY = 'fnb_session_token';
const CUSTOMER_LAST_ACTIVITY_KEY = 'fnb_customer_last_activity';
const ADMIN_TOKEN_KEY = 'fnb_admin_token';

export function getSessionToken(isAdmin = false): string | null {
  if (isAdmin) {
    return localStorage.getItem(ADMIN_TOKEN_KEY) || sessionStorage.getItem(ADMIN_TOKEN_KEY);
  }
  // Customer sessions are scoped strictly to tab/browser lifetime (sessionStorage only)
  try {
    if (localStorage.getItem(TOKEN_KEY)) {
      localStorage.removeItem(TOKEN_KEY);
    }
  } catch {}
  return sessionStorage.getItem(TOKEN_KEY);
}

export function setSessionToken(token: string, isAdmin = false) {
  if (isAdmin) {
    localStorage.setItem(ADMIN_TOKEN_KEY, token);
    sessionStorage.setItem(ADMIN_TOKEN_KEY, token);
  } else {
    try {
      localStorage.removeItem(TOKEN_KEY);
    } catch {}
    sessionStorage.setItem(TOKEN_KEY, token);
    sessionStorage.setItem(CUSTOMER_LAST_ACTIVITY_KEY, String(Date.now()));
  }
}

export function clearSessionToken(isAdmin?: boolean) {
  if (isAdmin) {
    localStorage.removeItem(ADMIN_TOKEN_KEY);
    sessionStorage.removeItem(ADMIN_TOKEN_KEY);
  } else {
    try {
      localStorage.removeItem(TOKEN_KEY);
      localStorage.removeItem(CUSTOMER_LAST_ACTIVITY_KEY);
    } catch {}
    sessionStorage.removeItem(TOKEN_KEY);
    sessionStorage.removeItem(CUSTOMER_LAST_ACTIVITY_KEY);
  }
}

export function sendCustomerPageCloseBeacon() {
  const token = getSessionToken(false);
  if (!token) return;
  const payload = JSON.stringify({ token });
  try {
    if (typeof navigator !== 'undefined' && typeof navigator.sendBeacon === 'function') {
      const blob = new Blob([payload], { type: 'application/json' });
      const sent = navigator.sendBeacon('/api/auth/customer-page-close', blob);
      if (sent) return;
    }
  } catch {}
  try {
    fetch('/api/auth/customer-page-close', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: payload,
      keepalive: true,
    }).catch(() => {});
  } catch {}
}

async function request<T>(endpoint: string, options: RequestInit = {}, isAdmin = false): Promise<T> {
  const token = getSessionToken(isAdmin);
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(options.headers as Record<string, string> || {}),
  };

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  let response: Response;
  try {
    response = await fetch(endpoint, {
      ...options,
      headers,
    });
  } catch (netErr: any) {
    console.error('Network request failed:', netErr);
    throw new Error('Unable to connect to the banking server. Please verify your connection or try again shortly.');
  }

  const data = await response.json().catch(() => ({}));

  if (!response.ok) {
    const err = new Error(data.error || `Request failed with status ${response.status}`) as Error & {
      code?: string;
      lockedUntil?: number;
      status?: number;
    };
    if (data.code) err.code = data.code;
    if (data.lockedUntil) err.lockedUntil = data.lockedUntil;
    err.status = response.status;
    throw err;
  }

  return data as T;
}

export const api = {
  checkUsername: (username: string) =>
    request<{ available: boolean; message: string }>(`/api/auth/check-username?username=${encodeURIComponent(username)}`),

  logout: (isAdmin = false) =>
    request<{ success: boolean; message: string }>('/api/auth/logout', { method: 'POST' }, isAdmin),

  pingCustomerActivity: () =>
    request<{ success: boolean; lastActivityAt: number }>('/api/auth/customer-activity', { method: 'POST' }, false),

  registerRequest: (payload: {
    firstName: string;
    middleName?: string;
    lastName: string;
    fullName?: string;
    dateOfBirth?: string;
    email: string;
    username: string;
    phone: string;
    country?: string;
    state?: string;
    residentialAddress?: string;
    postalCode?: string;
    password: string;
    confirmPassword: string;
    notificationPreferences?: {
      emailAlerts: boolean;
      smsAlerts: boolean;
    };
  }) => request<{ success: boolean; message: string; email: string; referenceNumber?: string; user?: any }>('/api/auth/register-request', {
    method: 'POST',
    body: JSON.stringify(payload),
  }),

  forgotPassword: (email: string) =>
    request<{ success: boolean; message: string; email?: string }>('/api/auth/forgot-password', {
      method: 'POST',
      body: JSON.stringify({ email }),
    }),

  resetPassword: (payload: { email: string; code: string; newPassword: string; confirmPassword: string }) =>
    request<{ success: boolean; message: string }>('/api/auth/reset-password', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  login: (identifier: string, password: string) =>
    request<{ success: boolean; token: string; user: User }>('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ identifier, password }),
    }),

  adminLogin: (password: string, email: string) =>
    request<{ success: boolean; token: string; user: User }>('/api/auth/admin-login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    }),

  getMe: (isAdmin = false) => request<{ user: User }>('/api/auth/me', { method: 'GET' }, isAdmin),

  updateProfile: (profile: { isTwoFactorEnabled?: boolean }) =>
    request<{ success: boolean; user: User }>('/api/auth/profile', {
      method: 'PUT',
      body: JSON.stringify(profile),
    }),

  changePassword: (currentPassword: string, newPassword: string) =>
    request<{ success: boolean; message: string }>('/api/auth/change-password', {
      method: 'POST',
      body: JSON.stringify({ currentPassword, newPassword }),
    }),

  getLoginActivity: () => request<{ activities: LoginActivity[] }>('/api/auth/login-activity', { method: 'GET' }),

  // --- Customer Banking ---
  getBankingSummary: () => request<{
    account: {
      id: string;
      holderName: string;
      email: string;
      phone: string;
      accountNumber: string;
      sortCode: string;
      balance: number;
      currency: string;
      status: string;
      isSandbox: boolean;
      unreadEmails: number;
      kycStatus?: 'unverified' | 'pending' | 'verified' | 'rejected';
    };
    recentTransactions: Transaction[];
    virtualCards: VirtualCard[];
  }>('/api/banking/summary', { method: 'GET' }),

  getBankDirectory: () => request<{
    version: string;
    source: string;
    countries: any[];
  }>('/api/banking/banks-directory', { method: 'GET' }),

  getTransactionPinStatus: () => request<{
    hasTransactionPin: boolean;
    transactionPinLength?: 4 | 6;
    transactionPinUpdatedAt?: string;
    pinLockedUntil?: number;
  }>('/api/banking/pin/status', { method: 'GET' }),

  setupTransactionPin: (pin: string, confirmPin: string) =>
    request<{ success: boolean; message: string; user: User }>('/api/banking/pin/setup', {
      method: 'POST',
      body: JSON.stringify({ pin, confirmPin }),
    }),

  changeTransactionPin: (currentPin: string, newPin: string, confirmPin: string) =>
    request<{ success: boolean; message: string; user: User }>('/api/banking/pin/change', {
      method: 'POST',
      body: JSON.stringify({ currentPin, newPin, confirmPin }),
    }),

  forgotTransactionPin: (currentPassword: string) =>
    request<{ success: boolean; message: string; email: string }>('/api/banking/pin/forgot', {
      method: 'POST',
      body: JSON.stringify({ currentPassword }),
    }),

  resetTransactionPin: (code: string, newPin: string, confirmPin: string) =>
    request<{ success: boolean; message: string; user: User }>('/api/banking/pin/reset', {
      method: 'POST',
      body: JSON.stringify({ code, newPin, confirmPin }),
    }),

  transfer: (payload: {
    beneficiaryName: string;
    beneficiaryBank: string;
    beneficiaryAccount: string;
    transferScope?: 'domestic' | 'international';
    beneficiaryCountry?: string;
    swiftBic?: string;
    routingCode?: string;
    amount: number;
    description: string;
    reference?: string;
    transactionPin: string;
  }) => request<{
    success: boolean;
    message: string;
    transaction: Transaction;
    newBalance: number;
  }>('/api/banking/transfer', {
    method: 'POST',
    body: JSON.stringify(payload),
  }),

  withdraw: (payload: { amount: number; method: string; destinationAccount: string; transactionPin: string }) =>
    request<{ success: boolean; message: string; transaction: Transaction }>('/api/banking/withdraw', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  payBill: (payload: {
    billerCategory: string;
    billerName: string;
    accountOrMeterNumber: string;
    amount: number;
    transactionPin: string;
  }) => request<{ success: boolean; message: string; transaction: Transaction }>('/api/banking/pay-bill', {
    method: 'POST',
    body: JSON.stringify(payload),
  }),

  getVirtualCards: () => request<{ cards: VirtualCard[] }>('/api/banking/virtual-cards', { method: 'GET' }),

  toggleCardFreeze: (cardId: string) =>
    request<{ success: boolean; card: VirtualCard }>(`/api/banking/virtual-cards/${cardId}/toggle-freeze`, {
      method: 'POST',
    }),

  updateCardLimits: (cardId: string, dailyLimit: number, onlineTransactionsEnabled: boolean) =>
    request<{ success: boolean; card: VirtualCard }>(`/api/banking/virtual-cards/${cardId}/limits`, {
      method: 'POST',
      body: JSON.stringify({ dailyLimit, onlineTransactionsEnabled }),
    }),

  getTransactions: (filters?: { type?: string; status?: string; tag?: string }) => {
    const params = new URLSearchParams(filters as any).toString();
    return request<{ transactions: Transaction[] }>(`/api/banking/transactions?${params}`, { method: 'GET' });
  },

  // --- Investments ---
  getInvestmentPlans: () => request<{ plans: InvestmentPlan[] }>('/api/banking/investment-plans', { method: 'GET' }),

  getInvestments: (isAdmin = false) =>
    request<{ investments: InvestmentRequest[] }>('/api/banking/investments', { method: 'GET' }, isAdmin),

  createInvestment: (payload: {
    planId: string;
    amount: number;
    durationMonths: number;
    userNotes?: string;
    transactionPin: string;
  }) =>
    request<{ success: boolean; message: string; investment: InvestmentRequest }>('/api/banking/investments', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  updateInvestmentStatus: (investmentId: string, status: string, adminComments?: string) =>
    request<{ success: boolean; message: string; investment: InvestmentRequest }>(`/api/admin/investments/${investmentId}/status`, {
      method: 'POST',
      body: JSON.stringify({ status, adminComments }),
    }, true),

  // --- Identity Verification (KYC) ---
  getVerifications: (isAdmin = false) =>
    request<{ verifications: VerificationRequest[] }>('/api/banking/verifications', { method: 'GET' }, isAdmin),

  createVerification: (payload: Omit<VerificationRequest, 'id' | 'userId' | 'reference' | 'status' | 'createdAt'>) =>
    request<{ success: boolean; message: string; verification: VerificationRequest }>('/api/banking/verifications', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  updateVerificationStatus: (verificationId: string, status: string, adminComments?: string) =>
    request<{ success: boolean; message: string; verification: VerificationRequest }>(`/api/admin/verifications/${verificationId}/status`, {
      method: 'POST',
      body: JSON.stringify({ status, adminComments }),
    }, true),

  // --- Support & Tickets ---
  getSupportEnquiries: (email?: string, isAdmin = false) => {
    const query = email ? `?email=${encodeURIComponent(email)}` : '';
    return request<{ enquiries: SupportEnquiry[] }>(`/api/support/enquiries${query}`, { method: 'GET' }, isAdmin);
  },

  createSupportEnquiry: (payload: { name: string; email: string; phone?: string; category: string; subject: string; message: string }) =>
    request<{ success: boolean; message: string; enquiry: SupportEnquiry }>('/api/support/enquiries', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  replySupportEnquiry: (enquiryId: string, reply: string, status?: string) =>
    request<{ success: boolean; message: string; enquiry: SupportEnquiry }>(`/api/admin/support/${enquiryId}/reply`, {
      method: 'POST',
      body: JSON.stringify({ reply, status }),
    }, true),

  // --- Notifications ---
  getNotifications: () => request<{ notifications: NotificationItem[] }>('/api/banking/notifications', { method: 'GET' }),

  markNotificationRead: (notificationId: string) =>
    request<{ success: boolean }>(`/api/banking/notifications/${notificationId}/read`, { method: 'POST' }),

  markAllNotificationsRead: () =>
    request<{ success: boolean; updatedCount: number }>('/api/banking/notifications/read-all', { method: 'POST' }),

  deleteNotification: (notificationId: string) =>
    request<{ success: boolean }>(`/api/banking/notifications/${notificationId}`, { method: 'DELETE' }),

  // --- Emails / Notification Center ---
  getEmails: (isAdmin = false) => request<{ emails: EmailMessage[] }>('/api/emails', { method: 'GET' }, isAdmin),

  markEmailRead: (emailId: string, isAdmin = false) =>
    request<{ success: boolean }>(`/api/emails/${emailId}/read`, { method: 'POST' }, isAdmin),

  // --- Administrator Controls ---
  getAdminStats: () => request<any>('/api/admin/stats', { method: 'GET' }, true),

  getAdminCustomers: () => request<{ customers: User[] }>('/api/admin/customers', { method: 'GET' }, true),

  adminCreateCustomer: (payload: {
    firstName: string;
    middleName?: string;
    lastName: string;
    email: string;
    username: string;
    phone: string;
    password: string;
    country?: string;
    residentialAddress?: string;
    dateOfBirth?: string;
    accountNumber?: string;
    status?: 'active' | 'pending_approval';
    initialBalance?: number;
  }) =>
    request<{ success: boolean; message: string; user: User }>('/api/admin/customers', {
      method: 'POST',
      body: JSON.stringify(payload),
    }, true),

  approveCustomer: (
    customerId: string,
    initialBalance = 0,
    options?: { accountNumber?: string; username?: string }
  ) =>
    request<{ success: boolean; message: string; user: User }>(`/api/admin/customers/${customerId}/approve`, {
      method: 'POST',
      body: JSON.stringify({
        initialBalance,
        ...(options?.accountNumber ? { accountNumber: options.accountNumber } : {}),
        ...(options?.username ? { username: options.username } : {}),
      }),
    }, true),

  rejectCustomer: (customerId: string, reason?: string) =>
    request<{ success: boolean; message: string; user: User }>(`/api/admin/customers/${customerId}/reject`, {
      method: 'POST',
      body: JSON.stringify({ reason }),
    }, true),

  setCustomerStatus: (customerId: string, status: 'active' | 'frozen' | 'suspended') =>
    request<{ success: boolean; message: string; user: User }>(`/api/admin/customers/${customerId}/status`, {
      method: 'POST',
      body: JSON.stringify({ status }),
    }, true),

  updateCustomerProfile: (
    customerId: string,
    profile: {
      firstName?: string;
      middleName?: string;
      lastName?: string;
      fullName?: string;
      email?: string;
      phone?: string;
      username?: string;
      accountNumber?: string;
      sortCode?: string;
      country?: string;
      state?: string;
      residentialAddress?: string;
      postalCode?: string;
      dateOfBirth?: string;
      kycStatus?: 'unverified' | 'pending' | 'pending_review' | 'verified' | 'rejected';
    }
  ) =>
    request<{ success: boolean; user: User }>(`/api/admin/customers/${customerId}/profile`, {
      method: 'PUT',
      body: JSON.stringify(profile),
    }, true),

  adminResetCustomerPassword: (customerId: string, newPassword: string) =>
    request<{ success: boolean; message: string; user: User }>(`/api/admin/customers/${customerId}/reset-password`, {
      method: 'POST',
      body: JSON.stringify({ newPassword }),
    }, true),

  adminDeleteCustomer: (customerId: string) =>
    request<{ success: boolean; message: string }>(`/api/admin/customers/${customerId}`, {
      method: 'DELETE',
      body: JSON.stringify({ confirmDelete: 'DELETE' }),
    }, true),

  getAdminBackups: () =>
    request<{
      backups: Array<{
        id: string;
        createdAt: string;
        createdBy: string;
        customerCount: number;
        transactionCount: number;
        reason?: string;
      }>;
    }>('/api/admin/backups', { method: 'GET' }, true),

  createAdminBackup: (reason?: string) =>
    request<{
      success: boolean;
      backup: {
        id: string;
        createdAt: string;
        createdBy: string;
        customerCount: number;
        transactionCount: number;
        reason?: string;
      };
    }>('/api/admin/backups', {
      method: 'POST',
      body: JSON.stringify({ reason }),
    }, true),

  exportAdminBackup: () =>
    request<any>('/api/admin/backups/export', { method: 'GET' }, true),

  adminCreditDebit: (payload: { customerId: string; type: 'credit' | 'debit'; amount: number; description: string; reference?: string }) =>
    request<{ success: boolean; message: string; transaction: Transaction }>('/api/admin/accounts/credit-debit', {
      method: 'POST',
      body: JSON.stringify(payload),
    }, true),

  getAdminLedger: (filters?: { userId?: string; type?: string; status?: string }) => {
    const params = new URLSearchParams(filters as any).toString();
    return request<{ ledger: Transaction[] }>(`/api/admin/ledger?${params}`, { method: 'GET' }, true);
  },

  adminReversal: (transactionId: string) =>
    request<{ success: boolean; message: string; transaction: Transaction }>(`/api/admin/transactions/${transactionId}/reversal`, {
      method: 'POST',
    }, true),

  getAdminAuditLogs: () => request<{ auditLogs: AuditLog[] }>('/api/admin/audit-logs', { method: 'GET' }, true),
};

