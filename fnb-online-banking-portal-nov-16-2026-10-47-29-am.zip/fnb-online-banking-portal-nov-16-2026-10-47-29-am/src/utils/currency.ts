/**
 * Consistent USD ($) currency normalization and formatting utilities.
 * Ensures legacy records carrying '£' or 'GBP' render cleanly in USD ($)
 * without altering underlying stored transaction/balance numeric values.
 */

export const USD_SYMBOL = '$';
export const USD_CODE = 'USD';

export function normalizeCurrencySymbol(_currency?: string): string {
  return USD_SYMBOL;
}

export function formatUsdNumber(amount: number): string {
  const numeric = Number(amount || 0);
  return numeric.toLocaleString('en-US', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
}

export function formatUsdAmount(amount: number, includeCode = false): string {
  const formatted = `${USD_SYMBOL}${formatUsdNumber(amount)}`;
  return includeCode ? `${formatted} ${USD_CODE}` : formatted;
}

export function formatUsdSigned(amount: number, isCredit: boolean): string {
  return `${isCredit ? '+' : '-'}${USD_SYMBOL}${formatUsdNumber(Math.abs(amount))}`;
}
