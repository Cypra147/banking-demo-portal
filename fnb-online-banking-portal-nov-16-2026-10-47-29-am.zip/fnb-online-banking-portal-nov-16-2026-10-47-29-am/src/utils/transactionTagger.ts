// Pure client-and-server-safe automatic transaction tagging logic

export interface TagRule {
  tag: string;
  category: string;
  keywords: string[];
  badgeColor: {
    bg: string;
    text: string;
    border: string;
    dot: string;
  };
}

export const TRANSACTION_TAG_RULES: TagRule[] = [
  {
    tag: 'Groceries',
    category: 'Groceries',
    keywords: [
      'grocery', 'groceries', 'supermarket', 'tesco', 'sainsbury', 'asda', 
      'waitrose', 'aldi', 'lidl', 'marks & spencer', 'm&s', 'whole foods', 
      'organic', 'fresh market', 'produce', 'bakery', 'butcher', 'food store', 
      'trader joe', 'costco', 'safeway', 'kroger', 'convenience store'
    ],
    badgeColor: {
      bg: 'bg-emerald-50 dark:bg-emerald-950/50',
      text: 'text-emerald-700 dark:text-emerald-300',
      border: 'border-emerald-200 dark:border-emerald-800',
      dot: 'bg-emerald-500'
    }
  },
  {
    tag: 'Utilities',
    category: 'Utilities',
    keywords: [
      'utility', 'utilities', 'electric', 'electricity', 'gas', 'water', 
      'power', 'energy', 'british gas', 'edf', 'e.on', 'thames water', 
      'council tax', 'broadband', 'internet', 'wifi', 'telecom', 'phone bill', 
      'mobile bill', 'ee telecom', 'vodafone', 'o2', 'three', 'virgin media',
      'refuse', 'waste', 'heating', 'bill payment'
    ],
    badgeColor: {
      bg: 'bg-amber-50 dark:bg-amber-950/50',
      text: 'text-amber-700 dark:text-amber-300',
      border: 'border-amber-200 dark:border-amber-800',
      dot: 'bg-amber-500'
    }
  },
  {
    tag: 'Entertainment',
    category: 'Entertainment',
    keywords: [
      'entertainment', 'netflix', 'spotify', 'disney', 'hulu', 'cinema', 
      'movie', 'theatre', 'theater', 'concert', 'ticket', 'youtube', 
      'playstation', 'xbox', 'steam', 'nintendo', 'gaming', 'apple tv', 
      'prime video', 'amusement', 'music', 'game', 'show', 'audible', 
      'subscription'
    ],
    badgeColor: {
      bg: 'bg-purple-50 dark:bg-purple-950/50',
      text: 'text-purple-700 dark:text-purple-300',
      border: 'border-purple-200 dark:border-purple-800',
      dot: 'bg-purple-500'
    }
  },
  {
    tag: 'Dining & Food',
    category: 'Dining & Food',
    keywords: [
      'dining', 'restaurant', 'cafe', 'coffee', 'starbucks', 'costa', 
      'mcdonald', 'kfc', 'burger', 'pizza', 'nando', 'subway', 'bistro', 
      'pub', 'bar', 'deliveroo', 'uber eats', 'just eat', 'takeaway', 
      'lunch', 'dinner', 'breakfast', 'sushi', 'pret a manger', 'deli'
    ],
    badgeColor: {
      bg: 'bg-orange-50 dark:bg-orange-950/50',
      text: 'text-orange-700 dark:text-orange-300',
      border: 'border-orange-200 dark:border-orange-800',
      dot: 'bg-orange-500'
    }
  },
  {
    tag: 'Shopping & Retail',
    category: 'Shopping & Retail',
    keywords: [
      'shopping', 'retail', 'amazon', 'ebay', 'clothing', 'apparel', 
      'shoes', 'zara', 'h&m', 'nike', 'adidas', 'apple store', 'electronics', 
      'mall', 'boutique', 'fashion', 'department store', 'currys', 'argos', 
      'asos', 'ikea', 'furniture', 'hardware'
    ],
    badgeColor: {
      bg: 'bg-blue-50 dark:bg-blue-950/50',
      text: 'text-blue-700 dark:text-blue-300',
      border: 'border-blue-200 dark:border-blue-800',
      dot: 'bg-blue-500'
    }
  },
  {
    tag: 'Travel & Transport',
    category: 'Travel & Transport',
    keywords: [
      'travel', 'transport', 'flight', 'airline', 'train', 'rail', 
      'underground', 'subway', 'tube', 'bus', 'tfl', 'uber', 'taxi', 
      'cab', 'lyft', 'petrol', 'fuel', 'diesel', 'gas station', 'shell', 
      'bp', 'parking', 'hotel', 'airbnb', 'booking.com', 'easyjet', 
      'ryanair', 'british airways', 'eurostar', 'commute', 'toll'
    ],
    badgeColor: {
      bg: 'bg-sky-50 dark:bg-sky-950/50',
      text: 'text-sky-700 dark:text-sky-300',
      border: 'border-sky-200 dark:border-sky-800',
      dot: 'bg-sky-500'
    }
  },
  {
    tag: 'Health & Wellness',
    category: 'Health & Wellness',
    keywords: [
      'health', 'wellness', 'pharmacy', 'chemist', 'boots', 'doctor', 
      'hospital', 'dental', 'dentist', 'gym', 'fitness', 'spa', 'clinic', 
      'optician', 'medical', 'prescription', 'puregym', 'care', 'therapy'
    ],
    badgeColor: {
      bg: 'bg-teal-50 dark:bg-teal-950/50',
      text: 'text-teal-700 dark:text-teal-300',
      border: 'border-teal-200 dark:border-teal-800',
      dot: 'bg-teal-500'
    }
  },
  {
    tag: 'Salary & Income',
    category: 'Salary & Income',
    keywords: [
      'salary', 'payroll', 'wage', 'income', 'dividend', 'bonus', 
      'interest', 'stipend', 'compensation', 'pension', 'opening credit', 
      'initial credit', 'initial sandbox', 'credit deposit', 'paycheck'
    ],
    badgeColor: {
      bg: 'bg-emerald-100 dark:bg-emerald-900/60',
      text: 'text-emerald-800 dark:text-emerald-200',
      border: 'border-emerald-300 dark:border-emerald-700',
      dot: 'bg-emerald-600'
    }
  },
  {
    tag: 'Investments',
    category: 'Investments',
    keywords: [
      'investment', 'invest', 'treasury', 'bond', 'stock', 'shares', 
      'portfolio', 'wealth', 'fund', 'asset', 'term deposit', 'fixed income', 
      'crypto', 'dividend reinvest'
    ],
    badgeColor: {
      bg: 'bg-indigo-50 dark:bg-indigo-950/50',
      text: 'text-indigo-700 dark:text-indigo-300',
      border: 'border-indigo-200 dark:border-indigo-800',
      dot: 'bg-indigo-500'
    }
  },
  {
    tag: 'Transfers & Remittance',
    category: 'Transfers & Remittance',
    keywords: [
      'transfer', 'wire', 'remittance', 'payment to', 'sent to', 
      'received from', 'p2p', 'reversal', 'refund', 'money transfer', 
      'faster payment', 'bacs', 'chaps', 'sepa', 'iban'
    ],
    badgeColor: {
      bg: 'bg-slate-100 dark:bg-slate-800/80',
      text: 'text-slate-700 dark:text-slate-300',
      border: 'border-slate-300 dark:border-slate-700',
      dot: 'bg-slate-500'
    }
  }
];

export const FALLBACK_TAG_RULE: TagRule = {
  tag: 'General',
  category: 'General',
  keywords: [],
  badgeColor: {
    bg: 'bg-slate-100 dark:bg-slate-800',
    text: 'text-slate-600 dark:text-slate-400',
    border: 'border-slate-200 dark:border-slate-700',
    dot: 'bg-slate-400'
  }
};

/**
 * Automatically tags a transaction using keyword-matching logic on description,
 * biller category, and transaction type.
 */
export function tagTransaction(
  description: string = '', 
  type: string = '', 
  billerCategory: string = ''
): { tag: string; tags: string[]; category: string } {
  const text = `${description} ${billerCategory} ${type}`.toLowerCase();
  
  // 1. Direct keyword search across defined tag rules
  for (const rule of TRANSACTION_TAG_RULES) {
    for (const keyword of rule.keywords) {
      if (text.includes(keyword)) {
        return {
          tag: rule.tag,
          tags: [rule.tag],
          category: rule.category
        };
      }
    }
  }

  // 2. Transaction type fallback logic
  if (type === 'bill_payment') {
    return { tag: 'Utilities', tags: ['Utilities'], category: 'Utilities' };
  }
  if (type === 'credit') {
    return { tag: 'Salary & Income', tags: ['Salary & Income'], category: 'Salary & Income' };
  }
  if (type === 'reversal') {
    return { tag: 'Transfers & Remittance', tags: ['Transfers & Remittance', 'Reversal'], category: 'Transfers & Remittance' };
  }
  if (type === 'transfer' || type === 'debit') {
    return { tag: 'Transfers & Remittance', tags: ['Transfers & Remittance'], category: 'Transfers & Remittance' };
  }

  return {
    tag: FALLBACK_TAG_RULE.tag,
    tags: [FALLBACK_TAG_RULE.tag],
    category: FALLBACK_TAG_RULE.category
  };
}

/**
 * Retrieves the visual badge styling for a given tag.
 */
export function getTagBadgeStyle(tag: string) {
  const match = TRANSACTION_TAG_RULES.find(
    r => r.tag.toLowerCase() === (tag || '').toLowerCase()
  );
  return match ? match.badgeColor : FALLBACK_TAG_RULE.badgeColor;
}

export const AVAILABLE_TRANSACTION_TAGS = [
  'All',
  'Groceries',
  'Utilities',
  'Entertainment',
  'Dining & Food',
  'Shopping & Retail',
  'Travel & Transport',
  'Health & Wellness',
  'Salary & Income',
  'Investments',
  'Transfers & Remittance',
  'General'
] as const;
