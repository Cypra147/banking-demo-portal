import React, { createContext, useContext, useState, useEffect } from 'react';

export type LanguageCode = 'en' | 'fr' | 'es' | 'de' | 'ar';

export interface LanguageOption {
  code: LanguageCode;
  name: string;
  flag: string;
  region: string;
  dir?: 'ltr' | 'rtl';
}

export const SUPPORTED_LANGUAGES: LanguageOption[] = [
  { code: 'en', name: 'English', flag: '🇬🇧', region: 'UK & Global', dir: 'ltr' },
  { code: 'fr', name: 'Français', flag: '🇫🇷', region: 'Europe & Afrique', dir: 'ltr' },
  { code: 'es', name: 'Español', flag: '🇪🇸', region: 'España & América Latina', dir: 'ltr' },
  { code: 'de', name: 'Deutsch', flag: '🇩🇪', region: 'Deutschland & DACH', dir: 'ltr' },
  { code: 'ar', name: 'العربية', flag: '🇦🇪', region: 'الشرق الأوسط والخليج', dir: 'rtl' },
];

const TRANSLATIONS: Record<LanguageCode, Record<string, string>> = {
  en: {
    // Navigation
    'nav.home': 'Home',
    'nav.about': 'About Us',
    'nav.services': 'Services',
    'nav.investments': 'Investments',
    'nav.verification': 'Verification',
    'nav.transactions': 'Transactions',
    'nav.support': 'Support',
    'nav.signIn': 'Sign In',
    'nav.register': 'Register',
    'nav.myDashboard': 'My Dashboard',
    'nav.logout': 'Logout',
    'nav.helpBanner': '24/7 Telephone Helpline & Electronic Banking',

    // Hero Section
    'hero.badge': 'SECURE • RELIABLE • GLOBAL',
    'hero.titleLine1': 'Banking for a',
    'hero.titleLine2': 'Brighter Tomorrow.',
    'hero.description': 'At FNB, we’re more than just a bank. We’re your partner in progress — helping you achieve your personal and business financial aspirations, today and always.',
    'hero.openAccount': 'Open An Account',
    'hero.signIn': 'Sign In to Online Banking',
    'hero.encryptedMetric': '256-Bit',
    'hero.encryptedDesc': 'Encrypted Banking',
    'hero.instantMetric': 'Instant',
    'hero.instantDesc': 'Electronic Transfers',
    'hero.helplineMetric': '24 / 7',
    'hero.helplineDesc': 'Customer Helpline',
    'hero.cardTag': 'Your goals. Our priority.',
    'hero.cardSub': 'First National Bank Premier Network',

    // Services grid
    'features.tag': 'BANKING CAPABILITIES',
    'features.heading': 'Modern Banking Services for Everyday Life',
    'features.subheading': 'Engineered with advanced financial technology, robust security safeguards, and seamless cross-device compatibility.',
    'features.transfersTitle': 'Domestic & International Transfers',
    'features.transfersDesc': 'Send funds to any beneficiary with validated sort codes and account numbers. Complete with rapid processing, cryptographic reference tags, and instant downloadable receipts.',
    'features.cardsTitle': 'Virtual Visa & Mastercard Cards',
    'features.cardsDesc': 'Instantly provision debit cards with customizable daily limits, one-tap freeze/unfreeze controls, and dynamic CVV security.',
    'features.billsTitle': 'Utility Bill Payments & Top-Ups',
    'features.billsDesc': 'Pay electricity, internet broadband, airtime, and mobile data packages directly from your account balance with official receipts.',
    'features.otpTitle': 'Multi-Factor OTP Authentication',
    'features.otpDesc': 'Secure registration and banking access protected by 6-digit email OTP verification, server-side password hashing, and administrative review.',
    'features.crossDeviceTitle': 'Cross-Device Experience',
    'features.crossDeviceDesc': 'Fully responsive layout engineered to perform smoothly across iOS, Android, tablets, and desktop computers.',
    'features.statementsTitle': 'Certified Account Statements',
    'features.statementsDesc': 'Generate official printable account statements and CSV records complete with Sort Code 20-04-15 and transaction references.',
    'features.exploreTransfers': 'Explore Transfers',
    'features.viewCards': 'View Card Solutions',
    'features.learnMore': 'Learn More',
    'features.securityStandards': 'Security Standards',
    'features.aboutPlatform': 'About Our Platform',
    'features.generateStatements': 'Generate Statements',

    // Language Toggle
    'lang.selectTitle': 'Select Region & Language',
    'lang.switchSuccess': 'Language updated',
  },

  fr: {
    // Navigation
    'nav.home': 'Accueil',
    'nav.about': 'À propos',
    'nav.services': 'Services',
    'nav.investments': 'Investissements',
    'nav.verification': 'Vérification',
    'nav.transactions': 'Transactions',
    'nav.support': 'Assistance',
    'nav.signIn': 'Connexion',
    'nav.register': 'S’inscrire',
    'nav.myDashboard': 'Mon Tableau de Bord',
    'nav.logout': 'Déconnexion',
    'nav.helpBanner': 'Ligne d’assistance 24h/24 et Services Bancaires Électroniques',

    // Hero Section
    'hero.badge': 'SÉCURISÉ • FIABLE • MONDIAL',
    'hero.titleLine1': 'Une Banque pour un',
    'hero.titleLine2': 'Avenir Plus Lumineux.',
    'hero.description': 'Chez FNB, nous sommes bien plus qu’une banque. Nous sommes votre partenaire de confiance — vous accompagnant vers vos ambitions financières personnelles et professionnelles.',
    'hero.openAccount': 'Ouvrir un Compte',
    'hero.signIn': 'Accéder à vos Comptes',
    'hero.encryptedMetric': '256-Bits',
    'hero.encryptedDesc': 'Chiffrement Bancaire',
    'hero.instantMetric': 'Instantané',
    'hero.instantDesc': 'Virements Électroniques',
    'hero.helplineMetric': '24h / 7j',
    'hero.helplineDesc': 'Ligne Client Dédiée',
    'hero.cardTag': 'Vos objectifs. Notre priorité.',
    'hero.cardSub': 'Réseau Premier First National Bank',

    // Services grid
    'features.tag': 'SERVICES BANCAIRES D’EXCELLENCE',
    'features.heading': 'Des Solutions Bancaires Modernes au Quotidien',
    'features.subheading': 'Conçu avec des technologies financières de pointe, des protocoles de sécurité robustes et une fluidité multi-écrans.',
    'features.transfersTitle': 'Virements Nationaux & Internationaux',
    'features.transfersDesc': 'Transférez des fonds vers tout bénéficiaire avec validation instantanée des codes bancaires et reçus officiels téléchargeables.',
    'features.cardsTitle': 'Cartes Virtuelles Visa & Mastercard',
    'features.cardsDesc': 'Émettez instantanément des cartes de débit avec plafonds personnalisables et blocage/déblocage en un clic.',
    'features.billsTitle': 'Paiement de Factures & Recharges',
    'features.billsDesc': 'Réglez vos factures d’énergie, abonnements internet et recharges mobiles directement depuis votre solde avec reçu certifié.',
    'features.otpTitle': 'Authentification OTP Multi-Facteurs',
    'features.otpDesc': 'Enregistrement et transactions protégés par code OTP sécurisé à 6 chiffres et chiffrement cryptographique de niveau institutionnel.',
    'features.crossDeviceTitle': 'Expérience Multi-Écrans',
    'features.crossDeviceDesc': 'Interface fluide et intuitive conçue pour fonctionner avec une réactivité totale sur smartphone, tablette et ordinateur.',
    'features.statementsTitle': 'Relevés de Compte Certifiés',
    'features.statementsDesc': 'Générez des relevés officiels imprimables et des exports comptables intégrant le code guichet 20-04-15 et les références cryptées.',
    'features.exploreTransfers': 'Explorer les Virements',
    'features.viewCards': 'Découvrir les Cartes',
    'features.learnMore': 'En Savoir Plus',
    'features.securityStandards': 'Normes de Sécurité',
    'features.aboutPlatform': 'Notre Plateforme',
    'features.generateStatements': 'Générer un Relevé',

    // Language Toggle
    'lang.selectTitle': 'Choisir la Région & la Langue',
    'lang.switchSuccess': 'Langue mise à jour',
  },

  es: {
    // Navigation
    'nav.home': 'Inicio',
    'nav.about': 'Nosotros',
    'nav.services': 'Servicios',
    'nav.investments': 'Inversiones',
    'nav.verification': 'Verificación',
    'nav.transactions': 'Transacciones',
    'nav.support': 'Soporte',
    'nav.signIn': 'Iniciar Sesión',
    'nav.register': 'Registrarse',
    'nav.myDashboard': 'Mi Panel',
    'nav.logout': 'Cerrar Sesión',
    'nav.helpBanner': 'Línea Telefónica 24/7 y Banca Electrónica',

    // Hero Section
    'hero.badge': 'SEGURO • CONFIABLE • GLOBAL',
    'hero.titleLine1': 'Banca para un',
    'hero.titleLine2': 'Futuro Más Brillante.',
    'hero.description': 'En FNB, somos más que un banco. Somos su aliado en el progreso: ayudándole a alcanzar sus aspiraciones financieras personales y empresariales, hoy y siempre.',
    'hero.openAccount': 'Abrir una Cuenta',
    'hero.signIn': 'Banca por Internet',
    'hero.encryptedMetric': '256-Bits',
    'hero.encryptedDesc': 'Banca Encriptada',
    'hero.instantMetric': 'Instantáneo',
    'hero.instantDesc': 'Transferencias Electrónicas',
    'hero.helplineMetric': '24 / 7',
    'hero.helplineDesc': 'Atención al Cliente',
    'hero.cardTag': 'Sus metas. Nuestra prioridad.',
    'hero.cardSub': 'Red Premier First National Bank',

    // Services grid
    'features.tag': 'CAPACIDADES BANCARIAS',
    'features.heading': 'Servicios Bancarios Modernos para el Día a Día',
    'features.subheading': 'Diseñado con tecnología financiera avanzada, estrictos estándares de seguridad y compatibilidad multiplataforma.',
    'features.transfersTitle': 'Transferencias Nacionales e Internacionales',
    'features.transfersDesc': 'Envíe fondos a cualquier beneficiario con validación de códigos bancarios y recibos digitales oficiales descargables.',
    'features.cardsTitle': 'Tarjetas Virtuales Visa y Mastercard',
    'features.cardsDesc': 'Emita tarjetas de débito al instante con límites personalizables y bloqueo/desbloqueo inmediato en un solo toque.',
    'features.billsTitle': 'Pago de Servicios y Recargas',
    'features.billsDesc': 'Pague electricidad, internet, paquetes de telefonía móvil directamente desde su cuenta con comprobante oficial.',
    'features.otpTitle': 'Autenticación OTP Multi-Factor',
    'features.otpDesc': 'Registro y acceso bancario protegidos por código OTP de 6 dígitos enviado a su correo y encriptación de nivel bancario.',
    'features.crossDeviceTitle': 'Experiencia Multiplataforma',
    'features.crossDeviceDesc': 'Diseño ultra-responsivo optimizado para una navegación fluida en iPhone, Android, tabletas y ordenadores.',
    'features.statementsTitle': 'Extractos Bancarios Certificados',
    'features.statementsDesc': 'Genere extractos oficiales imprimibles y archivos CSV con código de sucursal 20-04-15 y referencias verificadas.',
    'features.exploreTransfers': 'Explorar Transferencias',
    'features.viewCards': 'Ver Soluciones de Tarjetas',
    'features.learnMore': 'Más Información',
    'features.securityStandards': 'Estándares de Seguridad',
    'features.aboutPlatform': 'Sobre la Plataforma',
    'features.generateStatements': 'Generar Extractos',

    // Language Toggle
    'lang.selectTitle': 'Seleccionar Región e Idioma',
    'lang.switchSuccess': 'Idioma actualizado',
  },

  de: {
    // Navigation
    'nav.home': 'Startseite',
    'nav.about': 'Über Uns',
    'nav.services': 'Dienstleistungen',
    'nav.investments': 'Investitionen',
    'nav.verification': 'Verifizierung',
    'nav.transactions': 'Transaktionen',
    'nav.support': 'Kundendienst',
    'nav.signIn': 'Anmelden',
    'nav.register': 'Registrieren',
    'nav.myDashboard': 'Mein Dashboard',
    'nav.logout': 'Abmelden',
    'nav.helpBanner': '24/7 Telefon-Helpline & Elektronisches Banking',

    // Hero Section
    'hero.badge': 'SICHER • ZUVERLÄSSIG • GLOBAL',
    'hero.titleLine1': 'Banking für eine',
    'hero.titleLine2': 'Hellere Zukunft.',
    'hero.description': 'Bei der FNB sind wir mehr als nur eine Bank. Wir sind Ihr Partner für Fortschritt – damit Sie Ihre persönlichen und geschäftlichen Finanzziele heute und morgen erreichen.',
    'hero.openAccount': 'Konto Eröffnen',
    'hero.signIn': 'Zum Online-Banking',
    'hero.encryptedMetric': '256-Bit',
    'hero.encryptedDesc': 'Verschlüsseltes Banking',
    'hero.instantMetric': 'Sofort',
    'hero.instantDesc': 'Elektronische Überweisungen',
    'hero.helplineMetric': '24 / 7',
    'hero.helplineDesc': 'Kunden-Helpline',
    'hero.cardTag': 'Ihre Ziele. Unsere Priorität.',
    'hero.cardSub': 'First National Bank Premier Netzwerk',

    // Services grid
    'features.tag': 'BANKING-KAPAZITÄTEN',
    'features.heading': 'Moderne Bankdienstleistungen für den Alltag',
    'features.subheading': 'Entwickelt mit fortschrittlicher Finanztechnologie, robusten Sicherheitsstandards und reibungsloser Gerätekompatibilität.',
    'features.transfersTitle': 'Inlands- & Auslandsüberweisungen',
    'features.transfersDesc': 'Überweisen Sie Geld an beliebige Empfänger mit geprüften Bankleitzahlen und sofortigen offiziellen digitalen Belegen.',
    'features.cardsTitle': 'Virtuelle Visa- & Mastercard-Karten',
    'features.cardsDesc': 'Erstellen Sie sofort Debitkarten mit flexiblen Tageslimits und One-Touch-Karten-Sperrung.',
    'features.billsTitle': 'Rechnungsbegleichung & Guthaben',
    'features.billsDesc': 'Bezahlen Sie Strom, Breitband-Internet und Mobilfunkpakete direkt von Ihrem Kontostand mit Bestätigungsbeleg.',
    'features.otpTitle': 'Multi-Faktor-OTP-Authentifizierung',
    'features.otpDesc': 'Sichere Registrierung und Kontozugriffe, geschützt durch 6-stelligen E-Mail-OTP-Code und serverseitiges Hashing.',
    'features.crossDeviceTitle': 'Geräteübergreifendes Erlebnis',
    'features.crossDeviceDesc': 'Vollständig responsives Design, das auf Smartphones, Tablets und PCs Höchstleistung bietet.',
    'features.statementsTitle': 'Zertifizierte Kontoauszüge',
    'features.statementsDesc': 'Erstellen Sie offizielle druckbare Kontoauszüge mit Sort Code 20-04-15 und Transaktionsreferenzen.',
    'features.exploreTransfers': 'Überweisungen Entdecken',
    'features.viewCards': 'Kartenlösungen Ansehen',
    'features.learnMore': 'Mehr Erfahren',
    'features.securityStandards': 'Sicherheitsstandards',
    'features.aboutPlatform': 'Über Unsere Plattform',
    'features.generateStatements': 'Auszug Erstellen',

    // Language Toggle
    'lang.selectTitle': 'Region & Sprache Wählen',
    'lang.switchSuccess': 'Sprache aktualisiert',
  },

  ar: {
    // Navigation
    'nav.home': 'الرئيسية',
    'nav.about': 'من نحن',
    'nav.services': 'الخدمات',
    'nav.investments': 'الاستثمارات',
    'nav.verification': 'التحقق',
    'nav.transactions': 'المعاملات',
    'nav.support': 'الدعم الفني',
    'nav.signIn': 'تسجيل الدخول',
    'nav.register': 'فتح حساب جديد',
    'nav.myDashboard': 'لوحة التحكم',
    'nav.logout': 'تسجيل الخروج',
    'nav.helpBanner': 'خط مساعدة هاتفي على مدار 24/7 وخدمات مصرفية إلكترونية',

    // Hero Section
    'hero.badge': 'آمن • موثوق • عالمي',
    'hero.titleLine1': 'خدمات مصرفية من أجل',
    'hero.titleLine2': 'مستقبل أكثر إشراقاً.',
    'hero.description': 'في FNB، نحن شريكك في التقدم والنجاح — نساعدك على تحقيق تطلعاتك المالية الشخصية والتجارية اليوم ودائماً.',
    'hero.openAccount': 'افتح حسابك الآن',
    'hero.signIn': 'الدخول للخدمات المصرفية',
    'hero.encryptedMetric': '256 بت',
    'hero.encryptedDesc': 'تشفير مصرفي متقدم',
    'hero.instantMetric': 'فوري',
    'hero.instantDesc': 'تحويلات إلكترونية سريعة',
    'hero.helplineMetric': '24 / 7',
    'hero.helplineDesc': 'دعم عملاء مستمر',
    'hero.cardTag': 'أهدافك. أولويتنا.',
    'hero.cardSub': 'شبكة بنك فيرست ناشيونال المتميزة',

    // Services grid
    'features.tag': 'إمكانيات مصرفية عالمية',
    'features.heading': 'خدمات مصرفية حديثة لحياتك اليومية',
    'features.subheading': 'مصممة بأحدث التقنيات المالية وأنظمة الأمان المصرفي لضمان تجربة سلسة على جميع الأجهزة.',
    'features.transfersTitle': 'تحويلات محلية ودولية',
    'features.transfersDesc': 'أرسل الأموال إلى أي مستفيد مع التحقق الفوري من الحسابات وإيصالات رقمية قابلة للتنزيل.',
    'features.cardsTitle': 'بطاقات فيزا وماستركارد الافتراضية',
    'features.cardsDesc': 'إصدار فوري لبطاقات الخصم مع حدود إنفاق قابلة للتخصيص وميزة التجميد السريع بنقرة واحدة.',
    'features.billsTitle': 'سداد الفواتير وشحن الرصيد',
    'features.billsDesc': 'سدد فواتير الكهرباء والإنترنت وباقات الهاتف مباشرة من رصيد حسابك مع إيصالات رسمية.',
    'features.otpTitle': 'التحقق متعدد العوامل برمز OTP',
    'features.otpDesc': 'تسجيل ودخول مصرفي محمي برمز تحقق من 6 أرقام وتشفير تشفيري على مستوى البنوك المركزية.',
    'features.crossDeviceTitle': 'تجربة متكاملة عبر كافة الأجهزة',
    'features.crossDeviceDesc': 'تصميم متجاوب بالكامل وسريع الاستجابة على الهواتف والأجهزة اللوحية وأجهزة الكمبيوتر.',
    'features.statementsTitle': 'كشوف حساب معتمدة',
    'features.statementsDesc': 'إصدار كشوف حساب مصرفية قابلة للطباعة تتضمن رمز الفرع 20-04-15 والمراجع الرسمية.',
    'features.exploreTransfers': 'استكشف التحويلات',
    'features.viewCards': 'حلول البطاقات',
    'features.learnMore': 'اعرف المزيد',
    'features.securityStandards': 'معايير الأمان',
    'features.aboutPlatform': 'عن منصتنا',
    'features.generateStatements': 'إصدار كشف حساب',

    // Language Toggle
    'lang.selectTitle': 'اختر المنطقة واللغة',
    'lang.switchSuccess': 'تم تحديث اللغة بنجاح',
  },
};

interface LanguageContextType {
  currentLanguage: LanguageCode;
  selectedOption: LanguageOption;
  setLanguage: (lang: LanguageCode) => void;
  t: (key: string, fallback?: string) => string;
  supportedLanguages: LanguageOption[];
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentLanguage, setCurrentLanguage] = useState<LanguageCode>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('fnb_language') as LanguageCode;
      if (saved && TRANSLATIONS[saved]) {
        return saved;
      }
    }
    return 'en';
  });

  const selectedOption = SUPPORTED_LANGUAGES.find(l => l.code === currentLanguage) || SUPPORTED_LANGUAGES[0];

  const setLanguage = (code: LanguageCode) => {
    if (TRANSLATIONS[code]) {
      setCurrentLanguage(code);
      localStorage.setItem('fnb_language', code);
      // Update HTML lang and dir attributes
      document.documentElement.lang = code;
      const option = SUPPORTED_LANGUAGES.find(l => l.code === code);
      document.documentElement.dir = option?.dir || 'ltr';
    }
  };

  useEffect(() => {
    document.documentElement.lang = currentLanguage;
    document.documentElement.dir = selectedOption.dir || 'ltr';
  }, [currentLanguage, selectedOption.dir]);

  const t = (key: string, fallback?: string): string => {
    const langDict = TRANSLATIONS[currentLanguage];
    if (langDict && langDict[key]) {
      return langDict[key];
    }
    // Fallback to English
    if (TRANSLATIONS.en[key]) {
      return TRANSLATIONS.en[key];
    }
    return fallback || key;
  };

  return (
    <LanguageContext.Provider
      value={{
        currentLanguage,
        selectedOption,
        setLanguage,
        t,
        supportedLanguages: SUPPORTED_LANGUAGES,
      }}
    >
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = (): LanguageContextType => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};
