import React, { createContext, useContext, useState, useEffect, useCallback, useRef } from 'react';
import { User, EmailMessage } from '../types.ts';
import {
  api,
  clearSessionToken,
  setSessionToken,
  getSessionToken,
  sendCustomerPageCloseBeacon,
} from '../services/api.ts';

const PORTAL_KEY = 'fnb_active_portal';
const CUSTOMER_LAST_ACTIVITY_KEY = 'fnb_customer_last_activity';
const CUSTOMER_IDLE_TIMEOUT_MS = 10 * 60 * 1000; // 10 minutes

export type CustomerLogoutReason = 'manual' | 'inactivity' | 'expired' | null;

interface AuthContextType {
  user: User | null;
  adminUser: User | null;
  activePortal: 'customer' | 'admin' | 'public';
  setActivePortal: (portal: 'customer' | 'admin' | 'public') => void;
  isLoading: boolean;
  logoutReason: CustomerLogoutReason;
  clearLogoutReason: () => void;
  theme: 'light' | 'dark';
  toggleTheme: () => void;
  // Auth actions
  loginCustomer: (identifier: string, pass: string) => Promise<void>;
  loginAdmin: (pass: string, email: string) => Promise<void>;
  logoutCustomer: (reason?: CustomerLogoutReason) => Promise<void>;
  logoutAdmin: () => Promise<void>;
  logout: () => Promise<void>;
  refreshUser: (forAdmin?: boolean) => Promise<void>;
  // Mail notification center
  emails: EmailMessage[];
  unreadEmailCount: number;
  isMailModalOpen: boolean;
  setIsMailModalOpen: (open: boolean) => void;
  fetchEmails: () => Promise<void>;
  markEmailRead: (id: string) => Promise<void>;
  activeEmailForPreview: EmailMessage | null;
  setActiveEmailForPreview: (email: EmailMessage | null) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [adminUser, setAdminUser] = useState<User | null>(null);
  const [activePortal, setActivePortalState] = useState<'customer' | 'admin' | 'public'>('public');
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [logoutReason, setLogoutReason] = useState<CustomerLogoutReason>(null);
  const [theme, setTheme] = useState<'light' | 'dark'>('light');

  const lastActivityRef = useRef<number>(Date.now());
  const lastServerPingRef = useRef<number>(Date.now());
  const isLoggingOutCustomerRef = useRef<boolean>(false);
  const lastCloseBeaconRef = useRef<number>(0);

  const clearLogoutReason = useCallback(() => {
    setLogoutReason(null);
  }, []);

  const setActivePortal = useCallback((portal: 'customer' | 'admin' | 'public') => {
    setActivePortalState(portal);
    if (portal === 'public') {
      localStorage.removeItem(PORTAL_KEY);
    } else {
      localStorage.setItem(PORTAL_KEY, portal);
    }
  }, []);

  // Emails & notification modal
  const [emails, setEmails] = useState<EmailMessage[]>([]);
  const [isMailModalOpen, setIsMailModalOpen] = useState(false);
  const [activeEmailForPreview, setActiveEmailForPreview] = useState<EmailMessage | null>(null);

  // Load saved theme
  useEffect(() => {
    const savedTheme = localStorage.getItem('fnb_theme') as 'light' | 'dark';
    if (savedTheme) {
      setTheme(savedTheme);
      if (savedTheme === 'dark') {
        document.documentElement.classList.add('dark');
      } else {
        document.documentElement.classList.remove('dark');
      }
    }
  }, []);

  const toggleTheme = () => {
    setTheme(prev => {
      const next = prev === 'light' ? 'dark' : 'light';
      localStorage.setItem('fnb_theme', next);
      if (next === 'dark') {
        document.documentElement.classList.add('dark');
      } else {
        document.documentElement.classList.remove('dark');
      }
      return next;
    });
  };

  const fetchEmails = useCallback(async () => {
    if (!user && !adminUser) {
      setEmails([]);
      return;
    }
    try {
      const isAdmin = activePortal === 'admin' || (!!adminUser && !user);
      const res = await api.getEmails(isAdmin);
      setEmails(res.emails || []);
    } catch {
      // Silently fail if not authenticated
    }
  }, [activePortal, adminUser, user]);

  const markEmailRead = async (id: string) => {
    try {
      await api.markEmailRead(id, activePortal === 'admin');
      setEmails(prev => prev.map(e => e.id === id ? { ...e, read: true } : e));
    } catch (e) {
      console.error(e);
    }
  };

  // Initial session restoration
  useEffect(() => {
    const initAuth = async () => {
      setIsLoading(true);
      const token = getSessionToken(false);
      const adminToken = getSessionToken(true);
      let restoredCustomer: User | null = null;
      let restoredAdmin: User | null = null;

      if (token) {
        const storedLastActivity = Number(sessionStorage.getItem(CUSTOMER_LAST_ACTIVITY_KEY) || 0);
        if (storedLastActivity > 0 && Date.now() - storedLastActivity >= CUSTOMER_IDLE_TIMEOUT_MS) {
          try {
            await api.logout(false);
          } catch {}
          clearSessionToken(false);
          setLogoutReason('inactivity');
        } else {
          try {
            const res = await api.getMe(false);
            if (res.user.role === 'customer') {
              restoredCustomer = res.user;
              const now = Date.now();
              lastActivityRef.current = storedLastActivity > 0 ? storedLastActivity : now;
              lastServerPingRef.current = now;
              if (!storedLastActivity) {
                sessionStorage.setItem(CUSTOMER_LAST_ACTIVITY_KEY, String(now));
              }
              setUser(res.user);
            } else {
              clearSessionToken(false);
            }
          } catch {
            clearSessionToken(false);
          }
        }
      }

      if (adminToken) {
        try {
          const res = await api.getMe(true);
          if (res.user.role === 'admin') {
            restoredAdmin = res.user;
            setAdminUser(res.user);
          } else {
            clearSessionToken(true);
          }
        } catch {
          clearSessionToken(true);
        }
      }

      const savedPortal = localStorage.getItem(PORTAL_KEY);
      if (savedPortal === 'admin' && restoredAdmin) {
        setActivePortalState('admin');
      } else if (savedPortal === 'customer' && restoredCustomer) {
        setActivePortalState('customer');
      } else if (restoredAdmin && !restoredCustomer) {
        setActivePortalState('admin');
      } else if (restoredCustomer && !restoredAdmin) {
        setActivePortalState('customer');
      } else if (restoredAdmin && window.location.pathname.startsWith('/admin')) {
        setActivePortalState('admin');
      } else if (restoredCustomer) {
        setActivePortalState('customer');
      } else {
        setActivePortalState('public');
      }

      setIsLoading(false);
    };

    initAuth();
  }, []);

  // Poll for authenticated emails periodically only when a user or admin is signed in
  useEffect(() => {
    if (!user && !adminUser) {
      setEmails([]);
      return;
    }
    fetchEmails();
    const interval = setInterval(fetchEmails, 5000);
    return () => clearInterval(interval);
  }, [fetchEmails, user, adminUser]);

  const loginCustomer = async (identifier: string, pass: string) => {
    const res = await api.login(identifier, pass);
    const now = Date.now();
    lastActivityRef.current = now;
    lastServerPingRef.current = now;
    isLoggingOutCustomerRef.current = false;
    setLogoutReason(null);
    setSessionToken(res.token, false);
    setUser(res.user);
    setActivePortal('customer');
    await fetchEmails();
  };

  const loginAdmin = async (pass: string, email: string) => {
    const res = await api.adminLogin(pass, email);
    setSessionToken(res.token, true);
    setAdminUser(res.user);
    setActivePortal('admin');
    await fetchEmails();
  };

  const logoutCustomer = useCallback(async (reason: CustomerLogoutReason = 'manual') => {
    if (isLoggingOutCustomerRef.current) return;
    isLoggingOutCustomerRef.current = true;
    try {
      await api.logout(false);
    } catch {
      // Ignore network errors on logout cleanup
    }
    clearSessionToken(false);
    setUser(null);
    setLogoutReason(reason);
    setEmails([]);
    setIsMailModalOpen(false);
    setActiveEmailForPreview(null);
    setActivePortalState(prev => {
      const next = prev === 'admin' && adminUser ? 'admin' : 'public';
      if (next === 'public') localStorage.removeItem(PORTAL_KEY);
      return next;
    });
    isLoggingOutCustomerRef.current = false;
  }, [adminUser]);

  const logoutAdmin = useCallback(async () => {
    try {
      await api.logout(true);
    } catch {
      // Ignore network errors on logout cleanup
    }
    clearSessionToken(true);
    setAdminUser(null);
    setEmails([]);
    setIsMailModalOpen(false);
    setActiveEmailForPreview(null);
    setActivePortal('public');
  }, [setActivePortal]);

  const logout = async () => {
    const isAdmin =
      activePortal === 'admin' ||
      (typeof window !== 'undefined' && window.location.pathname.startsWith('/admin')) ||
      (!!adminUser && !user);
    if (isAdmin) {
      await logoutAdmin();
    } else {
      await logoutCustomer('manual');
    }
  };

  // Customer-only 10-minute inactivity timeout + tab/browser closure auto-logout
  useEffect(() => {
    if (!user) return;

    const storedLast = Number(sessionStorage.getItem(CUSTOMER_LAST_ACTIVITY_KEY) || 0);
    if (storedLast > 0) {
      lastActivityRef.current = storedLast;
    } else {
      const now = Date.now();
      lastActivityRef.current = now;
      sessionStorage.setItem(CUSTOMER_LAST_ACTIVITY_KEY, String(now));
    }

    const checkCustomerSessionHealth = () => {
      const token = getSessionToken(false);
      if (!token) {
        logoutCustomer('expired');
        return false;
      }
      if (Date.now() - lastActivityRef.current >= CUSTOMER_IDLE_TIMEOUT_MS) {
        logoutCustomer('inactivity');
        return false;
      }
      return true;
    };

    const handleUserActivity = () => {
      if (!getSessionToken(false)) {
        logoutCustomer('expired');
        return;
      }
      const now = Date.now();
      // Do not extend a session that has already crossed the 10-minute inactivity threshold (e.g. mobile wake)
      if (now - lastActivityRef.current >= CUSTOMER_IDLE_TIMEOUT_MS) {
        logoutCustomer('inactivity');
        return;
      }
      lastActivityRef.current = now;
      sessionStorage.setItem(CUSTOMER_LAST_ACTIVITY_KEY, String(now));

      if (now - lastServerPingRef.current >= 60 * 1000) {
        lastServerPingRef.current = now;
        api.pingCustomerActivity().catch((err: any) => {
          if (err?.status === 401 || err?.status === 403) {
            logoutCustomer('expired');
          }
        });
      }
    };

    const handleVisibilityOrFocus = () => {
      if (document.visibilityState === 'visible') {
        checkCustomerSessionHealth();
      }
    };

    const handlePageClose = () => {
      const now = Date.now();
      if (now - lastCloseBeaconRef.current < 250) return;
      lastCloseBeaconRef.current = now;
      sendCustomerPageCloseBeacon();
    };

    const activityEvents: Array<keyof WindowEventMap> = [
      'mousemove',
      'mousedown',
      'mouseup',
      'click',
      'keydown',
      'keyup',
      'keypress',
      'scroll',
      'wheel',
      'touchstart',
      'touchmove',
      'touchend',
      'pointerdown',
      'input',
    ];

    activityEvents.forEach(evt => {
      window.addEventListener(evt, handleUserActivity, { passive: true, capture: true });
    });
    document.addEventListener('visibilitychange', handleVisibilityOrFocus);
    window.addEventListener('focus', checkCustomerSessionHealth);
    window.addEventListener('pageshow', checkCustomerSessionHealth);
    window.addEventListener('pagehide', handlePageClose);
    window.addEventListener('beforeunload', handlePageClose);

    const idleInterval = setInterval(checkCustomerSessionHealth, 5000);

    return () => {
      activityEvents.forEach(evt => {
        window.removeEventListener(evt, handleUserActivity, true);
      });
      document.removeEventListener('visibilitychange', handleVisibilityOrFocus);
      window.removeEventListener('focus', checkCustomerSessionHealth);
      window.removeEventListener('pageshow', checkCustomerSessionHealth);
      window.removeEventListener('pagehide', handlePageClose);
      window.removeEventListener('beforeunload', handlePageClose);
      clearInterval(idleInterval);
    };
  }, [user, logoutCustomer]);

  const refreshUser = useCallback(async (forAdmin?: boolean) => {
    const checkAdmin = typeof forAdmin === 'boolean' ? forAdmin : activePortal === 'admin';
    if (checkAdmin && adminUser) {
      try {
        const res = await api.getMe(true);
        setAdminUser(res.user);
      } catch (e: any) {
        if (e?.status === 401 || e?.status === 403) {
          clearSessionToken(true);
          setAdminUser(null);
        }
      }
    } else if (user) {
      try {
        const res = await api.getMe(false);
        setUser(res.user);
      } catch (e: any) {
        if (e?.status === 401 || e?.status === 403) {
          clearSessionToken(false);
          setLogoutReason(prev => prev || 'expired');
          setUser(null);
        }
      }
    }
  }, [activePortal, adminUser, user]);

  const unreadEmailCount = emails.filter(e => !e.read).length;

  return (
    <AuthContext.Provider
      value={{
        user,
        adminUser,
        activePortal,
        setActivePortal,
        isLoading,
        logoutReason,
        clearLogoutReason,
        theme,
        toggleTheme,
        loginCustomer,
        loginAdmin,
        logoutCustomer,
        logoutAdmin,
        logout,
        refreshUser,
        emails,
        unreadEmailCount,
        isMailModalOpen,
        setIsMailModalOpen,
        fetchEmails,
        markEmailRead,
        activeEmailForPreview,
        setActiveEmailForPreview,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
