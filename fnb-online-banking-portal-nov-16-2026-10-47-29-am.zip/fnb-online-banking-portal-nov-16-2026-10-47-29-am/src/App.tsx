/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext.tsx';
import { getSessionToken } from './services/api.ts';
import { LanguageProvider } from './context/LanguageContext.tsx';
import { Navbar } from './components/Navbar.tsx';
import { Footer } from './components/Footer.tsx';
import { HomePage } from './pages/HomePage.tsx';
import { AuthPages } from './pages/AuthPages.tsx';
import { CustomerDashboard } from './pages/CustomerDashboard.tsx';
import { AdminDashboard } from './pages/AdminDashboard.tsx';
import { AdminLoginPage } from './pages/AdminLoginPage.tsx';
import { AboutPage } from './pages/AboutPage.tsx';
import { ServicesPage } from './pages/ServicesPage.tsx';
import { InvestmentsPage } from './pages/InvestmentsPage.tsx';
import { VerificationPage } from './pages/VerificationPage.tsx';
import { TransactionsPage } from './pages/TransactionsPage.tsx';
import { SupportPage } from './pages/SupportPage.tsx';
import { 
  PrivacyPolicyPage, 
  TermsConditionsPage, 
  SecurityCentrePage, 
  FAQPage 
} from './pages/LegalPages.tsx';
import { EmailViewerModal } from './components/EmailViewerModal.tsx';
import { LogOut, ShieldCheck, X } from 'lucide-react';

declare global {
  interface Window {
    Tawk_API?: {
      hideWidget?: () => void;
      showWidget?: () => void;
      minimize?: () => void;
    };
  }
}

const AppContent: React.FC = () => {
  const {
    user,
    adminUser,
    activePortal,
    setActivePortal,
    isLoading,
    logoutReason,
    clearLogoutReason,
    logoutCustomer,
    logoutAdmin,
    refreshUser,
  } = useAuth();

  // URL Route State
  const [currentPath, setCurrentPath] = useState<string>(() => {
    if (typeof window !== 'undefined') {
      return window.location.pathname || '/';
    }
    return '/';
  });

  const wasCustomerSignedInRef = useRef<boolean>(false);

  // Listen for browser navigation (popstate) and bfcache restoration (pageshow)
  useEffect(() => {
    const handlePopState = () => {
      const path = window.location.pathname || '/';
      if ((path === '/dashboard' || path.startsWith('/dashboard/')) && (!user || !getSessionToken(false))) {
        window.history.replaceState({}, '', '/login');
        setCurrentPath('/login');
        return;
      }
      setCurrentPath(path);
    };
    const handlePageShow = (event: PageTransitionEvent) => {
      const path = window.location.pathname || '/';
      if ((path === '/dashboard' || path.startsWith('/dashboard/')) && !getSessionToken(false)) {
        window.history.replaceState({}, '', '/login');
        setCurrentPath('/login');
        return;
      }
      setCurrentPath(path);
      if (event.persisted || path.startsWith('/dashboard')) {
        refreshUser(path.startsWith('/admin'));
      }
    };
    window.addEventListener('popstate', handlePopState);
    window.addEventListener('pageshow', handlePageShow);
    return () => {
      window.removeEventListener('popstate', handlePopState);
      window.removeEventListener('pageshow', handlePageShow);
    };
  }, [refreshUser, user]);

  const navigate = (path: string, replace = false) => {
    if (replace) {
      window.history.replaceState({}, '', path);
    } else {
      window.history.pushState({}, '', path);
    }
    setCurrentPath(path);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const cleanPath = currentPath.replace(/\/$/, '') || '/';
  const isAdminRoute = cleanPath === '/admin' || cleanPath.startsWith('/admin/');

  // Automatic Role-Based Redirection & Route Protection
  useEffect(() => {
    if (isLoading) return;

    // 1. Authenticated administrator (with active admin portal) landing on / or /dashboard -> /admin
    if (adminUser && (activePortal === 'admin' || (!user && cleanPath === '/dashboard'))) {
      if (cleanPath === '/' || cleanPath === '/dashboard' || cleanPath === '/login') {
        navigate('/admin', true);
        return;
      }
    }

    // 2. Track active customer login state & automatically redirect to /login when session ends
    if (user && getSessionToken(false)) {
      wasCustomerSignedInRef.current = true;
    } else if (wasCustomerSignedInRef.current && !user && !isAdminRoute && activePortal !== 'admin') {
      wasCustomerSignedInRef.current = false;
      if (cleanPath !== '/login') {
        navigate('/login', true);
        return;
      }
    }

    // 3. Authenticated customer landing on public root /, /login, or attempting /admin -> /dashboard
    if (user && (activePortal === 'customer' || !adminUser)) {
      if (isAdminRoute && !adminUser) {
        setActivePortal('customer');
        navigate('/dashboard', true);
        return;
      }
      if ((cleanPath === '/' || cleanPath === '/login') && activePortal !== 'admin') {
        setActivePortal('customer');
        navigate('/dashboard', true);
        return;
      }
    }

    // 4. Unauthenticated visitor accessing protected /dashboard -> main Login page /login
    if (cleanPath === '/dashboard' && (!user || !getSessionToken(false))) {
      if (adminUser && activePortal === 'admin') {
        navigate('/admin', true);
      } else {
        navigate('/login', true);
      }
    }
  }, [isLoading, user, adminUser, activePortal, cleanPath, isAdminRoute, setActivePortal]);

  // Role-Based Chat Widget (Tawk.to) Visibility: Hidden on ALL Admin pages, visible for Customer/Public without deleting history
  useEffect(() => {
    const syncChatWidgetVisibility = () => {
      const shouldHide = isAdminRoute || activePortal === 'admin';
      document.body.classList.toggle('admin-portal-active', shouldHide);

      // Hide or restore Tawk.to injected wrapper nodes cleanly while preserving state
      const bodyChildren = Array.from(document.body.children);
      for (const el of bodyChildren) {
        if (el.id === 'root' || el.tagName === 'SCRIPT') continue;
        const hasTawkIframe =
          el.querySelector('iframe[src*="tawk.to"], iframe[title*="chat" i]') !== null ||
          (el.id && el.id.toLowerCase().includes('tawk'));
        if (hasTawkIframe) {
          if (shouldHide) {
            el.setAttribute('data-tawk-hidden', 'true');
          } else {
            el.removeAttribute('data-tawk-hidden');
          }
        }
      }

      try {
        if (shouldHide) {
          window.Tawk_API?.minimize?.();
          window.Tawk_API?.hideWidget?.();
        } else {
          window.Tawk_API?.showWidget?.();
        }
      } catch {
        // Ignore if Tawk script not yet ready
      }
    };

    syncChatWidgetVisibility();
    const t1 = setTimeout(syncChatWidgetVisibility, 400);
    const t2 = setTimeout(syncChatWidgetVisibility, 1500);

    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
    };
  }, [isAdminRoute, activePortal, currentPath]);

  const getPageIdFromPath = (path: string): string => {
    const clean = path.replace(/\/$/, '') || '/';
    if (clean === '/admin') return 'admin';
    if (clean === '/login') return 'login';
    if (clean === '/about') return 'about';
    if (clean === '/services') return 'services';
    if (clean === '/investments') return 'investments';
    if (clean === '/verification') return 'verification';
    if (clean === '/transactions') return 'transactions';
    if (clean === '/support') return 'support';
    if (clean === '/privacy') return 'privacy';
    if (clean === '/terms') return 'terms';
    if (clean === '/security') return 'security';
    if (clean === '/faq') return 'faq';
    if (clean === '/dashboard') return 'dashboard';
    return 'home';
  };

  const currentPage = getPageIdFromPath(currentPath);

  const handleNavigateByPageId = (pageId: string) => {
    if (pageId === 'home') {
      if (user && activePortal !== 'admin') {
        navigate('/dashboard');
      } else {
        setActivePortal('public');
        navigate('/');
      }
    } else if (pageId === 'dashboard') {
      if (!user) {
        openAuth('login');
      } else {
        setActivePortal('customer');
        navigate('/dashboard');
      }
    } else {
      navigate(`/${pageId}`);
    }
  };

  // Auth Modal state for customer portal
  const [authModal, setAuthModal] = useState<{
    isOpen: boolean;
    mode: 'login' | 'register' | 'forgot';
  }>({
    isOpen: false,
    mode: 'login',
  });

  const openAuth = (mode: 'login' | 'register' | 'forgot' = 'login') => {
    clearLogoutReason();
    setAuthModal({ isOpen: true, mode });
  };

  const closeAuth = () => {
    setAuthModal(prev => ({ ...prev, isOpen: false }));
  };

  const handleCustomerLogout = async () => {
    await logoutCustomer('manual');
    navigate('/login', true);
  };

  const handleAdminLogout = async () => {
    await logoutAdmin();
    navigate('/', true);
  };

  const customerSessionNotice =
    logoutReason === 'inactivity'
      ? 'For your security, you were automatically logged out after 10 minutes of inactivity. Please sign in with your username and password.'
      : logoutReason === 'expired'
      ? 'Your previous session ended. Please enter your username and password to sign in.'
      : logoutReason === 'manual'
      ? 'You have securely logged out of your account. Enter your username and password to sign in again.'
      : null;

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#06152b] flex flex-col items-center justify-center text-white">
        <div className="w-16 h-16 rounded-2xl bg-white p-2 shadow-xl flex items-center justify-center animate-bounce">
          <img
            src="/assets/aistudio/file_00000000763081f4a6c9438dcd4940cf_665e4923.png"
            alt="FNB"
            className="w-12 h-12 object-contain"
          />
        </div>
        <p className="mt-4 font-black tracking-widest text-lg">FIRST NATIONAL BANK</p>
        <p className="text-xs text-red-400 font-semibold tracking-wider mt-1">INITIALIZING SECURE BANKING SERVICES...</p>
      </div>
    );
  }

  // ================= ADMIN ROUTE (/admin) =================
  if (isAdminRoute) {
    if (!adminUser) {
      // Unauthenticated visitors see Administrator login page; authenticated customers are redirected by effect above
      return (
        <>
          <AdminLoginPage
            onSuccess={() => {
              navigate('/admin', true);
            }}
            onNavigateHome={() => {
              navigate('/');
            }}
          />
          <EmailViewerModal />
        </>
      );
    }

    // Authenticated Administrator Dashboard
    return (
      <div className="min-h-screen flex flex-col bg-slate-100 dark:bg-slate-950 text-slate-900 dark:text-slate-100 font-['Plus_Jakarta_Sans',sans-serif]">
        {/* Persistent Administrator Header Bar with Accessible Logout */}
        <div className="bg-[#001736] text-slate-300 text-xs py-2.5 px-4 sm:px-6 flex items-center justify-between gap-3 border-b border-blue-900/50 sticky top-0 z-40">
          <div className="flex items-center gap-2 min-w-0">
            <span className="w-2 h-2 rounded-full bg-emerald-400 shrink-0" />
            <ShieldCheck className="w-4 h-4 text-red-400 shrink-0 hidden sm:block" />
            <span className="font-semibold text-white truncate">FNB Internal Admin Management Environment</span>
          </div>
          <div className="flex items-center gap-3 shrink-0">
            <span className="text-[11px] text-slate-400 hidden md:inline">{adminUser.email}</span>
            <button
              type="button"
              onClick={handleAdminLogout}
              className="px-3.5 py-1.5 rounded-xl bg-[#c8102e] hover:bg-[#a50d26] text-white font-bold text-xs shadow transition-colors flex items-center gap-1.5"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Logout</span>
            </button>
          </div>
        </div>

        <main className="flex-1">
          <AdminDashboard onLogout={handleAdminLogout} />
        </main>

        <EmailViewerModal />
      </div>
    );
  }

  // ================= CUSTOMER DASHBOARD PORTAL (/dashboard) =================
  if (currentPage === 'dashboard' && user && getSessionToken(false)) {
    return (
      <>
        <CustomerDashboard onLogout={handleCustomerLogout} />
        <EmailViewerModal />
      </>
    );
  }

  // ================= PUBLIC & MARKETING APPLICATION ROUTER =================
  return (
    <div className="min-h-screen flex flex-col bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 font-['Plus_Jakarta_Sans',sans-serif]">

      {/* Universal Top Navigation */}
      <Navbar
        currentPage={currentPage}
        onNavigate={handleNavigateByPageId}
        onOpenAuth={openAuth}
      />

      {/* Main Content Router */}
      <main className="flex-1">
        {currentPage === 'login' ? (
          <div className="py-10 px-3 sm:px-6 flex items-center justify-center min-h-[75vh] bg-slate-100 dark:bg-slate-950">
            <div className="w-full max-w-xl">
              <AuthPages
                initialMode="login"
                sessionNotice={customerSessionNotice}
                onSuccess={() => {
                  navigate('/dashboard', true);
                }}
              />
            </div>
          </div>
        ) : currentPage === 'about' ? (
          <AboutPage onOpenAuth={openAuth} onNavigate={handleNavigateByPageId} />
        ) : currentPage === 'services' ? (
          <ServicesPage onOpenAuth={openAuth} onNavigate={handleNavigateByPageId} />
        ) : currentPage === 'investments' ? (
          <InvestmentsPage
            onOpenAuth={openAuth}
            onNavigate={handleNavigateByPageId}
            isAuthenticated={!!user}
          />
        ) : currentPage === 'verification' ? (
          <VerificationPage
            onOpenAuth={openAuth}
            onNavigate={handleNavigateByPageId}
            isAuthenticated={!!user}
          />
        ) : currentPage === 'transactions' ? (
          <TransactionsPage
            onOpenAuth={openAuth}
            onNavigate={handleNavigateByPageId}
            isAuthenticated={!!user}
          />
        ) : currentPage === 'support' ? (
          <SupportPage
            onOpenAuth={openAuth}
            userEmail={user?.email}
            userName={user?.fullName || `${user?.firstName || ''} ${user?.lastName || ''}`.trim()}
          />
        ) : currentPage === 'privacy' ? (
          <PrivacyPolicyPage onNavigate={handleNavigateByPageId} onOpenAuth={openAuth} />
        ) : currentPage === 'terms' ? (
          <TermsConditionsPage onNavigate={handleNavigateByPageId} onOpenAuth={openAuth} />
        ) : currentPage === 'security' ? (
          <SecurityCentrePage onNavigate={handleNavigateByPageId} onOpenAuth={openAuth} />
        ) : currentPage === 'faq' ? (
          <FAQPage onNavigate={handleNavigateByPageId} onOpenAuth={openAuth} />
        ) : (
          // Default Home Route
          <HomePage onOpenAuth={openAuth} onNavigate={handleNavigateByPageId} />
        )}
      </main>

      {/* Universal Banking Footer */}
      <Footer
        onNavigate={handleNavigateByPageId}
        onOpenCustomerAuth={() => openAuth('login')}
        onNavigateAdmin={() => navigate('/admin')}
      />

      {/* Auth Modal (Customer Login, Registration & Password Recovery) */}
      {authModal.isOpen && (
        <div className="fixed inset-0 z-50 w-full max-w-[100vw] overflow-x-hidden overflow-y-auto flex items-center justify-center p-3 sm:p-4 bg-slate-900/75 backdrop-blur-sm">
          <div className="relative w-full min-w-0 max-w-xl my-auto max-h-[94vh] overflow-y-auto rounded-3xl shadow-2xl">
            <button
              onClick={closeAuth}
              className="absolute top-4 right-4 z-20 w-8 h-8 rounded-full bg-slate-800/80 text-white flex items-center justify-center hover:bg-red-600 transition-colors shadow-lg"
              aria-label="Close dialog"
            >
              <X className="w-4 h-4" />
            </button>
            <AuthPages
              initialMode={authModal.mode}
              onClose={closeAuth}
              onSuccess={() => {
                navigate('/dashboard', true);
              }}
            />
          </div>
        </div>
      )}

      {/* Live Communications & Notification Center */}
      <EmailViewerModal />

    </div>
  );
};

export default function App() {
  return (
    <LanguageProvider>
      <AuthProvider>
        <AppContent />
      </AuthProvider>
    </LanguageProvider>
  );
}
