import React, { useState, useRef, useEffect } from 'react';
import { useLanguage, SUPPORTED_LANGUAGES, LanguageCode } from '../context/LanguageContext.tsx';
import { Globe, ChevronDown, Check } from 'lucide-react';

interface LanguageToggleProps {
  variant?: 'navbar' | 'mobile' | 'compact' | 'navy';
}

export const LanguageToggle: React.FC<LanguageToggleProps> = ({ variant = 'navbar' }) => {
  const { currentLanguage, selectedOption, setLanguage, t } = useLanguage();
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Close dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };

    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        setIsOpen(false);
      }
    };

    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
      document.addEventListener('keydown', handleKeyDown);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [isOpen]);

  const handleSelectLanguage = (code: LanguageCode) => {
    setLanguage(code);
    setIsOpen(false);
  };

  const isNavy = variant === 'navy';

  if (variant === 'mobile') {
    return (
      <div className="pt-3 pb-2 border-t border-slate-200 dark:border-slate-800">
        <div className="flex items-center justify-between mb-2 px-1">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wider flex items-center gap-1.5">
            <Globe className="w-3.5 h-3.5 text-blue-600" />
            <span>Region & Language</span>
          </span>
          <span className="text-[10px] font-mono text-slate-400">
            {selectedOption.name}
          </span>
        </div>
        <div className="grid grid-cols-2 gap-1.5">
          {SUPPORTED_LANGUAGES.map(lang => {
            const isSelected = lang.code === currentLanguage;
            return (
              <button
                key={lang.code}
                onClick={() => handleSelectLanguage(lang.code)}
                className={`flex items-center justify-between p-2 rounded-xl text-xs font-semibold transition-all ${
                  isSelected
                    ? 'bg-[#002752] text-white shadow-sm'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700'
                }`}
              >
                <div className="flex items-center gap-2">
                  <span className="text-base">{lang.flag}</span>
                  <span className="truncate">{lang.name}</span>
                </div>
                {isSelected && <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />}
              </button>
            );
          })}
        </div>
      </div>
    );
  }

  return (
    <div className="relative inline-block text-left" ref={dropdownRef}>
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        aria-expanded={isOpen}
        aria-haspopup="true"
        className={
          isNavy
            ? 'flex items-center gap-1.5 px-2.5 py-2 rounded-xl border border-blue-800/60 bg-[#0d2240] hover:bg-[#132d54] text-white text-xs font-bold transition-all focus:outline-none focus:ring-2 focus:ring-blue-400/40'
            : 'flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/80 dark:bg-slate-900/80 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200 text-xs font-bold transition-all focus:outline-none focus:ring-2 focus:ring-[#002752]/20'
        }
        title="Change Region & Language"
      >
        <Globe className={isNavy ? 'w-3.5 h-3.5 text-blue-300' : 'w-3.5 h-3.5 text-blue-600 dark:text-blue-400'} />
        <span className="text-sm">{selectedOption.flag}</span>
        <span className="uppercase text-[11px] font-extrabold tracking-wider hidden sm:inline">
          {selectedOption.code}
        </span>
        <ChevronDown className={`w-3 h-3 ${isNavy ? 'text-blue-300' : 'text-slate-400'} transition-transform ${isOpen ? 'rotate-180' : ''}`} />
      </button>

      {/* Floating Language Menu */}
      {isOpen && (
        <div
          className={
            isNavy
              ? 'absolute right-0 mt-2 w-64 rounded-2xl bg-[#0a1d38] shadow-2xl border border-blue-800/60 py-2 z-50'
              : 'absolute right-0 mt-2 w-64 rounded-2xl bg-white dark:bg-slate-900 shadow-2xl border border-slate-200 dark:border-slate-800 py-2 z-50 animate-in fade-in zoom-in-95 duration-100'
          }
        >
          <div className={`px-3.5 py-2 border-b ${isNavy ? 'border-blue-800/50' : 'border-slate-100 dark:border-slate-800'}`}>
            <p className={`text-[11px] font-bold uppercase tracking-wider ${isNavy ? 'text-blue-300/80' : 'text-slate-400'}`}>
              {t('lang.selectTitle', 'Select Region & Language')}
            </p>
          </div>

          <div className="p-1 space-y-0.5">
            {SUPPORTED_LANGUAGES.map(lang => {
              const isSelected = lang.code === currentLanguage;
              return (
                <button
                  key={lang.code}
                  type="button"
                  onClick={() => handleSelectLanguage(lang.code)}
                  className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-left transition-all ${
                    isNavy
                      ? isSelected
                        ? 'bg-[#12315c] text-white font-bold'
                        : 'hover:bg-[#10294d] text-blue-100 font-medium'
                      : isSelected
                      ? 'bg-blue-50 dark:bg-blue-950/70 text-[#002752] dark:text-white font-bold'
                      : 'hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 font-medium'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <span className="text-xl shadow-xs">{lang.flag}</span>
                    <div>
                      <p className="text-xs leading-none">
                        {lang.name}
                      </p>
                      <p className={`text-[10px] mt-1 ${isNavy ? 'text-blue-300/70' : 'text-slate-400'}`}>
                        {lang.region}
                      </p>
                    </div>
                  </div>

                  {isSelected && (
                    <div className="w-5 h-5 rounded-full bg-[#c8102e] text-white flex items-center justify-center">
                      <Check className="w-3 h-3" />
                    </div>
                  )}
                </button>
              );
            })}
          </div>

          <div className={`px-3.5 py-1.5 border-t text-[10px] text-center ${isNavy ? 'border-blue-800/50 bg-[#07152b] text-blue-300/70' : 'border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/50 text-slate-400'}`}>
            Global Premier Banking Network
          </div>
        </div>
      )}
    </div>
  );
};
