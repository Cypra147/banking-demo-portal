import React, { useState, useMemo, useRef, useEffect } from 'react';
import {
  GLOBAL_BANK_DIRECTORY,
  CountryBankDirectory,
  BankEntryWithCountry,
  getCountryDirectory,
} from '../constants/banks.ts';
import {
  Building2,
  Globe,
  Search,
  ChevronDown,
  Check,
  ArrowLeftRight,
  Edit3,
} from 'lucide-react';

export interface BankSelectionValue {
  transferScope: 'domestic' | 'international';
  countryCode: string; // 'ALL' or ISO2 like 'US', 'GB', 'NG'
  bankName: string;
  swiftBic: string;
  isCustomBank: boolean;
}

interface BeneficiaryBankSelectorProps {
  value: BankSelectionValue;
  onChange: (next: BankSelectionValue) => void;
  directory?: CountryBankDirectory[];
  theme?: 'default' | 'navy';
}

export const BeneficiaryBankSelector: React.FC<BeneficiaryBankSelectorProps> = ({
  value,
  onChange,
  directory = GLOBAL_BANK_DIRECTORY,
  theme = 'default',
}) => {
  const isNavy = theme === 'navy';
  const [isOpen, setIsOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const dropdownRef = useRef<HTMLDivElement>(null);
  const searchInputRef = useRef<HTMLInputElement>(null);

  // Close dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Focus search input when opening
  useEffect(() => {
    if (isOpen && searchInputRef.current) {
      setTimeout(() => searchInputRef.current?.focus(), 50);
    }
  }, [isOpen]);

  // Countries available based on scope
  const availableCountries = useMemo(() => {
    if (value.transferScope === 'domestic') {
      return directory.filter(c => c.isDomestic);
    }
    return directory;
  }, [directory, value.transferScope]);

  // Banks grouped by country after applying country filter + search query
  const groupedBanks = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();

    const targetCountries =
      value.transferScope === 'domestic'
        ? availableCountries
        : value.countryCode === 'ALL'
        ? availableCountries
        : availableCountries.filter(c => c.countryCode === value.countryCode);

    return targetCountries
      .map(country => {
        const filtered = country.banks.filter(bank => {
          if (!q) return true;
          return (
            bank.name.toLowerCase().includes(q) ||
            bank.swiftBic.toLowerCase().includes(q) ||
            country.countryName.toLowerCase().includes(q) ||
            country.countryCode.toLowerCase().includes(q)
          );
        });
        return {
          country,
          banks: filtered,
        };
      })
      .filter(group => group.banks.length > 0);
  }, [availableCountries, value.transferScope, value.countryCode, searchQuery]);

  const handleScopeChange = (scope: 'domestic' | 'international') => {
    if (scope === value.transferScope) return;
    if (scope === 'domestic') {
      const uk = getCountryDirectory('GB');
      const defaultBank = uk?.banks[0];
      onChange({
        transferScope: 'domestic',
        countryCode: 'GB',
        bankName: defaultBank?.name || 'First National Bank (Domestic)',
        swiftBic: defaultBank?.swiftBic || 'FNBBGB2LXXX',
        isCustomBank: false,
      });
    } else {
      const us = getCountryDirectory('US');
      const defaultBank = us?.banks[0];
      onChange({
        transferScope: 'international',
        countryCode: 'US',
        bankName: defaultBank?.name || 'JPMorgan Chase',
        swiftBic: defaultBank?.swiftBic || 'CHASUS33XXX',
        isCustomBank: false,
      });
    }
    setSearchQuery('');
    setIsOpen(false);
  };

  const handleCountryChange = (newCountryCode: string) => {
    if (newCountryCode === 'ALL') {
      onChange({
        ...value,
        countryCode: 'ALL',
      });
      return;
    }
    const target = directory.find(c => c.countryCode === newCountryCode);
    const firstBank = target?.banks[0];
    onChange({
      ...value,
      countryCode: newCountryCode,
      bankName: firstBank ? firstBank.name : value.bankName,
      swiftBic: firstBank ? firstBank.swiftBic : value.swiftBic,
      isCustomBank: false,
    });
  };

  const handleSelectBank = (bank: BankEntryWithCountry | { name: string; swiftBic: string; countryCode: string }) => {
    onChange({
      ...value,
      countryCode: value.countryCode === 'ALL' ? bank.countryCode : value.countryCode,
      bankName: bank.name,
      swiftBic: bank.swiftBic,
      isCustomBank: false,
    });
    setIsOpen(false);
    setSearchQuery('');
  };

  const handleEnableCustomBank = () => {
    onChange({
      ...value,
      bankName: searchQuery.trim() || '',
      swiftBic: '',
      isCustomBank: true,
    });
    setIsOpen(false);
    setSearchQuery('');
  };

  const totalMatches = groupedBanks.reduce((sum, g) => sum + g.banks.length, 0);

  return (
    <div className="space-y-4">
      {/* Domestic vs International Transfer Mode */}
      <div>
        <label className={`block text-xs font-semibold mb-1.5 ${isNavy ? 'text-blue-200' : 'text-slate-700 dark:text-slate-300'}`}>
          Transfer Type
        </label>
        <div className={`grid grid-cols-2 gap-2 p-1 border rounded-xl ${isNavy ? 'bg-[#07152b] border-blue-800/50' : 'bg-slate-100 dark:bg-slate-950 border-slate-200 dark:border-slate-800'}`}>
          <button
            type="button"
            onClick={() => handleScopeChange('domestic')}
            className={`py-2 px-3 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition-all ${
              value.transferScope === 'domestic'
                ? 'bg-[#12396f] text-white shadow-sm'
                : isNavy
                ? 'text-blue-300/80 hover:text-white'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <Building2 className="w-3.5 h-3.5 shrink-0" />
            <span className="truncate">Domestic Transfer</span>
          </button>
          <button
            type="button"
            onClick={() => handleScopeChange('international')}
            className={`py-2 px-3 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition-all ${
              value.transferScope === 'international'
                ? 'bg-[#c8102e] text-white shadow-sm'
                : isNavy
                ? 'text-blue-300/80 hover:text-white'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <Globe className="w-3.5 h-3.5 shrink-0" />
            <span className="truncate">International Wire</span>
          </button>
        </div>
      </div>

      {/* Country Filter + Searchable Bank Selector */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {/* Destination Country Selector */}
        <div>
          <label className={`block text-xs font-semibold mb-1 ${isNavy ? 'text-blue-200' : 'text-slate-700 dark:text-slate-300'}`}>
            {value.transferScope === 'domestic' ? 'Clearing Jurisdiction' : 'Destination Country'}
          </label>
          {value.transferScope === 'domestic' ? (
            <div className={`w-full px-3.5 py-2.5 text-xs sm:text-sm border rounded-xl flex items-center justify-between ${isNavy ? 'bg-[#07152b] border-blue-800/60 text-blue-100' : 'bg-slate-100 dark:bg-slate-950/70 border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300'}`}>
              <span className="truncate font-medium">United Kingdom (Domestic Clearing)</span>
              <ArrowLeftRight className="w-3.5 h-3.5 text-slate-400 shrink-0 ml-2" />
            </div>
          ) : (
            <select
              value={value.countryCode}
              onChange={e => handleCountryChange(e.target.value)}
              className={`w-full px-3.5 py-2.5 text-xs sm:text-sm border rounded-xl focus:outline-none focus:ring-2 ${isNavy ? 'bg-[#07152b] border-blue-800/60 text-white focus:ring-blue-400/40' : 'bg-slate-50 dark:bg-slate-950 border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white focus:ring-[#002752]'}`}
            >
              <option value="ALL">All Countries ({directory.reduce((acc, c) => acc + c.banks.length, 0)} banks)</option>
              {directory.map(country => (
                <option key={country.countryCode} value={country.countryCode}>
                  {country.countryName} ({country.banks.length})
                </option>
              ))}
            </select>
          )}
        </div>

        {/* Searchable Bank Dropdown */}
        <div className="relative" ref={dropdownRef}>
          <div className="flex items-center justify-between mb-1">
            <label className={`block text-xs font-semibold ${isNavy ? 'text-blue-200' : 'text-slate-700 dark:text-slate-300'}`}>
              Beneficiary Bank
            </label>
            {value.isCustomBank && (
              <button
                type="button"
                onClick={() => {
                  onChange({ ...value, isCustomBank: false });
                  setIsOpen(true);
                }}
                className={`text-[11px] font-semibold hover:underline ${isNavy ? 'text-blue-300' : 'text-blue-600 dark:text-blue-400'}`}
              >
                Choose from directory
              </button>
            )}
          </div>

          {value.isCustomBank ? (
            <input
              type="text"
              required
              placeholder="Enter beneficiary bank name"
              value={value.bankName}
              onChange={e => onChange({ ...value, bankName: e.target.value })}
              className={`w-full px-3.5 py-2.5 text-xs sm:text-sm border rounded-xl focus:outline-none focus:ring-2 ${isNavy ? 'bg-[#07152b] border-blue-800/60 text-white placeholder-blue-300/40 focus:ring-blue-400/40' : 'bg-slate-50 dark:bg-slate-950 border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white focus:ring-[#002752]'}`}
            />
          ) : (
            <>
              <button
                type="button"
                onClick={() => setIsOpen(prev => !prev)}
                aria-expanded={isOpen}
                className={`w-full px-3.5 py-2.5 text-xs sm:text-sm border rounded-xl focus:outline-none focus:ring-2 flex items-center justify-between gap-2 text-left ${isNavy ? 'bg-[#07152b] border-blue-800/60 text-white focus:ring-blue-400/40' : 'bg-slate-50 dark:bg-slate-950 border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white focus:ring-[#002752]'}`}
              >
                <span className="truncate font-medium">
                  {value.bankName || 'Select beneficiary bank...'}
                </span>
                <ChevronDown
                  className={`w-4 h-4 text-slate-400 shrink-0 transition-transform ${
                    isOpen ? 'rotate-180' : ''
                  }`}
                />
              </button>

              {isOpen && (
                <div className={`absolute z-40 left-0 right-0 mt-1.5 border rounded-2xl shadow-2xl overflow-hidden ${isNavy ? 'bg-[#0a1d38] border-blue-800/60' : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-700'}`}>
                  {/* Search Input */}
                  <div className={`p-2.5 border-b ${isNavy ? 'border-blue-800/50 bg-[#07152b]' : 'border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950'}`}>
                    <div className="relative">
                      <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-400" />
                      <input
                        ref={searchInputRef}
                        type="text"
                        placeholder="Search bank name, country, or SWIFT..."
                        value={searchQuery}
                        onChange={e => setSearchQuery(e.target.value)}
                        className={`w-full pl-8 pr-3 py-1.5 text-xs border rounded-lg focus:outline-none focus:ring-2 ${isNavy ? 'bg-[#0d2240] border-blue-800/60 text-white placeholder-blue-300/40 focus:ring-blue-400/40' : 'bg-white dark:bg-slate-900 border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white focus:ring-[#002752]'}`}
                      />
                    </div>
                    <p className="text-[10px] text-slate-400 mt-1 px-0.5">
                      Showing {totalMatches} institution{totalMatches === 1 ? '' : 's'}
                    </p>
                  </div>

                  {/* Grouped Bank List */}
                  <div className={`max-h-64 overflow-y-auto divide-y ${isNavy ? 'divide-blue-900/40' : 'divide-slate-100 dark:divide-slate-800/60'}`}>
                    {groupedBanks.length === 0 ? (
                      <div className="p-4 text-center text-xs text-slate-400">
                        No banks matched "{searchQuery}".
                      </div>
                    ) : (
                      groupedBanks.map(({ country, banks }) => (
                        <div key={country.countryCode}>
                          <div className={`px-3 py-1.5 text-[10px] font-bold uppercase tracking-wider sticky top-0 flex items-center justify-between ${isNavy ? 'bg-[#07152b] text-blue-300' : 'bg-slate-100/80 dark:bg-slate-950/90 text-slate-500 dark:text-slate-400'}`}>
                            <span>{country.countryName}</span>
                            <span>{country.region}</span>
                          </div>
                          <div className="py-1">
                            {banks.map(bank => {
                              const isSelected = value.bankName === bank.name;
                              return (
                                <button
                                  key={bank.id}
                                  type="button"
                                  onClick={() =>
                                    handleSelectBank({
                                      ...bank,
                                      countryCode: country.countryCode,
                                    })
                                  }
                                  className={`w-full px-3 py-2 text-left text-xs flex items-center justify-between gap-2 transition-colors ${
                                    isNavy
                                      ? isSelected
                                        ? 'bg-[#12396f] text-white font-bold'
                                        : 'text-blue-100 hover:bg-[#10294d]'
                                      : isSelected
                                      ? 'bg-blue-50 dark:bg-blue-950/50 text-[#002752] dark:text-blue-300 font-bold'
                                      : 'text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800/80'
                                  }`}
                                >
                                  <div className="min-w-0">
                                    <p className="truncate">{bank.name}</p>
                                    <p className={`text-[10px] font-mono truncate ${isNavy ? 'text-blue-300/70' : 'text-slate-400'}`}>
                                      SWIFT: {bank.swiftBic}
                                      {bank.clearingCode ? ` • Code: ${bank.clearingCode}` : ''}
                                    </p>
                                  </div>
                                  {isSelected && <Check className="w-3.5 h-3.5 text-[#c8102e] shrink-0" />}
                                </button>
                              );
                            })}
                          </div>
                        </div>
                      ))
                    )}

                    {/* Custom Bank Fallback */}
                    <div className={`p-2 border-t ${isNavy ? 'bg-[#07152b] border-blue-800/50' : 'bg-slate-50 dark:bg-slate-950 border-slate-200 dark:border-slate-800'}`}>
                      <button
                        type="button"
                        onClick={handleEnableCustomBank}
                        className={`w-full px-2.5 py-2 rounded-lg text-xs font-semibold flex items-center gap-2 transition-colors ${isNavy ? 'text-blue-200 hover:bg-[#10294d]' : 'text-slate-600 dark:text-slate-300 hover:bg-slate-200/70 dark:hover:bg-slate-800'}`}
                      >
                        <Edit3 className="w-3.5 h-3.5 text-[#c8102e] shrink-0" />
                        <span>Other / Enter Bank Manually</span>
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
};
