import React, { useState } from 'react';

interface BrandLogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showText?: boolean;
}

export const BrandLogo: React.FC<BrandLogoProps> = ({ 
  className = '', 
  size = 'md',
  showText = false
}) => {
  const [imgError, setImgError] = useState(false);

  const sizeClasses = {
    sm: 'w-8 h-8',
    md: 'w-11 h-11',
    lg: 'w-14 h-14',
    xl: 'w-16 h-16'
  }[size];

  return (
    <div className={`flex items-center gap-3 ${className}`}>
      {!imgError ? (
        <img
          src="/fnb-logo.png"
          alt="First National Bank Logo"
          className={`${sizeClasses} object-contain rounded-xl bg-white p-1 shadow-sm transition-transform`}
          onError={() => setImgError(true)}
        />
      ) : (
        <div className={`${sizeClasses} rounded-xl bg-[#002752] flex flex-col items-center justify-center text-white font-black shadow-md border border-white/20`}>
          <span className="text-[#c8102e] text-xs leading-none">FNB</span>
          <span className="text-[7px] font-sans tracking-widest text-slate-300">BANK</span>
        </div>
      )}

      {showText && (
        <div>
          <div className="flex items-center">
            <span className="text-xl sm:text-2xl font-black tracking-tight text-[#002752] dark:text-white">
              FNB
            </span>
            <span className="ml-1 text-xs font-bold text-[#c8102e] tracking-widest uppercase">
              ONLINE
            </span>
          </div>
          <p className="text-[9px] sm:text-[10px] text-slate-500 dark:text-slate-400 tracking-wider font-semibold uppercase -mt-0.5">
            FIRST NATIONAL BANK
          </p>
        </div>
      )}
    </div>
  );
};
