import React, { useState, useEffect, useRef } from 'react';
import { User } from '../types.ts';
import { Lock, ShieldAlert, Clock, X, AlertCircle, KeyRound } from 'lucide-react';

export interface TransactionSummaryRow {
  label: string;
  value: string;
  highlight?: boolean;
}

interface TransactionPinModalProps {
  isOpen: boolean;
  user: User;
  transactionTitle: string;
  summaryItems: TransactionSummaryRow[];
  loading: boolean;
  error: string | null;
  errorCode?: string;
  lockedUntil?: number;
  onConfirm: (pin: string) => Promise<void> | void;
  onCancel: () => void;
  onNavigatePinSetup: (targetMode: 'setup' | 'forgot') => void;
}

export const TransactionPinModal: React.FC<TransactionPinModalProps> = ({
  isOpen,
  user,
  transactionTitle,
  summaryItems,
  loading,
  error,
  errorCode,
  lockedUntil,
  onConfirm,
  onCancel,
  onNavigatePinSetup,
}) => {
  const [pin, setPin] = useState('');
  const [localError, setLocalError] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement | null>(null);

  const expectedLen = user.transactionPinLength || 6;
  const activeLockUntil = lockedUntil || (user.pinLockedUntil && Date.now() < user.pinLockedUntil ? user.pinLockedUntil : undefined);
  const isLocked = Boolean(activeLockUntil && Date.now() < activeLockUntil) || errorCode === 'PIN_LOCKED';
  const lockMinutes = activeLockUntil ? Math.max(1, Math.ceil((activeLockUntil - Date.now()) / 60000)) : 15;
  const needsSetup = !user.hasTransactionPin || errorCode === 'PIN_NOT_SET';

  useEffect(() => {
    if (isOpen) {
      setPin('');
      setLocalError(null);
      setTimeout(() => {
        inputRef.current?.focus();
      }, 60);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLocalError(null);

    if (!/^(?:\d{4}|\d{6})$/.test(pin)) {
      setLocalError(`Please enter your ${user.transactionPinLength ? `${user.transactionPinLength}-digit` : '4-digit or 6-digit'} numeric Transaction PIN.`);
      return;
    }

    onConfirm(pin);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/75 backdrop-blur-sm animate-fade-in"
      role="dialog"
      aria-modal="true"
      aria-labelledby="pin-auth-modal-title"
    >
      <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden">
        {/* Header clearly indicating Awaiting Verification status */}
        <div className="p-5 bg-[#002752] text-white flex items-start justify-between gap-3">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center shrink-0">
              <Lock className="w-5 h-5 text-amber-300" />
            </div>
            <div>
              <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-amber-400/20 border border-amber-300/40 text-amber-200 text-[10px] font-bold uppercase tracking-wider mb-1">
                <Clock className="w-3 h-3" />
                Awaiting Transaction PIN Verification
              </span>
              <h3 id="pin-auth-modal-title" className="font-bold text-base leading-tight">
                {transactionTitle}
              </h3>
            </div>
          </div>
          <button
            type="button"
            disabled={loading}
            onClick={onCancel}
            aria-label="Cancel transaction verification"
            className="p-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-5 sm:p-6 space-y-5">
          {/* Pending Transaction Summary */}
          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-2 text-xs">
            <div className="flex items-center justify-between text-[10px] uppercase tracking-wider font-bold text-slate-400 pb-1 border-b border-slate-200 dark:border-slate-800">
              <span>Pending Instruction</span>
              <span className="text-amber-600 dark:text-amber-400">Not Yet Completed</span>
            </div>
            {summaryItems.map((item, idx) => (
              <div key={idx} className="flex justify-between items-center gap-3">
                <span className="text-slate-500">{item.label}</span>
                <span
                  className={
                    item.highlight
                      ? 'font-black text-sm text-[#002752] dark:text-blue-400 text-right'
                      : 'font-semibold text-slate-800 dark:text-slate-200 text-right'
                  }
                >
                  {item.value}
                </span>
              </div>
            ))}
          </div>

          {needsSetup ? (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 text-xs text-amber-900 dark:text-amber-200 flex items-start gap-2.5">
                <KeyRound className="w-4 h-4 shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <strong className="block">Transaction PIN Not Configured</strong>
                  <p>
                    For your protection, you must create a 4-digit or 6-digit Transaction PIN before authorizing any transaction. This transaction has not been executed.
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={onCancel}
                  className="flex-1 py-2.5 rounded-xl text-xs font-bold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={() => onNavigatePinSetup('setup')}
                  className="flex-1 py-2.5 rounded-xl text-xs font-bold bg-[#002752] hover:bg-[#001d3d] text-white shadow"
                >
                  Set Up Transaction PIN
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              {(error || localError) && (
                <div className="p-3.5 rounded-xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 text-xs text-red-700 dark:text-red-300 flex items-start gap-2">
                  {isLocked ? (
                    <ShieldAlert className="w-4 h-4 shrink-0 mt-0.5" />
                  ) : (
                    <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  )}
                  <span>
                    {error || localError}
                    {isLocked && !error ? ` (${lockMinutes}m remaining)` : ''}
                  </span>
                </div>
              )}

              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label
                    htmlFor="modal-tx-pin-input"
                    className="block text-xs font-semibold text-slate-700 dark:text-slate-300"
                  >
                    Enter {user.transactionPinLength ? `${user.transactionPinLength}-Digit` : '4 or 6-Digit'} Transaction PIN
                  </label>
                  <button
                    type="button"
                    disabled={loading}
                    onClick={() => onNavigatePinSetup('forgot')}
                    className="text-[11px] font-bold text-[#c8102e] hover:underline"
                  >
                    Forgot Transaction PIN?
                  </button>
                </div>

                <input
                  id="modal-tx-pin-input"
                  ref={inputRef}
                  type="password"
                  inputMode="numeric"
                  autoComplete="one-time-code"
                  maxLength={expectedLen}
                  disabled={loading || isLocked}
                  required
                  placeholder={'•'.repeat(user.transactionPinLength || 4)}
                  value={pin}
                  onChange={e => {
                    setLocalError(null);
                    setPin(e.target.value.replace(/\D/g, '').slice(0, expectedLen));
                  }}
                  className="w-full px-4 py-3 text-center text-lg font-mono tracking-[0.5em] bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#002752] disabled:opacity-50"
                />

                {/* Visual masked dot indicator */}
                <div className="flex items-center justify-center gap-2 mt-2.5" aria-hidden="true">
                  {Array.from({ length: user.transactionPinLength || 4 }).map((_, i) => (
                    <span
                      key={i}
                      className={`w-2.5 h-2.5 rounded-full transition-colors ${
                        i < pin.length
                          ? 'bg-[#002752] dark:bg-blue-400'
                          : 'bg-slate-200 dark:bg-slate-700'
                      }`}
                    />
                  ))}
                </div>
              </div>

              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-[11px] text-slate-500 flex items-start gap-2">
                <Lock className="w-3.5 h-3.5 text-[#002752] dark:text-blue-400 shrink-0 mt-0.5" />
                <span>
                  Your digits are masked for privacy. FNB will never ask you to share your Transaction PIN.
                </span>
              </div>

              <div className="flex items-center gap-3 pt-1">
                <button
                  type="button"
                  disabled={loading}
                  onClick={onCancel}
                  className="flex-1 py-2.5 rounded-xl text-xs font-bold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700 disabled:opacity-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={
                    loading ||
                    isLocked ||
                    (user.transactionPinLength
                      ? pin.length !== user.transactionPinLength
                      : pin.length !== 4 && pin.length !== 6)
                  }
                  className="flex-1 py-2.5 rounded-xl text-xs font-bold bg-[#c8102e] hover:bg-[#a50d26] text-white shadow disabled:opacity-50 transition-colors"
                >
                  {loading ? 'Verifying & Authorizing...' : 'Verify PIN & Complete'}
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
