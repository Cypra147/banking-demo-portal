import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext.tsx';
import { Mail, X, Check, Copy, ExternalLink, ShieldCheck, Clock, Inbox } from 'lucide-react';
import { EmailMessage } from '../types.ts';

export const EmailViewerModal: React.FC = () => {
  const { 
    isMailModalOpen, 
    setIsMailModalOpen, 
    emails, 
    markEmailRead, 
    activeEmailForPreview, 
    setActiveEmailForPreview 
  } = useAuth();
  
  const [copiedOtp, setCopiedOtp] = useState<string | null>(null);

  if (!isMailModalOpen) return null;

  const currentEmail = activeEmailForPreview || (emails.length > 0 ? emails[0] : null);

  const handleSelectEmail = (email: EmailMessage) => {
    setActiveEmailForPreview(email);
    markEmailRead(email.id);
  };

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedOtp(text);
    setTimeout(() => setCopiedOtp(null), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-900/70 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-5xl h-[88vh] bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 flex flex-col overflow-hidden">
        
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-800 bg-[#002752] text-white">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-white/10 flex items-center justify-center text-white">
              <Mail className="w-5 h-5 text-red-400" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-base sm:text-lg">FNB Secure Communications & Notifications</h3>
                <span className="px-2 py-0.5 text-xs font-semibold bg-red-600 text-white rounded-full">
                  Official Notices
                </span>
              </div>
              <p className="text-xs text-slate-300">
                Official FNB communications dispatched from <span className="font-mono text-white">info@fnnbbankss.online</span>
              </p>
            </div>
          </div>
          <button
            onClick={() => setIsMailModalOpen(false)}
            className="p-2 rounded-lg hover:bg-white/10 text-slate-300 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content split into Sidebar and Email body */}
        <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
          
          {/* Email List Sidebar */}
          <div className="w-full md:w-80 lg:w-96 border-r border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/60 overflow-y-auto">
            <div className="p-3 bg-slate-100 dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
              <span className="font-semibold uppercase tracking-wider">Inbox ({emails.length})</span>
              <span>Updated live</span>
            </div>

            {emails.length === 0 ? (
              <div className="p-8 text-center text-slate-400 flex flex-col items-center">
                <Inbox className="w-10 h-10 mb-2 opacity-50 text-slate-300" />
                <p className="text-sm">No notifications yet.</p>
                <p className="text-xs mt-1 text-slate-500">Initiate a registration, transfer, or approval to generate alerts.</p>
              </div>
            ) : (
              <div className="divide-y divide-slate-200/70 dark:divide-slate-800/80">
                {emails.map(email => {
                  const isSelected = currentEmail?.id === email.id;
                  return (
                    <button
                      key={email.id}
                      onClick={() => handleSelectEmail(email)}
                      className={`w-full text-left p-3.5 transition-all flex flex-col gap-1.5 ${
                        isSelected 
                          ? 'bg-blue-50/80 dark:bg-blue-950/40 border-l-4 border-[#002752] dark:border-red-500' 
                          : 'hover:bg-slate-100/70 dark:hover:bg-slate-900/40'
                      }`}
                    >
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-semibold text-slate-700 dark:text-slate-200 truncate max-w-[170px]">
                          {email.toName}
                        </span>
                        <span className="text-[11px] text-slate-400 flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {new Date(email.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>

                      <div className="text-xs font-medium text-slate-900 dark:text-white line-clamp-1">
                        {email.subject}
                      </div>

                      <div className="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-1">
                        {email.textContent}
                      </div>
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          {/* Email Preview Area */}
          <div className="flex-1 flex flex-col bg-white dark:bg-slate-900 overflow-y-auto">
            {currentEmail ? (
              <div className="p-4 sm:p-6 flex-1 flex flex-col">
                {/* Email details bar */}
                <div className="pb-4 mb-4 border-b border-slate-200 dark:border-slate-800">
                  <div className="flex flex-wrap items-start justify-between gap-3 mb-2">
                    <h2 className="text-lg sm:text-xl font-bold text-slate-900 dark:text-white">
                      {currentEmail.subject}
                    </h2>
                    <span className="text-xs text-slate-500 dark:text-slate-400">
                      {new Date(currentEmail.createdAt).toLocaleString()}
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-slate-600 dark:text-slate-300">
                    <div>
                      <span className="text-slate-400">From: </span>
                      <strong className="text-slate-900 dark:text-white">First National Bank</strong> &lt;info@fnnbbankss.online&gt;
                    </div>
                    <div>
                      <span className="text-slate-400">To: </span>
                      <strong className="text-slate-900 dark:text-white">{currentEmail.toName}</strong> &lt;{currentEmail.toEmail}&gt;
                    </div>
                  </div>
                </div>

                {/* HTML Body Render in Sandboxed Container */}
                <div 
                  className="flex-1 bg-slate-50 dark:bg-slate-950/40 rounded-xl p-4 overflow-y-auto border border-slate-200 dark:border-slate-800"
                  dangerouslySetInnerHTML={{ __html: currentEmail.htmlContent }}
                />
              </div>
            ) : (
              <div className="flex-1 flex flex-col items-center justify-center p-8 text-slate-400">
                <Mail className="w-12 h-12 mb-3 text-slate-300" />
                <p>Select an email from the list to view its official HTML template.</p>
              </div>
            )}
          </div>

        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 flex flex-wrap items-center justify-between text-xs text-slate-500">
          <div className="flex items-center gap-4">
            <span>FNB Enquiries: +12724736857</span>
            <span>Official Email: info@fnnbbankss.online</span>
          </div>
          <button
            onClick={() => setIsMailModalOpen(false)}
            className="px-4 py-1.5 bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 rounded-lg font-medium transition-colors"
          >
            Close Center
          </button>
        </div>

      </div>
    </div>
  );
};
