import React from 'react';
import { getTagBadgeStyle } from '../utils/transactionTagger.ts';
import { Tag } from 'lucide-react';

interface TransactionTagBadgeProps {
  tag?: string;
  size?: 'sm' | 'md';
  showIcon?: boolean;
  className?: string;
}

export const TransactionTagBadge: React.FC<TransactionTagBadgeProps> = ({
  tag = 'General',
  size = 'sm',
  showIcon = false,
  className = '',
}) => {
  const style = getTagBadgeStyle(tag);

  return (
    <span
      className={`inline-flex items-center gap-1.5 font-semibold rounded-full border transition-colors ${style.bg} ${style.text} ${style.border} ${
        size === 'sm' ? 'px-2 py-0.5 text-[10px]' : 'px-2.5 py-1 text-xs'
      } ${className}`}
      title={`Auto-tagged as ${tag}`}
    >
      {showIcon ? (
        <Tag className={size === 'sm' ? 'w-2.5 h-2.5' : 'w-3 h-3'} />
      ) : (
        <span className={`w-1.5 h-1.5 rounded-full ${style.dot}`} />
      )}
      <span>{tag}</span>
    </span>
  );
};
