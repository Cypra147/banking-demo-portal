import React, { useState } from 'react';
import { Transaction, User } from '../types.ts';
import { TransactionTagBadge } from './TransactionTagBadge.tsx';
import { tagTransaction } from '../utils/transactionTagger.ts';
import { formatUsdNumber, USD_SYMBOL, USD_CODE } from '../utils/currency.ts';
import { X, Printer, Download, FileSpreadsheet, ShieldCheck } from 'lucide-react';

interface StatementModalProps {
  user: User;
  transactions: Transaction[];
  onClose: () => void;
}

export const StatementModal: React.FC<StatementModalProps> = ({ user, transactions, onClose }) => {
  const [period, setPeriod] = useState<'30' | '90' | 'all'>('all');

  const filtered = transactions.filter(tx => {
    if (period === 'all') return true;
    const days = parseInt(period, 10);
    const cutoff = Date.now() - days * 24 * 60 * 60 * 1000;
    return new Date(tx.createdAt).getTime() >= cutoff;
  });

  const totalCredits = filtered
    .filter(t => t.type === 'credit' || t.type === 'reversal')
    .reduce((sum, t) => sum + t.amount, 0);

  const totalDebits = filtered
    .filter(t => t.type !== 'credit' && t.type !== 'reversal')
    .reduce((sum, t) => sum + t.amount, 0);

  const handlePrint = () => {
    document.body.classList.add('printing-modal');
    const cleanup = () => {
      document.body.classList.remove('printing-modal');
      window.removeEventListener('afterprint', cleanup);
    };
    window.addEventListener('afterprint', cleanup);
    window.print();
    setTimeout(cleanup, 1000);
  };

  const handleExportCSV = () => {
    const headers = ['Date', 'Reference', 'Type', 'Description', 'Amount', 'Currency', 'Status'];
    const rows = filtered.map(t => [
      `"${new Date(t.createdAt).toISOString()}"`,
      `"${t.reference}"`,
      `"${t.type}"`,
      `"${t.description.replace(/"/g, '""')}"`,
      t.type === 'debit' || t.type === 'transfer' || t.type === 'withdrawal' || t.type === 'bill_payment' ? -t.amount : t.amount,
      `"${USD_CODE}"`,
      `"${t.status}"`,
    ]);
    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `FNB_Statement_${user.accountNumber || 'Account'}_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="print-modal-root fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-900/75 backdrop-blur-sm animate-fade-in">
      <div className="print-modal-card relative w-full max-w-4xl bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 flex flex-col max-h-[92vh] overflow-hidden">

        {/* Top Control Bar (Hidden when printing) */}
        <div className="px-6 py-4 bg-[#002752] text-white flex flex-wrap items-center justify-between gap-3 print:hidden">
          <div className="flex items-center gap-3">
            <FileSpreadsheet className="w-5 h-5 text-red-400" />
            <div>
              <h3 className="font-bold text-base">FNB Electronic Statement of Account</h3>
              <p className="text-xs text-slate-300">Official statement for administrative & personal records</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <select
              value={period}
              onChange={e => setPeriod(e.target.value as any)}
              className="bg-white/10 text-white text-xs font-medium px-3 py-1.5 rounded-lg border border-white/20 focus:outline-none"
            >
              <option value="30" className="text-slate-900">Last 30 Days</option>
              <option value="90" className="text-slate-900">Last 90 Days</option>
              <option value="all" className="text-slate-900">All Transactions</option>
            </select>
            <button
              onClick={handleExportCSV}
              className="px-3 py-1.5 bg-white/10 hover:bg-white/20 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
              <span>CSV</span>
            </button>
            <button
              onClick={handlePrint}
              className="px-3 py-1.5 bg-[#c8102e] hover:bg-[#b00d27] text-white rounded-lg text-xs font-bold flex items-center gap-1.5 transition-colors shadow"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print / PDF</span>
            </button>
            <button
              onClick={onClose}
              aria-label="Close statement"
              className="p-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-white/10 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Statement Document */}
        <div className="print-modal-body p-6 sm:p-8 space-y-6 overflow-y-auto flex-1 bg-white text-slate-900">

          {/* Statement Header */}
          <div className="flex flex-col sm:flex-row items-start justify-between gap-6 pb-6 border-b-2 border-slate-900">
            <div>
              <div className="flex items-center gap-3">
                <img
                  src="/assets/aistudio/file_00000000763081f4a6c9438dcd4940cf_665e4923.png"
                  alt="FNB"
                  className="w-12 h-12 object-contain"
                />
                <div>
                  <h1 className="text-2xl font-black text-[#002752] tracking-tight">FIRST NATIONAL BANK</h1>
                  <p className="text-xs text-slate-500 font-semibold tracking-wide">FIRST NATIONAL BANK (FNB) GLOBAL BANKING</p>
                </div>
              </div>
              <div className="mt-4 text-xs text-slate-600 space-y-0.5">
                <p>13586 US-90, Boutte, LA 70039, United States</p>
                <p>Phone: +12724736857 | WhatsApp: +12724736857</p>
                <p>Official Enquiries: info@fnnbbankss.online</p>
              </div>
            </div>

            <div className="sm:text-right text-xs">
              <span className="inline-block px-3 py-1 bg-slate-100 text-slate-800 font-extrabold uppercase rounded mb-2 tracking-wider">
                Statement of Account
              </span>
              <p className="text-slate-500">Date Generated: <strong className="text-slate-900">{new Date().toLocaleDateString('en-US')}</strong></p>
              <p className="text-slate-500">Statement ID: <strong className="text-slate-900 font-mono">STM-{new Date().getFullYear()}-{Math.floor(100000 + Math.random() * 900000)}</strong></p>
              <p className="text-slate-500">Currency: <strong className="text-slate-900">USD ($)</strong></p>
            </div>
          </div>

          {/* Account & Customer Summary Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
              <h4 className="font-bold text-slate-500 uppercase tracking-wider text-[11px] mb-2">Account Holder Details</h4>
              <p className="text-base font-extrabold text-[#002752]">{user.firstName} {user.lastName}</p>
              <p className="text-slate-600">Email: {user.email}</p>
              <p className="text-slate-600">Registered Phone: {user.phone}</p>
              <p className="text-slate-600">Status: <span className="text-emerald-700 font-bold uppercase">{user.status}</span></p>
            </div>

            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
              <h4 className="font-bold text-slate-500 uppercase tracking-wider text-[11px] mb-2">Banking Coordinates</h4>
              <div className="flex justify-between py-1">
                <span className="text-slate-500">Account Number:</span>
                <span className="font-mono font-bold text-slate-900">{user.accountNumber || 'Pending'}</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-slate-500">Sort Code:</span>
                <span className="font-mono font-bold text-slate-900">{user.sortCode || '20-04-15'}</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-slate-500">Account Currency:</span>
                <span className="font-mono font-semibold text-slate-700">USD ($)</span>
              </div>
            </div>
          </div>

          {/* Financial Breakdown Totals */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 p-4 bg-slate-900 text-white rounded-xl text-center">
            <div>
              <p className="text-[11px] text-slate-400 font-semibold uppercase">Total Credits</p>
              <p className="text-lg font-black text-emerald-400">
                +{USD_SYMBOL}{formatUsdNumber(totalCredits)} {USD_CODE}
              </p>
            </div>
            <div>
              <p className="text-[11px] text-slate-400 font-semibold uppercase">Total Debits</p>
              <p className="text-lg font-black text-rose-400">
                -{USD_SYMBOL}{formatUsdNumber(totalDebits)} {USD_CODE}
              </p>
            </div>
            <div>
              <p className="text-[11px] text-slate-400 font-semibold uppercase">Closing Balance</p>
              <p className="text-lg font-black text-white">
                {USD_SYMBOL}{formatUsdNumber(Number(user.balance))} {USD_CODE}
              </p>
            </div>
          </div>

          {/* Ledger Table */}
          <div>
            <h3 className="font-bold text-sm text-[#002752] uppercase tracking-wider mb-3">
              Transaction Ledger ({filtered.length} entries)
            </h3>

            <div className="border border-slate-200 rounded-lg overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-slate-100 border-b border-slate-200 text-slate-700 font-bold">
                    <th className="py-2.5 px-3">Date</th>
                    <th className="py-2.5 px-3">Reference</th>
                    <th className="py-2.5 px-3">Description</th>
                    <th className="py-2.5 px-3">Category Tag</th>
                    <th className="py-2.5 px-3">Type</th>
                    <th className="py-2.5 px-3 text-right">Amount ({USD_CODE})</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filtered.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="py-6 text-center text-slate-400">
                        No transactions recorded for this statement period.
                      </td>
                    </tr>
                  ) : (
                    filtered.map(t => {
                      const isCredit = t.type === 'credit' || t.type === 'reversal';
                      return (
                        <tr key={t.id} className="hover:bg-slate-50/80">
                          <td className="py-2.5 px-3 text-slate-600 whitespace-nowrap">
                            {new Date(t.createdAt).toLocaleDateString('en-US')}
                          </td>
                          <td className="py-2.5 px-3 font-mono font-medium text-slate-800 whitespace-nowrap">
                            {t.reference}
                          </td>
                          <td className="py-2.5 px-3 text-slate-800 max-w-xs truncate font-medium">
                            {t.description}
                          </td>
                          <td className="py-2.5 px-3 whitespace-nowrap">
                            <TransactionTagBadge
                              tag={t.tag || tagTransaction(t.description, t.type, t.billerCategory).tag}
                            />
                          </td>
                          <td className="py-2.5 px-3 uppercase text-[10px] font-bold text-slate-500">
                            {t.type}
                          </td>
                          <td className={`py-2.5 px-3 text-right font-bold whitespace-nowrap ${
                            isCredit ? 'text-emerald-700' : 'text-slate-900'
                          }`}>
                            {isCredit ? '+' : '-'}{USD_SYMBOL}{formatUsdNumber(Number(t.amount))}
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Statement Footer Certification */}
          <div className="pt-6 border-t border-slate-200 text-[11px] text-slate-500 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-emerald-600" />
              <span>Certified Electronic Banking Statement • FNB Verification Engine</span>
            </div>
            <p>© {new Date().getFullYear()} First National Bank. All rights reserved.</p>
          </div>

        </div>

      </div>
    </div>
  );
};
