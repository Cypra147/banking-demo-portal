import React, { useState, useEffect } from 'react';
import { User } from '../types.ts';
import { api } from '../services/api.ts';
import {
  ShieldCheck,
  KeyRound,
  Lock,
  CheckCircle2,
  AlertCircle,
  Mail,
  RefreshCw,
  ArrowLeft,
  ShieldAlert,
} from 'lucide-react';

interface TransactionPinManagerProps {
  user: User;
  initialMode?: 'auto' | 'setup' | 'change' | 'forgot';
  onPinUpdated?: () => Promise<void> | void;
  onOpenMailbox?: () => void;
  theme?: 'default' | 'navy';
}

export const TransactionPinManager: React.FC<TransactionPinManagerProps> = ({
  user,
  initialMode = 'auto',
  onPinUpdated,
  onOpenMailbox,
  theme = 'default',
}) => {
  const isNavy = theme === 'navy';
  const resolveDefaultMode = (pref: 'auto' | 'setup' | 'change' | 'forgot') => {
    if (pref === 'forgot') return 'forgot';
    if (!user.hasTransactionPin) return 'setup';
    if (pref === 'setup') return 'change';
    return 'change';
  };

  const [mode, setMode] = useState<'setup' | 'change' | 'forgot'>(() =>
    resolveDefaultMode(initialMode)
  );

  useEffect(() => {
    if (initialMode === 'forgot') {
      setMode('forgot');
    } else if (initialMode === 'setup' && !user.hasTransactionPin) {
      setMode('setup');
    } else if (initialMode === 'change' && user.hasTransactionPin) {
      setMode('change');
    } else if (initialMode === 'auto') {
      setMode(user.hasTransactionPin ? 'change' : 'setup');
    }
  }, [initialMode, user.hasTransactionPin]);

  const [pinLength, setPinLength] = useState<4 | 6>(user.transactionPinLength || 4);
  const [pinInput, setPinInput] = useState('');
  const [confirmPinInput, setConfirmPinInput] = useState('');
  const [currentPinInput, setCurrentPinInput] = useState('');

  // Forgot PIN recovery state
  const [forgotStep, setForgotStep] = useState<'verify_password' | 'enter_code'>('verify_password');
  const [accountPassword, setAccountPassword] = useState('');
  const [recoveryCode, setRecoveryCode] = useState('');
  const [resetTargetEmail, setResetTargetEmail] = useState(user.email);

  const [submitting, setSubmitting] = useState(false);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const isLocked = Boolean(user.pinLockedUntil && Date.now() < user.pinLockedUntil);
  const lockMinutesRemaining = user.pinLockedUntil
    ? Math.max(1, Math.ceil((user.pinLockedUntil - Date.now()) / 60000))
    : 0;

  const sanitizeNumeric = (val: string, maxLen: number) =>
    val.replace(/\D/g, '').slice(0, maxLen);

  const clearInputs = () => {
    setPinInput('');
    setConfirmPinInput('');
    setCurrentPinInput('');
    setAccountPassword('');
    setRecoveryCode('');
  };

  const handleSetupPin = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    if (pinInput.length !== pinLength) {
      setErrorMsg(`Please enter a ${pinLength}-digit numeric Transaction PIN.`);
      return;
    }
    if (pinInput !== confirmPinInput) {
      setErrorMsg('Transaction PIN and confirmation PIN do not match. Please enter both identically.');
      return;
    }

    setSubmitting(true);
    try {
      const res = await api.setupTransactionPin(pinInput, confirmPinInput);
      clearInputs();
      setSuccessMsg(res.message || `${pinLength}-digit Transaction PIN created successfully.`);
      if (onPinUpdated) await onPinUpdated();
      setMode('change');
    } catch (err: any) {
      setErrorMsg(err.message || 'Unable to set up Transaction PIN.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleChangePin = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    if (!/^(?:\d{4}|\d{6})$/.test(currentPinInput)) {
      setErrorMsg('Please enter your current 4-digit or 6-digit Transaction PIN.');
      return;
    }
    if (pinInput.length !== pinLength) {
      setErrorMsg(`New Transaction PIN must be ${pinLength} digits.`);
      return;
    }
    if (pinInput !== confirmPinInput) {
      setErrorMsg('New Transaction PIN and confirmation PIN do not match.');
      return;
    }

    setSubmitting(true);
    try {
      const res = await api.changeTransactionPin(currentPinInput, pinInput, confirmPinInput);
      clearInputs();
      setSuccessMsg(res.message || 'Your Transaction PIN has been updated successfully.');
      if (onPinUpdated) await onPinUpdated();
    } catch (err: any) {
      setErrorMsg(err.message || 'Unable to change Transaction PIN.');
      if (err.code === 'PIN_LOCKED' && onPinUpdated) {
        await onPinUpdated();
      }
    } finally {
      setSubmitting(false);
    }
  };

  const handleRequestForgotCode = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    if (!accountPassword) {
      setErrorMsg('Please enter your account password to verify your identity.');
      return;
    }

    setSubmitting(true);
    try {
      const res = await api.forgotTransactionPin(accountPassword);
      setAccountPassword('');
      setResetTargetEmail(res.email || user.email);
      setForgotStep('enter_code');
      setSuccessMsg(res.message);
    } catch (err: any) {
      setErrorMsg(err.message || 'Identity verification failed.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleResetPin = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    if (!/^\d{6}$/.test(recoveryCode.trim())) {
      setErrorMsg('Please enter the 6-digit security verification code sent to your email.');
      return;
    }
    if (pinInput.length !== pinLength) {
      setErrorMsg(`New Transaction PIN must be ${pinLength} numeric digits.`);
      return;
    }
    if (pinInput !== confirmPinInput) {
      setErrorMsg('New Transaction PIN and confirmation PIN do not match.');
      return;
    }

    setSubmitting(true);
    try {
      const res = await api.resetTransactionPin(recoveryCode.trim(), pinInput, confirmPinInput);
      clearInputs();
      setForgotStep('verify_password');
      setSuccessMsg(res.message || 'Your Transaction PIN has been securely reset.');
      if (onPinUpdated) await onPinUpdated();
      setMode('change');
    } catch (err: any) {
      setErrorMsg(err.message || 'Unable to reset Transaction PIN.');
    } finally {
      setSubmitting(false);
    }
  };

  const cardCls = isNavy
    ? 'bg-[#071832] rounded-2xl border border-blue-800/50 p-5 sm:p-6 space-y-5 text-white'
    : 'bg-slate-50 dark:bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 sm:p-6 space-y-5';
  const labelCls = isNavy ? 'block text-xs font-semibold text-blue-200 mb-1' : 'block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1';
  const inputCls = isNavy
    ? 'w-full px-3.5 py-2.5 text-sm font-mono tracking-[0.4em] bg-[#041022] border border-blue-800/60 rounded-xl text-white placeholder-blue-300/40 focus:outline-none focus:ring-2 focus:ring-blue-400/50'
    : 'w-full px-3.5 py-2.5 text-sm font-mono tracking-[0.4em] bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#002752]';

  return (
    <div className={cardCls}>
      {/* Header & Status Badge */}
      <div className={`flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b ${isNavy ? 'border-blue-800/50' : 'border-slate-200 dark:border-slate-800'}`}>
        <div className="flex items-start gap-3">
          <div className={`w-10 h-10 rounded-xl ${isNavy ? 'bg-[#12396f]' : 'bg-[#002752]'} text-white flex items-center justify-center shrink-0`}>
            <KeyRound className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className={`font-bold text-base ${isNavy ? 'text-white' : 'text-slate-900 dark:text-white'}`}>Transaction PIN</h3>
              {isLocked ? (
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-red-100 text-red-700 dark:bg-red-950/60 dark:text-red-300">
                  Locked ({lockMinutesRemaining}m)
                </span>
              ) : user.hasTransactionPin ? (
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-emerald-100 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300">
                  {user.transactionPinLength || 4}-Digit Active
                </span>
              ) : (
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300">
                  Not Configured
                </span>
              )}
            </div>
            <p className={`text-xs mt-0.5 ${isNavy ? 'text-blue-200/75' : 'text-slate-500'}`}>
              Required to authorize transfers, withdrawals, bill payments, and investments
            </p>
          </div>
        </div>

        {user.hasTransactionPin && (
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => {
                setErrorMsg(null);
                setSuccessMsg(null);
                setMode('change');
              }}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors ${
                mode === 'change'
                  ? 'bg-[#12396f] text-white'
                  : isNavy
                  ? 'bg-[#0b2347] border border-blue-800/60 text-blue-100'
                  : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
              }`}
            >
              Change PIN
            </button>
            <button
              type="button"
              onClick={() => {
                setErrorMsg(null);
                setSuccessMsg(null);
                setForgotStep('verify_password');
                setMode('forgot');
              }}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors ${
                mode === 'forgot'
                  ? 'bg-[#c8102e] text-white'
                  : isNavy
                  ? 'bg-[#0b2347] border border-blue-800/60 text-rose-300'
                  : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-[#c8102e] dark:text-red-400'
              }`}
            >
              Forgot PIN?
            </button>
          </div>
        )}
      </div>

      {/* Temporary Security Lock Alert */}
      {isLocked && mode !== 'forgot' && (
        <div className="p-4 rounded-xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 text-xs text-red-700 dark:text-red-300 flex items-start gap-2.5">
          <ShieldAlert className="w-4 h-4 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <strong className="block">Transaction PIN Temporarily Locked</strong>
            <p>
              Multiple incorrect PIN entries triggered a 15-minute safeguard ({lockMinutesRemaining} minute(s) remaining). You may wait for the timer to expire or verify your identity via{' '}
              <button
                type="button"
                onClick={() => {
                  setErrorMsg(null);
                  setForgotStep('verify_password');
                  setMode('forgot');
                }}
                className="underline font-bold"
              >
                Forgot Transaction PIN?
              </button>
              .
            </p>
          </div>
        </div>
      )}

      {successMsg && (
        <div className="p-3.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-xs text-emerald-800 dark:text-emerald-200 flex items-start gap-2">
          <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />
          <span>{successMsg}</span>
        </div>
      )}

      {errorMsg && (
        <div className="p-3.5 rounded-xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 text-xs text-red-700 dark:text-red-300 flex items-start gap-2">
          <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
          <span>{errorMsg}</span>
        </div>
      )}

      {/* MODE 1: CREATE PIN */}
      {mode === 'setup' && (
        <form onSubmit={handleSetupPin} className="space-y-4">
          <div>
            <label className={labelCls}>
              Select PIN Length
            </label>
            <div className="grid grid-cols-2 gap-2.5 max-w-xs">
              {([4, 6] as const).map(len => (
                <button
                  key={len}
                  type="button"
                  onClick={() => {
                    setPinLength(len);
                    setPinInput(prev => prev.slice(0, len));
                    setConfirmPinInput(prev => prev.slice(0, len));
                  }}
                  className={`py-2 px-3 rounded-xl text-xs font-bold border transition-all ${
                    pinLength === len
                      ? 'bg-[#c8102e] text-white border-[#c8102e]'
                      : isNavy
                      ? 'bg-[#0b2347] text-blue-100 border-blue-800/60'
                      : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border-slate-300 dark:border-slate-700'
                  }`}
                >
                  {len}-Digit PIN
                </button>
              ))}
            </div>
          </div>

          <div className="grid sm:grid-cols-2 gap-4">
            <div>
              <label className={labelCls}>
                Create {pinLength}-Digit Transaction PIN
              </label>
              <input
                type="password"
                inputMode="numeric"
                autoComplete="new-password"
                maxLength={pinLength}
                required
                placeholder={'•'.repeat(pinLength)}
                value={pinInput}
                onChange={e => setPinInput(sanitizeNumeric(e.target.value, pinLength))}
                className={inputCls}
              />
            </div>

            <div>
              <label className={labelCls}>
                Confirm Transaction PIN
              </label>
              <input
                type="password"
                inputMode="numeric"
                autoComplete="new-password"
                maxLength={pinLength}
                required
                placeholder={'•'.repeat(pinLength)}
                value={confirmPinInput}
                onChange={e => setConfirmPinInput(sanitizeNumeric(e.target.value, pinLength))}
                className={inputCls}
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={submitting}
            className="px-6 py-2.5 bg-[#c8102e] hover:bg-[#a50d26] disabled:opacity-50 text-white font-bold rounded-xl text-xs shadow transition-colors flex items-center gap-2"
          >
            <ShieldCheck className="w-4 h-4" />
            <span>{submitting ? 'Securing PIN...' : 'Create Transaction PIN'}</span>
          </button>
        </form>
      )}

      {/* MODE 2: CHANGE PIN */}
      {mode === 'change' && (
        <form onSubmit={handleChangePin} className="space-y-4">
          <div className="grid sm:grid-cols-2 gap-4">
            <div>
              <label className={labelCls}>
                Current Transaction PIN
              </label>
              <input
                type="password"
                inputMode="numeric"
                autoComplete="off"
                maxLength={6}
                required
                placeholder="••••"
                value={currentPinInput}
                onChange={e => setCurrentPinInput(sanitizeNumeric(e.target.value, 6))}
                className={inputCls}
              />
            </div>

            <div>
              <label className={labelCls}>
                New PIN Length
              </label>
              <div className="grid grid-cols-2 gap-2">
                {([4, 6] as const).map(len => (
                  <button
                    key={len}
                    type="button"
                    onClick={() => {
                      setPinLength(len);
                      setPinInput(prev => prev.slice(0, len));
                      setConfirmPinInput(prev => prev.slice(0, len));
                    }}
                    className={`py-2.5 px-3 rounded-xl text-xs font-bold border transition-all ${
                      pinLength === len
                        ? 'bg-[#c8102e] text-white border-[#c8102e]'
                        : isNavy
                        ? 'bg-[#0b2347] text-blue-100 border-blue-800/60'
                        : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border-slate-300 dark:border-slate-700'
                    }`}
                  >
                    {len}-Digit
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="grid sm:grid-cols-2 gap-4">
            <div>
              <label className={labelCls}>
                New {pinLength}-Digit Transaction PIN
              </label>
              <input
                type="password"
                inputMode="numeric"
                autoComplete="new-password"
                maxLength={pinLength}
                required
                placeholder={'•'.repeat(pinLength)}
                value={pinInput}
                onChange={e => setPinInput(sanitizeNumeric(e.target.value, pinLength))}
                className={inputCls}
              />
            </div>

            <div>
              <label className={labelCls}>
                Confirm New Transaction PIN
              </label>
              <input
                type="password"
                inputMode="numeric"
                autoComplete="new-password"
                maxLength={pinLength}
                required
                placeholder={'•'.repeat(pinLength)}
                value={confirmPinInput}
                onChange={e => setConfirmPinInput(sanitizeNumeric(e.target.value, pinLength))}
                className={inputCls}
              />
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
            <button
              type="submit"
              disabled={submitting || isLocked}
              className="px-6 py-2.5 bg-[#002752] hover:bg-[#001d3d] disabled:opacity-50 text-white font-bold rounded-xl text-xs shadow transition-colors flex items-center gap-2"
            >
              <Lock className="w-4 h-4" />
              <span>{submitting ? 'Updating PIN...' : 'Update Transaction PIN'}</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setErrorMsg(null);
                setSuccessMsg(null);
                setForgotStep('verify_password');
                setMode('forgot');
              }}
              className="text-xs font-bold text-[#c8102e] hover:underline"
            >
              Forgot Transaction PIN?
            </button>
          </div>
        </form>
      )}

      {/* MODE 3: FORGOT TRANSACTION PIN */}
      {mode === 'forgot' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between gap-2">
            <p className={`text-xs font-semibold ${isNavy ? 'text-blue-200' : 'text-slate-700 dark:text-slate-300'}`}>
              Authorized Identity Verification — Existing PINs are never stored in readable form or revealed.
            </p>
            <button
              type="button"
              onClick={() => {
                setErrorMsg(null);
                setSuccessMsg(null);
                setMode(user.hasTransactionPin ? 'change' : 'setup');
              }}
              className={`text-xs font-bold hover:underline flex items-center gap-1 shrink-0 ${isNavy ? 'text-blue-300' : 'text-[#002752] dark:text-blue-400'}`}
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Back</span>
            </button>
          </div>

          {forgotStep === 'verify_password' ? (
            <form onSubmit={handleRequestForgotCode} className="space-y-4">
              <div>
                <label className={labelCls}>
                  Enter Your Account Login Password
                </label>
                <input
                  type="password"
                  required
                  placeholder="Enter your FNB login password"
                  value={accountPassword}
                  onChange={e => setAccountPassword(e.target.value)}
                  className={isNavy
                    ? 'w-full px-3.5 py-2.5 text-xs sm:text-sm bg-[#041022] border border-blue-800/60 rounded-xl text-white placeholder-blue-300/40 focus:outline-none focus:ring-2 focus:ring-blue-400/50'
                    : 'w-full px-3.5 py-2.5 text-xs sm:text-sm bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#002752]'
                  }
                />
                <p className={`text-[11px] mt-1 ${isNavy ? 'text-blue-200/75' : 'text-slate-500'}`}>
                  After password verification, a 6-digit one-time reset code will be sent to{' '}
                  <strong className={isNavy ? 'text-white' : 'text-slate-700 dark:text-slate-300'}>{user.email}</strong>.
                </p>
              </div>

              <button
                type="submit"
                disabled={submitting}
                className="px-6 py-2.5 bg-[#c8102e] hover:bg-[#a50d26] disabled:opacity-50 text-white font-bold rounded-xl text-xs shadow transition-colors flex items-center gap-2"
              >
                <Mail className="w-4 h-4" />
                <span>{submitting ? 'Verifying Identity...' : 'Send Verification Code'}</span>
              </button>
            </form>
          ) : (
            <form onSubmit={handleResetPin} className="space-y-4">
              <div className={`p-3 rounded-xl border text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-2 ${isNavy ? 'bg-[#0b2347] border-blue-700/60 text-blue-100' : 'bg-blue-50 dark:bg-blue-950/40 border-blue-200 dark:border-blue-800 text-blue-900 dark:text-blue-200'}`}>
                <span>
                  Verification code sent to <strong>{resetTargetEmail}</strong> (valid 10 minutes).
                </span>
                {onOpenMailbox && (
                  <button
                    type="button"
                    onClick={onOpenMailbox}
                    className="px-3 py-1 rounded-lg bg-[#c8102e] text-white font-bold text-[11px] shrink-0 self-start sm:self-auto"
                  >
                    Open FNB Mailbox
                  </button>
                )}
              </div>

              <div className="grid sm:grid-cols-2 gap-4">
                <div>
                  <label className={labelCls}>
                    6-Digit Verification Code
                  </label>
                  <input
                    type="text"
                    inputMode="numeric"
                    maxLength={6}
                    required
                    placeholder="6-digit code"
                    value={recoveryCode}
                    onChange={e => setRecoveryCode(sanitizeNumeric(e.target.value, 6))}
                    className={inputCls}
                  />
                </div>

                <div>
                  <label className={labelCls}>
                    New PIN Length
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    {([4, 6] as const).map(len => (
                      <button
                        key={len}
                        type="button"
                        onClick={() => {
                          setPinLength(len);
                          setPinInput(prev => prev.slice(0, len));
                          setConfirmPinInput(prev => prev.slice(0, len));
                        }}
                        className={`py-2.5 px-3 rounded-xl text-xs font-bold border transition-all ${
                          pinLength === len
                            ? 'bg-[#c8102e] text-white border-[#c8102e]'
                            : isNavy
                            ? 'bg-[#0b2347] text-blue-100 border-blue-800/60'
                            : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border-slate-300 dark:border-slate-700'
                        }`}
                      >
                        {len}-Digit
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <div className="grid sm:grid-cols-2 gap-4">
                <div>
                  <label className={labelCls}>
                    New {pinLength}-Digit Transaction PIN
                  </label>
                  <input
                    type="password"
                    inputMode="numeric"
                    autoComplete="new-password"
                    maxLength={pinLength}
                    required
                    placeholder={'•'.repeat(pinLength)}
                    value={pinInput}
                    onChange={e => setPinInput(sanitizeNumeric(e.target.value, pinLength))}
                    className={inputCls}
                  />
                </div>

                <div>
                  <label className={labelCls}>
                    Confirm New Transaction PIN
                  </label>
                  <input
                    type="password"
                    inputMode="numeric"
                    autoComplete="new-password"
                    maxLength={pinLength}
                    required
                    placeholder={'•'.repeat(pinLength)}
                    value={confirmPinInput}
                    onChange={e => setConfirmPinInput(sanitizeNumeric(e.target.value, pinLength))}
                    className={inputCls}
                  />
                </div>
              </div>

              <div className="flex flex-wrap items-center justify-between gap-3">
                <button
                  type="submit"
                  disabled={submitting}
                  className="px-6 py-2.5 bg-[#c8102e] hover:bg-[#a50d26] disabled:opacity-50 text-white font-bold rounded-xl text-xs shadow transition-colors flex items-center gap-2"
                >
                  <RefreshCw className="w-4 h-4" />
                  <span>{submitting ? 'Resetting PIN...' : 'Verify Code & Reset PIN'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setErrorMsg(null);
                    setForgotStep('verify_password');
                  }}
                  className={`text-xs font-semibold ${isNavy ? 'text-blue-300 hover:text-white' : 'text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'}`}
                >
                  Request New Code
                </button>
              </div>
            </form>
          )}
        </div>
      )}

      {/* Security Anti-Phishing Notice */}
      <div className={`pt-3 border-t flex items-start gap-2 text-[11px] ${isNavy ? 'border-blue-800/50 text-blue-200/70' : 'border-slate-200 dark:border-slate-800 text-slate-500'}`}>
        <Lock className={`w-3.5 h-3.5 shrink-0 mt-0.5 ${isNavy ? 'text-blue-300' : 'text-[#002752] dark:text-blue-400'}`} />
        <span>
          Security Notice: Never share your Transaction PIN with anyone. FNB personnel will never ask for your PIN by telephone, email, support ticket, or WhatsApp.
        </span>
      </div>
    </div>
  );
};
