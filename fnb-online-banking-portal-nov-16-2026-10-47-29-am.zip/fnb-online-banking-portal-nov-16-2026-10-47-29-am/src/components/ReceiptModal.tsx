import React from 'react';
import { Transaction } from '../types.ts';
import {
  X,
  Printer,
  CheckCircle2,
} from 'lucide-react';
import { TransactionTagBadge } from './TransactionTagBadge.tsx';
import { tagTransaction } from '../utils/transactionTagger.ts';
import { formatUsdNumber, USD_SYMBOL, USD_CODE } from '../utils/currency.ts';

interface ReceiptModalProps {
  transaction: Transaction | null;
  onClose: () => void;
  onReversalSuccess?: () => void;
}

export const ReceiptModal: React.FC<ReceiptModalProps> = ({
  transaction,
  onClose,
}) => {
  if (!transaction) return null;

  const handlePrint = () => {
    document.body.classList.add('printing-modal');
    const cleanup = () => {
      document.body.classList.remove('printing-modal');
      window.removeEventListener('afterprint', cleanup);
    };
    window.addEventListener('afterprint', cleanup);
    window.print();
    setTimeout(cleanup, 1000);
  };

  const formattedAmount = `${USD_SYMBOL}${formatUsdNumber(Number(transaction.amount))}`;

  return (
    <div className="print-modal-root fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-sm animate-fade-in">
      <div className="print-modal-card relative w-full max-w-lg bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col max-h-[92vh]">

        {/* Header */}
        <div className="p-6 pb-4 border-b border-slate-100 dark:border-slate-800 flex items-start justify-between">
          <div className="flex items-center gap-3">
            <img
              src="/assets/aistudio/file_00000000763081f4a6c9438dcd4940cf_665e4923.png"
              alt="FNB Logo"
              className="w-12 h-12 object-contain rounded-xl shadow-sm"
            />
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold text-xl tracking-tight text-[#002752] dark:text-white">
                  FIRST NATIONAL BANK
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Electronic Transaction Receipt
              </p>
              <p className="text-[11px] font-medium tracking-wide text-slate-400 dark:text-slate-500 mt-0.5">
                PREVIEW RECEIPT
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            aria-label="Close receipt"
            className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors print:hidden"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Receipt Body */}
        <div className="print-modal-body p-6 space-y-5 overflow-y-auto flex-1">

          {/* Payment Summary & Amount Highlight */}
          <div className="text-center py-4 px-4 bg-slate-50 dark:bg-slate-950 rounded-2xl border border-slate-200/80 dark:border-slate-800">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400 rounded-full text-xs font-semibold mb-2">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>{transaction.isReversed ? 'Transaction Reversed' : 'Payment Summary • Completed'}</span>
            </div>

            <div className="text-3xl sm:text-4xl font-extrabold tracking-tight text-[#002752] dark:text-white">
              {formattedAmount}{' '}
              <span className="text-base sm:text-lg font-bold text-slate-500 dark:text-slate-400">
                {USD_CODE}
              </span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              {transaction.description || 'Electronic Funds Transfer'}
            </p>
          </div>

          {/* Key Details Table */}
          <div className="space-y-3 text-xs sm:text-sm">
            <div className="flex justify-between py-2 border-b border-slate-100 dark:border-slate-800 gap-4">
              <span className="text-slate-500 dark:text-slate-400">Transaction Reference</span>
              <span className="font-mono font-bold text-slate-900 dark:text-white text-right">
                {transaction.reference}
              </span>
            </div>

            <div className="flex justify-between py-2 border-b border-slate-100 dark:border-slate-800 gap-4">
              <span className="text-slate-500 dark:text-slate-400">Transaction Date & Time</span>
              <span className="font-medium text-slate-800 dark:text-slate-200 text-right">
                {new Date(transaction.createdAt).toLocaleString('en-US')}
              </span>
            </div>

            <div className="flex justify-between py-2 border-b border-slate-100 dark:border-slate-800 items-center gap-4">
              <span className="text-slate-500 dark:text-slate-400">Transaction Category</span>
              <TransactionTagBadge
                tag={transaction.tag || tagTransaction(transaction.description, transaction.type, transaction.billerCategory).tag}
                showIcon
                size="md"
              />
            </div>

            {transaction.type === 'transfer' && (
              <div className="flex justify-between py-2 border-b border-slate-100 dark:border-slate-800 gap-4">
                <span className="text-slate-500 dark:text-slate-400">Transfer Channel</span>
                <span className="font-semibold text-slate-900 dark:text-white text-right">
                  {transaction.transferScope === 'international' ? 'International Wire (SWIFT)' : 'Domestic Bank Transfer'}
                </span>
              </div>
            )}

            {transaction.beneficiaryName && (
              <div className="flex justify-between py-2 border-b border-slate-100 dark:border-slate-800 gap-4">
                <span className="text-slate-500 dark:text-slate-400">Beneficiary Name</span>
                <span className="font-semibold text-slate-900 dark:text-white text-right">
                  {transaction.beneficiaryName}
                </span>
              </div>
            )}

            {transaction.beneficiaryBank && (
              <div className="flex justify-between py-2 border-b border-slate-100 dark:border-slate-800 gap-4">
                <span className="text-slate-500 dark:text-slate-400 shrink-0">Beneficiary Bank</span>
                <span className="font-medium text-slate-800 dark:text-slate-200 text-right">
                  {transaction.beneficiaryBank}
                </span>
              </div>
            )}

            {transaction.beneficiaryCountry && (
              <div className="flex justify-between py-2 border-b border-slate-100 dark:border-slate-800 gap-4">
                <span className="text-slate-500 dark:text-slate-400">Destination Country</span>
                <span className="font-medium text-slate-800 dark:text-slate-200 text-right">
                  {transaction.beneficiaryCountry}
                </span>
              </div>
            )}

            {transaction.beneficiaryAccount && (
              <div className="flex justify-between py-2 border-b border-slate-100 dark:border-slate-800 gap-4">
                <span className="text-slate-500 dark:text-slate-400 shrink-0">Destination Account / IBAN</span>
                <span className="font-mono font-medium text-slate-800 dark:text-slate-200 text-right break-all">
                  {transaction.beneficiaryAccount}
                </span>
              </div>
            )}

            {transaction.swiftBic && (
              <div className="flex justify-between py-2 border-b border-slate-100 dark:border-slate-800 gap-4">
                <span className="text-slate-500 dark:text-slate-400">SWIFT / BIC</span>
                <span className="font-mono font-medium text-slate-800 dark:text-slate-200 text-right">
                  {transaction.swiftBic}
                </span>
              </div>
            )}

            {transaction.routingCode && (
              <div className="flex justify-between py-2 border-b border-slate-100 dark:border-slate-800 gap-4">
                <span className="text-slate-500 dark:text-slate-400">Routing / Sort Code</span>
                <span className="font-mono font-medium text-slate-800 dark:text-slate-200 text-right">
                  {transaction.routingCode}
                </span>
              </div>
            )}

            {transaction.withdrawalMethod && (
              <div className="flex justify-between py-2 border-b border-slate-100 dark:border-slate-800 gap-4">
                <span className="text-slate-500 dark:text-slate-400">Withdrawal Method</span>
                <span className="font-semibold text-slate-900 dark:text-white text-right">
                  {transaction.withdrawalMethod}
                </span>
              </div>
            )}

            <div className="flex justify-between py-2 border-b border-slate-100 dark:border-slate-800 gap-4">
              <span className="text-slate-500 dark:text-slate-400">Sender Account</span>
              <span className="font-mono text-slate-800 dark:text-slate-200 text-right">
                {transaction.customerName ? `${transaction.customerName} • ` : ''}{transaction.accountNumber || 'Primary Checking'}
              </span>
            </div>

            <div className="flex justify-between py-2 gap-4">
              <span className="text-slate-500 dark:text-slate-400">Sort Code</span>
              <span className="font-mono font-semibold text-slate-800 dark:text-slate-200 text-right">
                20-04-15
              </span>
            </div>
          </div>

          {/* Official Bank Signoff */}
          <div className="text-[11px] text-slate-400 text-center space-y-1 pt-2 border-t border-slate-100 dark:border-slate-800">
            <p className="font-semibold text-slate-500 dark:text-slate-400">FIRST NATIONAL BANK (FNB) • ELECTRONIC BANKING DIVISION</p>
            <p>13586 US-90, Boutte, LA 70039, United States</p>
            <p>Tel: +12724736857 | WhatsApp: +12724736857 | info@fnnbbankss.online</p>
          </div>
        </div>

        {/* Modal Actions */}
        <div className="p-4 bg-slate-50 dark:bg-slate-950 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3 print:hidden">
          <button
            onClick={handlePrint}
            className="px-4 py-2 bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 rounded-xl text-xs font-semibold flex items-center gap-2 transition-colors"
          >
            <Printer className="w-4 h-4" />
            <span>Print Receipt</span>
          </button>

          <button
            onClick={onClose}
            className="px-6 py-2 bg-[#c8102e] hover:bg-[#b00d27] text-white rounded-xl text-xs font-bold transition-all shadow-md"
          >
            Done
          </button>
        </div>

      </div>
    </div>
  );
};
