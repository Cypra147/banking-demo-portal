/**
 * FNB Digital Banking Simulator - Core Types
 */

export type UserRole = 'customer' | 'admin';

export type AccountStatus = 'pending_approval' | 'active' | 'frozen' | 'suspended' | 'rejected';

export type TransactionType = 'credit' | 'debit' | 'transfer' | 'withdrawal' | 'bill_payment' | 'reversal' | 'investment';

export type TransactionStatus = 'completed' | 'pending' | 'reversed' | 'rejected';

export interface User {
  id: string;
  email: string;
  username: string;
  firstName: string;
  middleName?: string;
  lastName: string;
  fullName?: string;
  dateOfBirth?: string;
  phone: string;
  country?: string;
  state?: string;
  residentialAddress?: string;
  postalCode?: string;
  role: UserRole;
  status: AccountStatus;
  accountNumber?: string;
  sortCode?: string;
  accountType?: string; // Checking, High Yield Savings, Premium Wealth
  balance: number;
  currency: string;
  createdAt: string;
  approvedAt?: string;
  registrationReference?: string;
  isTwoFactorEnabled?: boolean;
  notificationPreferences?: {
    emailAlerts: boolean;
    smsAlerts: boolean;
  };
  kycStatus?: 'unverified' | 'pending' | 'pending_review' | 'verified' | 'rejected';
  hasTransactionPin?: boolean;
  transactionPinLength?: 4 | 6;
  transactionPinUpdatedAt?: string;
  pinLockedUntil?: number;
}

export interface Transaction {
  id: string;
  reference: string;
  userId: string;
  customerName: string;
  accountNumber: string;
  type: TransactionType;
  amount: number;
  currency: string;
  status: TransactionStatus;
  description: string;
  beneficiaryName?: string;
  beneficiaryBank?: string;
  beneficiaryAccount?: string;
  transferScope?: 'domestic' | 'international';
  beneficiaryCountry?: string;
  swiftBic?: string;
  routingCode?: string;
  billerCategory?: string;
  billerName?: string;
  withdrawalMethod?: string;
  destinationAccount?: string;
  isSandbox: boolean;
  isReversed?: boolean;
  reversedAt?: string;
  scheduledReversalAt?: number;
  tag?: string;
  tags?: string[];
  category?: string;
  createdAt: string;
  adminNote?: string;
}

export interface VirtualCard {
  id: string;
  userId: string;
  cardNumber: string; // 16 digits
  cardHolder: string;
  expiryDate: string; // MM/YY
  cvv: string;
  status: 'active' | 'frozen';
  dailyLimit: number;
  onlineTransactionsEnabled: boolean;
  colorTheme: 'navy' | 'crimson' | 'black' | 'gold';
}

export interface InvestmentPlan {
  id: string;
  name: string;
  category: string;
  riskLevel: 'Conservative' | 'Moderate' | 'Growth' | 'Aggressive' | 'Low Risk' | 'Moderate Risk' | 'Moderate-High' | 'High Risk';
  minAmount?: number;
  minimumAmount: number;
  maxAmount?: number;
  maximumAmount: number;
  durations?: number[]; // in months e.g. [3, 6, 12, 24]
  allowedDurationsMonths: number[];
  projectedAnnualReturn?: number; // e.g. 8.5%
  annualReturnRate: number;
  lockInPeriod: string;
  description: string;
  features: string[];
}

export interface InvestmentRequest {
  id: string;
  userId: string;
  userName: string;
  userEmail: string;
  accountNumber: string;
  reference: string;
  planId: string;
  planName: string;
  amount: number;
  currency: string;
  durationMonths: number;
  projectedReturnRate: number; // percentage
  projectedReturnAmount: number;
  status: 'pending_review' | 'approved' | 'active' | 'completed' | 'rejected';
  termsAccepted: boolean;
  createdAt: string;
  approvedAt?: string;
  adminComments?: string;
}

export interface VerificationRequest {
  id: string;
  userId: string;
  reference: string;
  fullName: string;
  dateOfBirth: string;
  residentialAddress: string;
  countryOfResidence: string;
  phone: string;
  email: string;
  accountReference: string;
  idDocumentType: 'passport' | 'national_id' | 'drivers_licence' | 'other';
  idDocumentNumber?: string;
  sampleDocFrontName: string;
  sampleDocBackName?: string;
  sampleProofOfAddressName: string;
  additionalComments?: string;
  declarationAccepted: boolean;
  consentAccepted: boolean;
  status: 'pending_review' | 'approved' | 'rejected';
  adminComments?: string;
  createdAt: string;
  reviewedAt?: string;
}

export interface SupportEnquiry {
  id: string;
  userId?: string;
  reference: string;
  name: string;
  email: string;
  phone?: string;
  category: 'general' | 'technical' | 'account' | 'complaint';
  subject: string;
  message: string;
  status: 'open' | 'in_progress' | 'resolved';
  adminReply?: string;
  createdAt: string;
  updatedAt: string;
}

export interface AuditLog {
  id: string;
  timestamp: string;
  adminEmail: string;
  action: string;
  targetUserId?: string;
  targetUserName?: string;
  details: string;
  ipAddress?: string;
}

export interface LoginActivity {
  id: string;
  userId: string;
  timestamp: string;
  ipAddress: string;
  device: string;
  status: 'success' | 'failed';
}

export interface EmailMessage {
  id: string;
  toEmail: string;
  toName: string;
  subject: string;
  templateType: 
    | 'registration_otp'
    | 'account_approved'
    | 'account_rejected'
    | 'account_activity'
    | 'credit_alert'
    | 'debit_alert'
    | 'transfer_request'
    | 'transaction_reversal'
    | 'investment_received'
    | 'investment_approved'
    | 'verification_submitted'
    | 'verification_approved'
    | 'password_change'
    | 'password_reset'
    | 'pin_reset_code'
    | 'security_notification';
  htmlContent: string;
  textContent: string;
  otpCode?: string;
  createdAt: string;
  read: boolean;
}

export interface NotificationItem {
  id: string;
  userId: string;
  title: string;
  message: string;
  type: 'info' | 'success' | 'warning' | 'alert';
  category?: 'registration' | 'verification' | 'investment' | 'account' | 'security' | 'transaction';
  read: boolean;
  createdAt: string;
  actionUrl?: string;
}
