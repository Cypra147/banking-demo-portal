import { isValidIBAN, isValidBIC, electronicFormatIBAN, countrySpecs } from 'ibantools';
import bankDirectoryData from '../data/globalBanksDirectory.json';

export interface BankInstitution {
  id: string;
  name: string;
  swiftBic: string;
  clearingCode?: string;
}

export interface CountryBankDirectory {
  countryCode: string;
  countryName: string;
  region: string;
  isDomestic: boolean;
  usesIban: boolean;
  domesticIdentifierLabel?: string;
  domesticIdentifierPlaceholder?: string;
  domesticRoutingLabel?: string;
  domesticRoutingPlaceholder?: string;
  internationalIdentifierLabel: string;
  internationalIdentifierPlaceholder: string;
  internationalRoutingLabel?: string;
  internationalRoutingPlaceholder?: string;
  banks: BankInstitution[];
}

export interface BankEntryWithCountry extends BankInstitution {
  countryCode: string;
  countryName: string;
  region: string;
  isDomestic: boolean;
}

export const GLOBAL_BANK_DIRECTORY: CountryBankDirectory[] = bankDirectoryData.countries as CountryBankDirectory[];

export const ALL_BANK_ENTRIES: BankEntryWithCountry[] = GLOBAL_BANK_DIRECTORY.flatMap(country =>
  country.banks.map(bank => ({
    ...bank,
    countryCode: country.countryCode,
    countryName: country.countryName,
    region: country.region,
    isDomestic: country.isDomestic,
  }))
);

export function getCountryDirectory(countryCode: string): CountryBankDirectory | undefined {
  return GLOBAL_BANK_DIRECTORY.find(c => c.countryCode === countryCode);
}

export function getIbanSpecForCountry(countryCode: string) {
  return countrySpecs[countryCode as keyof typeof countrySpecs];
}

export function validateBankAccountIdentifier(
  accountValue: string,
  transferScope: 'domestic' | 'international',
  countryCode: string
): { valid: boolean; formatted: string; message?: string } {
  const trimmed = accountValue.trim();
  if (!trimmed) {
    return { valid: false, formatted: trimmed };
  }

  const country = getCountryDirectory(countryCode);
  const expectsIban = transferScope === 'international' && Boolean(country?.usesIban);

  if (expectsIban) {
    const electronic = electronicFormatIBAN(trimmed) || trimmed.replace(/\s+/g, '').toUpperCase();
    const valid = isValidIBAN(electronic);
    return {
      valid,
      formatted: electronic,
      message: valid
        ? `Valid ${country?.countryName || countryCode} IBAN format verified.`
        : `Enter a valid ${country?.countryName || countryCode} IBAN (e.g. ${country?.internationalIdentifierPlaceholder?.replace('e.g. ', '') || ''}).`,
    };
  }

  // Non-IBAN validation (basic length & character checks for domestic / international account numbers)
  const cleanDigits = trimmed.replace(/[\s-]/g, '');
  if (cleanDigits.length < 6) {
    return {
      valid: false,
      formatted: trimmed,
      message: 'Account number must be at least 6 characters.',
    };
  }
  return { valid: true, formatted: trimmed };
}

export function validateSwiftBicCode(swiftValue: string): { valid: boolean; formatted: string; message?: string } {
  const clean = swiftValue.trim().toUpperCase().replace(/\s+/g, '');
  if (!clean) {
    return { valid: false, formatted: '' };
  }
  const valid = isValidBIC(clean);
  return {
    valid,
    formatted: clean,
    message: valid ? 'Valid SWIFT/BIC format' : 'SWIFT/BIC must be 8 or 11 characters (e.g. BARCGB22XXX)',
  };
}
