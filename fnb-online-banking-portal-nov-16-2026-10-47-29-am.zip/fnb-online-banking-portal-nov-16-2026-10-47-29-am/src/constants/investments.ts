import { InvestmentPlan } from '../types.ts';

export const INVESTMENT_PLANS: InvestmentPlan[] = [
  {
    id: 'plan-fixed-income',
    name: 'Fixed Income Treasury Note',
    category: 'Treasury & Sovereign Bonds',
    description: 'Capital-preservation plan benchmarked to sovereign treasury yields. Provides regular fixed returns with zero principal volatility.',
    annualReturnRate: 7.2,
    minimumAmount: 500,
    maximumAmount: 250000,
    allowedDurationsMonths: [3, 6, 12, 24],
    riskLevel: 'Low Risk',
    lockInPeriod: '3 - 24 Months',
    features: [
      'Fixed annualized target yield (7.2% p.a.)',
      'Daily compounding return ledger',
      'Zero management or maintenance fee',
      'Early liquidation with interest prorated'
    ]
  },
  {
    id: 'plan-bluechip-dividends',
    name: 'Blue-Chip Dividend Portfolio',
    category: 'Equities & Global Dividend Leaders',
    description: 'High-quality dividend aristocrat equities selected from FTSE 100, S&P 500, and European exchanges for steady defensive income and dividend growth.',
    annualReturnRate: 11.5,
    minimumAmount: 1000,
    maximumAmount: 500000,
    allowedDurationsMonths: [6, 12, 24],
    riskLevel: 'Moderate Risk',
    lockInPeriod: '6 - 24 Months',
    features: [
      'Projected dividend yield of 11.5% p.a.',
      'Quarterly dividend reinvestment schedule',
      'Diversified across defensive global leaders',
      'Automated quarterly performance statement'
    ]
  },
  {
    id: 'plan-green-energy',
    name: 'Green Energy & Infrastructure',
    category: 'Sustainable Infrastructure & ESG',
    description: 'Direct financing exposure into renewable solar, wind, and battery storage projects with long-term inflation-linked power purchase agreements.',
    annualReturnRate: 14.8,
    minimumAmount: 2500,
    maximumAmount: 1000000,
    allowedDurationsMonths: [12, 24, 36],
    riskLevel: 'Moderate-High',
    lockInPeriod: '12 - 36 Months',
    features: [
      'Impact investing with 14.8% p.a. target yield',
      'Backing verified green energy facilities',
      'Inflation-hedged allocation model',
      'Annual sustainability impact report'
    ]
  },
  {
    id: 'plan-tech-growth',
    name: 'Technology Growth Momentum',
    category: 'AI & Next-Gen Compute Equities',
    description: 'High-conviction portfolio tracking artificial intelligence infrastructure, enterprise SaaS leaders, semiconductor manufacturing, and quantum computing.',
    annualReturnRate: 18.5,
    minimumAmount: 5000,
    maximumAmount: 2500000,
    allowedDurationsMonths: [12, 24, 36],
    riskLevel: 'High Risk',
    lockInPeriod: '12 - 36 Months',
    features: [
      'Dynamic momentum allocation target (18.5% p.a.)',
      'Quarterly portfolio rebalancing model',
      'Exposure to top AI and cloud innovators',
      'Real-time portfolio analytics dashboard'
    ]
  }
];
