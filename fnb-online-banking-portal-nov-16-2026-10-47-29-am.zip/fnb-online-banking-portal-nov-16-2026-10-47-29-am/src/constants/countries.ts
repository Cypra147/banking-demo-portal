export interface CountryData {
  name: string;
  code: string;
  dialCode: string;
}

export const COUNTRIES: CountryData[] = [
  { name: 'United Kingdom', code: 'GB', dialCode: '+44' },
  { name: 'United States', code: 'US', dialCode: '+1' },
  { name: 'South Africa', code: 'ZA', dialCode: '+27' },
  { name: 'Canada', code: 'CA', dialCode: '+1' },
  { name: 'Australia', code: 'AU', dialCode: '+61' },
  { name: 'Germany', code: 'DE', dialCode: '+49' },
  { name: 'France', code: 'FR', dialCode: '+33' },
  { name: 'Ireland', code: 'IE', dialCode: '+353' },
  { name: 'Netherlands', code: 'NL', dialCode: '+31' },
  { name: 'Switzerland', code: 'CH', dialCode: '+41' },
  { name: 'United Arab Emirates', code: 'AE', dialCode: '+971' },
  { name: 'Saudi Arabia', code: 'SA', dialCode: '+966' },
  { name: 'Singapore', code: 'SG', dialCode: '+65' },
  { name: 'Hong Kong', code: 'HK', dialCode: '+852' },
  { name: 'India', code: 'IN', dialCode: '+91' },
  { name: 'Nigeria', code: 'NG', dialCode: '+234' },
  { name: 'Ghana', code: 'GH', dialCode: '+233' },
  { name: 'Kenya', code: 'KE', dialCode: '+254' },
  { name: 'New Zealand', code: 'NZ', dialCode: '+64' },
  { name: 'Spain', code: 'ES', dialCode: '+34' },
  { name: 'Italy', code: 'IT', dialCode: '+39' },
  { name: 'Sweden', code: 'SE', dialCode: '+46' },
  { name: 'Norway', code: 'NO', dialCode: '+47' },
  { name: 'Denmark', code: 'DK', dialCode: '+45' },
  { name: 'Japan', code: 'JP', dialCode: '+81' },
  { name: 'Brazil', code: 'BR', dialCode: '+55' },
  { name: 'Mexico', code: 'MX', dialCode: '+52' },
  { name: 'Poland', code: 'PL', dialCode: '+48' },
  { name: 'Portugal', code: 'PT', dialCode: '+351' },
  { name: 'Belgium', code: 'BE', dialCode: '+32' },
  { name: 'Austria', code: 'AT', dialCode: '+43' },
];
