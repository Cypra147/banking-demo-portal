# Security Specification — FNB Prototype Persistent Firestore Vault

## 1. Data Invariants
1. Every document lives under an isolated server-only vault namespace (`/vaults/{vaultId}/...`) guarded by `isAuthorizedServerVault(vaultId)` and `isValidId(docId)`.
2. Public root collections have default-deny (`allow read, write: if false;`), preventing unauthenticated listing or scraping of PII, account balances, password hashes, or salts.
3. Every `CustomerAccount` document requires valid `id`, `email`, `username`, `firstName`, `lastName`, `role` (`customer` | `admin`), `status` (`pending_approval` | `active` | `frozen` | `suspended` | `rejected`), `balance` (`number`), `currency`, `createdAt`, `passwordHash`, and `salt`.
4. Every write validates strict field types and size limits to prevent resource/payload poisoning.

## 2. Adversarial Test Cases ("Dirty Dozen")
1. Unauthenticated `list` on `/vaults/public/customers` -> PERMISSION_DENIED
2. Unauthenticated `get` on `/vaults/default/customers/cust-sarah-101` -> PERMISSION_DENIED
3. Writing to root `/customers/cust-1` -> PERMISSION_DENIED
4. Writing `CustomerAccount` with wrong `role: "superroot"` -> PERMISSION_DENIED
5. Writing `CustomerAccount` with 5KB `id` (ID poisoning) -> PERMISSION_DENIED
6. Writing `CustomerAccount` missing `passwordHash` or `salt` -> PERMISSION_DENIED
7. Writing `CustomerAccount` with invalid `status: "hacked"` -> PERMISSION_DENIED
8. Writing `TransactionRecord` with negative or non-number `amount: "100"` -> PERMISSION_DENIED
9. Writing `SessionRecord` with invalid `role: "superuser"` -> PERMISSION_DENIED
10. Modifying `CustomerAccount` to strip required `createdAt` -> PERMISSION_DENIED
11. Writing oversized `details` (> 5000 chars) on `AuditLogRecord` -> PERMISSION_DENIED
12. Deleting any root document outside vault -> PERMISSION_DENIED
