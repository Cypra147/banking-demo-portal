# FNB Online Banking — Complete Full-Stack Application

Full-stack banking web application built with **React**, **TypeScript**, **Tailwind CSS**, **Express**, and **Firebase Firestore** (with local JSON persistence fallback).

## Key Features
- **Customer Portal**: Dark-navy responsive banking dashboard with Overview, My Account, Investments, Fund Transfers, International Payments, Beneficiaries, Payment History, Account Statements, Savings Accounts, Fixed Deposits, Loan Services, Personal Profile (admin-managed read-only), Security Settings (Password, 2FA, Transaction PIN), Login History, Notifications Centre, Customer Support, Document Centre, and Print Receipts.
- **Security Controls**: Salted `scrypt` password & Transaction PIN hashing with rate limiting/lockouts, Email OTP verification, automatic 10-minute inactivity & tab/page-closure logout for customer sessions, `Cache-Control: no-store` protection, and browser Back-button block after logout.
- **Administrator Console**: Customer account approvals, balance adjustments, credit/debit ledger posting, profile editing, KYC compliance reviews, investment request processing, support ticket management, audit logs, and Tawk.to suppression on `/admin*`.
- **Currency & Branding**: Standardized US Dollars (`USD $`) formatting (`$1,250.00`) across balances, ledgers, transfers, statements, and receipts.

## Project Structure
- `server.ts` — Express API server, authentication & session management, Vite dev middleware / production static serving
- `src/server/` — Persistence engine (`storage.ts`, `firestoreStore.ts`) and email dispatch (`emailService.ts`)
- `src/` — React + TypeScript frontend (`pages/`, `components/`, `context/`, `services/`, `constants/`, `utils/`)
- `public/` — Static branding assets
- `data/` — JSON database store (`fnb_database.json`)
- `firebase-applet-config.json`, `firebase-blueprint.json`, `firestore.rules` — Firebase & Firestore configuration

## Running Locally

1. **Install dependencies**
   ```bash
   npm install
   ```

2. **Configure environment (optional)**
   Copy `.env.example` to `.env` and populate values as needed (`GEMINI_API_KEY`, `APP_URL`, `PORT`). By default the server listens on port `3000`.

3. **Run in Development Mode (Backend + Frontend)**
   ```bash
   npm run dev
   ```
   Opens full-stack server + Vite dev middleware on `http://localhost:3000`.

4. **Build & Run in Production Mode**
   ```bash
   npm run build
   NODE_ENV=production npm start
   ```

5. **Type Check**
   ```bash
   npm run lint
   ```
