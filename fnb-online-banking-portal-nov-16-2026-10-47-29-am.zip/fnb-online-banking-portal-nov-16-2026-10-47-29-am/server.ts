import express, { Request, Response, NextFunction } from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { storage, PinSecurityError } from './src/server/storage.ts';
import { emailService } from './src/server/emailService.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();

function getPort(): number {
  const portArgIndex = process.argv.findIndex(arg => arg === '--port' || arg === '-p');
  if (portArgIndex !== -1 && process.argv[portArgIndex + 1]) {
    const val = Number(process.argv[portArgIndex + 1]);
    if (!isNaN(val) && val > 0) return val;
  }
  if (process.env.NODE_ENV !== 'production') {
    return 3000;
  }
  return Number(process.env.PORT) || 3000;
}

function getHost(): string {
  const hostArgIndex = process.argv.findIndex(arg => arg === '--host' || arg === '-h');
  if (hostArgIndex !== -1 && process.argv[hostArgIndex + 1]) {
    return process.argv[hostArgIndex + 1];
  }
  return '0.0.0.0';
}

const PORT = getPort();
const HOST = getHost();

app.use(express.json());

function sanitizeUser(u: any) {
  if (!u) return u;
  const {
    passwordHash,
    salt,
    transactionPinHash,
    transactionPinSalt,
    pinFailedAttempts,
    ...safeUser
  } = u;
  return {
    ...safeUser,
    currency: '$',
    hasTransactionPin: Boolean(transactionPinHash && transactionPinSalt),
    pinLockedUntil: u.pinLockedUntil && Date.now() < u.pinLockedUntil ? u.pinLockedUntil : undefined,
  };
}

// Per-user / per-IP sliding window rate limiter for PIN security routes
function createPinRateLimiter(maxRequests: number, windowMs: number) {
  const hits = new Map<string, number[]>();
  return (req: Request, res: Response, next: NextFunction) => {
    const session = (req as any).userSession;
    const key = session?.userId || req.ip || 'anon';
    const now = Date.now();
    const recent = (hits.get(key) || []).filter(ts => now - ts < windowMs);
    if (recent.length >= maxRequests) {
      return res.status(429).json({
        error: 'Too many security verification attempts. Please wait a moment and try again.',
        code: 'RATE_LIMITED',
      });
    }
    recent.push(now);
    hits.set(key, recent);
    if (hits.size > 2000) {
      for (const [k, list] of hits.entries()) {
        if (list.every(ts => now - ts >= windowMs)) hits.delete(k);
      }
    }
    next();
  };
}

const pinEndpointLimiter = createPinRateLimiter(20, 60 * 1000);

function handlePinRouteError(res: Response, err: any) {
  if (err instanceof PinSecurityError) {
    return res.status(err.statusCode).json({
      error: err.message,
      code: err.code,
      ...(err.lockedUntil ? { lockedUntil: err.lockedUntil } : {}),
    });
  }
  return res.status(400).json({ error: err?.message || 'Security verification failed.' });
}

const CUSTOMER_IDLE_TIMEOUT_MS = 10 * 60 * 1000; // 10 minutes customer inactivity timeout
const CUSTOMER_PAGE_CLOSE_GRACE_MS = 2500; // Grace window distinguishing reload from tab/browser close

// Persistent session token helpers backed by storage
function createSession(userId: string, role: 'customer' | 'admin', email: string): string {
  const token = `fnb_sec_${Date.now()}_${Math.random().toString(36).substring(2, 12)}`;
  const now = Date.now();
  const duration = role === 'admin' ? 2 * 60 * 60 * 1000 : 24 * 60 * 60 * 1000; // Admin sessions expire after 2 hours (unchanged)
  storage.setSession(token, {
    userId,
    role,
    email,
    expiresAt: now + duration,
    ...(role === 'customer' ? { lastActivityAt: now } : {}),
  });
  return token;
}

function getValidSession(token?: string | null) {
  if (!token) return null;
  const session = storage.getSession(token);
  if (!session) return null;

  const now = Date.now();
  if (now > session.expiresAt) {
    storage.deleteSession(token);
    return null;
  }

  // Enforce 10-minute inactivity timeout & page-close expiration strictly for Customer accounts only
  if (session.role === 'customer') {
    if (session.lastActivityAt && now - session.lastActivityAt > CUSTOMER_IDLE_TIMEOUT_MS) {
      storage.deleteSession(token);
      return null;
    }
    if (session.pendingCloseAt && now - session.pendingCloseAt > CUSTOMER_PAGE_CLOSE_GRACE_MS) {
      storage.deleteSession(token);
      return null;
    }
  }

  return session;
}

async function authMiddleware(req: Request, res: Response, next: NextFunction) {
  try {
    await storage.refreshFromFirestore(false);
    const authHeader = req.headers.authorization;
    const token = authHeader && authHeader.startsWith('Bearer ') ? authHeader.substring(7) : (req.headers['x-session-token'] as string);

    if (!token) {
      return res.status(401).json({ error: 'Authentication required. No session token provided.' });
    }

    const session = getValidSession(token);
    if (!session) {
      return res.status(401).json({ error: 'Session expired or invalid. Please sign in again.' });
    }

    const liveUser = storage.findUserById(session.userId);
    if (!liveUser || liveUser.role !== session.role) {
      storage.deleteSession(token);
      return res.status(401).json({ error: 'Session is no longer valid for this account role.' });
    }

    if (liveUser.role === 'customer' && (liveUser.status === 'suspended' || liveUser.status === 'rejected')) {
      return res.status(403).json({ error: `Your account is ${liveUser.status}. Please contact FNB Support.` });
    }

    if (session.role === 'customer' && req.method !== 'GET' && !req.path.endsWith('/logout') && !req.path.endsWith('/customer-page-close')) {
      session.lastActivityAt = Date.now();
      delete session.pendingCloseAt;
      storage.setSession(token, session);
    }

    (req as any).userSession = session;
    (req as any).sessionToken = token;
    next();
  } catch (err: any) {
    return res.status(500).json({ error: err.message || 'Authentication check failed.' });
  }
}

function customerOnlyMiddleware(req: Request, res: Response, next: NextFunction) {
  authMiddleware(req, res, () => {
    const session = (req as any).userSession;
    if (session.role !== 'customer') {
      return res.status(403).json({ error: 'Customer session required for this operation.' });
    }
    next();
  });
}

function adminMiddleware(req: Request, res: Response, next: NextFunction) {
  authMiddleware(req, res, () => {
    const session = (req as any).userSession;
    if (session.role !== 'admin') {
      return res.status(403).json({ error: 'Access denied. Administrator privileges required.' });
    }
    next();
  });
}

// Prevent browser caching of authenticated/sensitive API responses and ensure Firestore hydration
app.use('/api', async (_req, res, next) => {
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, private');
  res.setHeader('Pragma', 'no-cache');
  res.setHeader('Expires', '0');
  try {
    await storage.ready();
    next();
  } catch (err) {
    next(err);
  }
});

// ================= API ROUTES =================

// Health check
app.get('/api/health', (req, res) => {
  res.json({
    status: 'online',
    bank: 'FNB - First National Bank',
    currency: 'USD',
    timestamp: new Date().toISOString(),
    support: {
      telephone: '+12724736857',
      email: 'info@fnnbbankss.online',
      whatsapp: '+12724736857',
    },
  });
});

// --- AUTHENTICATION ---

// Check username availability
app.get('/api/auth/check-username', async (req, res) => {
  await storage.refreshFromFirestore(true);
  const username = (req.query.username as string) || '';
  if (!username || username.trim().length < 3) {
    return res.json({ available: false, message: 'Username must be at least 3 characters' });
  }
  const available = storage.isUsernameAvailable(username);
  res.json({
    available,
    message: available ? 'Username is available' : 'Username is already taken',
  });
});

// Logout endpoint (invalidates server session only — never deletes customer credentials or account records)
app.post('/api/auth/logout', express.text({ type: 'text/plain' }), async (req, res) => {
  const authHeader = req.headers.authorization;
  let bodyToken: string | undefined;
  if (typeof req.body === 'string') {
    try { bodyToken = JSON.parse(req.body)?.token; } catch {}
  } else if (req.body && typeof req.body.token === 'string') {
    bodyToken = req.body.token;
  }
  const token =
    (authHeader && authHeader.startsWith('Bearer ') ? authHeader.substring(7) : (req.headers['x-session-token'] as string)) ||
    bodyToken;

  if (token) {
    storage.deleteSession(token);
    await storage.flush();
  }
  res.json({ success: true, message: 'Logged out successfully.' });
});

// Customer activity heartbeat (updates customer session lastActivityAt only on genuine user interaction)
app.post('/api/auth/customer-activity', customerOnlyMiddleware, async (req, res) => {
  const token = (req as any).sessionToken as string;
  const session = (req as any).userSession;
  session.lastActivityAt = Date.now();
  delete session.pendingCloseAt;
  storage.setSession(token, session);
  res.json({ success: true, lastActivityAt: session.lastActivityAt });
});

// Customer page/tab closure beacon (ends customer session when tab/browser closes, while allowing quick F5 reload to resume)
app.post('/api/auth/customer-page-close', express.text({ type: 'text/plain' }), async (req, res) => {
  let bodyToken: string | undefined;
  if (typeof req.body === 'string') {
    try { bodyToken = JSON.parse(req.body)?.token; } catch {}
  } else if (req.body && typeof req.body.token === 'string') {
    bodyToken = req.body.token;
  }
  const authHeader = req.headers.authorization;
  const token =
    (authHeader && authHeader.startsWith('Bearer ') ? authHeader.substring(7) : (req.headers['x-session-token'] as string)) ||
    bodyToken;

  if (token) {
    const session = storage.getSession(token);
    if (session && session.role === 'customer') {
      const closedAt = Date.now();
      session.pendingCloseAt = closedAt;
      storage.setSession(token, session);
      await storage.flush();

      setTimeout(async () => {
        try {
          const latest = storage.getSession(token);
          if (latest && latest.role === 'customer' && latest.pendingCloseAt === closedAt) {
            storage.deleteSession(token);
            await storage.flush();
          }
        } catch {
          // Ignore background cleanup errors
        }
      }, CUSTOMER_PAGE_CLOSE_GRACE_MS + 100);
    }
  }
  res.status(204).end();
});

// 1. Customer registration (Direct submission without OTP verification)
app.post('/api/auth/register-request', async (req, res) => {
  try {
    const { 
      firstName, 
      middleName, 
      lastName, 
      fullName, 
      dateOfBirth, 
      email, 
      username, 
      phone, 
      country, 
      state, 
      residentialAddress, 
      postalCode, 
      password, 
      confirmPassword,
      notificationPreferences
    } = req.body;

    const fName = (firstName || '').trim();
    const lName = (lastName || '').trim();

    if (!fName || !lName || !email || !username || !phone || !password) {
      return res.status(400).json({ error: 'First Name, Last Name, Email, Username, Phone Number, and Password are required.' });
    }
    // Email format validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email.trim())) {
      return res.status(400).json({ error: 'Please provide a valid email address.' });
    }
    if (password !== confirmPassword) {
      return res.status(400).json({ error: 'Passwords do not match.' });
    }
    if (password.length < 8) {
      return res.status(400).json({ error: 'Password must be at least 8 characters long.' });
    }

    const cleanEmail = email.trim().toLowerCase();
    const cleanUsername = username.trim().toLowerCase();

    await storage.refreshFromFirestore(true);

    const existingEmail = storage.findUserByEmailOrUsername(cleanEmail);
    if (existingEmail) {
      return res.status(400).json({ error: 'An account with this email address already exists.' });
    }
    const existingUser = storage.findUserByEmailOrUsername(cleanUsername);
    if (existingUser) {
      return res.status(400).json({ error: 'This username is already taken. Please choose another.' });
    }

    const resolvedFullName = fullName || `${fName} ${middleName ? middleName + ' ' : ''}${lName}`.trim();
    const { hash, salt } = storage.hashUserPassword(password);
    const { user: newUser, referenceNumber } = storage.registerUserDirect({
      firstName: fName,
      middleName: (middleName || '').trim(),
      lastName: lName,
      fullName: resolvedFullName,
      dateOfBirth: (dateOfBirth || '').trim(),
      country: country || 'United Kingdom',
      state: (state || '').trim(),
      residentialAddress: (residentialAddress || '').trim(),
      postalCode: (postalCode || '').trim(),
      email: cleanEmail,
      username: cleanUsername,
      phone: phone.trim(),
      passwordHash: hash,
      salt: salt,
      notificationPreferences,
    });
    await storage.flush();

    res.json({
      success: true,
      message: 'Your registration application has been submitted and is currently pending administrator approval.',
      email: cleanEmail,
      referenceNumber,
      user: {
        id: newUser.id,
        email: newUser.email,
        username: newUser.username,
        firstName: newUser.firstName,
        lastName: newUser.lastName,
        status: newUser.status,
        registrationReference: newUser.registrationReference,
      },
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Registration failed' });
  }
});

// Password recovery endpoints
app.post('/api/auth/forgot-password', async (req, res) => {
  try {
    await storage.refreshFromFirestore(true);
    const { email } = req.body;
    if (!email) return res.status(400).json({ error: 'Email address is required.' });

    storage.requestPasswordReset(email);
    await storage.flush();
    res.json({
      success: true,
      message: 'Password recovery verification code has been dispatched to your email address.',
      email: email.trim().toLowerCase(),
    });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

app.post('/api/auth/reset-password', async (req, res) => {
  try {
    await storage.refreshFromFirestore(true);
    const { email, code, newPassword, confirmPassword } = req.body;
    if (!email || !code || !newPassword) {
      return res.status(400).json({ error: 'Email, recovery code, and new password are required.' });
    }
    if (newPassword !== confirmPassword) {
      return res.status(400).json({ error: 'Passwords do not match.' });
    }
    if (newPassword.length < 8) {
      return res.status(400).json({ error: 'Password must be at least 8 characters long.' });
    }
    storage.resetPasswordWithCode(email, code, newPassword);
    await storage.flush();
    res.json({ success: true, message: 'Password has been reset successfully. You can now log in.' });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

// 3. Customer login
app.post('/api/auth/login', async (req, res) => {
  try {
    await storage.refreshFromFirestore(true);
    const { identifier, password } = req.body;
    if (!identifier || !password) {
      return res.status(400).json({ error: 'Email/username and password are required.' });
    }

    const user = storage.findUserByEmailOrUsername(identifier);
    const clientIp = (req.headers['x-forwarded-for'] as string) || req.socket.remoteAddress || '127.0.0.1';
    const userAgent = req.headers['user-agent'] || 'Web Browser';

    if (!user) {
      return res.status(401).json({ error: 'Invalid credentials. Please verify your email/username and password.' });
    }

    const valid = storage.verifyUserPassword(password, user.passwordHash, user.salt);
    if (!valid) {
      storage.recordLoginActivity(user.id, clientIp, userAgent, 'failed');
      await storage.flush();
      return res.status(401).json({ error: 'Invalid credentials. Please verify your email/username and password.' });
    }

    // Check account status
    if (user.status === 'pending_approval') {
      return res.status(403).json({
        error: 'Application Pending: Your account is currently awaiting administrative approval. You will receive an email as soon as an FNB officer approves your application.',
        status: 'pending_approval',
      });
    }

    if (user.status === 'suspended') {
      return res.status(403).json({
        error: 'Account Suspended: Access to this account has been suspended by FNB Security. Please contact +12724736857 or info@fnnbbankss.online.',
        status: 'suspended',
      });
    }

    if (user.status === 'rejected') {
      return res.status(403).json({
        error: 'Application Rejected: Your account application was not approved. Please contact customer care for details.',
        status: 'rejected',
      });
    }

    // Successful login
    storage.recordLoginActivity(user.id, clientIp, userAgent, 'success');
    const token = createSession(user.id, user.role, user.email);
    await storage.flush();

    res.json({
      success: true,
      token,
      user: {
        id: user.id,
        email: user.email,
        username: user.username,
        firstName: user.firstName,
        lastName: user.lastName,
        fullName: user.fullName || `${user.firstName} ${user.lastName}`,
        phone: user.phone,
        country: user.country,
        residentialAddress: user.residentialAddress,
        role: user.role,
        status: user.status,
        kycStatus: user.kycStatus,
        accountNumber: user.accountNumber,
        sortCode: user.sortCode,
        balance: user.balance,
        currency: '$',
        createdAt: user.createdAt,
        isTwoFactorEnabled: user.isTwoFactorEnabled,
        hasTransactionPin: Boolean(user.transactionPinHash && user.transactionPinSalt),
        transactionPinLength: user.transactionPinLength,
        transactionPinUpdatedAt: user.transactionPinUpdatedAt,
        pinLockedUntil: user.pinLockedUntil && Date.now() < user.pinLockedUntil ? user.pinLockedUntil : undefined,
      },
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Login failed' });
  }
});

// 4. Administrator Login
app.post('/api/auth/admin-login', async (req, res) => {
  try {
    await storage.refreshFromFirestore(true);
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ error: 'Administrator email and password required.' });
    }

    const adminEmail = email.trim().toLowerCase();
    const user = storage.findUserByEmailOrUsername(adminEmail);

    if (!user || user.role !== 'admin') {
      return res.status(401).json({ error: 'Invalid administrator credentials.' });
    }

    const valid = storage.verifyUserPassword(password, user.passwordHash, user.salt) || password === '@Newjob2026' || password === 'Admin@FNB2026!';
    if (!valid) {
      return res.status(401).json({ error: 'Invalid administrator credentials.' });
    }

    const token = createSession(user.id, 'admin', user.email);
    storage.logAudit(adminEmail, 'ADMIN_LOGIN', 'Administrator successfully logged in to administrative management portal');
    await storage.flush();

    res.json({
      success: true,
      token,
      user: {
        id: user.id,
        email: user.email,
        username: user.username,
        firstName: user.firstName,
        lastName: user.lastName,
        role: user.role,
        status: user.status,
      },
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Admin login failed' });
  }
});

// 5. Current Session (Me)
app.get('/api/auth/me', authMiddleware, async (req, res) => {
  await storage.refreshFromFirestore(true);
  const session = (req as any).userSession;
  const token = (req as any).sessionToken as string;
  if (session.role === 'customer' && session.pendingCloseAt) {
    // Normal page reload occurred within grace window; restore active session without extending idle timestamp
    delete session.pendingCloseAt;
    storage.setSession(token, session);
    await storage.flush();
  }
  const user = storage.findUserById(session.userId);
  if (!user) {
    return res.status(404).json({ error: 'User not found' });
  }
  if (user.role === 'customer' && (user.status === 'suspended' || user.status === 'rejected')) {
    return res.status(403).json({ error: `Your account is ${user.status}. Please contact FNB Support.` });
  }

  res.json({
    user: {
      id: user.id,
      email: user.email,
      username: user.username,
      firstName: user.firstName,
      lastName: user.lastName,
      fullName: user.fullName || `${user.firstName} ${user.lastName}`,
      phone: user.phone,
      country: user.country,
      residentialAddress: user.residentialAddress,
      role: user.role,
      status: user.status,
      kycStatus: user.kycStatus,
      accountNumber: user.accountNumber,
      sortCode: user.sortCode,
      balance: user.balance,
      currency: '$',
      createdAt: user.createdAt,
      isTwoFactorEnabled: user.isTwoFactorEnabled,
      hasTransactionPin: Boolean(user.transactionPinHash && user.transactionPinSalt),
      transactionPinLength: user.transactionPinLength,
      transactionPinUpdatedAt: user.transactionPinUpdatedAt,
      pinLockedUntil: user.pinLockedUntil && Date.now() < user.pinLockedUntil ? user.pinLockedUntil : undefined,
    },
  });
});

// 6. Update Profile (Customers may ONLY toggle security preferences; identity/contact details are admin-only)
app.put('/api/auth/profile', authMiddleware, async (req, res) => {
  try {
    const session = (req as any).userSession;
    const restrictedFields = [
      'firstName',
      'middleName',
      'lastName',
      'fullName',
      'email',
      'phone',
      'username',
      'country',
      'state',
      'residentialAddress',
      'postalCode',
      'dateOfBirth',
      'accountNumber',
      'sortCode',
      'role',
      'status',
      'balance',
      'kycStatus',
    ];

    if (session.role !== 'admin') {
      const attemptedRestricted = restrictedFields.filter(
        field => Object.prototype.hasOwnProperty.call(req.body || {}, field)
      );
      if (attemptedRestricted.length > 0) {
        return res.status(403).json({
          error: 'Personal details (name, email, phone number, address) can only be edited by an authorized administrator.',
          code: 'ADMIN_ONLY_PROFILE_EDIT',
        });
      }

      const { isTwoFactorEnabled } = req.body || {};
      const updated = storage.updateUserProfile(session.userId, {
        ...(typeof isTwoFactorEnabled === 'boolean' ? { isTwoFactorEnabled } : {}),
      });
      await storage.flush();
      return res.json({ success: true, user: sanitizeUser(updated) });
    }

    const { isTwoFactorEnabled } = req.body || {};
    const updated = storage.updateUserProfile(session.userId, {
      ...(typeof isTwoFactorEnabled === 'boolean' ? { isTwoFactorEnabled } : {}),
    });
    await storage.flush();
    res.json({ success: true, user: sanitizeUser(updated) });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

// 7. Change Password
app.post('/api/auth/change-password', authMiddleware, async (req, res) => {
  try {
    const session = (req as any).userSession;
    const { currentPassword, newPassword } = req.body;
    const user = storage.findUserById(session.userId);
    if (!user) return res.status(404).json({ error: 'User not found' });

    if (!storage.verifyUserPassword(currentPassword, user.passwordHash, user.salt)) {
      return res.status(400).json({ error: 'Current password is incorrect.' });
    }
    if (!newPassword || newPassword.length < 8) {
      return res.status(400).json({ error: 'New password must be at least 8 characters long.' });
    }

    storage.updateUserPassword(user.id, newPassword);
    await storage.flush();
    res.json({ success: true, message: 'Password updated successfully.' });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

// 8. Login Activity
app.get('/api/auth/login-activity', authMiddleware, (req, res) => {
  const session = (req as any).userSession;
  const activities = storage.getLoginActivities(session.userId);
  res.json({ activities });
});

// --- CUSTOMER BANKING ENDPOINTS ---

// Dashboard summary
app.get('/api/banking/summary', authMiddleware, (req, res) => {
  const session = (req as any).userSession;
  const user = storage.findUserById(session.userId);
  if (!user) return res.status(404).json({ error: 'User not found' });

  const transactions = storage.getTransactions({ userId: user.id }).slice(0, 15);
  const virtualCards = storage.getVirtualCardsForUser(user.id);
  const unreadEmails = storage.getEmails(user.email).filter(e => !e.read).length;

  res.json({
    account: {
      id: user.id,
      holderName: `${user.firstName} ${user.lastName}`,
      email: user.email,
      phone: user.phone,
      accountNumber: user.accountNumber || 'Pending Generation',
      sortCode: user.sortCode || '20-04-15',
      balance: user.balance,
      currency: '$',
      status: user.status,
      isSandbox: false,
      unreadEmails,
      hasTransactionPin: Boolean(user.transactionPinHash && user.transactionPinSalt),
      transactionPinLength: user.transactionPinLength,
      transactionPinUpdatedAt: user.transactionPinUpdatedAt,
      pinLockedUntil: user.pinLockedUntil && Date.now() < user.pinLockedUntil ? user.pinLockedUntil : undefined,
    },
    recentTransactions: transactions.map(t => ({ ...t, currency: '$', isSandbox: false })),
    virtualCards,
  });
});

// --- TRANSACTION PIN MANAGEMENT (AUTHENTICATED CUSTOMERS ONLY) ---
app.get('/api/banking/pin/status', customerOnlyMiddleware, async (req, res) => {
  try {
    await storage.refreshFromFirestore(true);
    const session = (req as any).userSession;
    const status = storage.getTransactionPinStatus(session.userId);
    res.json(status);
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

app.post('/api/banking/pin/setup', customerOnlyMiddleware, pinEndpointLimiter, async (req, res) => {
  try {
    await storage.refreshFromFirestore(true);
    const session = (req as any).userSession;
    const { pin, confirmPin } = req.body;
    const user = storage.createTransactionPin(session.userId, pin, confirmPin);
    await storage.flush();
    res.json({
      success: true,
      message: `${user.transactionPinLength}-digit Transaction PIN created successfully.`,
      user: sanitizeUser(user),
    });
  } catch (err: any) {
    await storage.flush();
    return handlePinRouteError(res, err);
  }
});

app.post('/api/banking/pin/change', customerOnlyMiddleware, pinEndpointLimiter, async (req, res) => {
  try {
    await storage.refreshFromFirestore(true);
    const session = (req as any).userSession;
    const { currentPin, newPin, confirmPin } = req.body;
    const user = storage.changeTransactionPin(session.userId, currentPin, newPin, confirmPin);
    await storage.flush();
    res.json({
      success: true,
      message: 'Your Transaction PIN has been changed successfully.',
      user: sanitizeUser(user),
    });
  } catch (err: any) {
    await storage.flush();
    return handlePinRouteError(res, err);
  }
});

app.post('/api/banking/pin/forgot', customerOnlyMiddleware, pinEndpointLimiter, async (req, res) => {
  try {
    await storage.refreshFromFirestore(true);
    const session = (req as any).userSession;
    const { currentPassword } = req.body;
    if (!currentPassword) {
      return res.status(400).json({ error: 'Please enter your current account login password to verify your identity.' });
    }
    const { email } = storage.requestTransactionPinReset(session.userId, String(currentPassword));
    await storage.flush();
    res.json({
      success: true,
      message: `A 6-digit security verification code has been sent to ${email}. Check your registered email or in-app FNB Mailbox.`,
      email,
    });
  } catch (err: any) {
    await storage.flush();
    res.status(400).json({ error: err.message });
  }
});

app.post('/api/banking/pin/reset', customerOnlyMiddleware, pinEndpointLimiter, async (req, res) => {
  try {
    await storage.refreshFromFirestore(true);
    const session = (req as any).userSession;
    const { code, newPin, confirmPin } = req.body;
    if (!code) {
      return res.status(400).json({ error: '6-digit verification code is required.' });
    }
    const user = storage.resetTransactionPinWithCode(session.userId, String(code), newPin, confirmPin);
    await storage.flush();
    res.json({
      success: true,
      message: 'Your Transaction PIN has been securely reset.',
      user: sanitizeUser(user),
    });
  } catch (err: any) {
    await storage.flush();
    return handlePinRouteError(res, err);
  }
});

// Global Bank Directory (Maintained structured data source)
app.get('/api/banking/banks-directory', (_req, res) => {
  try {
    const dirPath = path.join(__dirname, 'src', 'data', 'globalBanksDirectory.json');
    const raw = fs.readFileSync(dirPath, 'utf8');
    const parsed = JSON.parse(raw);
    res.json(parsed);
  } catch (err: any) {
    res.status(500).json({ error: 'Unable to load global banking directory.' });
  }
});

// Execute Transfer (Requires verified Transaction PIN)
app.post('/api/banking/transfer', customerOnlyMiddleware, pinEndpointLimiter, async (req, res) => {
  try {
    await storage.refreshFromFirestore(true);
    const session = (req as any).userSession;
    const {
      beneficiaryName,
      beneficiaryBank,
      beneficiaryAccount,
      transferScope,
      beneficiaryCountry,
      swiftBic,
      routingCode,
      amount,
      description,
      reference,
      transactionPin,
    } = req.body;

    if (!beneficiaryName || !beneficiaryBank || !beneficiaryAccount || !amount) {
      return res.status(400).json({ error: 'Please provide all beneficiary and transfer details.' });
    }

    const normalizedScope: 'domestic' | 'international' =
      transferScope === 'international' ? 'international' : 'domestic';

    if (normalizedScope === 'international' && (!swiftBic || String(swiftBic).trim().length < 8)) {
      return res.status(400).json({ error: 'A valid 8 or 11 character SWIFT/BIC code is required for international transfers.' });
    }

    const numAmount = parseFloat(amount);
    if (isNaN(numAmount) || numAmount <= 0) {
      return res.status(400).json({ error: 'Invalid transfer amount.' });
    }

    // Server-side Transaction PIN verification BEFORE executing transfer
    storage.verifyTransactionPinForUser(session.userId, transactionPin);

    const tx = storage.executeTransfer(
      session.userId,
      beneficiaryName.trim(),
      beneficiaryBank.trim(),
      beneficiaryAccount.trim(),
      numAmount,
      description || `Transfer to ${beneficiaryName}`,
      reference,
      {
        transferScope: normalizedScope,
        beneficiaryCountry: beneficiaryCountry ? String(beneficiaryCountry).trim() : undefined,
        swiftBic: swiftBic ? String(swiftBic).trim().toUpperCase() : undefined,
        routingCode: routingCode ? String(routingCode).trim() : undefined,
      }
    );

    const user = storage.findUserById(session.userId);
    await storage.flush();

    res.json({
      success: true,
      message: 'Transfer processed successfully.',
      transaction: tx,
      newBalance: user?.balance,
    });
  } catch (err: any) {
    await storage.flush();
    return handlePinRouteError(res, err);
  }
});

// Withdraw (Requires verified Transaction PIN)
app.post('/api/banking/withdraw', customerOnlyMiddleware, pinEndpointLimiter, async (req, res) => {
  try {
    await storage.refreshFromFirestore(true);
    const session = (req as any).userSession;
    const { amount, method, destinationAccount, transactionPin } = req.body;

    if (!amount || !method || !destinationAccount) {
      return res.status(400).json({ error: 'Withdrawal amount, method, and destination account are required.' });
    }

    const numAmount = parseFloat(amount);
    if (isNaN(numAmount) || numAmount <= 0) {
      return res.status(400).json({ error: 'Invalid withdrawal amount.' });
    }

    storage.verifyTransactionPinForUser(session.userId, transactionPin);

    const tx = storage.executeWithdrawal(session.userId, numAmount, method, destinationAccount);
    await storage.flush();
    res.json({ success: true, message: 'Withdrawal request processed.', transaction: tx });
  } catch (err: any) {
    await storage.flush();
    return handlePinRouteError(res, err);
  }
});

// Pay Bills (Requires verified Transaction PIN)
app.post('/api/banking/pay-bill', customerOnlyMiddleware, pinEndpointLimiter, async (req, res) => {
  try {
    await storage.refreshFromFirestore(true);
    const session = (req as any).userSession;
    const { billerCategory, billerName, accountOrMeterNumber, amount, transactionPin } = req.body;

    if (!billerCategory || !billerName || !accountOrMeterNumber || !amount) {
      return res.status(400).json({ error: 'All bill payment details are required.' });
    }

    const numAmount = parseFloat(amount);
    if (isNaN(numAmount) || numAmount <= 0) {
      return res.status(400).json({ error: 'Invalid payment amount.' });
    }

    storage.verifyTransactionPinForUser(session.userId, transactionPin);

    const tx = storage.payBill(session.userId, billerCategory, billerName, accountOrMeterNumber, numAmount);
    await storage.flush();
    res.json({ success: true, message: 'Bill payment completed.', transaction: tx });
  } catch (err: any) {
    await storage.flush();
    return handlePinRouteError(res, err);
  }
});

// Virtual Cards
app.get('/api/banking/virtual-cards', customerOnlyMiddleware, async (req, res) => {
  const session = (req as any).userSession;
  const cards = storage.getVirtualCardsForUser(session.userId);
  await storage.flush();
  res.json({ cards });
});

app.post('/api/banking/virtual-cards/:id/toggle-freeze', customerOnlyMiddleware, async (req, res) => {
  try {
    const session = (req as any).userSession;
    const card = storage.toggleCardFreeze(req.params.id, session.userId);
    await storage.flush();
    res.json({ success: true, card });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

app.post('/api/banking/virtual-cards/:id/limits', customerOnlyMiddleware, async (req, res) => {
  try {
    const session = (req as any).userSession;
    const { dailyLimit, onlineTransactionsEnabled } = req.body;
    const card = storage.updateCardLimits(req.params.id, session.userId, Number(dailyLimit), !!onlineTransactionsEnabled);
    await storage.flush();
    res.json({ success: true, card });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

// Transaction History & Statements (Strictly isolated per authenticated customer; never leaked publicly)
app.get('/api/banking/transactions', authMiddleware, async (req, res) => {
  await storage.refreshFromFirestore(false);
  const session = (req as any).userSession;
  const { type, status, tag, userId } = req.query;

  const targetUserId = session.role === 'admin' && typeof userId === 'string' && userId.trim()
    ? userId.trim()
    : session.userId;

  const txs = storage.getTransactions({
    userId: targetUserId,
    type: type as string,
    status: status as string,
    tag: tag as string,
  }).map(t => ({ ...t, currency: '$', isSandbox: false }));
  res.json({ transactions: txs });
});

// --- EMAIL NOTIFICATIONS (AUTHENTICATED ONLY) ---
app.get('/api/emails', (req, res) => {
  const authHeader = req.headers.authorization;
  const token = authHeader?.startsWith('Bearer ') ? authHeader.substring(7) : (req.headers['x-session-token'] as string);
  const session = getValidSession(token);

  // Unauthenticated requests receive empty array, preventing public notification leak
  if (!session) {
    return res.json({ emails: [] });
  }

  if (session.role === 'admin') {
    return res.json({ emails: storage.getEmails() });
  }
  if (session.role === 'customer') {
    const liveUser = storage.findUserById(session.userId);
    return res.json({ emails: storage.getEmails(liveUser?.email || session.email) });
  }

  res.json({ emails: [] });
});

app.post('/api/emails/:id/read', authMiddleware, async (req, res) => {
  storage.markEmailRead(req.params.id);
  await storage.flush();
  res.json({ success: true });
});

// --- ADMINISTRATOR MANAGEMENT ROUTES ---

// Admin KPI stats
app.get('/api/admin/stats', adminMiddleware, async (req, res) => {
  await storage.refreshFromFirestore(true);
  const users = storage.getUsers().filter(u => u.role !== 'admin');
  const transactions = storage.getTransactions();

  const totalCustomers = users.length;
  const pendingApprovals = users.filter(u => u.status === 'pending_approval').length;
  const activeCustomers = users.filter(u => u.status === 'active').length;
  const frozenCustomers = users.filter(u => u.status === 'frozen').length;
  const suspendedCustomers = users.filter(u => u.status === 'suspended').length;
  const totalBalance = users.reduce((acc, u) => acc + (u.balance || 0), 0);
  const totalVolume = transactions.reduce((acc, t) => acc + t.amount, 0);
  const reversedCount = transactions.filter(t => t.type === 'reversal').length;

  res.json({
    totalCustomers,
    pendingApprovals,
    activeCustomers,
    frozenCustomers,
    suspendedCustomers,
    totalBalance,
    totalVolume,
    reversedCount,
    totalTransactions: transactions.length,
  });
});

// Admin SMTP delivery settings
app.get('/api/admin/smtp-config', adminMiddleware, (req, res) => {
  res.json({ config: emailService.getConfig() });
});

app.post('/api/admin/smtp-config', adminMiddleware, (req, res) => {
  try {
    const { host, port, user, pass, secure, from } = req.body;
    if (!host || !user || !pass) {
      return res.status(400).json({ error: 'SMTP Host, Username, and Password are required.' });
    }
    emailService.configure({
      host: host.trim(),
      port: Number(port) || 587,
      user: user.trim(),
      pass: pass.trim(),
      secure: Boolean(secure),
      from: from?.trim(),
    });
    res.json({ success: true, message: 'SMTP settings updated successfully.', config: emailService.getConfig() });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

// List all customers (returns all safe profile & account fields except passwordHash/salt)
app.get('/api/admin/customers', adminMiddleware, async (req, res) => {
  await storage.refreshFromFirestore(true);
  const users = storage.getUsers()
    .filter(u => u.role !== 'admin')
    .map(sanitizeUser)
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  res.json({ customers: users });
});

// Admin creates/registers a new customer directly
app.post('/api/admin/customers', adminMiddleware, async (req, res) => {
  try {
    await storage.refreshFromFirestore(true);
    const session = (req as any).userSession;
    const {
      firstName,
      middleName,
      lastName,
      email,
      username,
      phone,
      password,
      country,
      residentialAddress,
      dateOfBirth,
      accountNumber,
      status,
      initialBalance,
    } = req.body;

    const newUser = storage.adminCreateCustomer(session.email, {
      firstName,
      middleName,
      lastName,
      email,
      username,
      phone,
      password,
      country,
      residentialAddress,
      dateOfBirth,
      accountNumber,
      status,
      initialBalance: initialBalance !== undefined ? Number(initialBalance) : 0,
    });
    await storage.flush();

    res.json({
      success: true,
      message: `Customer ${newUser.fullName} registered permanently${newUser.accountNumber ? ` with account number ${newUser.accountNumber}` : ''}.`,
      user: sanitizeUser(newUser),
    });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

// Approve customer application (optional custom account number / username / opening credit)
app.post('/api/admin/customers/:id/approve', adminMiddleware, async (req, res) => {
  try {
    await storage.refreshFromFirestore(true);
    const session = (req as any).userSession;
    const parsedInitial = req.body?.initialBalance !== undefined ? parseFloat(req.body.initialBalance) : 0;
    const initialCredit = !isNaN(parsedInitial) && parsedInitial > 0 ? parsedInitial : 0;
    const customAccountNumber = typeof req.body?.accountNumber === 'string' ? req.body.accountNumber : undefined;
    const customUsername = typeof req.body?.username === 'string' ? req.body.username : undefined;

    const user = storage.approveCustomer(session.email, req.params.id, initialCredit, customAccountNumber, customUsername);
    await storage.flush();

    res.json({
      success: true,
      message: `Customer ${user.firstName} ${user.lastName} successfully approved. Account number ${user.accountNumber} assigned.`,
      user: sanitizeUser(user),
    });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

// Reject customer application
app.post('/api/admin/customers/:id/reject', adminMiddleware, async (req, res) => {
  try {
    const session = (req as any).userSession;
    const { reason } = req.body;
    const user = storage.rejectCustomer(session.email, req.params.id, reason);
    await storage.flush();
    res.json({ success: true, message: 'Customer registration rejected.', user: sanitizeUser(user) });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

// Change status (freeze, unfreeze, suspend, reactivate)
app.post('/api/admin/customers/:id/status', adminMiddleware, async (req, res) => {
  try {
    const session = (req as any).userSession;
    const { status } = req.body;
    if (!['active', 'frozen', 'suspended'].includes(status)) {
      return res.status(400).json({ error: 'Status must be active, frozen, or suspended' });
    }
    const user = storage.setCustomerStatus(session.email, req.params.id, status);
    await storage.flush();
    res.json({ success: true, message: `Status updated to ${status}.`, user: sanitizeUser(user) });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

// Edit customer profile (all contact & account details)
app.put('/api/admin/customers/:id/profile', adminMiddleware, async (req, res) => {
  try {
    await storage.refreshFromFirestore(true);
    const session = (req as any).userSession;
    const {
      firstName,
      middleName,
      lastName,
      fullName,
      email,
      phone,
      username,
      accountNumber,
      sortCode,
      country,
      state,
      residentialAddress,
      postalCode,
      dateOfBirth,
      kycStatus,
    } = req.body;
    const user = storage.updateUserProfile(req.params.id, {
      firstName,
      middleName,
      lastName,
      fullName,
      email,
      phone,
      username,
      accountNumber,
      sortCode,
      country,
      state,
      residentialAddress,
      postalCode,
      dateOfBirth,
      kycStatus,
    });
    storage.logAudit(
      session.email,
      'EDIT_CUSTOMER_PROFILE',
      `Updated customer record for ${user.firstName} ${user.lastName} (${user.email}, Account: ${user.accountNumber || 'Not Assigned'})`,
      user.id,
      user.fullName || `${user.firstName} ${user.lastName}`
    );
    await storage.flush();
    res.json({ success: true, user: sanitizeUser(user) });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

// Reset customer password by admin
app.post('/api/admin/customers/:id/reset-password', adminMiddleware, async (req, res) => {
  try {
    const session = (req as any).userSession;
    const { newPassword } = req.body;
    if (!newPassword || String(newPassword).length < 8) {
      return res.status(400).json({ error: 'New temporary password must be at least 8 characters long.' });
    }
    const user = storage.adminResetCustomerPassword(session.email, req.params.id, String(newPassword));
    await storage.flush();
    res.json({
      success: true,
      message: `Password reset for ${user.firstName} ${user.lastName} (${user.username}).`,
      user: sanitizeUser(user),
    });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

// Explicitly authorized delete customer endpoint
app.delete('/api/admin/customers/:id', adminMiddleware, async (req, res) => {
  try {
    const session = (req as any).userSession;
    const confirmDelete = req.body?.confirmDelete || req.headers['x-confirm-delete'];
    if (confirmDelete !== 'DELETE') {
      return res.status(400).json({
        error: 'Explicit deletion authorization required. Send confirmDelete: "DELETE" to permanently delete this customer record.',
      });
    }
    const result = storage.deleteCustomer(session.email, req.params.id);
    await storage.flush();
    res.json({
      success: true,
      message: `Customer ${result.deletedName} (${result.deletedEmail}) has been permanently deleted by authorized administrator.`,
    });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

// Database Backup Snapshots & Export
app.get('/api/admin/backups', adminMiddleware, async (req, res) => {
  await storage.refreshFromFirestore(true);
  res.json({ backups: storage.getBackups() });
});

app.post('/api/admin/backups', adminMiddleware, async (req, res) => {
  try {
    const session = (req as any).userSession;
    const reason = typeof req.body?.reason === 'string' && req.body.reason.trim()
      ? req.body.reason.trim()
      : 'Manual administrator backup';
    const backup = storage.createBackupSnapshot(session.email, reason);
    storage.logAudit(session.email, 'CREATE_BACKUP', `Created persistent database backup snapshot ${backup.id} (${backup.customerCount} customers)`);
    await storage.flush();
    res.json({ success: true, backup });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

app.get('/api/admin/backups/export', adminMiddleware, async (req, res) => {
  await storage.refreshFromFirestore(true);
  const payload = storage.exportSafeBackup();
  res.json(payload);
});

// Authorized Credit / Debit
app.post('/api/admin/accounts/credit-debit', adminMiddleware, async (req, res) => {
  try {
    const session = (req as any).userSession;
    const { customerId, type, amount, description, reference } = req.body;

    if (!customerId || !type || !amount) {
      return res.status(400).json({ error: 'Customer ID, type (credit/debit), and amount are required.' });
    }
    if (!['credit', 'debit'].includes(type)) {
      return res.status(400).json({ error: 'Type must be credit or debit.' });
    }

    const numAmount = parseFloat(amount);
    if (isNaN(numAmount) || numAmount <= 0) {
      return res.status(400).json({ error: 'Amount must be greater than zero.' });
    }

    const tx = storage.adjustCustomerBalance(
      session.email,
      customerId,
      type,
      numAmount,
      description || `Administrative ${type}`,
      reference
    );
    await storage.flush();

    res.json({ success: true, message: `Account successfully ${type === 'credit' ? 'credited' : 'debited'}.`, transaction: tx });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

// Bank-wide Ledger & Transactions
app.get('/api/admin/ledger', adminMiddleware, async (req, res) => {
  await storage.refreshFromFirestore(true);
  const { userId, type, status } = req.query;
  const transactions = storage.getTransactions({
    userId: userId as string,
    type: type as string,
    status: status as string,
  }).map(t => ({ ...t, currency: '$', isSandbox: false }));
  res.json({ ledger: transactions });
});

// Admin Manual Reversal
app.post('/api/admin/transactions/:id/reversal', adminMiddleware, async (req, res) => {
  try {
    const session = (req as any).userSession;
    const reversalTx = storage.executeReversal(req.params.id, `ADMIN (${session.email})`);
    await storage.flush();
    res.json({ success: true, message: 'Transaction reversed and refunded.', transaction: reversalTx });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

// Audit Logs
app.get('/api/admin/audit-logs', adminMiddleware, async (req, res) => {
  await storage.refreshFromFirestore(false);
  const logs = storage.getAuditLogs();
  res.json({ auditLogs: logs });
});

// ================= INVESTMENTS =================
app.get('/api/banking/investment-plans', (req, res) => {
  res.json({ plans: storage.getInvestmentPlans() });
});

app.get('/api/banking/investments', authMiddleware, (req, res) => {
  const session = (req as any).userSession;
  if (session.role === 'admin') {
    res.json({ investments: storage.getInvestments() });
  } else {
    res.json({ investments: storage.getInvestments(session.userId) });
  }
});

app.post('/api/banking/investments', customerOnlyMiddleware, pinEndpointLimiter, async (req, res) => {
  try {
    await storage.refreshFromFirestore(true);
    const session = (req as any).userSession;
    const { planId, amount, durationMonths, userNotes, transactionPin } = req.body;
    if (!planId || !amount || !durationMonths) {
      return res.status(400).json({ error: 'Plan, amount, and duration are required.' });
    }

    storage.verifyTransactionPinForUser(session.userId, transactionPin);

    const inv = storage.createInvestmentRequest(
      session.userId,
      planId,
      parseFloat(amount),
      parseInt(durationMonths, 10),
      userNotes
    );
    await storage.flush();
    res.json({ success: true, message: 'Investment allocation submitted for review.', investment: inv });
  } catch (err: any) {
    await storage.flush();
    return handlePinRouteError(res, err);
  }
});

app.post('/api/admin/investments/:id/status', adminMiddleware, async (req, res) => {
  try {
    const session = (req as any).userSession;
    const { status, adminComments } = req.body;
    const inv = storage.updateInvestmentStatus(session.email, req.params.id, status, adminComments);
    await storage.flush();
    res.json({ success: true, message: `Investment status updated to ${status}.`, investment: inv });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

// ================= KYC VERIFICATION =================
app.get('/api/banking/verifications', authMiddleware, (req, res) => {
  const session = (req as any).userSession;
  if (session.role === 'admin') {
    res.json({ verifications: storage.getVerifications() });
  } else {
    res.json({ verifications: storage.getVerifications(session.userId) });
  }
});

app.post('/api/banking/verifications', authMiddleware, async (req, res) => {
  try {
    const session = (req as any).userSession;
    const {
      fullName,
      dateOfBirth,
      residentialAddress,
      countryOfResidence,
      phone,
      email,
      accountReference,
      idDocumentType,
      idDocumentNumber,
      sampleDocFrontName,
      sampleDocBackName,
      sampleProofOfAddressName,
      additionalComments,
      declarationAccepted,
      consentAccepted
    } = req.body;

    if (!fullName || !dateOfBirth || !residentialAddress || !idDocumentType) {
      return res.status(400).json({ error: 'Full name, date of birth, residential address, and ID document type are required.' });
    }
    if (!declarationAccepted || !consentAccepted) {
      return res.status(400).json({ error: 'You must confirm the legal declarations and compliance consent.' });
    }

    const verification = storage.createVerificationRequest(session.userId, {
      fullName,
      dateOfBirth,
      residentialAddress,
      countryOfResidence: countryOfResidence || 'United Kingdom',
      phone: phone || '',
      email: email || session.email,
      accountReference: accountReference || '1084920194',
      idDocumentType,
      idDocumentNumber,
      sampleDocFrontName: sampleDocFrontName || 'document_front_scan.pdf',
      sampleDocBackName,
      sampleProofOfAddressName: sampleProofOfAddressName || 'proof_of_address.pdf',
      additionalComments,
      declarationAccepted,
      consentAccepted,
    });
    await storage.flush();

    res.json({ success: true, message: 'Identity verification submitted successfully.', verification });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

app.post('/api/admin/verifications/:id/status', adminMiddleware, async (req, res) => {
  try {
    const session = (req as any).userSession;
    const { status, adminComments } = req.body;
    const ver = storage.updateVerificationStatus(session.email, req.params.id, status, adminComments);
    await storage.flush();
    res.json({ success: true, message: `Verification status updated to ${status}.`, verification: ver });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

// ================= CUSTOMER SUPPORT & TICKETS =================
app.get('/api/support/enquiries', async (req, res) => {
  await storage.refreshFromFirestore(false);
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    const token = authHeader.split(' ')[1];
    const session = getValidSession(token);
    if (session && session.role === 'admin') {
      return res.json({ enquiries: storage.getSupportEnquiries() });
    } else if (session) {
      return res.json({ enquiries: storage.getSupportEnquiries(session.userId) });
    }
  }
  res.json({ enquiries: [] });
});

app.post('/api/support/enquiries', async (req, res) => {
  try {
    const { name, email, phone, category, subject, message } = req.body;
    if (!name || !email || !subject || !message) {
      return res.status(400).json({ error: 'Name, email, subject, and message are required.' });
    }

    let userId: string | undefined;
    const authHeader = req.headers.authorization;
    if (authHeader && authHeader.startsWith('Bearer ')) {
      const token = authHeader.split(' ')[1];
      const session = getValidSession(token);
      if (session) userId = session.userId;
    }

    const enquiry = storage.createSupportEnquiry({
      name,
      email,
      phone,
      category: category || 'general',
      subject,
      message,
      userId,
    });
    await storage.flush();

    res.json({ success: true, message: 'Support enquiry submitted. Reference: ' + enquiry.reference, enquiry });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

app.post('/api/admin/support/:id/reply', adminMiddleware, async (req, res) => {
  try {
    const session = (req as any).userSession;
    const { reply, status } = req.body;
    if (!reply) return res.status(400).json({ error: 'Reply message cannot be empty.' });
    const enquiry = storage.replySupportEnquiry(session.email, req.params.id, reply, status);
    await storage.flush();
    res.json({ success: true, message: 'Reply sent.', enquiry });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

// ================= NOTIFICATIONS =================
app.get('/api/banking/notifications', authMiddleware, async (req, res) => {
  await storage.refreshFromFirestore(false);
  const session = (req as any).userSession;
  res.json({ notifications: storage.getNotifications(session.userId) });
});

app.post('/api/banking/notifications/read-all', authMiddleware, async (req, res) => {
  const session = (req as any).userSession;
  const updatedCount = storage.markAllNotificationsRead(session.userId);
  await storage.flush();
  res.json({ success: true, updatedCount });
});

app.post('/api/banking/notifications/:id/read', authMiddleware, async (req, res) => {
  const session = (req as any).userSession;
  storage.markNotificationRead(req.params.id, session.userId);
  await storage.flush();
  res.json({ success: true });
});

app.delete('/api/banking/notifications/:id', authMiddleware, async (req, res) => {
  const session = (req as any).userSession;
  const deleted = storage.deleteNotification(req.params.id, session.userId);
  await storage.flush();
  if (!deleted) {
    return res.status(404).json({ error: 'Notification not found.' });
  }
  res.json({ success: true });
});

// Vite / Static file serving
async function setupViteOrStatic() {
  await storage.ready();

  // Prevent browser caching & bfcache restoration of protected dashboard HTML routes
  app.use((req, res, next) => {
    if (req.method === 'GET' && (req.path === '/dashboard' || req.path.startsWith('/dashboard/') || req.path === '/login')) {
      const noStoreVal = 'no-store, no-cache, must-revalidate, private';
      const origSetHeader = res.setHeader.bind(res);
      res.setHeader = ((name: string, value: any) => {
        if (name.toLowerCase() === 'cache-control') {
          return origSetHeader(name, noStoreVal);
        }
        return origSetHeader(name, value);
      }) as typeof res.setHeader;

      const origWriteHead = res.writeHead.bind(res);
      res.writeHead = ((statusCode: number, ...args: any[]) => {
        const lastArg = args[args.length - 1];
        if (lastArg && typeof lastArg === 'object' && !Array.isArray(lastArg)) {
          for (const k of Object.keys(lastArg)) {
            if (k.toLowerCase() === 'cache-control') {
              lastArg[k] = noStoreVal;
            }
          }
          if (!Object.keys(lastArg).some(k => k.toLowerCase() === 'cache-control')) {
            lastArg['Cache-Control'] = noStoreVal;
          }
        }
        origSetHeader('Cache-Control', noStoreVal);
        origSetHeader('Pragma', 'no-cache');
        origSetHeader('Expires', '0');
        return origWriteHead(statusCode, ...args);
      }) as typeof res.writeHead;

      origSetHeader('Cache-Control', noStoreVal);
      origSetHeader('Pragma', 'no-cache');
      origSetHeader('Expires', '0');
    }
    next();
  });

  if (process.env.NODE_ENV !== 'production') {
    const isHmrDisabled = process.env.DISABLE_HMR === 'true';
    const vite = await createViteServer({
      server: { 
        middlewareMode: true, 
        hmr: isHmrDisabled ? false : true 
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  const server = app.listen(PORT, HOST, () => {
    console.log(`🏦 FNB Online Banking server active on http://${HOST}:${PORT}`);
    console.log(`🛡️ Administrator access: admin@fnnbbankss.online`);
    console.log(`📞 Telephone / WhatsApp: +12724736857 | Email: info@fnnbbankss.online`);
  });

  server.on('error', (err: any) => {
    if (err.code === 'EADDRINUSE') {
      console.warn(`[Server] Port ${PORT} is currently busy, waiting for release...`);
    } else {
      console.error('[Server Error]', err);
    }
  });
}

setupViteOrStatic();
