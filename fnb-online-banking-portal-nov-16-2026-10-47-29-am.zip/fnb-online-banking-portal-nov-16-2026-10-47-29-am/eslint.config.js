import firebaseRulesPlugin from '@firebase/eslint-plugin-security-rules';

export default [
  {
    ignores: ['dist/**/*', 'node_modules/**/*', 'src_backup_*/**/*']
  },
  firebaseRulesPlugin.configs['flat/recommended']
];
